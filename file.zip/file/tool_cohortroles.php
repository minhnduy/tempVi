<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_cohortroles', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_cohortroles
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['acohortroleassignmentssaved']= '{$a} nhiệm vụ nhóm thuần tập đã được lưu.';
$string['assign']= 'Chỉ định';
$string['assignroletocohort']= 'Gán vai trò ngữ cảnh người dùng cho tất cả các thành viên nhóm thuần tập';
$string['backgroundsync']= 'Lưu ý: Nhiệm vụ nhóm thuần tập mới sẽ không có hiệu lực ngay lập tức. Các thay đổi phân công vai trò sẽ được thực hiện bởi một nhiệm vụ đã lên lịch. ';
$string['cohortroleassignmentnotremoved']= 'Nhiệm vụ nhóm thuần tập không bị xóa.';
$string['cohortroleassignmentremoved']= 'Nhiệm vụ nhóm thuần tập đã bị xóa.';
$string['cohortroles']= 'Các vai trò trong nhóm';
$string['existingcohortroles']= 'Chỉ định vai trò nhóm thuần tập hiện có';
$string['managecohortroles']= 'Chỉ định vai trò người dùng cho nhóm thuần tập';
$string['noassignableroles']= 'Hiện tại không có vai trò nào có thể được chỉ định trong bối cảnh người dùng. <a href="../../roles/manage.php"> Quản lý vai trò </a> ';
$string['nocohortroleassignmentssaved']= 'Không có nhiệm vụ nhóm thuần tập nào được lưu.';
$string['onecohortroleassignmentsaved']= 'Một nhiệm vụ nhóm thuần tập đã được lưu.';
$string['pluginname']= 'Quản lý vai trò theo nhóm';
$string['privacy:metadata:tool_cohortroles']= 'Plugin quản lý vai trò nhóm thuần tập lưu trữ ánh xạ vai trò nhóm thuần tập của người dùng.';
$string['privacy:metadata:tool_cohortroles:cohortid']= 'ID của nhóm';
$string['privacy:metadata:tool_cohortroles:id']= 'ID của bản ghi ánh xạ vai trò nhóm thuần tập';
$string['privacy:metadata:tool_cohortroles:roleid']= 'ID của vai trò';
$string['privacy:metadata:tool_cohortroles:timecreated']= 'Thời điểm ánh xạ vai trò nhóm thuần tập được tạo';
$string['privacy:metadata:tool_cohortroles:timemodified']= 'Thời gian ánh xạ vai trò nhóm thuần tập được sửa đổi';
$string['privacy:metadata:tool_cohortroles:userid']= 'ID của người dùng';
$string['privacy:metadata:tool_cohortroles:usermodified']= 'ID của người dùng sửa đổi lần cuối ánh xạ vai trò nhóm thuần tập';
$string['removecohortroleassignment']= 'Bỏ gán vai trò theo nhóm';
$string['removecohortroleassignmentconfirm']= 'Bạn có chắc chắn muốn xóa phân công vai trò thuần tập này không? Vai trò này sẽ bị xóa đối với người dùng này trong tất cả các bối cảnh người dùng khác. ';
$string['selectcohorts']= 'Chọn nhóm thuần tập';
$string['selectrole']= 'Chọn vai trò';
$string['selectusers']= 'Chọn người dùng để chỉ định vai trò';
$string['taskname']= 'Đồng bộ hóa vai trò nhóm thuần tập';
$string['thisuserroles']= 'Các vai trò được chỉ định liên quan đến người dùng này';
