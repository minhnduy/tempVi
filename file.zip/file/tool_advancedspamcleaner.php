<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_advancedspamcleaner', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   tool_advancedspamcleaner
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['akismetkey']= 'Chìa khóa akismet của bạn';
$string['akismetkey_desc']= 'Nhập khóa bạn nhận được từ akismet.com';
$string['alreadyreported']= 'Bạn đã báo cáo nội dung này là spam.';
$string['apilimit']= 'Giới hạn api';
$string['apilimit_help']= 'Số lượng lệnh gọi Api tối đa cần thực hiện. (0 = không giới hạn) ';
$string['blogpost']= 'Bài đăng trên blog';
$string['blogsummary']= 'Tóm tắt blog';
$string['cannotdelete']= 'Không thể xóa nội dung cho người dùng này.';
$string['commment']= 'Bình luận';
$string['confirmdelete']= 'Xóa người gửi thư rác';
$string['confirmdeletemsg']= 'Bạn có chắc chắn muốn đánh dấu <strong> {$a->firstname} {$a->lastname} ({$a->username}) không? Dữ liệu thuộc về người dùng này sẽ bị bỏ trống hoặc bị xóa. ';
$string['confirmspamreportmsg']= 'Bạn có chắc chắn muốn báo cáo nội dung này là spam không?';
$string['countcomment']= 'Bình luận: {$a}';
$string['countforum']= 'Bài viết trên diễn đàn: {$a}';
$string['countmessageread']= 'Đọc tin nhắn: {$a}';
$string['countmessageunread']= 'Tin nhắn chưa đọc: {$a}';
$string['counttags']= 'Các thẻ duy nhất: {$a}';
$string['datelimits']= 'Giới hạn ngày tháng';
$string['deletebutton']= 'Người gửi thư rác Nuke';
$string['enddate']= 'Ngày kết thúc';
$string['forummessage']= 'Tin nhắn diễn đàn';
$string['forumsubject']= 'Chủ đề diễn đàn';
$string['hitlimit']= 'Giới hạn lần truy cập';
$string['hitlimit_help']= 'Dừng lại sau khi phát hiện số lượng mục spam này (0 = không giới hạn)';
$string['keywordstouse']= 'Từ khóa để sử dụng';
$string['limithit']= 'Đã đạt đến giới hạn thiết lập. Kết quả sau đó có thể không đầy đủ .. ';
$string['limits']= 'Giới hạn';
$string['message']= 'Tin nhắn';
$string['messageblocked']= 'Bài đăng của bạn đã bị chặn, vì hệ thống ngăn chặn thư rác của chúng tôi đã gắn cờ nó có thể chứa thư rác. Nếu không đúng như vậy, vui lòng xem \'Bài đăng của tôi đã bị gắn cờ không chính xác là chứa spam \' trong <a href="http://docs.moodle.org/en/Moodle.org_FAQ#My_post_has_been_incorrectly_flagged_as_contain_spam"> http: / /docs.moodle.org/en/Moodle.org_FAQ </a>. Thông báo của bạn ở bên dưới nếu bạn cần sao chép và dán nó. ';
$string['messageblockedtitle']= 'Đã phát hiện thấy thư rác tiềm ẩn!';
$string['messageprovider:spamreport']= 'Báo cáo thư rác';
$string['method']= 'Phương pháp sử dụng';
$string['methodoptions']= 'Tùy chọn phương pháp';
$string['methodused']= 'Phương pháp phát hiện thư rác được sử dụng: {$a}';
$string['missingkeywords']= 'Từ khóa không được để trống';
$string['missingmethod']= 'Phương thức sử dụng không được để trống';
$string['missingscope']= 'Không có phạm vi được chỉ định để tìm kiếm';
$string['noakismetkey']= 'Đặt khóa api từ trang cài đặt trước khi sử dụng tùy chọn này';
$string['notrecentlyaccessed']= 'Hãy coi chừng! Ngày truy cập đầu tiên của tài khoản này là hơn 1 tháng trước. Hãy chắc chắn rằng nó thực sự là một kẻ gửi thư rác. ';
$string['nukeuser']= 'Người dùng Nuke';
$string['pluginname']= 'Trình dọn rác nâng cao';
$string['pluginpage']= 'Trang trình cắm';
$string['pluginsettings']= 'Cài đặt plugin phụ của trình dọn rác nâng cao cho {$a}';
$string['reportasspam']= 'Báo cáo là thư rác';
$string['reportcontentasspam']= 'Báo cáo nội dung là spam';
$string['reportissue']= 'Báo cáo sự cố';
$string['searchblogs']= 'Bao gồm các blog';
$string['searchcomments']= 'Bao gồm các bình luận';
$string['searchforums']= 'Bao gồm các diễn đàn';
$string['searchmsgs']= 'Bao gồm tin nhắn';
$string['searchscope']= 'Phạm vi tìm kiếm thư rác';
$string['searchusers']= 'Bao gồm hồ sơ người dùng';
$string['settingpage']= 'Cài đặt trình dọn rác nâng cao';
$string['showstats']= 'Số lượng mục nhập sau đây đã được kiểm tra xem có spam: <br/> Blog: {$a->blogs}, Hồ sơ người dùng: {$a->users}, Nhận xét: 46b46016-6971-4669-bf6d- b4007cbb4efe,
Tin nhắn: {$a->msgs}, Bài viết trên diễn đàn: {$a->forums} <br/> Thời gian sử dụng là {$a->time} giây khoảng ';
$string['spamauto']= 'Tự động phát hiện thư rác bằng cách sử dụng các từ khóa thư rác phổ biến';
$string['spamcannotdelete']= 'Không thể xóa người dùng này';
$string['spamcannotfinduser']= 'Không có người dùng nào phù hợp với tìm kiếm của bạn';
$string['spamcleanerintro']= 'Tập lệnh này cho phép bạn tìm kiếm tất cả hồ sơ người dùng, nhận xét, bài đăng trên blog, bài đăng trên diễn đàn và tin nhắn cho một số chuỗi nhất định và sau đó xóa những tài khoản rõ ràng là do những kẻ gửi thư rác tạo ra.
Bạn có thể tìm kiếm nhiều từ khóa bằng dấu phẩy (ví dụ: sòng bạc, phim khiêu dâm) hoặc sử dụng hệ thống của bên thứ ba để quét trang web của bạn (ví dụ: Akismet).
Xin lưu ý rằng điều này có thể mất một chút thời gian dựa trên phương pháp tìm kiếm của bạn. Sử dụng các giới hạn để giảm phạm vi tìm kiếm. ';
$string['spamcount']= 'Số lượng thư rác';
$string['spamdeleteall']= 'Xóa tất cả các tài khoản người dùng này';
$string['spamdeleteallconfirm']= 'Bạn có chắc chắn muốn xóa tất cả các tài khoản người dùng này không? Bạn không thể hoàn tác điều này. ';
$string['spamdeleteconfirm']= 'Bạn có chắc chắn muốn xóa mục này không? Bạn không thể hoàn tác điều này. ';
$string['spam_deletion:addinstance']= 'Thêm xóa khối spammer';
$string['spam_deletion:spamdelete']= 'Xóa thư rác';
$string['spam_deletion:viewspamreport']= 'Xem báo cáo spam';
$string['spamdesc']= 'Mô tả';
$string['spamdescription']= 'Spammer - spam bị xóa và tài khoản bị khóa {$a}';
$string['spameg']= 'ví dụ: sòng bạc, khiêu dâm, xxx';
$string['spamfromblog']= 'Từ bài đăng trên blog:';
$string['spamfromcomments']= 'Từ các bình luận:';
$string['spamfromforumpost']= 'Từ bài đăng trên diễn đàn:';
$string['spamfrommessages']= 'Từ tin nhắn:';
$string['spaminvalidresult']= 'Kết quả không xác định nhưng không hợp lệ';
$string['spamoperation']= 'Hoạt động';
$string['spamreportmessage']= '{$a->spammer} có thể là người gửi spam.
Xem báo cáo spam tại {$a->url} ';
$string['spamreportmessagetitle']= '{$a->spammer} có thể là người gửi thư rác.';
$string['spamreports']= 'Báo cáo spam: {$a}';
$string['spamresult']= 'Xin lưu ý xóa người dùng không xóa mục nhập bị spam <be /> Kết quả tìm kiếm hồ sơ người dùng chứa:';
$string['spamsearch']= 'Tìm kiếm thư rác';
$string['spamtext']= 'Thư rác';
$string['spamtype']= 'Loại thư rác';
$string['startdate']= 'Ngày bắt đầu';
$string['thanksspamrecorded']= 'Cảm ơn, báo cáo spam của bạn đã được ghi lại.';
$string['totalcount']= 'Tổng số bản ghi của người dùng này: -';
$string['usedatestartlimit']= 'Giới hạn ngày sử dụng';
$string['usedatestartlimit_help']= 'Chỉ cho phép chạy tìm kiếm thư rác trên các thực thể trong phạm vi ngày đã chọn';
$string['usekeywords']= 'Sử dụng các từ khóa đã nhập';
$string['uselimits']= 'Giới hạn sử dụng';
$string['uselimits_help']= 'Sử dụng giới hạn để giảm sử dụng tài nguyên <br /> (Lưu ý rằng giới hạn không được sử dụng cho các phương pháp phát hiện tự động và từ khóa)';
$string['userdesc']= 'Mô tả người dùng';
