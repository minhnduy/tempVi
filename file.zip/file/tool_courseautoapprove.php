<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_courseautoapprove', language 'en', branch 'MOODLE_36_STABLE'
 *
 * @package   tool_courseautoapprove
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['courseautoapprovetask']= 'Tự động phê duyệt các yêu cầu khóa học';
$string['maxcourses']= 'Các khóa học tự động được phê duyệt tối đa';
$string['maxcourses_desc']= 'Có bao nhiêu khóa học cho mỗi người dùng được tự động phê duyệt. Để tắt tính năng này, hãy đặt số bằng 0. ';
$string['pluginname']= 'Tự động phê duyệt khóa học';
$string['privacy:metadata']= 'Tự động phê duyệt khóa học không lưu trữ bất kỳ dữ liệu cá nhân nào';
$string['reject']= 'Tự động từ chối các khóa học bổ sung';
$string['reject_desc']= 'Đặt giá trị này thành \' Có \'để tự động từ chối các yêu cầu khóa học sau khi đạt đến giới hạn. Nếu không được đặt, các yêu cầu không được phê duyệt tự động, sẽ phải được xử lý thủ công. ';
$string['rejectmsgcount']= 'Bạn đã là giáo viên trong (các) khóa học {$a->currentcourses} và giới hạn đã được đặt thành {$a->maxcourses} (các) khóa học.';
$string['rejectmshshortname']= 'Có một khóa học khác với tên ngắn gọn đó';
