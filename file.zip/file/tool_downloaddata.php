<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_downloaddata', language 'en', branch 'MOODLE_31_STABLE'
 *
 * @package   tool_downloaddata
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['addallfields']= 'Thêm tất cả các trường';
$string['addallroles']= 'Thêm tất cả các vai trò';
$string['addfieldselection']= 'Thêm trường vào vùng chọn';
$string['addroleselection']= 'Thêm vai trò vào lựa chọn';
$string['available']= 'Có sẵn';
$string['cliunknownoption']= 'Tham số tập lệnh cli không xác định';
$string['csvdelimiter']= 'Dấu phân cách CSV';
$string['download']= 'Tải xuống';
$string['downloadcourses']= 'Tải xuống các khóa học';
$string['downloadusersbyrole']= 'Tải xuống người dùng theo vai trò';
$string['emptyfields']= 'Không có trường nào được chỉ định';
$string['emptyoverrides']= 'Không có ghi đè được chỉ định';
$string['emptyroles']= 'Không có vai trò nào được chỉ định';
$string['emptyrolescache']= 'Không có bộ đệm vai trò';
$string['encoding']= 'Mã hóa';
$string['fields']= 'Trường';
$string['fields_help']= 'Chọn các trường để tải xuống. Các trường mặc định nằm trong DOWNLOADDATA_PLUGIN_DIRECTORY / config.php. ';
$string['filenotprepared']= 'Tập tin không được chuẩn bị';
$string['format']= 'Định dạng tệp';
$string['formatcsv']= 'Các giá trị được phân tách bằng dấu phẩy (.csv)';
$string['formatxls']= 'Sổ làm việc Microsoft Excel 2007 (.xls)';
$string['invaliddata']= 'Dữ liệu được chọn không hợp lệ';
$string['invaliddelimiter']= 'Dấu phân cách CSV không hợp lệ';
$string['invalidencoding']= 'Mã hóa không hợp lệ';
$string['invalidfield']= 'Trường không hợp lệ "{$a}"';
$string['invalidformat']= 'Định dạng không hợp lệ';
$string['invalidoverrides']= 'Ghi đè không hợp lệ "{$a}"';
$string['invalidrole']= 'Vai trò không hợp lệ "{$a}"';
$string['noselectedfields']= 'Không có trường nào được chọn';
$string['noselectedroles']= 'Không có vai trò nào được chọn';
$string['overrides']= 'Ghi đè';
$string['overrides_help']= 'Nhập các trường cần ghi đè dưới dạng danh sách các cặp trường = ghi đè được phân tách bằng dấu phẩy.';
$string['pluginname']= 'Tải xuống các khóa học và người dùng theo vai trò';
$string['processstarted']= 'Quá trình đã bắt đầu';
$string['removeallfields']= 'Xóa tất cả các trường';
$string['removeallroles']= 'Xóa tất cả các vai trò';
$string['removefieldselection']= 'Xóa các trường khỏi lựa chọn';
$string['removeroleselection']= 'Xóa vai trò khỏi lựa chọn';
$string['roles']= 'Vai trò';
$string['roles_help']= 'Tải xuống những người dùng có vai trò được chỉ định. Nếu người dùng có nhiều hơn một vai trò, chỉ những vai trò được yêu cầu mới được lưu ';
$string['selected']= 'Đã chọn';
$string['sortbycategorypath']= 'Sắp xếp theo đường dẫn danh mục';
$string['sortbycategorypath_help']= '\' Sắp xếp các khóa học theo thứ tự bảng chữ cái theo đường dẫn danh mục. Hữu ích nếu sử dụng các đường dẫn khác nhau tương tự như \'Năm 1 / Học kỳ 1 \', \'Năm 1 / Học kỳ 2 \', v.v. ';
$string['useoverrides']= 'Ghi đè các trường';
$string['useoverrides_help']= 'Điều này cho phép các trường cụ thể được ghi đè. Các trường sẽ được tạo nếu chúng không phải là một phần của các trường được yêu cầu. Yêu cầu các trường ghi đè được chỉ định trong phần \'Ghi đè \'. ';
