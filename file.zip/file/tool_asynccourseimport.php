<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_asynccourseimport', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   tool_asynccourseimport
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['event_importcourse_error']= 'Không thể nhập khóa học trong quá trình nhập khóa học Async.';
$string['import_footer_count']= '{$a} (các) khóa học được / được lên lịch để nhập';
$string['import_footer_message']= 'Các khóa học của bạn đã được lên lịch để nhập. Bạn cần đợi khi tác vụ được xử lý bởi một cron. ';
$string['pluginname']= 'Nhập khóa học không đồng bộ';
$string['report_errors_header']= '<p> Không thể nhập các khóa học sau: </p>';
$string['report_header']= 'Tác vụ nhập khóa học bạn lập lịch đã hoàn thành. \\ n';
$string['task_complete']= 'Quá trình nhập các khóa học không đồng bộ đã hoàn tất.';
$string['task_incomplete']= 'Không thể hoàn tất quá trình nhập khóa học (Id nhiệm vụ: {$a}).';
