<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_syncgroups', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_syncgroups
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['addingmembers']= 'Thêm thành viên';
$string['done']= 'Đã xong';
$string['error']= 'đã xảy ra lỗi';
$string['groupcreated']= 'Đã tạo nhóm';
$string['groupexists']= 'Nhóm tồn tại';
$string['intro']= 'Với công cụ này, bạn có thể phản chiếu các nhóm và thành viên nhóm từ khóa học này sang các khóa học khác mà bạn có thể chỉnh sửa.';
$string['memberadded']= 'Đã thêm thành viên nhóm (userid: {$a}) (hoặc đã có trong nhóm)';
$string['memberremoved']= 'Đã xóa thành viên nhóm (userid: {$a})';
$string['nogroups']= 'Không có nhóm nào trong khóa học này. Bạn phải tạo một số nhóm trước khi sử dụng công cụ này. ';
$string['pluginname']= 'Đồng bộ hóa nhóm';
$string['removingmembers']= 'Xóa thành viên';
$string['selectgroups']= 'Chọn các nhóm từ khóa học này mà bạn muốn đồng bộ hóa';
$string['sync']= 'Đồng bộ hóa';
$string['syncgroupsto']= 'Chọn các khóa học mục tiêu để đồng bộ hóa các nhóm với nhau';
$string['usernotenrolled']= 'Người dùng chưa đăng ký (userid: {$a})';
