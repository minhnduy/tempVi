<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_userrestore', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_userrestore
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['button:backtocourse']= 'Quay lại khóa học';
$string['button:backtoform']= 'Quay lại biểu mẫu lưu trữ người dùng';
$string['button:userrestore:continue']= 'Khôi phục người dùng';
$string['cache:fill']= 'Nạp đầy bộ nhớ cache';
$string['cache:fillneeded']= 'Bộ nhớ đệm cần thiết để theo dõi thông tin người dùng đã xóa không được lấp đầy. <br/>
Bộ nhớ cache này là cần thiết để tăng tốc độ hiển thị biểu mẫu khôi phục người dùng và tránh hết thời gian chờ. <br/>
Xin lưu ý rằng việc lấp đầy bộ nhớ cache, tùy thuộc vào cấu hình và kích thước cài đặt của bạn có thể là một quá trình <i> rất </i> kéo dài. <br/>
Trên các bản cài đặt lớn, toàn bộ quá trình có thể mất vài phút hoặc lâu hơn để hoàn thành. <br/> <br/>
Khi bộ nhớ đệm đã được lấp đầy, biểu mẫu khôi phục sẽ được tải trong vòng vài giây. <br/> <br/>
Bạn có thể chọn thêm vào bộ nhớ cache hoặc lấp đầy hoàn toàn bộ nhớ cache. <br/>
Sự khác biệt là việc thêm vào bộ nhớ cache sẽ <i> không </i> xóa bộ nhớ cache trước, trong khi việc nạp đầy đủ sẽ xóa bộ nhớ cache. ';
$string['cache:fill:smart']= 'Nối thông tin bị thiếu vào bộ nhớ cache';
$string['cache:iscomplete']= 'Bộ nhớ đệm có tất cả thông tin cần thiết';
$string['cache:purge']= 'Xóa bộ nhớ cache';
$string['config:cleanlogs:disabled']= 'Tự động làm sạch nhật ký bị tắt trong cấu hình chung';
$string['config:tool:disabled']= 'Tiện ích Khôi phục Người dùng bị tắt trong cấu hình công cụ toàn cầu';
$string['deletedby']= 'Bị xóa bởi';
$string['email:user:restore:body']= '<p> Kính gửi {fullname} </p>
<p> Tài khoản của bạn đã được khôi phục </p>
<p> Tuy nhiên, tên người dùng của bạn có thể không được truy xuất chính xác do cách moodle xử lý việc xóa người dùng
và các bản ghi sự kiện đã được làm sạch hay chưa. Tên người dùng của bạn là {username} </p>
<p> Nếu bạn cảm thấy điều này là không mong muốn hoặc có bất kỳ câu hỏi nào,
vui lòng liên hệ {contact} </p>
<p> Bạn có thể sử dụng mật khẩu cũ của mình để đăng nhập vào trang web. <br/>
Nếu không, hãy sử dụng địa chỉ email mà email này đã được gửi đến để yêu cầu đặt lại mật khẩu. <br/>
Vui lòng đăng nhập vào trang web để nhập lại tất cả thông tin của bạn bằng liên kết bên dưới: <br/>
{loginlink} </p>
<p> Trân trọng <br/> {signature} </p> ';
$string['email:user:restore:subject']= 'Tài khoản của bạn đã được khôi phục';
$string['err:statustable:set_sql']= 'set_sql () bị tắt. Bảng này xác định nó là của riêng và không thể tùy chỉnh ';
$string['form:label:email']= 'Nội dung email';
$string['form:label:sendmail']= 'Gửi E-mail';
$string['form:label:subject']= 'Chủ đề email';
$string['form:static:email:template']= 'Bạn có thể sử dụng các chuỗi mẫu sau trong email của mình.
Chúng sẽ tự động được thay thế bằng các biến chính xác. Vui lòng sử dụng chính xác như được chỉ định, nếu không kết quả có thể không như mong đợi.
<ul>
<li> {firstname} - Tên của người dùng được khôi phục </li>
<li> {lastname} - Họ của người dùng được khôi phục </li>
<li> {fullname} - Tên đầy đủ của người dùng được khôi phục </li>
<li> {username} - Tên người dùng của người dùng được khôi phục (điều này CÓ THỂ khác với trước khi tài khoản bị xóa) </li>
<li> {signature} - Chữ ký (tên đầy đủ của người dùng hỗ trợ cho trang moodle) </li>
<li> {contact} - Địa chỉ email liên hệ (dựa trên người dùng hỗ trợ cho trang moodle) </li>
<li> {loginlink} - Liên kết đăng nhập cho trang web (dựa trên tên người dùng đã được khôi phục) </li>
</ul> ';
$string['hasloginfo']= 'Có thông tin nhật ký không?';
$string['label:users:potential']= 'Người dùng tiềm năng';
$string['link:cache']= 'Bộ nhớ đệm';
$string['link:currentstatus:overview']= 'Xem các thay đổi trạng thái hiện tại';
$string['link:log']= 'Khôi phục nhật ký người dùng';
$string['link:log:overview']= 'Xem nhật ký thay đổi trạng thái';
$string['link:restore']= 'Khôi phục người dùng';
$string['link:viewstatus']= 'Xem danh sách trạng thái';
$string['msg:no-users-to-restore']= 'Không có tài khoản người dùng đã xóa nào được tìm thấy để khôi phục.';
$string['page:view:log.php:introduction']= 'Bảng bên dưới hiển thị nhật ký trạng thái mà người dùng đã được khôi phục.';
$string['page:view:restore.php:introduction']= 'Biểu mẫu này cho phép bạn chọn người dùng để khôi phục và tùy chọn gửi cho họ
email về việc tài khoản người dùng của họ đang được khôi phục. Xin lưu ý, trong bảng bên dưới tên người dùng và địa chỉ email đại diện cho bản gốc
thông tin của người dùng được truy xuất từ ​​các bản ghi nhật ký sự kiện. ';
$string['pluginname']= 'Khôi phục người dùng';
$string['privacy:metadata:tool_userrestore_log']= 'Nhật ký lưu trữ người dùng chứa thông tin lịch sử / ghi nhật ký về những người dùng đã được khôi phục';
$string['privacy:metadata:tool_userrestore:mailedto']= 'Địa chỉ e-mail của người dùng được khôi phục';
$string['privacy:metadata:tool_userrestore:mailsent']= 'Email đã được gửi hay chưa';
$string['privacy:metadata:tool_userrestore:restored']= 'Tài khoản có được khôi phục hay không';
$string['privacy:metadata:tool_userrestore_status']= 'Trạng thái lưu trữ người dùng chứa thông tin về người dùng đã được khôi phục';
$string['privacy:metadata:tool_userrestore:timecreated']= 'Thời gian bản ghi được tạo.';
$string['privacy:metadata:tool_userrestore:userid']= 'Khóa chính của người dùng Moodle mà tài khoản đã được khôi phục.';
$string['promo']= 'plugin userrestore cho Moodle';
$string['promodesc']= 'Plugin này được viết bởi Sebsoft Managed Hosting & Software Development
(<a href=\'http://www.sebsoft.nl/\' target=\'_new\'> http://sebsoft.nl </a>). <br /> <br />
{$a} <br /> <br /> ';
$string['restore:deleted-user-not-found']= 'Không thể khôi phục người dùng: không tìm thấy người dùng đã xóa';
$string['restore:email-exists']= 'Không thể khôi phục người dùng: địa chỉ email \' {$a->email} \'đã tồn tại cho một người dùng đang hoạt động khác';
$string['restoresettings']= 'Cài đặt Khôi phục Người dùng';
$string['restoresettingsdesc']= '';
$string['restore:user-mnet-not-local']= 'Không thể khôi phục người dùng: máy chủ mnet để khôi phục người dùng không phải là máy chủ mnet cục bộ đã định cấu hình';
$string['restore:username-exists']= 'Không thể khôi phục người dùng: tên người dùng \' {$a->username} \'đã tồn tại cho một người dùng đang hoạt động khác';
$string['restore:user-restored']= 'Người dùng <i> \' {$a->username} \'</i> (\' {$a->email} \') đã được khôi phục thành công';
$string['setting:cleanlogsafter']= 'Tần suất nhật ký sạch';
$string['setting:desc:cleanlogsafter']= 'Định cấu hình tần suất mà sau đó các bản ghi được làm sạch. Bất kỳ nhật ký nào cũ hơn cài đặt này sẽ bị xóa. ';
$string['setting:desc:enablecleanlogs']= 'Bật hoặc tắt tính năng tự động xóa nhật ký lịch sử.';
$string['setting:desc:maxrestoreusers']= 'Điều này đặt số lượng người dùng tối đa được hiển thị trên biểu mẫu người dùng khôi phục.';
$string['setting:enablecleanlogs']= 'Cho phép dọn dẹp logcleạch';
$string['setting:maxrestoreusers']= 'Người dùng khôi phục tối đa';
$string['table:log:all']= 'Nhật ký khôi phục lịch sử';
$string['table:log:latest']= 'Nhật ký khôi phục mới nhất';
$string['table:logs']= 'Nhật ký';
$string['task:filldeletedcache']= 'Điền vào bộ nhớ cache đã xóa để khôi phục người dùng';
$string['task:logclean']= 'Làm sạch nhật ký để khôi phục người dùng';
$string['th:action']= 'Hành động';
$string['th:mailedto']= 'Đã gửi e-mail tới';
$string['th:mailsent']= 'Đã gửi e-mail';
$string['th:name']= 'Tên';
$string['th:restored']= 'Đã khôi phục';
$string['th:timecreated']= 'Được tạo trên';
$string['th:userid']= 'ID người dùng';
$string['timedeleted']= 'Đã xóa lúc';
