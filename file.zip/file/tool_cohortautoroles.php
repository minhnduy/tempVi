<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_cohortautoroles', language 'en', branch 'MOODLE_31_STABLE'
 *
 * @package   tool_cohortautoroles
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['acohortroleassignmentssaved']= '{$a} nhiệm vụ nhóm thuần tập đã được lưu.';
$string['assign']= 'Chỉ định';
$string['assignroletocohort']= 'Gán vai trò ngữ cảnh người dùng cho tất cả các thành viên nhóm thuần tập';
$string['backgroundsync']= 'Lưu ý: Nhiệm vụ nhóm thuần tập mới sẽ không có hiệu lực ngay lập tức. Các thay đổi phân công vai trò sẽ được thực hiện bởi một nhiệm vụ đã lên lịch. ';
$string['cohortautoroles']= 'Các vai trò trong nhóm';
$string['cohortroleassignmentnotremoved']= 'Nhiệm vụ nhóm thuần tập không bị xóa.';
$string['cohortroleassignmentremoved']= 'Nhiệm vụ nhóm thuần tập đã bị xóa.';
$string['existingcohortautoroles']= 'Chỉ định vai trò nhóm thuần tập hiện có';
$string['managecohortautoroles']= 'Gán vai trò tự động cho nhóm thuần tập';
$string['noassignableroles']= 'Hiện tại không có vai trò nào có thể được chỉ định trong bối cảnh người dùng. <a href="../../roles/manage.php"> Quản lý vai trò </a> ';
$string['nocohortroleassignmentssaved']= 'Không có nhiệm vụ nhóm thuần tập nào được lưu.';
$string['onecohortroleassignmentsaved']= 'Một nhiệm vụ nhóm thuần tập đã được lưu.';
$string['pluginname']= 'Quản lý vai trò tự động theo nhóm';
$string['removecohortroleassignment']= 'Bỏ gán vai trò theo nhóm';
$string['removecohortroleassignmentconfirm']= 'Bạn có chắc chắn muốn xóa phân công vai trò thuần tập này không? Vai trò này sẽ bị xóa đối với người dùng này trong tất cả các bối cảnh người dùng khác. ';
$string['selectcohorts']= 'Chọn nhóm thuần tập';
$string['selectrole']= 'Chọn vai trò để chỉ định ở cấp độ người dùng';
$string['selectsysrole']= 'Chọn vai trò để xác định người cố vấn';
$string['sysrole']= 'Vai trò Hệ thống được sử dụng để xác định người cố vấn';
$string['taskname']= 'Tự động phân công vai trò nhóm thuần tập';
$string['thisuserroles']= 'Các vai trò được chỉ định liên quan đến người dùng này';
