<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'webexactivity', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   webexactivity
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['additionalsettings']= 'Cài đặt cuộc họp bổ sung';
$string['allchat']= 'Người tham gia có thể trò chuyện với những người tham gia khác';
$string['apipassword']= 'Mật khẩu quản trị WebEx';
$string['apipassword_help']= 'Mật khẩu cho tài khoản quản trị trên trang web của bạn.';
$string['apisettings']= 'Cài đặt API';
$string['apiusername']= 'Tên người dùng quản trị WebEx';
$string['apiusername_help']= 'Tên người dùng cho tài khoản quản trị trên trang web của bạn. Đây phải là một tài khoản dành riêng cho Moodle vì lý do bảo mật. ';
$string['availabilityendtime']= 'Thời gian kết thúc khả dụng kéo dài';
$string['badpassword']= 'Tên người dùng và mật khẩu WebEx của bạn không khớp.';
$string['badpasswordexception']= 'Mật khẩu WebEx của bạn không chính xác và không thể cập nhật được.';
$string['calpublish']= 'Xuất bản cuộc họp lên lịch';
$string['calpublish_help']= 'Xuất bản cuộc họp lên lịch Moodle của các khóa học và hiển thị nó trên các trang bảng điều khiển của người dùng. Các cuộc họp Tính sẵn sàng mở rộng sẽ không được công bố. ';
$string['confirmrecordingdelete']= 'Bạn có chắc chắn muốn xóa bản ghi <b> {$a->name} </b>, có độ dài là {$a->time}? Điều này không thể được hoàn tác.';
$string['confirmrecordingsdelete']= 'Bạn có chắc chắn muốn xóa các bản ghi đã chọn không? Điều này không thể được hoàn tác.';
$string['connectionexception']= 'Đã xảy ra lỗi khi cố gắng kết nối: {$a->error}';
$string['curlsetupexception']= 'Đã xảy ra lỗi khi thiết lập curl.';
$string['defaultmeetingtype']= 'Loại cuộc họp mặc định';
$string['defaultmeetingtype_help']= 'Loại cuộc họp sẽ được chọn trước khi tạo cuộc họp mới.';
$string['deletelink']= '<a href="{$a->url}"> Xóa </a>';
$string['deletetime']= 'Thời gian xóa';
$string['deletionin']= '<div> {$a->time} cho đến khi xóa. </div>';
$string['deletionsoon']= '<div> Sẽ sớm bị xóa. </div>';
$string['description']= 'Mô tả';
$string['directlinks']= 'Liên kết trực tiếp';
$string['directlinkstext']= '<p> Các liên kết này cung cấp quyền truy cập trực tiếp vào các bản ghi âm trên máy chủ Moodle. Truy cập vào chúng không yêu cầu đăng nhập và không được đăng nhập. </p> <br />
Truyền trực tuyến: <a target="_blank" href="{$a->streamurl}" alt="Streaming link"> {$a->streamurl} </a> <br />
Load xuống: <a target="_blank" href="{$a->fileurl}" alt="Streaming link"> {$a->fileurl} </a> <br /> ';
$string['duration']= 'Thời lượng dự kiến';
$string['duration_help']= 'Khoảng thời gian dự kiến ​​của cuộc họp. Nó chỉ nhằm mục đích cung cấp thông tin, và không ảnh hưởng đến thời gian cuộc họp có thể diễn ra. ';
$string['enablecallin']= 'Bật cuộc gọi điện thoại';
$string['enablecallin_help']= 'Bật hỗ trợ callin qua điện thoại cho các cuộc họp mới được tạo. Không bật trừ khi bạn có hỗ trợ điện thoại CALLIN. ';
$string['entermeeting']= 'Vào cuộc họp';
$string['error_']= '';
$string['errordeletingrecording']= 'Lỗi khi xóa ghi âm';
$string['error_HM_AccessDenied']= 'Quyền truy cập bị từ chối để tổ chức cuộc họp này.';
$string['error_JM_InvalidMeetingKey']= 'Đã xảy ra lỗi khóa họp trong WebEx và bạn không thể tham gia cuộc họp này.';
$string['error_JM_InvalidMeetingKeyOrPassword']= 'Đã xảy ra lỗi khóa họp hoặc mật khẩu trong WebEx và bạn không thể tham gia cuộc họp này.';
$string['error_JM_MeetingLocked']= 'Cuộc họp này bị khóa và bạn không thể tham gia.';
$string['error_JM_MeetingNotInProgress']= 'Cuộc họp hiện không diễn ra. Nó có thể chưa bắt đầu, hoặc đã kết thúc. ';
$string['error_LI_AccessDenied']= 'Người dùng không thể đăng nhập vào WebEx.';
$string['error_LI_AccountLocked']= 'Tài khoản người dùng WebEx bị khóa.';
$string['error_LI_AutoLoginDisabled']= 'Đăng nhập tự động bị tắt cho người dùng này';
$string['error_LI_InvalidSessionTicket']= 'Phiếu phiên không hợp lệ. Vui lòng thử lại.';
$string['error_LI_InvalidTicket']= 'Phiếu đăng nhập không hợp lệ. Vui lòng thử lại.';
$string['error_unknown']= 'Đã xảy ra lỗi không xác định.';
$string['event_meeting_ended']= 'Cuộc họp đã kết thúc';
$string['event_meeting_hosted']= 'Cuộc họp được tổ chức';
$string['event_meeting_joined']= 'cuộc họp đã tham gia';
$string['event_meeting_started']= 'Cuộc họp đã bắt đầu';
$string['event_recording_created']= 'Bản ghi đã được tạo';
$string['event_recording_deleted']= 'Bản ghi đã bị xóa';
$string['event_recording_downloaded']= 'Bản ghi đã tải xuống';
$string['event_recording_undeleted']= 'Bản ghi không bị xóa';
$string['event_recording_viewed']= 'Bản ghi đã xem';
$string['externallinktext']= '<p> Liên kết này dành cho những người tham gia chưa đăng ký khóa học này. Sinh viên trong khóa học sẽ không cần phải gửi email liên kết này, vì họ có thể chỉ cần nhấp vào liên kết Tham gia cuộc họp trên trang trước. Liên kết này nên được phân phối cẩn thận - bất kỳ ai có liên kết này sẽ có thể truy cập cuộc họp này. Để mời những người khác tham gia cuộc họp, hãy sao chép URL bên dưới và gửi cho họ. Nếu đây là một cuộc họp công khai, liên kết này cũng có thể được đặt trên một trang web. </p> ';
$string['externalpassword']= 'Những người tham gia cũng sẽ cần biết mật khẩu cuộc họp: <b> {$a} </b>';
$string['getexternallink']= '<a href="{$a->url}"> Nhận liên kết của người tham gia bên ngoài </a>';
$string['host']= 'Máy chủ';
$string['hostmeetinglink']= '<a href="{$a->url}"> Người tổ chức cuộc họp </a>';
$string['hostschedulingexception']= 'Người dùng không thể lên lịch họp cho máy chủ lưu trữ này.';
$string['inprogress']= 'Đang tiến hành';
$string['invalidtype']= 'Loại không hợp lệ';
$string['joinmeetinglink']= '<a href="{$a->url}"> Tham gia cuộc họp </a>';
$string['longavailability']= 'Tính khả dụng mở rộng';
$string['longavailability_help']= 'Đặt tùy chọn này sẽ khiến cuộc họp có thể tổ chức cho đến khi kết thúc Thời gian rảnh mở rộng. Cho phép các cuộc họp có thể sử dụng lại cho những việc như giờ hành chính. ';
$string['manageallrecordings']= 'Quản lý tất cả các bản ghi WebEx';
$string['manageallrecordings_help']= 'Quản lý tất cả các bản ghi từ máy chủ WebEx, không chỉ những bản ghi có hoạt động Moodle.';
$string['meetingclosegrace']= 'Thời gian ân hạn đáp ứng';
$string['meetingclosegrace_help']= 'Số phút sau thời gian bắt đầu cộng với khoảng thời gian sau đó cuộc họp sẽ được coi là hoàn thành.';
$string['meetingpassword']= 'Mật khẩu cuộc họp';
$string['meetingpast']= 'Cuộc họp này đã qua.';
$string['meetingsettings']= 'Cài đặt cuộc họp';
$string['meetingtemplate']= 'Mẫu WebEx';
$string['meetingtemplate_help']= 'Tên của mẫu bạn đã thiết lập trên tài khoản WebEx của mình cho loại cuộc họp này. Để trống để sử dụng cài đặt mặc định. Lưu ý: việc chỉ ra tên mẫu không tồn tại sẽ ngăn việc tạo các phiên thuộc loại cuộc họp này. ';
$string['meetingtype']= 'Loại cuộc họp';
$string['meetingtypes']= 'Các loại cuộc họp';
$string['meetingtypes_desc']= 'Đây là các kiểu họp WebEx được hỗ trợ bởi mô-đun này. Đối với mỗi loại, bạn có thể chọn xem nó là "Có sẵn" (bạn có giấy phép cho nó trong WebEx và bạn muốn nó có thể sử dụng từ Moodle) và nếu bạn muốn nó là "Có sẵn cho tất cả người dùng" . Chỉ những người có quyền mod / webexactivity: allavailabletypes mới có thể chọn được các loại "Có sẵn" chứ không phải "Có sẵn cho tất cả người dùng". "Yêu cầu mật khẩu cuộc họp" là cho plugin biết liệu WebEx có yêu cầu mật khẩu hay không. Sử dụng "Tạo mật khẩu bắt buộc" bên dưới để cho phép người dùng không cung cấp mật khẩu. ';
$string['meetingupcoming']= 'Cuộc họp này chưa có sẵn để tham gia.';
$string['modulename']= 'Cuộc họp WebEx';
$string['modulename_help']= 'Hoạt động Cuộc họp WebEx cho phép người hướng dẫn lên lịch cuộc họp vào hệ thống hội nghị trên web WebEx *.
Khi bạn thêm hoạt động Cuộc họp WebEx, bạn xác định ngày và giờ của cuộc họp, cũng như một số thông số tùy chọn khác (chẳng hạn như thời lượng dự kiến, mô tả, v.v.). Sau đó, những người tham gia (sinh viên đã đăng ký) có thể tham gia cuộc họp WebEx bằng cách nhấp vào liên kết "tham gia cuộc họp" trong hoạt động trong Moodle (giáo viên sẽ thấy một liên kết có nội dung "chủ trì cuộc họp"). Nếu cuộc họp được ghi lại, học sinh sẽ có thể xem đoạn ghi âm sau khi cuộc họp kết thúc.
* WebEx là một hệ thống hội nghị trên web cho phép sinh viên và giáo viên cộng tác đồng bộ. Nó truyền âm thanh và video theo thời gian thực và bao gồm các công cụ như bảng trắng, trò chuyện và chia sẻ máy tính để bàn. ';
$string['modulenameplural']= 'Cuộc họp WebEx';
$string['page_managerecordings']= 'Quản lý Bản ghi âm';
$string['page_manageusers']= 'Quản lý người dùng';
$string['pluginadministration']= 'Quản trị cuộc họp WebEx';
$string['pluginname']= 'Cuộc họp WebEx';
$string['pluginnamepural']= 'Cuộc họp WebEx';
$string['prefix']= 'Tiền tố tên người dùng';
$string['prefix_help']= 'Chuỗi này sẽ được đặt trước tất cả các tên người dùng được tạo bởi mô-đun này.';
$string['privacy:metadata:email']= 'Địa chỉ email của người dùng truy cập Webex';
$string['privacy:metadata:firstname']= 'Tên người dùng truy cập Webex';
$string['privacy:metadata:lastname']= 'Họ của người dùng truy cập Webex';
$string['privacy:metadata:timecreated']= 'Thời gian bản ghi được tạo';
$string['privacy:metadata:timemodified']= 'Thời gian bản ghi được sửa đổi trong cơ sở dữ liệu';
$string['privacy:metadata:username']= 'Tên người dùng của người dùng tổ chức cuộc họp.';
$string['privacy:metadata:webexactivity']= 'Phiên bản hoạt động Webex';
$string['privacy:metadata:webexactivity:hostwebexid']= 'Id người dùng Webex của người dùng máy chủ';
$string['privacy:metadata:webexactivity:password']= 'Mật khẩu cuộc họp';
$string['privacy:metadata:webexactivity_recording']= 'Ghi âm Webex';
$string['privacy:metadata:webexactivity_recording:hostid']= 'Tên người dùng máy chủ của bản ghi âm';
$string['privacy:metadata:webexactivity_user']= 'Người dùng máy chủ của Webex';
$string['privacy:metadata:webexactivity_user:webexid']= 'Tên người dùng Webex của người dùng Webex';
$string['privacy:metadata:webexactivity_user:webexuserid']= 'Id người dùng Webex của người dùng Webex';
$string['privacy:metadata:webexhost']= 'Thông tin máy chủ WebEx';
$string['privacy:metadata:webexparticipant']= 'Thông tin người tham gia Webex';
$string['privacy:metadata:webexpassword']= 'Mật khẩu Webex được sử dụng để thương lượng thay mặt người dùng. Chỉ được sử dụng trên các trang web có cài đặt plugin này rất cũ. ';
$string['recordingfileurl']= 'Tải xuống';
$string['recordinglength']= A (1 Y086 AD-81110 -4772 -942F-với cấp 064 Yataba, Al-Sharq-4-0913-411-82 A-4 -329917-Qdah) a;
$string['recordingname']= 'Tên ghi âm';
$string['recordings']= 'Bản ghi âm';
$string['recordingsettings']= 'Cài đặt ghi âm';
$string['recordingstreamurl']= 'Chơi';
$string['recordingtrashtime']= 'Ghi thời gian thùng rác';
$string['recordingtrashtime_help']= 'Số giờ ghi âm sẽ được giữ trước khi bị xóa vĩnh viễn.';
$string['requiremeetingpassword']= 'Yêu cầu mật khẩu cuộc họp';
$string['requiremeetingpassword_help']= 'Yêu cầu người dùng nhập mật khẩu cuộc họp. Nếu không được chọn và loại cuộc họp được đánh dấu là yêu cầu mật khẩu ở trên, mật khẩu sẽ được tạo ngẫu nhiên. ';
$string['search:activity']= 'Cuộc họp WebEx - thông tin hoạt động';
$string['selectnone']= 'Bỏ chọn tất cả';
$string['settings']= 'Cài đặt cuộc họp WebEx';
$string['sitename']= 'Tên trang web';
$string['sitename_help']= 'Phần url trước .webex.com. Nếu url trang web của bạn là "https://example.webex.com", bạn sẽ nhập "ví dụ" ở trên. ';
$string['startssoon']= 'Sắp bắt đầu';
$string['starttime']= 'Thời gian bắt đầu';
$string['stream']= 'Luồng';
$string['studentdownload']= 'Cho phép học sinh tải xuống các bản ghi âm';
$string['studentdownload_help']= 'Cho phép sinh viên truy cập vào liên kết tải xuống các bản ghi âm.';
$string['studentvisible']= 'Hiển thị cho sinh viên';
$string['task_deleterecordings']= 'Xóa các bản ghi đã xóa';
$string['task_updateallrecordings']= 'Cập nhật tất cả các bản ghi âm';
$string['task_updatemediumrecordings']= 'Cập nhật các bản ghi vừa qua';
$string['task_updateopensessions']= 'Cập nhật các phiên đang mở';
$string['task_updaterecentrecordings']= 'Cập nhật các bản ghi gần đây trong quá khứ';
$string['typeforall']= 'Có sẵn cho tất cả người dùng';
$string['typeinstalled']= 'Có sẵn';
$string['typemeetingcenter']= 'Trung tâm Hội nghị';
$string['typemeetingcenter_desc']= '';
$string['typepwreq']= 'Yêu cầu mật khẩu cuộc họp';
$string['typetrainingcenter']= 'Trung tâm đào tạo';
$string['typetrainingcenter_desc']= '';
$string['undeletelink']= '<a href="{$a->url}"> Phục hồi </a>';
$string['unknownhostwebexidexception']= 'ID Máy chủ WebEx không tồn tại';
$string['usereditauto']= 'Người dùng WebEx của bạn được quản lý nội bộ và không thể chỉnh sửa được.';
$string['usereditbad']= 'Bạn không nên đến trang này.';
$string['usereditunabletoload']= 'Không thể tải người dùng của bạn từ WebEx.';
$string['userexistsexplanation']= 'Địa chỉ email của bạn ({$a->email}) đã được Người dùng WebEx <b> {$a->username} </b> sử dụng. Vui lòng nhập mật khẩu WebEx của bạn bên dưới. ';
$string['webexactivity:addinstance']= 'Thêm cuộc họp WebEx mới';
$string['webexactivity:allavailabletypes']= 'Tạo cuộc họp của tất cả các kiểu đã cài đặt';
$string['webexactivity:hostmeeting']= 'Tổ chức và quản lý Cuộc họp WebEx';
$string['webexactivityname']= 'Tên cuộc họp';
$string['webexactivity:reports']= 'Sử dụng báo cáo WebEx';
$string['webexactivity:view']= 'Xem cuộc họp WebEx';
$string['webexid']= 'ID WebEx';
$string['webexrecordings']= 'Bản ghi WebEx';
$string['webexusercollision']= 'Va chạm với người dùng WebEx hiện tại.';
$string['webexxmlexception']= 'Đã xảy ra lỗi trong WebEx khi xử lý XML: {$a->errorcode} {$a->error}';
