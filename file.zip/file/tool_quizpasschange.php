<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_quizpasschange', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   tool_quizpasschange
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['courseselect']= 'Chọn một khóa học';
$string['enable']= 'Bật';
$string['heading']= 'Đổi mật khẩu đố';
$string['passwordtext']= 'Mật khẩu';
$string['pluginname']= 'Đổi mật khẩu đố';
$string['quizpasschangeintro']= 'Tập lệnh này sẽ cập nhật mật khẩu bài kiểm tra theo khóa học.';
$string['submit']= 'Áp dụng mật khẩu';
$string['success']= 'Đã cập nhật mật khẩu cho khóa học';
$string['to']= 'to';
$string['updateblank']= 'Cập nhật mật khẩu trống';
$string['updateblank_help']= 'Bạn có thể muốn tắt tính năng này nếu một số mật khẩu bài kiểm tra để trống. Ngược lại, nếu nó được chọn, TẤT CẢ các mật khẩu bài kiểm tra trong khóa học sẽ được cập nhật, ngay cả khi chúng hiện đang trống. ';
