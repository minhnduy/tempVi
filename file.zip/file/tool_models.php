<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_models', language 'en', branch 'MOODLE_34_STABLE'
 *
 * @package   tool_models
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['accuracy']= 'Độ chính xác';
$string['allpredictions']= 'Tất cả các dự đoán';
$string['analysingsitedata']= 'Phân tích trang web';
$string['analyticmodels']= 'Mô hình phân tích';
$string['bettercli']= 'Đánh giá mô hình và tạo dự đoán có thể đòi hỏi quá trình xử lý nặng. Bạn nên chạy các hành động này thông qua giao diện dòng lệnh ';
$string['cantguessenddate']= 'Không thể đoán ngày kết thúc';
$string['cantguessstartdate']= 'Không thể đoán ngày bắt đầu';
$string['clienablemodel']= 'Bạn có thể kích hoạt mô hình bằng cách chọn phương pháp chia nhỏ thời gian theo id của nó. Lưu ý rằng bạn cũng có thể kích hoạt nó sau này bằng giao diện web (\'none \' để thoát) ';
$string['editmodel']= 'Chỉnh sửa "mô hình {$a}';
$string['edittrainedwarning']= 'Mô hình này đã được đào tạo, lưu ý rằng việc thay đổi các chỉ số hoặc phương pháp phân chia thời gian của nó sẽ xóa các dự đoán trước đó và bắt đầu tạo các dự đoán mới';
$string['enabled']= 'Đã bật';
$string['errorcantenablenotimesplitting']= 'Bạn cần chọn phương pháp chia nhỏ thời gian trước khi bật mô hình';
$string['errornoenabledandtrainedmodels']= 'Không có mô hình được kích hoạt và đào tạo để dự đoán';
$string['errornoenabledmodels']= 'Không có mô hình nào được kích hoạt để đào tạo';
$string['errornostaticedit']= 'Không thể chỉnh sửa mô hình dựa trên giả định';
$string['errornostaticevaluated']= 'Không thể đánh giá các mô hình dựa trên các giả định, chúng luôn đúng 100% theo cách chúng được xác định';
$string['errornostaticlog']= 'Không thể đánh giá mô hình dựa trên các giả định, không có nhật ký hoạt động';
$string['evaluate']= 'Đánh giá';
$string['evaluatemodel']= 'Đánh giá mô hình';
$string['evaluationinbatches']= 'Nội dung trang web được tính toán và lưu trữ theo lô, trong quá trình đánh giá, bạn có thể dừng quá trình bất cứ lúc nào, lần sau khi bạn chạy nó, nó sẽ tiếp tục từ thời điểm bạn dừng nó.';
$string['extrainfo']= 'Thông tin';
$string['generalerror']= 'Lỗi đánh giá. Mã trạng thái {$a} ';
$string['getpredictions']= 'Nhận dự đoán';
$string['getpredictionsresults']= 'Kết quả sử dụng phân tách thời lượng khóa học {$a->name}';
$string['getpredictionsresultscli']= 'Kết quả sử dụng {$a->name} (id: {$a->id}) chia nhỏ thời lượng khóa học';
$string['goodmodel']= 'Đây là một mô hình tốt và nó có thể được sử dụng để dự đoán, cho phép nó bắt đầu nhận các dự đoán.';
$string['indicators']= 'Các chỉ số';
$string['info']= 'Thông tin';
$string['insights']= 'Thông tin chi tiết';
$string['loginfo']= 'Ghi thông tin bổ sung';
$string['modelresults']= '{$a} kết quả';
$string['modelslist']= 'Danh sách kiểu máy';
$string['modeltimesplitting']= 'Tách thời gian';
$string['nodatatoevaluate']= 'Không có dữ liệu để đánh giá mô hình';
$string['nodatatopredict']= 'Không có phần tử mới nào để nhận dự đoán cho';
$string['nodatatotrain']= 'Không có dữ liệu mới nào có thể được sử dụng để đào tạo';
$string['notdefined']= 'Chưa được xác định';
$string['pluginname']= 'Mô hình phân tích';
$string['predictionprocessfinished']= 'Quá trình dự đoán kết thúc';
$string['predictionresults']= 'Kết quả dự đoán';
$string['predictmodels']= 'Dự đoán mô hình';
$string['predictorresultsin']= 'Dự đoán đã ghi thông tin vào thư mục {$a}';
$string['sameenddate']= 'Ngày kết thúc hiện tại là tốt';
$string['samestartdate']= 'Ngày bắt đầu hiện tại là tốt';
$string['target']= 'Mục tiêu';
$string['trainandpredictmodel']= 'Mô hình đào tạo và tính toán dự đoán';
$string['trainingprocessfinished']= 'Quá trình đào tạo đã kết thúc';
$string['trainingresults']= 'Kết quả đào tạo';
$string['trainmodels']= 'Mô hình xe lửa';
$string['viewlog']= 'Nhật ký';
$string['weeksenddateautomaticallyset']= 'Ngày kết thúc tự động được đặt dựa trên ngày bắt đầu và số phần';
$string['weeksenddatedefault']= 'Ngày kết thúc sẽ được tự động tính từ ngày bắt đầu khóa học';
