<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_deletecourses', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_deletecourses
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['deleteallcourses']= 'Xóa tất cả các khóa học';
$string['deleteconfirm']= 'Trang này cho phép bạn xóa tất cả các khóa học trong danh mục <strong> {$a} </strong> và các danh mục phụ của nó. Hành động này không thể được hoàn tác.';
$string['deletecourses:deletecourses']= 'Xóa tất cả các khóa học trong một danh mục.';
$string['deletequeued']= 'Một nhiệm vụ adhoc đã được xếp hàng đợi để xóa tất cả các khóa học trong danh mục <strong> {$a} </strong> và các danh mục phụ. Nó sẽ chạy vào lần tiếp theo cron thực thi. ';
$string['disablerecyclebin']= 'Tắt thùng rác';
$string['pluginname']= 'Xóa các khóa học';
$string['privacy:metadata']= 'Plugin Xóa các khóa học không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['recursive']= 'Đệ quy qua các danh mục con?';
