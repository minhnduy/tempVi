<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'wavefront', language 'en', branch 'MOODLE_34_STABLE'
 *
 * @package   wavefront
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['acceptablefiletypebriefing']= 'Nếu bạn muốn tải lên nhiều tệp cùng một lúc, bạn có thể gửi một tệp zip có hình ảnh bên trong nó và tất cả các hình ảnh hợp lệ trong kho lưu trữ zip sẽ được thêm vào thư viện.';
$string['addcomment']= 'Thêm bình luận';
$string['addmodel']= 'Thêm mô hình';
$string['addmodel_help']= 'Duyệt các tệp mô hình trên máy cục bộ của bạn để thêm vào thư viện hiện tại.
Bạn cũng có thể chọn một kho lưu trữ zip chứa các tệp mô hình, tệp này sẽ được trích xuất vào thư mục mô hình sau khi được tải lên. ';
$string['allowcomments']= 'Cho phép nhận xét';
$string['cameraangle']= 'Góc nhìn';
$string['camerafar']= 'Xa';
$string['cameraheading']= 'Máy ảnh';
$string['camerax']= 'X';
$string['cameray']= 'Y';
$string['cameraz']= 'Z';
$string['commentadded']= 'Bình luận của bạn đã được đăng lên thư viện';
$string['commentcount']= '{$a} bình luận';
$string['commentdelete']= 'Xác nhận xóa bình luận?';
$string['descriptionpos']= 'Vị trí chú thích';
$string['displayingmodel']= 4194 Shack-Daiat-4-medial -8-rắc-fda-fah-hét;
$string['editmodel']= 'Chỉnh sửa mô hình';
$string['errornofile']= 'Không tìm thấy tệp được yêu cầu: {$a}';
$string['errornomodel']= 'Không tìm thấy tệp mô hình nào trong thư viện này';
$string['erroruploadmodel']= 'Các tệp bạn tải lên phải là mô hình Mặt sóng hợp lệ';
$string['eventmodelcommentcreated']= 'Đã tạo bình luận';
$string['eventmodelupdated']= 'Đã cập nhật mô hình mặt sóng';
$string['eventviewed']= 'Đã xem mô hình mặt tiền sóng';
$string['invalidwavefrontid']= 'ID mặt sóng không hợp lệ';
$string['makepublic']= 'Công khai';
$string['modeldescription']= 'Mô tả';
$string['modelfiles']= 'Tải lên các tệp Wavefront';
$string['modelfiles_help']= 'Tải lên tất cả các tệp mô hình riêng lẻ hoặc bạn có thể chọn một kho lưu trữ zip chứa các tệp mô hình, tệp này sẽ được trích xuất vào thư mục mô hình sau khi được tải lên.';
$string['modulename']= 'Trình kết xuất mặt sóng';
$string['modulenameadd']= 'Trình kết xuất mặt sóng';
$string['modulename_help']= 'Mô-đun tài nguyên của Trình kết xuất 3D Wavefront cho phép người tham gia xem mô hình 3D tương thích với định dạng tệp Wavefront .OBJ.
Tài nguyên này cho phép bạn hiển thị hình ảnh \'3D \' trong khóa học Moodle của bạn.
Là một giáo viên của khóa học, bạn có thể thêm và xóa các mô hình.
Nếu được bật, người dùng có thể để lại nhận xét về mô hình của bạn. ';
$string['modulenameplural']= 'Trình kết xuất mặt sóng';
$string['modulenameshort']= 'Mặt sóng';
$string['newmodelcomments']= 'Nhận xét mô hình mới';
$string['nocomments']= 'Không có ý kiến';
$string['pluginadministration']= 'Quản trị Wavefront Renderer';
$string['pluginname']= 'Trình kết xuất mặt sóng';
$string['position_bottom']= 'Dưới cùng';
$string['position_top']= 'Trên cùng';
$string['stageheading']= 'Giai đoạn';
$string['stageheight']= 'Chiều cao';
$string['stagewidth']= 'Chiều rộng';
$string['wavefront:addcomment']= 'Nhận xét về một mô hình';
$string['wavefront:edit']= 'Chỉnh sửa mô hình';
$string['wavefrontrenderer']= 'Trình kết xuất mặt sóng';
$string['wavefront:submit']= 'Gửi một mô hình đến phòng trưng bày';
$string['wavefront:viewcomments']= 'Xem bình luận của bộ sưu tập mô hình';
