<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'virtualclass', language 'en', branch 'MOODLE_30_STABLE'
 *
 * @package   virtualclass
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['anyonepresenter']= 'Bất kỳ ai cũng có thể là người thuyết trình';
$string['anyonepresenter_help']= 'Nếu cho phép bất kỳ ai (kể cả sinh viên) đều có thể là người thuyết trình.';
$string['askplaymsg']= '<span id = "askplaymsg"> "Đang tải xuống, hãy nhấp vào Phát để bắt đầu </span>"';
$string['audio']= 'Âm thanh';
$string['audio_help']= 'Nếu kích hoạt, Theo mặc định, âm thanh của tất cả học sinh sẽ được bật.';
$string['audiotest']= 'Kiểm tra âm thanh';
$string['closebeforeopen']= 'Không thể lưu lớp ảo. Bạn đã chỉ định ngày đóng trước ngày mở. ';
$string['closenotset']= 'Bạn phải chỉ định thời gian đóng cửa.';
$string['closesameopen']= 'Thời gian mở và đóng phiên không được giống nhau';
$string['closetime']= 'Phiên đóng cửa';
$string['configactiontolocalrun']= 'Nếu bạn chọn \' Local \'SSL (https: //) sẽ được yêu cầu để sử dụng Tính năng Chia sẻ Màn hình.';
$string['customsetting']= 'Cài đặt tùy chỉnh';
$string['disableAudio']= 'Tắt âm thanh';
$string['disablespeaker']= 'Tắt tiếng';
$string['downloadsession']= 'Vui lòng đợi trong khi tải xuống bản ghi âm.';
$string['enableAudio']= 'Bật âm thanh';
$string['enablespeaker']= 'Bật âm thanh';
$string['indvprogress']= 'Công việc hiện tại';
$string['joinroom']= 'Tham gia lớp học ảo';
$string['liverun']= 'Trực tuyến - Sử dụng máy chủ vidya.io';
$string['localrun']= 'Cục bộ - Sử dụng tệp Moodle';
$string['modulename']= 'Lớp ảo';
$string['modulename_help']= 'Sử dụng mô-đun lớp ảo để học trực tuyến trong thời gian thực. mô-đun lớp ảo cho phép bạn tham gia vào quá trình học đồng bộ, có nghĩa là giáo viên và học sinh được đăng nhập vào môi trường học tập ảo và tương tác với nhau cùng một lúc.
Mô-đun này cung cấp cho sinh viên các công cụ giao tiếp không đồng bộ, chẳng hạn như bảng trắng và khả năng trò chuyện ';
$string['modulenameplural']= 'Virtualclasss';
$string['notsavekey']= 'Khóa API bị thiếu. Truy cập <a href="{$a}"> trang GetKey </a> để lưu khóa. ';
$string['opentime']= 'Phiên mở cửa';
$string['overallprogress']= 'Tiến độ tổng thể';
$string['play']= 'Chơi';
$string['pluginadministration']= 'Quản trị lớp ảo';
$string['pluginname']= 'Lớp ảo';
$string['pressalways']= 'Nhấn luôn để nói';
$string['pressAlwaysToSpeak']= 'Nhấn luôn để nói.';
$string['pressonce']= 'Nhấn một lần để nói';
$string['pushtotalk']= 'Đẩy để nói chuyện';
$string['pushtotalk_help']= 'Nếu kích hoạt, một tùy chọn bổ sung để hiển thị thử nghiệm âm thanh.';
$string['replay']= 'Chơi lại';
$string['replay_message']= 'Cảm ơn đã xem.';
$string['selectcolor']= 'Chọn màu';
$string['selectcolor_help']= 'Chọn màu của riêng bạn cho lớp học của bạn';
$string['selectteacher']= 'Chọn giáo viên';
$string['selectteacher_help']= 'Chọn giáo viên làm người điều hành cho lớp học ảo';
$string['sessionclosed']= 'Phiên này hiện không có sẵn';
$string['sessionendmsg']= 'Phiên đã bị đóng. Bây giờ bạn có thể đóng trình duyệt của mình. ';
$string['sessionsschedule']= 'Lịch trình cho các phiên họp';
$string['silencedetect']= 'Phát hiện im lặng';
$string['teachername']= 'Giáo viên: {$a->firstname} {$a->lastname}';
$string['totalprogress']= 'Tổng tiến độ';
$string['tpAudioTest']= 'Kiểm tra âm thanh';
$string['uploadedsession']= 'Đã lưu thành công bản ghi.';
$string['uploadrecordedfile']= 'Tải lên tệp đã ghi';
$string['uploadsession']= 'Vui lòng đợi cho đến khi quá trình xử lý hoàn tất.';
$string['virtualclass']= 'Lớp ảo';
$string['virtualclass:addinstance']= 'Thêm một lớp ảo mới';
$string['virtualclass:dorecording']= 'Lưu giải mã';
$string['virtualclassfieldset']= 'Bộ trường mẫu tùy chỉnh';
$string['virtualclassname']= 'Tên lớp ảo';
$string['virtualclassname_help']= 'Đây là phòng học trực tuyến thời gian thực cho phép tương tác tham gia với nhau và cung cấp các công cụ giao tiếp không đồng bộ như bảng trắng, trò chuyện và chia sẻ màn hình.';
$string['virtualclass:recordingdelete']= 'Xóa bản ghi âm';
$string['virtualclass:recordingupload']= 'Tải lên tệp đã ghi';
$string['virtualclasstiming']= 'Định thời lớp ảo: {$a->open} đến {$a->close}';
$string['virtualclass:view']= 'Xem lớp ảo';
$string['waitmsgconnect']= 'Vui lòng đợi một lúc. Ứng dụng đang cố gắng kết nối. ';
$string['wheretorunvirtualclass']= 'Từ đâu để phục vụ Ứng dụng lớp ảo';
