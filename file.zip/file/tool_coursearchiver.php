<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_coursearchiver', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_coursearchiver
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['accessafter']= 'Truy cập lần cuối sau khi';
$string['accessbefore']= 'Truy cập lần cuối trước đây';
$string['accessbeforeafter']= 'Truy cập Trước / Sau';
$string['anycategory']= 'Bất kỳ loại nào';
$string['archive']= 'Kho lưu trữ các khóa học';
$string['archivedeletesetting']= 'Trì hoãn xóa lưu trữ';
$string['archivedeletesetting_help']= 'Việc xóa kho lưu trữ sẽ bị trì hoãn bao nhiêu ngày.';
$string['archiveemail']= 'Gửi "Khóa học được lưu trữ" Email ';
$string['archivelimit']= 'Giới hạn tìm kiếm lưu trữ';
$string['archivelimit_help']= 'Số lượng kết quả tối đa để hiển thị trên màn hình';
$string['archivelimitstring']= 'Hiển thị tối đa';
$string['archivelist']= 'Kho lưu trữ khóa học';
$string['archivelocation']= 'Thư mục con lưu trữ khóa học';
$string['archiverecoverform']= 'Đang chờ xóa';
$string['archivewarningemailsetting']= 'Cảnh báo Email Mặc định về Lưu trữ Khóa học';
$string['archivewarningemailsettingdefault']= '% đến
Chúng tôi muốn thông báo với bạn rằng (các) khóa học Moodle sau đây mà bạn đã giảng dạy sắp được lưu trữ.
Điều này có nghĩa là khóa học sẽ được sao lưu ở trạng thái hiện tại và sau đó bị xóa khỏi Moodle. Nếu bạn muốn chọn không tham gia quá trình này cho một trong các khóa học sau, vui lòng nhấp vào liên kết bên cạnh khóa học.
% khóa học
Cảm ơn bạn.';
$string['archivewarningemailsetting_help']= 'Đây là nội dung của một email sẽ được gửi đến tất cả các giáo viên của một khóa học được chọn để lưu trữ.';
$string['archivewarningsubject']= 'Thông báo: Các khóa học sẽ sớm được lưu trữ.';
$string['back']= 'Bắt ​​đầu lại';
$string['cannotdeletecoursenotexist']= 'Không thể xóa một khóa học không tồn tại';
$string['category']= 'Danh mục';
$string['cli_cannot_continue']= '\\ nSTOPPED: Không đủ dữ liệu để tiếp tục. \\ n';
$string['cli_question_archive']= 'Lưu trữ và xóa các khóa học {$a} này?';
$string['cli_question_archiveemail']= 'Gửi cho những người dùng {$a} này email "Khóa học được lưu trữ"?';
$string['cli_question_delete']= 'Xóa {$a} khóa học này?';
$string['cli_question_hide']= 'Ẩn các khóa học {$a} này?';
$string['cli_question_hideemail']= 'Gửi cho những người dùng {$a} này email "Khóa học cần ẩn"?';
$string['confirm']= 'Tiếp tục';
$string['confirmdelete']= 'Bạn có chắc chắn muốn xóa không?';
$string['confirmmessage']= 'Bạn có chắc chắn muốn {$a}';
$string['confirmmessagearchive']= 'lưu trữ và xóa các khóa học {$a} này?';
$string['confirmmessagearchiveemail']= 'gửi email tới chủ sở hữu khóa học {$a} này?';
$string['confirmmessagedelete']= 'xóa hoàn toàn các khóa học {$a} này?';
$string['confirmmessagehide']= 'ẩn các khóa học {$a} này?';
$string['confirmmessagehideemail']= 'gửi email đến các chủ sở hữu khóa học {$a} này?';
$string['confirmmessageoptout']= 'từ chối các khóa học {$a} này?';
$string['confirmrestore']= 'Khôi phục việc xóa kho lưu trữ đang chờ xử lý?';
$string['coursearchiver']= 'Kho lưu trữ khóa học';
$string['coursearchiver_help']= 'Tìm kiếm các khóa học sử dụng các tiêu chí sau: khớp với tên viết tắt, tên đầy đủ, idnumber, khóa học, ngày truy cập khóa học cuối cùng hoặc * khóa học trống. \\ n
Các khóa học được hiển thị dưới dạng chuyển sang màu xám nếu chúng đã bị ẩn. Tên đầy đủ của khóa học sẽ có một dòng trong đó nếu khóa học là * khóa học trống. \\ n \\ n
LƯU Ý: Tìm kiếm truy cập cuối cùng sẽ chỉ trả về các khóa học đã được tạo trước ngày được cung cấp. \\ n
LƯU Ý: Số lượng địa chỉ email được tìm thấy có thể khác với số lượng email đã gửi. Điều này có 2 nguyên nhân. \\ n
1. Một khóa học đã bị ẩn sẽ không gửi email thông báo cho (các) chủ sở hữu nếu khóa học được chọn là ẩn. \\ n
2. Một địa chỉ hiển thị trong nhiều khóa học sẽ được liên kết thành một email. \\ n \\ n
* các khóa học trống được định nghĩa là 0 bài tập, 0 tài nguyên, 0 hạng mục trong sổ điểm và 0 hạng mục trong sổ điểm. ';
$string['coursearchiverpath']= 'Đường dẫn thư mục để lưu trữ các khóa học đã lưu trữ';
$string['coursearchiverpath_help']= 'Đường dẫn này liên quan đến Moodle $ CFG-> dataroot';
$string['coursearchiverpreview']= 'Tải lên bản xem trước các khóa học';
$string['coursearchiverresult']= 'Tải lên kết quả các khóa học';
$string['coursearchiver_settings']= 'Cài đặt trình lưu trữ khóa học';
$string['coursedeleted']= 'Khóa học đã bị xóa';
$string['coursedeletionnotallowed']= 'Không được phép xóa khóa học';
$string['coursefullname']= 'Tên đầy đủ của khóa học';
$string['courseid']= 'ID khóa học';
$string['courseidnum']= 'Số thứ tự của khóa học';
$string['course_readded']= '{$a->fullname} đã bị xóa khỏi danh sách chọn không tham gia. Cảm ơn bạn.';
$string['courseselector']= 'Kết quả tìm kiếm khóa học';
$string['courseshortname']= 'Tên viết tắt của khóa học';
$string['course_skipped']= '{$a->fullname} sẽ bị bỏ qua cho {$a->optoutmonths} tháng tiếp theo. Cảm ơn bạn.';
$string['courseteacher']= 'Tên người dùng / email của giáo viên';
$string['createdafter']= 'Được tạo sau';
$string['createdbefore']= 'Được tạo trước đây';
$string['createdbeforeafter']= 'Được tạo trước / sau';
$string['crontask']= 'Công việc xóa kho lưu trữ khóa học';
$string['delete']= 'Xóa khóa học';
$string['deletedarchiveemails']= 'Địa chỉ email của giáo viên';
$string['deselectall']= 'Bỏ chọn tất cả';
$string['email']= 'Gửi Email';
$string['emailselector']= 'Người dùng được chọn để nhận email.';
$string['empty']= 'rỗng';
$string['emptycourse']= 'Khóa học trống';
$string['emptyonly']= 'Chỉ trả về các khóa học trống';
$string['endafter']= 'Kết thúc sau';
$string['endbefore']= 'Kết thúc trước';
$string['errorarchivefile']= 'Tệp lưu trữ khóa học không tồn tại.';
$string['errorarchivepath']= 'Không thể tạo đường dẫn lưu trữ.';
$string['errorarchivingcourse']= 'Không thể lưu trữ khóa học: ({$a->id}) {$a->fullname}.';
$string['errorbackup']= 'Sao lưu không thành công.';
$string['errordeletingcourse']= 'Không thể xóa khóa học: ({$a->id}) {$a->fullname}.';
$string['erroremptysearch']= 'Không có tiêu chí tìm kiếm nào được đưa ra.';
$string['errorhidingcourse']= 'Không thể ẩn khóa học: ({$a->id}) {$a->fullname}.';
$string['errorinsufficientdata']= 'Không đủ thông tin để thực hiện hành động này';
$string['error_key']= 'Khóa bảo mật không chính xác.';
$string['errormissingcourses']= 'Biến% khóa học bị thiếu trong mẫu email. Đây là danh sách các khóa học. ';
$string['errormissingto']= 'Biến% thành bị thiếu trong mẫu email. Đây là tên của người nhận. ';
$string['error_nocourseid']= 'Hồ sơ khóa học không chứa ID';
$string['errornoform']= 'Mẫu không được đưa ra.';
$string['errornonnumericid']= 'ID khóa học phải là số';
$string['errornonnumerictimestamp']= 'Dấu thời gian phải là số (dấu thời gian UNIX)';
$string['erroroptoutcourse']= 'Khóa học: ({$a->id}) {$a->fullname} không thể được chọn không tham gia.';
$string['errors']= 'Lỗi';
$string['errors_count']= 'Lỗi: {$a}';
$string['errorsendingemail']= 'Gửi email tới {$a->firstname} {$a->lastname} ({$a->email}) không thành công.';
$string['errorvalidarchive']= 'Không phải là tệp sao lưu hợp lệ.';
$string['hidden']= 'ẩn';
$string['hide']= 'Ẩn các khóa học';
$string['hideemail']= 'Gửi "Khóa học được ẩn" Email ';
$string['hidewarningemailsetting']= 'Cảnh báo Email Mặc định cho việc Ẩn Khóa học';
$string['hidewarningemailsettingdefault']= '% đến
Chúng tôi muốn thông báo cho bạn rằng (các) khóa học Moodle sau đây mà bạn đã dạy sắp bị ẩn.
Điều này có nghĩa là sinh viên vẫn đang đăng ký khóa học sẽ không còn quyền truy cập vào các khóa học. Nếu bạn muốn chọn không tham gia quá trình này cho một trong các khóa học sau, vui lòng nhấp vào liên kết bên cạnh khóa học.
% khóa học
Cảm ơn bạn.';
$string['hidewarningemailsetting_help']= 'Đây là nội dung của một email sẽ được gửi đến tất cả giáo viên của một khóa học được chọn để ẩn.';
$string['hidewarningsubject']= 'Thông báo: Các khóa học sẽ sớm bị ẩn.';
$string['includesubcat']= 'Bao gồm các khóa học trong các danh mục phụ';
$string['invalidmode']= 'Chế độ hợp lệ cho công cụ không được cung cấp.';
$string['messageprovider:courseowner']= 'Thông báo từ công cụ lưu trữ / ẩn khóa học.';
$string['never']= 'Không bao giờ';
$string['nocoursesfound']= 'Việc tìm kiếm đã dẫn đến 0 khóa học được tìm thấy.';
$string['nocoursesselected']= 'Để thực hiện hành động này, bạn phải chọn ít nhất 1 khóa học.';
$string['noticecoursehidden']= 'Khóa học: ({$a->id}) {$a->fullname} đã bị ẩn.';
$string['notices']= 'Thông báo';
$string['notices_count']= 'Thông báo: {$a}';
$string['nousersfound']= 'Không có chủ sở hữu khóa học nào để thông báo';
$string['nousersselected']= 'Để thực hiện hành động này, bạn phải có ít nhất 1 người dùng được chọn.';
$string['optout']= 'Các khóa học Optout';
$string['optoutarchive']= 'Không lưu trữ khóa học này';
$string['optoutby']= 'Được yêu cầu bởi';
$string['optouthide']= 'Không ẩn khóa học này';
$string['optoutleft']= '{$a} ngày còn lại';
$string['optoutlist']= 'Quản lý Danh sách Optout';
$string['optoutmonthssetting']= 'Tính kiên trì chọn không tham gia khóa học';
$string['optoutmonthssetting_help']= 'Việc chọn không tham gia sẽ áp dụng trong bao nhiêu tháng cho mỗi khóa học.';
$string['optouttime']= 'Thời gian còn lại';
$string['outaccess']= 'Lần truy cập cuối cùng';
$string['outemail']= 'Email';
$string['outfirstname']= 'Tên đầu tiên';
$string['outfullname']= 'Họ và tên';
$string['outid']= 'ID';
$string['outidnumber']= 'Idnumber';
$string['outlastname']= 'Họ';
$string['outowners']= 'Chủ sở hữu khóa học';
$string['outselected']= 'Đã chọn';
$string['outshortname']= 'Tên viết tắt';
$string['outuse']= 'Lần sử dụng cuối cùng';
$string['pluginname']= 'Kho lưu trữ khóa học';
$string['privacy:metadata']= 'Plugin không chứa dữ liệu người dùng.';
$string['processarchiving']= 'Lưu trữ các khóa học đã chọn';
$string['processcomplete']= 'Hoàn tất quá trình';
$string['processdeleting']= 'Đang xóa các khóa học đã chọn';
$string['processemailing']= 'Gửi Email';
$string['processhiding']= 'Ẩn các khóa học đã chọn';
$string['processoptout']= 'Bỏ qua các khóa học đã chọn';
$string['processstarted']= 'Quá trình đã được bắt đầu';
$string['recover']= 'Khôi phục các khóa học';
$string['results']= 'Kết quả';
$string['results_archive']= 'Các khóa học đã lưu trữ: {$a}';
$string['results_archiveemail']= 'Email cảnh báo về kho lưu trữ khóa học đã được gửi: {$a}';
$string['results_courselist']= 'Các khóa học được liệt kê: {$a}';
$string['results_delete']= 'Các khóa học đã xóa: {$a}';
$string['results_getemails']= 'Địa chỉ email được thu thập: {$a}';
$string['results_hide']= 'Khóa học ẩn: {$a}';
$string['results_hideemail']= 'Đã gửi email cảnh báo khóa học ẩn: {$a}';
$string['results_optout']= 'Các khóa học optout: {$a}';
$string['resume']= 'Tiếp tục';
$string['resumenone']= 'Không tìm thấy bản lưu nào';
$string['resumeselect']= 'Chọn điểm lưu';
$string['save']= 'Tạo điểm lưu';
$string['saved']= 'Điểm lưu đã được thực hiện';
$string['search']= 'Tìm kiếm các khóa học';
$string['selectall']= 'Chọn tất cả';
$string['startafter']= 'Bắt ​​đầu sau';
$string['startbefore']= 'Bắt ​​đầu trước';
$string['startend']= 'Ngày bắt đầu / kết thúc';
$string['status']= 'Trạng thái';
$string['step2savetitle']= '{$a} lưu danh sách khóa học';
$string['step3savetitle']= '{$a} lưu danh sách email';
$string['unknownerror']= 'Quá trình đã dẫn đến lỗi yêu cầu khởi động lại quá trình.';
$string['visible']= 'hiển thị';
