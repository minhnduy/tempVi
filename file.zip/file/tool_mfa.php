<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_mfa', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_mfa
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['achievedweight']= 'Trọng lượng đã đạt được';
$string['areyousure']= 'Bạn có chắc chắn muốn thu hồi hệ số không?';
$string['combination']= 'Kết hợp';
$string['connector']= 'VÀ';
$string['created']= 'Đã tạo';
$string['createdfromip']= 'Được tạo từ IP';
$string['debugmode:currentweight']= 'Trọng lượng hiện tại: {$a}';
$string['debugmode:heading']= 'Chế độ gỡ lỗi';
$string['devicename']= 'Thiết bị';
$string['email:subject']= 'Không thể đăng nhập vào {$a}';
$string['enablefactor']= 'Yếu tố kích hoạt';
$string['error:actionnotfound']= 'Hành động \' {$a} \'không được hỗ trợ';
$string['error:directaccess']= 'Trang này không nên được truy cập trực tiếp';
$string['error:factornotenabled']= 'Hệ số MFA \' {$a} \'không được kích hoạt';
$string['error:factornotfound']= 'Hệ số MFA \' {$a} \'không tìm thấy';
$string['error:home']= 'Nhấp vào đây để trở về nhà.';
$string['error:notenoughfactors']= 'Không thể xác thực';
$string['error:reauth']= 'Chúng tôi không thể xác nhận đủ danh tính của bạn để đáp ứng chính sách bảo mật xác thực trang web này. Nếu bạn bỏ qua bất kỳ yếu tố nào, bạn có thể thử lại hoặc vui lòng liên hệ với quản trị viên trang web của bạn. ';
$string['error:revoke']= 'Không thể thu hồi hệ số';
$string['error:setupfactor']= 'Không thể thiết lập hệ số';
$string['error:support']= 'Nếu bạn vẫn không thể đăng nhập hoặc tin rằng bạn đang nhìn thấy lỗi này,
vui lòng gửi email đến địa chỉ sau để được hỗ trợ: ';
$string['error:supportpage']= 'Nhấp vào đây để đến trang hỗ trợ chung.';
$string['error:wrongfactorid']= 'Id hệ số \' {$a} \'không chính xác';
$string['event:userpassedmfa']= 'Đã thông qua xác minh';
$string['event:userrevokedfactor']= 'Thu hồi hệ số';
$string['event:usersetupfactor']= 'Thiết lập hệ số';
$string['factor']= 'Hệ số';
$string['factorreport']= 'Báo cáo tất cả các yếu tố';
$string['factorrevoked']= 'Factor \' {$a} \'đã được thu hồi thành công.';
$string['factorsetup']= 'Factor \' {$a} \'thiết lập thành công.';
$string['fallback']= 'Hệ số dự phòng';
$string['fallback_info']= 'Yếu tố này là dự phòng nếu không có yếu tố nào khác được định cấu hình. Yếu tố này sẽ luôn không thành công. ';
$string['gotourl']= 'Chuyển đến URL ban đầu của bạn:';
$string['inputrequired']= 'Đầu vào của người dùng';
$string['lastverified']= 'Xác minh lần cuối';
$string['lockoutnotification']= 'Bạn còn {$a} lần thử xác minh.';
$string['mfa']= 'MFA';
$string['mfa:mfaaccess']= 'Tương tác với MFA';
$string['mfareports']= 'Báo cáo MFA';
$string['mfasettings']= 'Quản lý MFA';
$string['na']= 'n / a';
$string['overall']= 'Tổng thể';
$string['pending']= 'Đang chờ xử lý';
$string['pluginname']= 'Xác thực nhiều yếu tố';
$string['preferences:activefactors']= 'Yếu tố hoạt động';
$string['preferences:availablefactors']= 'Các yếu tố có sẵn';
$string['preferences:header']= 'Tùy chọn xác thực đa yếu tố';
$string['privacy:metadata:tool_mfa']= 'Dữ liệu với các yếu tố MFA được định cấu hình';
$string['privacy:metadata:tool_mfa:createdfromip']= 'IP mà yếu tố được thiết lập từ';
$string['privacy:metadata:tool_mfa:factor']= 'Loại nhân tố';
$string['privacy:metadata:tool_mfa:id']= 'ID bản ghi';
$string['privacy:metadata:tool_mfa:label']= 'nhãn cho trường hợp yếu tố, ví dụ thiết bị hoặc email';
$string['privacy:metadata:tool_mfa:lastverified']= 'Người dùng thời gian được xác minh lần cuối với yếu tố này';
$string['privacy:metadata:tool_mfa:secret']= 'Bất kỳ dữ liệu bí mật nào cho hệ số';
$string['privacy:metadata:tool_mfa:timecreated']= 'Thời gian thiết lập nhân tố';
$string['privacy:metadata:tool_mfa:timemodified']= 'Yếu tố thời gian được sửa đổi lần cuối';
$string['privacy:metadata:tool_mfa:userid']= 'ID của người dùng thuộc về yếu tố đó';
$string['redirecterrordetected']= 'Đã phát hiện chuyển hướng không được hỗ trợ, quá trình thực thi tập lệnh đã chấm dứt. Đã xảy ra lỗi chuyển hướng giữa MFA và {$a}. ';
$string['revoke']= 'Thu hồi';
$string['revokefactor']= 'Thu hồi hệ số';
$string['settings:combinations']= 'Tóm tắt các điều kiện tốt để đăng nhập';
$string['settings:debugmode']= 'Bật chế độ gỡ lỗi';
$string['settings:debugmode_help']= 'Chế độ gỡ lỗi sẽ hiển thị một biểu ngữ thông báo nhỏ trên các trang quản trị MFA, cũng như trang tùy chọn người dùng
với thông tin về các yếu tố hiện được kích hoạt. ';
$string['settings:enabled']= 'Đã bật plugin MFA';
$string['settings:enabled_help']= '';
$string['settings:enablefactor']= 'Yếu tố kích hoạt';
$string['settings:enablefactor_help']= 'Kiểm tra điều khiển này để cho phép yếu tố được sử dụng để xác thực MFA.';
$string['settings:general']= 'Cài đặt MFA chung';
$string['settings:lockout']= 'Ngưỡng khóa';
$string['settings:lockout_help']= 'Số lần người dùng cố gắng trả lời các yếu tố đầu vào trước khi họ không được phép đăng nhập.';
$string['settings:weight']= 'Trọng số hệ số';
$string['settings:weight_help']= 'Trọng số của hệ số này nếu được thông qua. Người dùng cần ít nhất 100 điểm để đăng nhập. ';
$string['setup']= 'Thiết lập';
$string['setupfactor']= 'Yếu tố thiết lập';
$string['setuprequired']= 'Thiết lập người dùng';
$string['state:fail']= 'Không đạt';
$string['state:neutral']= 'Trung lập';
$string['state:pass']= 'Vượt qua';
$string['state:unknown']= 'Không xác định';
$string['totalweight']= 'Tổng trọng lượng';
$string['weight']= 'Trọng lượng';
