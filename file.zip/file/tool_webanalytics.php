<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_webanalytics', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_webanalytics
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['add_tool']= 'Thêm Công cụ Analytics mới';
$string['cachedef_records']= 'Bản ghi Công cụ phân tích trang web';
$string['cleanurl']= 'URL sạch';
$string['cleanurl_help']= 'Tạo URL sạch để theo dõi nâng cao';
$string['create_breadcrumb']= 'Tạo Công cụ Phân tích';
$string['create_heading']= 'Tạo Công cụ Phân tích';
$string['delete_breadcrumb']= 'Xóa Công cụ Phân tích';
$string['delete_confirm']= 'Bạn có chắc chắn muốn xóa Công cụ Analytics có ID {$a} không?';
$string['delete_heading']= 'Xóa Công cụ Phân tích';
$string['edit']= 'Chỉnh sửa';
$string['edit_breadcrumb']= 'Chỉnh sửa công cụ phân tích';
$string['edit_heading']= 'Chỉnh sửa Công cụ Analytics';
$string['enabled']= 'Đã bật';
$string['enabled_help']= 'Bật Analytics cho Moodle';
$string['footer']= 'Chân trang';
$string['head']= 'Tiêu đề';
$string['location']= 'Vị trí mã theo dõi';
$string['location_help']= 'Vị trí trên trang mà bạn muốn đặt mã, đầu trang sẽ mang lại kết quả đáng tin cậy nhất, nhưng chân trang cho hiệu suất tốt nhất. Nếu bạn không nhận được kết quả chính xác trong Google / Piwik, hãy đặt giá trị này thành "Header" ';
$string['manage_heading']= 'Quản lý Công cụ Phân tích';
$string['name']= 'Tên';
$string['name_help']= 'Tên này sẽ giúp bạn xác định Công cụ Analytics này trong danh sách.';
$string['no_analytics']= 'Không tìm thấy Công cụ Phân tích.';
$string['not_enabled']= 'Công cụ Analytics chưa được bật';
$string['not_found']= 'Không tìm thấy Công cụ Analytics';
$string['pluginname']= 'Phân tích trang web';
$string['privacy:metadata']= 'Công cụ Phân tích Trang web không lưu trữ bất kỳ dữ liệu cá nhân nào, tuy nhiên các plugin phụ thực hiện các chính sách bảo mật của riêng chúng.';
$string['subplugintype_watool']= 'Công cụ phân tích trang web';
$string['subplugintype_watool_plural']= 'Công cụ phân tích trang web';
$string['topofbody']= 'Phần trên của cơ thể';
$string['trackadmin']= 'Quản trị viên Theo dõi';
$string['trackadmin_help']= 'Bật theo dõi người dùng Quản trị (không được khuyến nghị)';
$string['type']= 'Công cụ phân tích trang web';
$string['type_help']= 'Chọn loại Phân tích trang web';
$string['view']= 'Xem';
