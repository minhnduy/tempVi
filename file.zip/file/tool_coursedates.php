<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_coursedates', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_coursedates
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['atleastonedate']= 'Bạn phải đặt ít nhất một ngày để cập nhật';
$string['autoenddate']= 'Tính ngày kết thúc?';
$string['autoenddate_default']= 'Không sửa đổi';
$string['autoenddate_help']= 'Moodle có thể tính toán ngày kết thúc dựa trên số phần trong các khóa học sử dụng định dạng chủ đề hàng tuần. Bạn có thể chọn có thực thi điều này ở cấp độ danh mục hay không. ';
$string['autoenddate_off']= 'Tắt ngày kết thúc tự động';
$string['autoenddate_on']= 'Buộc ngày kết thúc tự động';
$string['coursedates:setdates']= 'Đặt ngày bắt đầu / kết thúc của tất cả các khóa học trong một danh mục.';
$string['keependdates']= 'Giữ ngày kết thúc hiện tại';
$string['pluginname']= 'Đặt ngày khóa học';
$string['privacy:metadata']= 'Plugin Đặt ngày khóa học không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['setdates']= 'Đặt ngày khóa học';
$string['setdatesinstruction']= 'Đặt ngày bắt đầu và ngày kết thúc cho tất cả các khóa học trong một danh mục, bao gồm cả các danh mục phụ. Chọn các tùy chọn của bạn và nhấp vào "Xác nhận". Khi xác nhận, Moodle sẽ tạo một "nhiệm vụ adhoc" để đặt tất cả các ngày trong nền. Điều này yêu cầu phải bật cron. ';
$string['updatequeued']= 'Một nhiệm vụ adhoc đã được xếp hàng đợi để cập nhật tất cả các khóa học trong danh mục <strong> {$a} </strong>. Nó sẽ chạy vào lần tiếp theo cron thực thi. ';
