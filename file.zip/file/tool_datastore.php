<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_datastore', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_datastore
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['datastore:uploadcoursecompletion']= 'Tải phần hoàn thành khóa học lên kho dữ liệu';
$string['entitycourse']= 'Kho dữ liệu khóa học';
$string['entityuser']= 'Người dùng lưu trữ dữ liệu';
$string['pluginname']= 'Kho dữ liệu';
$string['privacy:metadata:tool_datastore_action']= 'Thông tin về hành động được lưu trữ';
$string['privacy:metadata:tool_datastore:action']= 'Loại hành động';
$string['privacy:metadata:tool_datastore:actionid']= 'ID của hành động liên quan';
$string['privacy:metadata:tool_datastore_entity']= 'Thông tin về các thực thể liên quan đến mỗi hành động';
$string['privacy:metadata:tool_datastore:entityid']= 'ID của thực thể liên quan';
$string['privacy:metadata:tool_datastore_idx_fields']= 'Thông tin về các trường liên quan đến từng thực thể';
$string['privacy:metadata:tool_datastore:name']= 'Tên trường';
$string['privacy:metadata:tool_datastore:originalcourseid']= 'ID của khóa học mà hành động liên quan đến';
$string['privacy:metadata:tool_datastore:originalid']= 'ID ban đầu của thực thể (như được xác định bởi loại của nó)';
$string['privacy:metadata:tool_datastore:originalprogramid']= 'ID của chương trình mà hành động liên quan đến';
$string['privacy:metadata:tool_datastore:relateduserid']= 'ID của người dùng mà hành động liên quan đến';
$string['privacy:metadata:tool_datastore:tenantid']= 'ID của người thuê mà hành động được thực hiện trong';
$string['privacy:metadata:tool_datastore:timecreated']= 'Thời gian hành động được thực hiện';
$string['privacy:metadata:tool_datastore:type']= 'Loại thực thể';
$string['privacy:metadata:tool_datastore:usermodified']= 'ID của người dùng đã thực hiện hành động';
$string['privacy:metadata:tool_datastore:value']= 'Giá trị trường';
$string['reg_wpdatastorerecords']= 'Số bản ghi trong kho dữ liệu ({$a})';
