<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tutorialbooking', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tutorialbooking
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['addstudents']= 'Thêm người tham gia';
$string['adminlockhelp']= 'Chọn để khóa tất cả các trang đăng ký theo mặc định';
$string['adminlockprompt']= 'Chọn để khóa các trang đăng ký theo mặc định';
$string['adminnumbershelp']= 'Nhập số lượng người tham gia mặc định cho các phiên - có thể được ghi đè khi định cấu hình phiên';
$string['adminnumbersprompt']= 'Chọn số lượng người tham gia mặc định';
$string['adminservicehelp']= 'LƯU Ý: Bật tính năng này có nghĩa là email / thông báo sẽ được gửi đến người tham gia - khi tắt, chỉ quản trị viên chính (id = 2) nhận thông báo';
$string['adminserviceprompt']= 'Đánh dấu trường hợp này là một dịch vụ Moodle trực tiếp';
$string['after']= 'Sau {$a->session}';
$string['ajax_invalid_slots']= 'Các phiên không dành cho đúng trang đăng ký';
$string['ajax_slots_not_exist']= 'Các phiên không tồn tại';
$string['alreadysignedup']= 'Bạn đã đăng ký một phiên.';
$string['attendcoltitle']= 'Điểm danh';
$string['attendees']= 'Người tham gia';
$string['availabletoadd']= 'Có sẵn để thêm';
$string['backtosession']= 'Tin nhắn đã được gửi, nhấp vào đây để quay lại danh sách đăng ký';
$string['cancel']= 'Hủy bỏ';
$string['completionsignedup']= 'Người dùng phải đăng ký một phiên';
$string['completionsignedupgroup']= 'Yêu cầu đăng ký';
$string['confirm']= 'Xác nhận';
$string['confirmmessage']= 'Bạn có chắc chắn muốn xóa {$a->name} khỏi {$a->timeslot} không?';
$string['confirmremovefromslot']= 'Bạn có chắc chắn muốn xóa đăng ký của mình không?';
$string['confirmusersignupremoval']= 'Xác nhận xóa đăng ký';
$string['copysession']= 'Sao chép phiên';
$string['cronfixduplicates']= 'Sửa các đăng ký trùng lặp trong trang đăng ký';
$string['defaultdescription']= 'Phiên {$a}';
$string['deletepageheader']= 'Xác nhận xóa';
$string['deletesession']= 'Xóa';
$string['deletewarningtext']= 'Bạn có chắc chắn muốn xóa "{$a}"';
$string['editsession']= 'Chỉnh sửa';
$string['editsessionheading']= 'Chỉnh sửa phiên hiện có';
$string['editsessionhelp']= 'Để sửa đổi phiên, vui lòng điền vào biểu mẫu bên dưới.';
$string['editspaceserror']= 'LỖI: Bạn không thể giảm số lượng địa điểm ({$a->spaces}) xuống ít hơn số lượng đăng ký ({$a->signedup})';
$string['emailgroupprompt']= 'Gửi email cho người tham gia';
$string['emailpagetitle']= 'Gửi email cho người tham gia';
$string['eventexport']= 'Đã xuất các đăng ký';
$string['eventexportall']= 'Đã xuất tất cả các đăng ký';
$string['eventsessionadded']= 'Đã thêm phiên';
$string['eventsessiondeleted']= 'Phiên đã bị xóa';
$string['eventsessionmessage']= 'Người dùng được nhắn tin trong phiên';
$string['eventsessionupdated']= 'Phiên đã cập nhật';
$string['eventsignupadded']= 'Đăng ký';
$string['eventsignupcapabilityremoved']= 'Khả năng đăng ký bị mất';
$string['eventsignupremoved']= 'Đã xóa đăng ký';
$string['eventsignupteacheradded']= 'Bắt ​​buộc đăng ký';
$string['eventsignupteacherremoved']= 'Đăng ký bị thu hồi';
$string['exportcsvlistallprompt']= 'Xuất đăng ký từ tất cả các trang đăng ký trong khóa học này';
$string['exportlistprompt']= 'Xuất bảng đăng ký';
$string['first']= 'Đầu tiên';
$string['freespaces']= 'Địa điểm miễn phí';
$string['indexnoid']= 'Phải quy định id khóa học để xem tất cả các tờ đăng ký';
$string['instancedesc']= 'Ghi chú trang đăng ký';
$string['instancedeschelp']= 'Thông tin người tham gia cần biết khi đăng ký, chẳng hạn như thời lượng của phiên.';
$string['instanceheading']= 'Cài đặt chung';
$string['instancenamehelp']= 'ví dụ Hướng dẫn 1 hoặc Phòng thí nghiệm máy tính hoặc Hướng dẫn bốn đêm ';
$string['instancetitle']= 'Tiêu đề trang đăng ký';
$string['last']= 'Cuối cùng';
$string['linktomanagetext']= 'Quản lý phiên';
$string['liveservicemsg']= 'Dịch vụ trực tiếp được công nhận, thông báo được gửi đến tất cả những người tham gia';
$string['locked']= 'Mở khóa trang đăng ký';
$string['lockederror']= 'Trang đăng ký bị khóa. Bạn không thể đăng ký vào lúc này. ';
$string['lockedprompt']= 'Đã khóa';
$string['lockhelp']= 'Nếu người dùng bị khóa sẽ không thể thay đổi đăng ký trên trang đăng ký này.
Khóa nó ngay bây giờ sẽ đóng băng hiệu quả các phiên ở trạng thái hiện tại của chúng. ';
$string['lockwarning']= 'Bảng đăng ký này đã bị giáo viên khóa. Bạn không thể sửa đổi đăng ký thành phiên. ';
$string['messageprompt']= 'Tin nhắn';
$string['messageprovider:notify']= 'Thông báo bảng đăng ký';
$string['messagessent']= 'Tin nhắn đã gửi';
$string['messagewillbesent']= 'Thông báo cho người tham gia bị xóa';
$string['moduleadminname']= 'Bảng đăng ký';
$string['modulename']= 'Bảng đăng ký';
$string['modulename_help']= 'Hoạt động trang đăng ký cho phép người dùng đăng ký một phiên duy nhất.
Giáo viên có thể:
* Đặt nếu tên của những người tham gia một phiên được hiển thị cho những người dùng khác.
* In sổ đăng ký của những người tham gia đã đăng ký phiên.
* Tạo tệp csv của các đăng ký.
* Thêm và xóa người tham gia khỏi phiên theo cách thủ công.
* Khóa và mở khóa khả năng đăng ký.
* Gửi tin nhắn đến mọi người đã đăng ký phiên. ';
$string['modulenameplural']= 'Bảng đăng ký';
$string['movedownsession']= 'Di chuyển xuống';
$string['moveslot']= 'Di chuyển phiên {$a}';
$string['moveupsession']= 'Di chuyển lên';
$string['newsessionheading']= 'Phiên mới';
$string['newsessionhelp']= 'Để tạo phiên mới trong bảng đăng ký ở trên, vui lòng điền vào biểu mẫu bên dưới.';
$string['newtimslotprompt']= 'Thêm phiên mới';
$string['nosignup']= 'Bạn chưa đăng ký vào bảng đăng ký.';
$string['noslots']= 'Không có phiên nào cho trang đăng ký này.';
$string['numbersline']= '{$a->total} tổng số địa điểm có sẵn ({$a->taken} đã sử dụng, {$a->left} miễn phí)';
$string['numbersline_oversubscribed']= '{$a->total} tổng số địa điểm có sẵn ({$a->taken} đã được sử dụng, được đăng ký quá mức bởi {$a->left})';
$string['option_spaces_high']= 'Số vị trí phải nhỏ hơn 65536';
$string['option_spaces_low']= 'Số lượng vị trí phải lớn hơn 0';
$string['oversubscribed']= 'Còn {$a->freeslots} địa điểm trên {$a->timeslotname}. Bạn đã cố thêm {$a->numbertoadd} atendee. ';
$string['oversubscribedby']= 'Được đăng ký quá nhiều bởi';
$string['pagecrumb']= 'Phiên';
$string['pagetitle']= 'Bảng đăng ký';
$string['pluginadministration']= 'Bảng đăng ký';
$string['pluginname']= 'Bảng đăng ký';
$string['positionfirst']= 'Đầu trang';
$string['positionlast']= 'Cuối trang';
$string['positionprompt']= 'Chức vụ';
$string['privacy']= 'Quyền riêng tư';
$string['privacy:export:messages']= 'Tin nhắn';
$string['privacy:export:signups']= 'Đăng ký';
$string['privacy:metadata:core_message']= 'Tin nhắn được gửi đến người tham gia qua hệ thống nhắn tin';
$string['privacy:metadata:tutorialbooking_messages']= 'Lưu trữ các tin nhắn được gửi đến người tham gia thông qua plugin trang đăng ký';
$string['privacy:metadata:tutorialbooking_messages:message']= 'Tin nhắn đã được gửi đi';
$string['privacy:metadata:tutorialbooking_messages:sentby']= 'Người dùng đã gửi tin nhắn';
$string['privacy:metadata:tutorialbooking_messages:senttime']= 'Thời gian tin nhắn được gửi đi';
$string['privacy:metadata:tutorialbooking_messages:sentto']= 'Người dùng mà tin nhắn đã được gửi đến';
$string['privacy:metadata:tutorialbooking_messages:subject']= 'Chủ đề của tin nhắn';
$string['privacy:metadata:tutorialbooking_signups']= 'Lưu trữ các đăng ký mà người tham gia đã thực hiện để thực hiện các hoạt động trên trang đăng ký';
$string['privacy:metadata:tutorialbooking_signups:sessionid']= 'Phiên mà người dùng đã đăng ký';
$string['privacy:metadata:tutorialbooking_signups:signupdate']= 'Ngày người dùng đăng ký';
$string['privacy:metadata:tutorialbooking_signups:userid']= 'Người dùng đã đăng ký';
$string['privacy_showall']= 'Người dùng có thể xem tất cả các đăng ký';
$string['privacy_showown']= 'Người dùng chỉ có thể xem đăng ký của họ';
$string['reasonrequired']= 'Bạn phải cung cấp lý do bạn loại bỏ người tham gia.';
$string['registerdateline']= 'Please enter date of session (dd/mm/yy):&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_&nbsp;_&nbsp;&nbsp;_&nbsp;_&nbsp;&nbsp;_&nbsp; _';

$string['registerfooter']= 'Vui lòng ký bên cạnh tên của bạn để cho biết sự tham dự. Nếu tên bạn không có trong danh sách thì hãy làm
không thêm nó mà không hỏi trước. ';
$string['registerprintdate']= 'In đăng ký (bằng cách đăng ký)';
$string['registerprintname']= 'In thanh ghi (theo tên)';
$string['removalmessagesubject']= 'Bạn đã bị xóa khỏi {$a->timeslot}';
$string['removalreason']= 'Lý do loại bỏ';
$string['remove']= 'Xác nhận loại bỏ';
$string['removefromslot']= 'Xóa đăng ký của tôi';
$string['removeuserfromslot']= 'Xóa khỏi phiên này';
$string['reset']= 'Hoàn tác';
$string['save']= 'Lưu';
$string['saveasnew']= 'Lưu dưới dạng phiên mới';
$string['search:activity']= 'Bảng đăng ký - thông tin hoạt động';
$string['search:session']= 'Bảng đăng ký - thông tin phiên';
$string['selectformat']= 'Chọn định dạng xuất';
$string['sendmessage']= 'Gửi tin nhắn';
$string['sentby']= 'Người gửi';
$string['senttime']= 'Đã gửi vào';
$string['sentto']= 'Người nhận';
$string['sessiondescriptionhelp']= 'Ngày, giờ và địa điểm, ví dụ: 10:00 sáng Thứ Năm ngày 14 tháng 8 tại Phòng B35, Trường Kinh doanh hoặc 10:00 sáng Thứ Năm ngày 14 & 21 tháng 8 và ngày 4 tháng 9 tại Phòng B35, Trường Kinh doanh. ';
$string['sessiondescriptionhelp2']= 'Hãy đảm bảo rằng bạn đã bao gồm tên của tòa nhà! <br/>
Những người triệu tập mô-đun phải đảm bảo rằng họ đã đặt phòng! ';
$string['sessiondescriptionprompt']= 'Tiêu đề';
$string['sessionerror']= '{$a}';
$string['sessionfull']= 'Không còn chỗ nào, vui lòng chọn phiên khác.';
$string['sessionpagetitle']= 'Quản lý phiên';
$string['sessionsummaryprompt']= 'Chi tiết';
$string['showallmessages']= 'Hiển thị tất cả các tin nhắn';
$string['showalltutorialbookings']= 'Chỉ mục bảng đăng ký';
$string['showmymessages']= 'Chỉ hiển thị tin nhắn của tôi';
$string['signupforslot']= 'Đăng ký cho tôi phiên này';
$string['signuprequired']= 'Đăng ký vào trang đăng ký';
$string['spacesprompt']= 'Số lượng địa điểm';
$string['statsline']= 'Bảng đăng ký có {$a->places} vị trí, với {$a->signedup} người tham gia';
$string['studentcoltitle']= 'Tên người tham gia';
$string['subjecttitleprompt']= 'Chủ đề';
$string['testservicemsg']= 'Dịch vụ không hoạt động - thông báo được gửi đến Quản trị viên (id = 2)';
$string['thereareno']= 'Không có trang đăng ký nào trong khóa học này';
$string['timeslottitle']= 'Tiêu đề phiên';
$string['totalspaces']= 'Tổng số khoảng trắng';
$string['tutorialbooking']= 'Bảng đăng ký';
$string['tutorialbooking:addinstance']= 'Cho phép người dùng thêm hoạt động này vào khóa học';
$string['tutorialbooking:adduser']= 'Cho phép người dùng thêm người tham gia vào một phiên.';
$string['tutorialbooking:editsignuplist']= 'Cho phép người dùng chỉnh sửa phiên.';
$string['tutorialbooking:export']= 'Cho phép người dùng xuất các đăng ký';
$string['tutorialbooking:exportallcoursetutorials']= 'Bắt ​​buộc phải xuất danh sách cho tất cả các đăng ký trong một khóa học.';
$string['tutorialbooking:message']= 'Cho phép người dùng gửi tin nhắn cho người tham dự thông qua hoạt động trang đăng ký.';
$string['tutorialbooking:oversubscribe']= 'Cho phép người dùng thêm người tham gia vào một phiên ngay cả khi điều này sẽ chiếm vị trí tối đa của phiên.';
$string['tutorialbooking:printregisters']= 'Cho phép người dùng in các đăng ký cho hoạt động.';
$string['tutorialbooking:removeuser']= 'Cho phép người dùng xóa người tham gia khỏi phiên.';
$string['tutorialbooking:submit']= 'Bắt ​​buộc phải đăng ký một phiên.';
$string['tutorialbooking:viewadminpage']= 'Cho phép người dùng xem trang quản trị của hoạt động.';
$string['tutorialbooking:viewallmessages']= 'Được yêu cầu để xem tin nhắn mà người dùng khác đã gửi cho những người tham dự một phiên.';
$string['unauthorised']= 'Bạn không có quyền đăng ký.';
$string['unlocked']= 'Khóa trang đăng ký';
$string['usedspaces']= 'Địa điểm đã sử dụng';
$string['useralreadysignedup']= 'Người dùng {$a->id} đã được đăng ký một phiên.';
$string['userdisplay']= '{$a->name} ({$a->username})';
$string['viewmessages']= 'Xem tin nhắn đã gửi';
$string['you']= 'Bạn';
$string['yousignedup']= 'Bạn đã đăng ký phiên này';
