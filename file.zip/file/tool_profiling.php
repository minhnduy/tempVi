<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_profiling', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_profiling
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['calls']= 'Lệnh gọi hàm';
$string['cannotfindanyrunforrunid']= 'Xin lỗi, không thể tìm thấy \' {$a} \'chạy cấu hình';
$string['cannotfindanyrunforurl']= 'Xin lỗi, không thể tìm thấy bất kỳ cấu hình chạy nào cho \' {$a} \'URL';
$string['comment']= 'Bình luận';
$string['cputime']= 'Thời gian CPU';
$string['differencesbetween2runsof']= 'Sự khác biệt giữa 2 lần chạy {$a}';
$string['executiontime']= 'Thời gian thực hiện';
$string['export']= 'Xuất';
$string['exportproblem']= 'Một số vấn đề đã xảy ra khi xuất cấu hình chạy "{$a->runid}" tương ứng với yêu cầu "{$a->listurl}".';
$string['exportthis']= 'Xuất bản chạy cấu hình này';
$string['import']= 'Nhập';
$string['importok']= 'Tập tin "{$a}" được nhập thành công.';
$string['importprefix']= 'Nhập tiền tố';
$string['importproblem']= 'Đã xảy ra sự cố khi nhập tệp "{$a}".';
$string['lastrunof']= 'Tóm tắt lần chạy cuối cùng của {$a}';
$string['markreferencerun']= 'Đánh dấu là tham chiếu run / comment';
$string['memory']= 'Bộ nhớ được sử dụng';
$string['pluginname']= 'Đang chạy cấu hình';
$string['privacy:metadata']= 'Plugin chạy Profiling không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['profilingfocusscript']= 'Tập trung vào các lần chạy cấu hình cho tập lệnh: {$a}';
$string['profilingruns']= 'Đang chạy cấu hình';
$string['profilingrunsfor']= 'Cấu hình chạy cho {$a}';
$string['referencerun']= 'Tham chiếu run / comment';
$string['runid']= 'Chạy ID';
$string['summaryof']= 'Tóm tắt {$a}';
$string['viewdetails']= 'Xem chi tiết hồ sơ';
$string['viewdiff']= 'Xem sự khác biệt về cấu hình với:';
$string['viewdiffdetails']= 'Xem chi tiết cấu hình khác biệt';
