<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'vitero', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   vitero
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['adminlogin']= 'Đăng nhập vào khu vực quản trị';
$string['adminpassword']= 'Mật khẩu quản trị viên';
$string['adminpassword_desc']= 'Mật khẩu của người dùng trên';
$string['adminusername']= 'Tên người dùng quản trị viên';
$string['adminusername_desc']= 'Tên người dùng Vitero của người dùng có quyền thêm phiên, người dùng, v.v.';
$string['alreadyover']= 'Cuộc hẹn này đã kết thúc.';
$string['appointmentfields']= 'Trường cuộc hẹn';
$string['cannotcreatemeeting']= 'Không thể tạo cuộc họp';
$string['cannotcreateteam']= 'Không thể tạo nhóm';
$string['cannotobtainsessioncode']= 'Không thể lấy mã phiên';
$string['clickhereformeeting']= 'Nhấp vào đây để vào phiên';
$string['connectiontest']= 'Kiểm tra kết nối';
$string['conntest_failed']= 'Kiểm tra kết nối không thành công.';
$string['customerid']= 'ID khách hàng';
$string['customerid_desc']= 'ID của khách hàng trên trong hệ thống Vitero';
$string['customerlicense']= 'Giấy phép Khách hàng';
$string['customerlicense_desc']= 'Giấy phép khách hàng';
$string['customername']= 'Tên khách hàng';
$string['customername_desc']= 'Tên khách hàng';
$string['endbuffer']= 'Bộ đệm kết thúc (phút)';
$string['endtime']= 'Thời gian kết thúc';
$string['errorcode']= 'Mã lỗi Vitero';
$string['errorcode1001']= 'Mã phiên không tồn tại';
$string['errorcode101']= 'Khách hàng không tồn tại trong hệ thống';
$string['errorcode102']= 'Tên viết tắt của một khách hàng mới đã tồn tại';
$string['errorcode103']= 'Người dùng không được gắn với khách hàng';
$string['errorcode151']= 'Nhóm không tồn tại trong hệ thống';
$string['errorcode152']= 'Tên và khách hàng của một nhóm mới đã tồn tại';
$string['errorcode153']= 'Mối quan hệ giữa người dùng và nhóm không tồn tại';
$string['errorcode2']= 'Lỗi không xác định';
$string['errorcode3']= 'Lỗi Nội bộ';
$string['errorcode302']= 'Danh sách-Chỉ mục Không hợp lệ';
$string['errorcode303']= 'Giá trị của thuộc tính không hợp lệ';
$string['errorcode304']= 'Múi giờ không hợp lệ';
$string['errorcode305']= 'Ngôn ngữ không hợp lệ';
$string['errorcode306']= 'Không có mô-đun giám sát';
$string['errorcode4']= 'Không đủ quyền';
$string['errorcode451']= 'Kích thước tệp tin vượt quá tệp bạn cố tải lên quá lớn';
$string['errorcode452']= 'Loại tệp không được phép';
$string['errorcode501']= 'Đặt chỗ va chạm - giấy phép bị vượt quá (đặt chỗ mới va chạm với các đặt chỗ hiện có và giấy phép không cho phép đặt chỗ khác trong khoảng thời gian này)';
$string['errorcode502']= 'Lựa chọn mô-đun không hợp lệ';
$string['errorcode505']= 'Đặt chỗ trước đây bạn đã tạo đặt chỗ trước đây';
$string['errorcode506']= 'Đặt chỗ không tồn tại';
$string['errorcode507']= 'Nhóm bị khóa (sự kiện đang diễn ra), và chỉ có thể gia hạn đặt chỗ cho nhóm này';
$string['errorcode508']= 'Không còn phòng trống';
$string['errorcode51']= 'Người dùng khác có tên này đã tồn tại';
$string['errorcode52']= 'Người dùng khác có email này đã tồn tại';
$string['errorcode53']= 'Người dùng không tồn tại trong hệ thống';
$string['errorcode54']= 'Người dùng phải được gắn với ít nhất một khách hàng';
$string['errorcode601']= 'Không tìm thấy nút';
$string['errorcode703']= 'Khách hàng đã hết hạn';
$string['errorduplicate']= 'Phiên bản Vitero trùng lặp hiện không được hỗ trợ. Vui lòng tạo một phiên mới. ';
$string['greaterstarttime']= 'Thời gian bắt đầu không được lớn hơn thời gian kết thúc';
$string['hostname']= 'Tên máy chủ';
$string['hostname_desc']= 'Tên máy chủ, ví dụ: http://www.example.com';
$string['missingcertificate']= 'Thiếu tệp chứng chỉ: {$a}';
$string['modulename']= 'Vitero';
$string['modulename_help']= 'Sử dụng mô-đun vitero để liên kết Moodle và Vitero.';
$string['modulenameplural']= 'Cuộc hẹn Vitero';
$string['nologinhint']= 'Sau khi ID phiên được tạo, bạn cần lưu hoạt động trước khi có thể đến khu vực quản trị Vitero. Trong khu vực quản trị Vitero, bạn có thể tạo thư mục và tải lên tài liệu.
Sau khi lưu, bạn cần nhấp vào biểu tượng “cập nhật” của hoạt động để di chuyển lại trong hộp thoại cấu hình này. Sau đó, bạn tìm thấy một nút để nhấp vào đây. ';
$string['notstartedyet']= 'Cuộc hẹn này vẫn chưa bắt đầu.';
$string['novmssessioncode']= 'Không thể lấy mã phiên VMS. Vui lòng kiểm tra kết nối ';
$string['paststarttime']= 'Thời gian bắt đầu không được ở hiện tại hoặc quá khứ';
$string['pluginadministration']= 'Quản trị Vitero';
$string['pluginname']= 'Vitero';
$string['port']= 'Cổng';
$string['port_desc']= 'Cổng (tùy chọn)';
$string['privacy:metadata:vitero_remusers']= 'Chi tiết người dùng đã được gửi đến máy chủ Vitero';
$string['privacy:metadata:vitero_remusers:lastemail']= 'Địa chỉ email cuối cùng được gửi đến Vitero';
$string['privacy:metadata:vitero_remusers:lastfirstname']= 'Tên cuối cùng được gửi đến Vitero';
$string['privacy:metadata:vitero_remusers:lastlastname']= 'Họ cuối cùng được gửi đến Vitero';
$string['privacy:metadata:vitero_remusers:timecreated']= 'Thời gian chi tiết người dùng lần đầu tiên được gửi đến Vitero';
$string['privacy:metadata:vitero_remusers:timeupdated']= 'Thời gian chi tiết người dùng được gửi lần cuối đến Vitero';
$string['privacy:metadata:vitero_remusers:userid']= 'ID của người dùng Moodle có thông tin chi tiết đã được gửi đến Vitero';
$string['privacy:metadata:vitero_remusers:viteroid']= 'ID của tài khoản người dùng trên máy chủ Vitero';
$string['roomsize']= 'Kích thước phòng';
$string['root']= 'Gốc Vitero';
$string['root_desc']= 'Đường dẫn gốc của Vitero trong máy chủ (tùy chọn)';
$string['startbuffer']= 'Start Buffer (phút)';
$string['starttime']= 'Thời gian bắt đầu';
$string['syncavatars']= 'Đồng bộ hóa Ảnh đại diện';
$string['syncavatars_desc']= 'Tải ảnh đại diện của người dùng lên Vitero. Sẽ gửi ảnh đại diện của người dùng mỗi khi người dùng xem hoạt động. ';
$string['teamname']= 'Tên nhóm';
$string['testconnection']= 'Kiểm tra kết nối (sau khi lưu)';
$string['vitero']= 'Vitero';
$string['vitero:addinstance']= 'Thêm phiên bản Vitero';
$string['viteroappointment']= 'Cuộc hẹn Vitero';
$string['viterofieldset']= 'Bộ trường mẫu tùy chỉnh';
$string['viteroname']= 'Vitero';
$string['viteroname_help']= 'Đây là nội dung của chú giải công cụ trợ giúp được liên kết với trường viteroname. Cú pháp đánh dấu được hỗ trợ. ';
$string['vitero:participant']= 'Người tham gia Vitero';
$string['vitero:teamleader']= 'Vitero Teamleader';
