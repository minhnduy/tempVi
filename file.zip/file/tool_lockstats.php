<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_lockstats', language 'en', branch 'MOODLE_33_STABLE'
 *
 * @package   tool_lockstats
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['blacklist']= 'Danh sách đen lịch sử';
$string['blacklistdesc']= 'Chúng được xác định bởi classpath của chúng, ví dụ. \\ tool_crawler \\ task \\ crawl_task ';
$string['cleanup']= 'Lịch sử dọn dẹp';
$string['cleanupdesc']= 'Tự động cắt bỏ bảng lịch sử sau giá trị này.';
$string['debug']= 'Gỡ lỗi';
$string['debugdesc']= 'In đầu ra gỡ lỗi hữu ích bổ sung trong cron.log';
$string['form_reset_button']= 'Đặt lại lịch sử khóa';
$string['form_reset_warning']= 'Cảnh báo. Bạn sắp đặt lại lịch sử thống kê khóa. Bạn có chắc chắn muốn làm điều này?';
$string['h1_current']= 'Tác vụ đang chạy hiện tại';
$string['h1_detail']= 'Chi tiết Nhiệm vụ';
$string['h1_history']= 'Các công việc gần đây có thời lượng> {$a} giây';
$string['h1_nexttask']= 'Các tác vụ đang chạy tiếp theo';
$string['pluginname']= 'Khóa thống kê';
$string['reset_header']= 'Đặt lại lịch sử thống kê khóa';
$string['reset_text']= 'Đặt lại lịch sử thống kê khóa.';
$string['table_duration']= 'Thời lượng Trung bình';
$string['table_gained']= 'Thời gian đã đạt được';
$string['table_host']= 'Máy chủ cuối cùng';
$string['table_lockcount']= 'Đếm';
$string['table_pid']= 'PID';
$string['table_released']= 'Thời gian giải phóng';
$string['table_resource']= 'Tài nguyên';
$string['table_task']= 'Công việc';
$string['task_cleanup']= 'Dọn dẹp lịch sử ổ khóa';
$string['threshold']= 'Ngưỡng lịch sử';
$string['thresholddesc']= 'Chỉ ghi lại các mục lịch sử mới khi thời gian tác vụ cron vượt quá giá trị này.';
