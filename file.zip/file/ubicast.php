<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'ubicast', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   ubicast
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['form_resource']= 'ID tài nguyên';
$string['form_resource_header']= 'Tài nguyên';
$string['form_resource_help']= 'Chọn tài nguyên từ MediaServer. Bạn cũng có thể sao chép-dán ID tài nguyên theo cách thủ công (ví dụ: "v124cbdfb0e5c9e28a30"). ';
$string['language_code']= 'vi';
$string['modulename']= 'Tài nguyên MediaServer';
$string['modulename_help']= 'Mô-đun UbiCast MediaServer cho phép giáo viên cung cấp kênh hoặc phương tiện từ web TV MediaServer làm tài nguyên khóa học.';
$string['modulename_link']= 'mod / ubicast / view';
$string['modulenameplural']= 'Tài nguyên MediaServer';
$string['pluginadministration']= 'Quản trị mô-đun UbiCast MediaServer';
$string['pluginname']= 'Plugin UbiCast MediaServer';
$string['privacy:metadata']= 'Mô-đun UbiCast MediaServer chỉ lưu trữ các liên kết đến phương tiện từ MediaServer.';
$string['settings_ltikey']= 'Khóa LTI của MediaServer';
$string['settings_ltikey_help']= 'Nhập khóa MediaServer LTI. Khóa LTI trông giống như "xmz9GgcutbUvwDFNBzHMryMmzyX7wy". ';
$string['settings_ltisecret']= 'Bí mật LTI của MediaServer';
$string['settings_ltisecret_help']= 'Nhập bí mật MediaServer LTI. Bí mật LTI trông giống như "4fCQKsxQwFSxCCvdd4Dq9cxNbhZK4afPBpY312wq1mASGkAgC9qy8n9QEPq8". ';
$string['settings_speakerfilter']= 'Chỉ hiển thị phương tiện của người dùng được lựa chọn';
$string['settings_speakerfilter_help']= 'Khi chọn phương tiện để nhúng, chỉ hiển thị phương tiện mà người dùng được đặt làm diễn giả. Cài đặt này bị bỏ qua nếu MediaServer đang sử dụng phiên bản thấp hơn hoặc bằng 8.3.0. ';
$string['settings_url']= 'URL cơ sở MediaServer';
$string['settings_url_help']= 'Nhập URL cơ sở MediaServer. Ví dụ: "https://mediaserver.ubicast.tv". ';
$string['ubicast:addinstance']= 'Thêm tài nguyên MediaServer mới';
$string['ubicast:view']= 'Xem tài nguyên MediaServer';
