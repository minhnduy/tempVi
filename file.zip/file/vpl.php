<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'vpl', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   vpl
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['about']= 'Giới thiệu';
$string['acceptcertificates']= 'Chấp nhận chứng chỉ tự ký';
$string['acceptcertificates_description']= 'Nếu máy chủ thực thi không sử dụng chứng chỉ tự ký, hãy bỏ chọn tùy chọn này';
$string['acceptcertificatesnote']= '<p> Bạn đang sử dụng kết nối được mã hóa. <p />
<p> Để sử dụng kết nối được mã hóa với các máy chủ thực thi, bạn phải chấp nhận các chứng chỉ của nó. </p>
<p> Nếu bạn gặp sự cố với quy trình này, bạn có thể thử sử dụng kết nối http (không được mã hóa) hoặc trình duyệt khác. </p>
<p> Vui lòng nhấp vào các liên kết sau (máy chủ #) và chấp nhận chứng chỉ được cung cấp. </p> ';
$string['addfile']= 'Thêm tệp';
$string['advanced']= 'Nâng cao';
$string['allfiles']= 'Tất cả các tệp';
$string['allsubmissions']= 'Tất cả các bài gửi';
$string['always_use_ws']= 'Luôn sử dụng giao thức websocket (ws) không được mã hóa';
$string['always_use_wss']= 'Luôn sử dụng giao thức websocket được mã hóa (wss)';
$string['anyfile']= 'Bất kỳ tệp nào';
$string['attemptnumber']= 'Cố gắng số {$a}';
$string['autodetect']= 'Tự động phát hiện';
$string['automaticevaluation']= 'Đánh giá tự động';
$string['automaticgrading']= 'Điểm tự động';
$string['averageperiods']= 'Giai đoạn trung bình {$a}';
$string['averagetime']= 'Thời gian trung bình {$a}';
$string['basedon']= 'Dựa trên';
$string['basic']= 'Cơ bản';
$string['binaryfile']= 'Tệp nhị phân';
$string['browserupdate']= 'Vui lòng cập nhật trình duyệt của bạn lên phiên bản mới nhất <br /> hoặc sử dụng trình duyệt khác hỗ trợ Websocket.';
$string['calculate']= 'Tính toán';
$string['changesNotSaved']= 'Các thay đổi chưa được lưu';
$string['check_jail_servers']= 'Kiểm tra máy chủ thực thi';
$string['check_jail_servers_help']= '<p> Trang này kiểm tra và hiển thị trạng thái của các máy chủ thực thi được sử dụng
cho hoạt động này. </p> ';
$string['clipboard']= 'Bảng tạm';
$string['closed']= 'Đã đóng cửa';
$string['comments']= 'Nhận xét';
$string['compilation']= 'Biên dịch';
$string['connected']= 'được kết nối';
$string['connecting']= 'kết nối';
$string['connection_closed']= 'kết nối đã đóng';
$string['connection_fail']= 'kết nối không thành công';
$string['console']= 'Bảng điều khiển';
$string['copy']= 'Sao chép';
$string['create_new_file']= 'Tạo một tệp mới';
$string['crontask']= 'Hiển thị các hoạt động VPL đạt đến thời điểm "Có sẵn từ" ';
$string['currentstatus']= 'Tình trạng hiện tại';
$string['cut']= 'Cắt';
$string['datesubmitted']= 'Ngày gửi';
$string['debug']= 'Gỡ lỗi';
$string['debugging']= 'Gỡ lỗi';
$string['debugscript']= 'Tập lệnh gỡ lỗi';
$string['debugscript_help']= 'Chọn tập lệnh gỡ lỗi để sử dụng trong hoạt động này';
$string['defaultexefilesize']= 'Kích thước tệp thực thi mặc định tối đa';
$string['defaultexememory']= 'Bộ nhớ mặc định tối đa được sử dụng';
$string['defaultexeprocesses']= 'Số lượng quy trình mặc định tối đa';
$string['defaultexetime']= 'Thời gian thực thi mặc định tối đa';
$string['defaultfilesize']= 'Kích thước tệp tải lên tối đa mặc định';
$string['defaultresourcelimits']= 'Giới hạn tài nguyên thực thi mặc định';
$string['delete']= 'Xóa';
$string['deleteallsubmissions']= 'Xóa tất cả các bài gửi';
$string['delete_file_fq']= 'xóa \' {\\$a} \'tệp?';
$string['delete_file_q']= 'Xóa tệp?';
$string['depends_on_https']= 'Sử dụng ws hoặc wss tùy thuộc vào việc sử dụng http hay https';
$string['description']= 'Mô tả';
$string['diff']= 'khác biệt';
$string['discard_submission_period']= 'Bỏ khoảng thời gian gửi';
$string['discard_submission_period_description']= 'Đối với mỗi học sinh và bài tập, hệ thống sẽ cố gắng loại bỏ các bài nộp. Hệ thống giữ lại cái cuối cùng và ít nhất một lần nộp cho mỗi kỳ ';
$string['download']= 'Tải xuống';
$string['downloadallsubmissions']= 'Tải xuống tất cả các phụ đề';
$string['downloadsubmissions']= 'Tải xuống các phụ đề';
$string['duedate']= 'Ngày đến hạn';
$string['edit']= 'Chỉnh sửa';
$string['editing']= 'Chỉnh sửa';
$string['editortheme']= 'Chủ đề trình soạn thảo';
$string['evaluate']= 'Đánh giá';
$string['evaluateonsubmission']= 'Chỉ đánh giá khi nộp đơn';
$string['evaluating']= 'Đánh giá';
$string['evaluation']= 'Đánh giá';
$string['examples']= 'Ví dụ';
$string['execution']= 'Thực thi';
$string['executionfiles']= 'Tập tin thực thi';
$string['executionfiles_help']= '<h2> Giới thiệu </h2>
<p> Tại đây, bạn đặt các tệp cần thiết để chuẩn bị thực thi,
gỡ lỗi hoặc đánh giá một bài nộp. Điều này bao gồm các tệp kịch bản,
tệp thử nghiệm chương trình và tệp dữ liệu. </p>
<h2> Tập lệnh mặc định để chạy hoặc gỡ lỗi </h2>
<p> Nếu bạn không đặt các tệp tập lệnh để chạy hoặc gỡ lỗi gửi, hệ thống
sẽ giải quyết ngôn ngữ bạn sử dụng (dựa trên phần mở rộng tên tệp) và sử dụng
tập lệnh xác định trước.
<h2> Đánh giá tự động </h2>
<p> Các tính năng kết hợp để tạo điều kiện thuận lợi cho việc đánh giá các bài nộp của học sinh.
Tính năng này cho phép chạy chương trình sinh viên và kiểm tra đầu ra của nó cho một đầu vào nhất định.
To set up the evaluation cases you must populate the file &quot;vpl_evaluate.cases&quot;.

<p> Tệp "vpl_evaluate.case" có định dạng sau:
<ul>
<li> "<strong> case </strong> = Mô tả trường hợp": Tùy chọn. Đặt bắt đầu định nghĩa trường hợp thử nghiệm. </li>
<li> "<strong> input </strong> = text": có thể sử dụng nhiều dòng. Kết thúc với hướng dẫn khác. </li>
<li> "<strong> output </strong> = text": có thể sử dụng nhiều dòng. Kết thúc với hướng dẫn khác. Một trường hợp có thể có đầu ra chính xác sai khác. Có ba loại đầu ra: số, văn bản và kiểm tra chính xác:
<ul>
<li> <strong> số </strong>: được định nghĩa là chuỗi số (số nguyên và số thực). Chỉ các số trong đầu ra được kiểm tra, các văn bản khác bị bỏ qua. Phao được kiểm tra với dung sai </li>
<li> <strong> văn bản </strong>: được định nghĩa là văn bản không có dấu ngoặc kép. Chỉ các từ được chọn và phần còn lại của ký tự bị bỏ qua, so sánh không phân biệt chữ hoa chữ thường </li>
<li> <strong> văn bản chính xác </strong>: được định nghĩa là văn bản thành dấu ngoặc kép. Kết quả khớp chính xác được sử dụng để kiểm tra đầu ra. </li>
</ Ul>
</li>
<li> "<strong> giảm điểm </strong> = [value |%%]": Theo mặc định, lỗi làm giảm điểm của học sinh
(bắt đầu với nâng cấp tối đa) theo (cấp độ / số trường hợp) nhưng với hướng dẫn này, bạn có thể thay đổi
giá trị giảm hoặc tỷ lệ phần trăm. </li>
</ Ul>
</p>
<h2> Sử dụng chung </h2>
<p>A new file can be added by writing its name in the box  &quot;<b>Add file</b>&quot;

and then clicking on the button &quot;<b>Add file</b>&quot;.</p>

<p>An existing file can be uploaded by means of the  &quot;<b>Upload file</b>&quot;.<p>All the added  or uploaded files can

được chỉnh sửa và tất cả chúng, ngoại trừ ba tệp kịch bản đã đề cập
bên dưới, có thể được đổi tên hoặc xóa. </p>
<h2> Chạy, thực thi hoặc đánh giá thủ công </h2>
<p> Ba tệp kịch bản để chuẩn bị cho mỗi hành động có thể được đặt.
Các tệp này có tên được xác định trước: <b> vpl_run.sh </b> (thực thi),
<b> vpl_debug.sh </b> (gỡ lỗi) và <b> vpl_evaluate.sh </b> (đánh giá). </p>
<p> Việc thực thi bất kỳ tệp kịch bản nào trong số đó sẽ tạo ra
tệp có tên <b> vpl_execution </b>.
This file must be a binary executable or a script beginning with &quot;#!/bin/sh &quot;.

Việc không tạo tệp này cản trở việc chạy tác vụ đã chọn. </p>
<p> Nếu hoạt động mà bạn đang định cấu hình "dựa trên" hoạt động khác,
các tệp của hoạt động cơ sở được thêm tự động.
Nội dung của các tệp vpl_run.sh, vpl_debug.sh và vpl_evaluate.sh
được nối từ cấp sâu nhất của "dựa trên" với hiện tại. </P>
<p> Cuối cùng, tệp <b> vpl_enosystem.sh </b> sẽ tự động được thêm vào.
Tệp kịch bản này chứa thông tin về bài nộp.
Thông tin đến dưới dạng các biến môi trường: </p>
<ul> <li> LANG: ngôn ngữ được sử dụng. </li>
<li> LC_ALL: cùng giá trị với LANG. </li>
<li> VPL_MAXTIME: thời gian thực thi tối đa tính bằng giây. </li>
<li> VPL_FILEBASEURL: URL để truy cập các tệp của khóa học. </li>
<li> VPL_SUBFILE #: tên từng tệp do sinh viên gửi. # Phạm vi từ 0 đến số tệp đã gửi. </L
<li> VPL_SUBFILES: danh sách tất cả các tệp đã gửi. </li>
<li> VPL_VARIATION + id: trong đó id là thứ tự biến thể bắt đầu bằng 0 và giá trị là giá trị của biến thể. </li>
</ Ul>
Nếu hành động được yêu cầu là đánh giá, thì các vars sau cũng được thêm vào.
<ul>
<li> VPL_MAXTIME: thời gian thực thi tối đa tính bằng giây. </li>
<li> VPL MAX MEMORY: bộ nhớ tối đa có thể sử dụng </li>
<li> VPL_MAXFILESIZE: kích thước tệp tối đa tính bằng byte có thể được tạo. </li>
<li> VPL_MAXPROCESSES: số lượng quá trình tối đa có thể được chạy đồng thời. </li>
<L domains VPL_FILEBASEURL: URL đến các tệp khóa học. </Licy
<li> VPL_GRADEMIN: Điểm tối thiểu cho hoạt động này </li>
<li> VPL_GRADEMAX: Điểm tối đa cho hoạt động này </li>
</ Ul>
<h2> Kết quả đánh giá </h2>
<p> Đầu ra đánh giá được xử lý để trích xuất, nếu có thể, các nhận xét và điểm đề xuất cho đánh giá.
Comments can be set in two ways: with a line comment defined by a line beginning with \'Comment :=&gt;&gt;\' or

with block comments starting with a line containing only \'&lt;|--\' and ending with a line containing only \'--|&gt;\'.

The grade is taken from the last line that begins with \'Grade :=&gt;&gt;\'.

</p> ';
$string['executionoptions']= 'Tùy chọn thực thi';
$string['executionoptions_help']= '<p> Các tùy chọn thực thi khác nhau được đặt trong trang này </p>
<ul>
<li> <b> Dựa trên </b>: đặt phiên bản VPL khác mà từ đó một số tính năng được nhập:
<ul> <li> Tệp thực thi (nối các tệp kịch bản được xác định trước) </li>
<li> Giới hạn đối với tài nguyên thực thi. </li>
<li> Các biến thể, được nối với nhau để tạo ra các biến đa biến. </li>
<li> Độ dài tối đa cho mỗi tệp được tải lên cùng với nội dung gửi </li>
</ Ul>
</li>
<li> <b> Chạy </b>, <b> Gỡ lỗi </b> và <b> Đánh giá </b>: phải được đặt thành \'Có \' nếu hành động tương ứng có thể được thực hiện khi chỉnh sửa nội dung gửi . Điều này chỉ ảnh hưởng đến học sinh, người dùng có khả năng chấm điểm luôn có thể thực hiện các hành động này. </li>
<li> <b> Chỉ đánh giá khi gửi </b>: nội dung gửi được đánh giá tự động khi tải lên. </li>
<li> <b> Chấm điểm tự động </b>: nếu kết quả đánh giá bao gồm các mã chấm điểm, chúng sẽ được sử dụng để đặt điểm tự động. </li>
</ul> ';
$string['file']= 'Tập tin';
$string['fileadded']= 'Tập tin \' {\\$a} \'đã được thêm';
$string['filedeleted']= 'Tập tin \' {\\$a} \'đã bị xóa';
$string['filelist']= 'Danh sách tập tin';
$string['file_name']= 'Tên tệp';
$string['filenotadded']= 'Tập tin chưa được thêm vào';
$string['fileNotChanged']= 'Tệp không thay đổi';
$string['filenotdeleted']= 'Tệp \' {$a} \'KHÔNG bị xóa';
$string['filenotrenamed']= 'Tệp \' {$a} \'KHÔNG được đổi tên';
$string['filerenamed']= 'Tệp \' {\\$a->from} \'đã được đổi tên thành \' {\\$a->to} \'';
$string['filesChangedNotSaved']= 'Các tập tin đã thay đổi nhưng chúng chưa được lưu';
$string['filesNotChanged']= 'Các tập tin không thay đổi';
$string['filestoscan']= 'Các tập tin cần quét';
$string['fileupdated']= 'Tệp \' {\\$a} \'đã được cập nhật';
$string['finalreduction']= 'Giảm cuối cùng';
$string['finalreduction_help']= '<b> FR [NE / FE R] </b> <br>
<b> FR </b> Giảm điểm cuối cùng. <br>
<b> NE </b> Đánh giá tự động do sinh viên yêu cầu. <br>
<b> FE </b> Được phép đánh giá miễn phí. <br>
<b> R </b> Giảm hạng theo đánh giá. Nếu nó là một phần trăm, nó được áp dụng so với kết quả trước đó. <br> ';
$string['find']= 'Tìm';
$string['find_replace']= 'Tìm / Thay thế';
$string['freeevaluations']= 'Đánh giá miễn phí';
$string['freeevaluations_help']= 'Số lượng đánh giá tự động không làm giảm điểm cuối cùng';
$string['fulldescription']= 'Mô tả đầy đủ';
$string['fulldescription_help']= '<p> Bạn phải viết ở đây một mô tả đầy đủ cho hoạt động. </p>
<p> Nếu bạn không viết gì ở đây, thay vào đó, mô tả ngắn sẽ được hiển thị. </p>
<p> Nếu bạn muốn đánh giá tự động, các giao diện cho bài tập phải chi tiết và không mơ hồ. </p> ';
$string['fullscreen']= 'Toàn màn hình';
$string['getjails']= 'Nhận máy chủ thực thi';
$string['gradeandnext']= 'Lớp & tiếp theo';
$string['graded']= 'Đã chấm điểm';
$string['gradedbyuser']= 'Người dùng chấm điểm';
$string['gradedon']= 'Đã đánh giá trên';
$string['gradedonby']= 'Đã đánh giá trên {$a->date} bởi {$a->gradername}';
$string['gradenotremoved']= 'Điểm KHÔNG bị xóa. Kiểm tra cấu hình hoạt động trong sổ điểm. ';
$string['gradenotsaved']= 'Điểm KHÔNG được lưu. Kiểm tra cấu hình hoạt động trong sổ điểm. ';
$string['gradeoptions']= 'Tùy chọn lớp';
$string['grader']= 'Người đánh giá';
$string['gradercomments']= 'Báo cáo đánh giá';
$string['graderemoved']= 'Điểm đã bị xóa';
$string['groupwork']= 'Làm việc nhóm';
$string['inconsistentgroup']= 'Bạn không chỉ là thành viên của một nhóm (0 o> 1)';
$string['incorrect_file_name']= 'Tên tệp không chính xác';
$string['individualwork']= 'Công việc cá nhân';
$string['instanceselection']= 'Lựa chọn VPL';
$string['isexample']= 'Hoạt động này hoạt động như một ví dụ';
$string['jail_servers']= 'Danh sách máy chủ thực thi';
$string['jail_servers_config']= 'Cấu hình máy chủ thực thi';
$string['jail_servers_description']= 'Viết một dòng cho mỗi máy chủ';
$string['joinedfiles']= 'Đã kết hợp các tệp đã chọn';
$string['keepfiles']= 'Các tập tin cần giữ lại khi chạy';
$string['keepfiles_help']= '<p>Due to security issues, the files added as &quot;Execution files&quot; are deleted before running the file vpl_execution.</p>

Nếu bất kỳ tệp nào trong số đó là cần thiết trong quá trình thực thi (ví dụ: được sử dụng làm dữ liệu thử nghiệm), nó phải được đánh dấu ở đây. ';
$string['keyboard']= 'Bàn phím';
$string['lasterror']= 'Thông tin lỗi cuối cùng';
$string['lasterrordate']= 'Ngày lỗi cuối cùng';
$string['listofcomments']= 'Danh sách các bình luận';
$string['listsimilarity']= 'Danh sách các điểm tương đồng được tìm thấy';
$string['listwatermarks']= 'Danh sách vết nước';
$string['load']= 'Tải';
$string['loading']= 'Đang tải';
$string['local_jail_servers']= 'Máy chủ thực thi cục bộ';
$string['local_jail_servers_help']= '<p> Tại đây, bạn có thể đặt các máy chủ thực thi cục bộ được thêm vào cho hoạt động này và những
dựa trên nó. </p>
<p> Nhập URL đầy đủ của máy chủ trên mỗi dòng. Bạn có thể sử dụng các dòng trống
và nhận xét bắt đầu từ dòng bằng "#". </p>
<p> Hoạt động này sẽ sử dụng làm danh sách máy chủ thực thi: các máy chủ đặt ở đây
cộng với danh sách máy chủ được đặt trong hoạt động "dựa trên"
cộng với danh sách các máy chủ thực thi phổ biến.
Nếu bạn muốn ngăn chặn hoạt động này và những hoạt động bắt nguồn
từ việc sử dụng các máy chủ khác, sau đó bạn phải thêm một dòng
chứa "end_of_jails" ở cuối danh sách máy chủ.
</p> ';
$string['manualgrading']= 'Phân loại thủ công';
$string['maxexefilesize']= 'Kích thước tệp thực thi tối đa';
$string['maxexememory']= 'Bộ nhớ tối đa được sử dụng';
$string['maxexeprocesses']= 'Số lượng quá trình tối đa';
$string['maxexetime']= 'Thời gian thực hiện tối đa';
$string['maxfiles']= 'Số lượng tệp tối đa';
$string['maxfilesexceeded']= 'Đã vượt quá số tệp tối đa';
$string['maxfilesize']= 'Kích thước tệp tải lên tối đa';
$string['maxfilesizeexceeded']= 'Đã vượt quá kích thước tệp tối đa';
$string['maximumperiod']= 'Khoảng thời gian tối đa {$a}';
$string['maxresourcelimits']= 'Giới hạn tài nguyên thực thi tối đa';
$string['maxsimilarityoutput']= 'Sản lượng tối đa theo độ tương tự';
$string['menucheck_jail_servers']= 'Kiểm tra máy chủ thực thi';
$string['menuexecutionfiles']= 'Tập tin thực thi';
$string['menuexecutionoptions']= 'Tùy chọn';
$string['menukeepfiles']= 'Các tập tin cần lưu giữ';
$string['menulocal_jail_servers']= 'Máy chủ thực thi cục bộ';
$string['menuresourcelimits']= 'Giới hạn tài nguyên';
$string['minsimlevel']= 'Mức độ tương tự tối thiểu để hiển thị';
$string['moduleconfigtitle']= 'Cấu hình mô-đun VPL';
$string['modulename']= 'Phòng thí nghiệm lập trình ảo';
$string['modulename_help']= '<p> VPL là một mô-đun hoạt động cho Moodle quản lý các bài tập lập trình và có các tính năng nổi bật là:
</p>
<ul>
<li> Cho phép chỉnh sửa mã nguồn chương trình trong trình duyệt </li>
<li> Học sinh có thể chạy các chương trình tương tác trong trình duyệt </li>
<li> Bạn có thể chạy thử nghiệm để xem lại chương trình. </li>
<li> Cho phép tìm kiếm sự giống nhau giữa các tệp. </li>
<li> Cho phép đặt các giới hạn chỉnh sửa và tránh dán văn bản bên ngoài. </li>
</ul>
<p> <a href="http://vpl.dis.ulpgc.es"> Trang chủ phòng thí nghiệm Lập trình Ảo </a> </p> ';
$string['modulename_link']= 'mod / vpl / view';
$string['modulenameplural']= 'Phòng thí nghiệm lập trình ảo';
$string['multidelete']= 'Xóa nhiều lần';
$string['nevaluations']= '{$a} thực hiện đánh giá tự động';
$string['new']= 'Mới';
$string['new_file_name']= 'Tên tệp mới';
$string['next']= 'Tiếp theo';
$string['nojailavailable']= 'Không có máy chủ thực thi nào';
$string['noright']= 'Bạn không có quyền truy cập';
$string['nosubmission']= 'Không có bài nộp nào';
$string['notexecuted']= 'Không được thực thi';
$string['notgraded']= 'Không được chấm điểm';
$string['notsaved']= 'Không được lưu';
$string['novpls']= 'Không có phòng thí nghiệm lập trình ảo nào được xác định';
$string['nowatermark']= 'Dấu nước riêng {$a}';
$string['nsubmissions']= '{$a} đệ trình';
$string['numcluster']= 'Cụm {$a}';
$string['open']= 'Mở';
$string['opnotallowfromclient']= 'Hành động không được phép từ máy này';
$string['options']= 'Tùy chọn';
$string['optionsnotsaved']= 'Các tùy chọn chưa được lưu';
$string['optionssaved']= 'Các tùy chọn đã được lưu';
$string['origin']= 'Nguồn gốc';
$string['othersources']= 'Các nguồn khác để thêm vào bản quét';
$string['outofmemory']= 'Hết bộ nhớ';
$string['paste']= 'Dán';
$string['pluginadministration']= 'Quản trị VPL';
$string['pluginname']= 'Phòng thí nghiệm lập trình ảo';
$string['previoussubmissionslist']= 'Danh sách gửi trước đó';
$string['print']= 'Trong';
$string['proposedgrade']= 'Điểm đề xuất: {$a}';
$string['proxy']= 'proxy';
$string['proxy_description']= 'Proxy từ Moodle tới máy chủ thực thi';
$string['redo']= 'Làm lại';
$string['reductionbyevaluation']= 'Giảm bằng cách đánh giá tự động';
$string['reductionbyevaluation_help']= 'Giảm điểm tổng kết theo một giá trị hoặc tỷ lệ phần trăm cho mỗi đánh giá tự động do học sinh yêu cầu';
$string['regularscreen']= 'Màn hình thông thường';
$string['removegrade']= 'Xóa điểm';
$string['rename']= 'Đổi tên';
$string['rename_file']= 'Đổi tên tệp';
$string['replace_find']= 'Thay thế / Tìm';
$string['requestedfiles']= 'Tệp được yêu cầu';
$string['requestedfiles_help']= '<p> Tại đây, bạn đặt tên và nội dung ban đầu của nó cho các tệp được yêu cầu thành số tệp tối đa được đặt trong mô tả cơ bản của hoạt động. </p>
<p> Nếu bạn không đặt tên cho toàn bộ số lượng tệp, các tệp chưa đặt tên là tùy chọn và có thể có bất kỳ tên nào. </p>
<p> Bạn cũng có thể thêm nội dung vào các tệp được yêu cầu, vì vậy những nội dung này sẽ có sẵn trong lần đầu tiên chúng được mở bằng trình chỉnh sửa, nếu không có nội dung gửi trước đó. </p> ';
$string['requirednet']= 'Được phép gửi từ net';
$string['requiredpassword']= 'Cần có mật khẩu';
$string['resetfiles']= 'Đặt lại tệp';
$string['resetvpl']= 'Đặt lại {$a}';
$string['resourcelimits']= 'Giới hạn tài nguyên';
$string['resourcelimits_help']= '<p> Bạn có thể đặt giới hạn cho thời gian thực thi, bộ nhớ được sử dụng, kích thước tệp thực thi và số lượng quy trình được thực thi đồng thời. </p>
<p> Các giới hạn này được sử dụng khi chạy các tệp tập lệnh vpl_run.sh, vpl_debug.sh và vpl_evaluate.sh và tệp vpl_execution do chúng tạo. </p>
<p> Nếu hoạt động này dựa trên hoạt động khác, thì các giới hạn có thể bị ảnh hưởng bởi những giới hạn được đặt trong hoạt động cơ sở và tổ tiên của nó hoặc trong cấu hình chung của mô-đun. </p> ';
$string['restrictededitor']= 'Tắt tải lên tệp bên ngoài, dán và thả nội dung bên ngoài';
$string['retrieve']= 'Lấy kết quả';
$string['run']= 'Chạy';
$string['running']= 'Đang chạy';
$string['runscript']= 'Chạy tập lệnh';
$string['runscript_help']= 'Chọn tập lệnh chạy để sử dụng trong hoạt động này';
$string['save']= 'Lưu';
$string['savecontinue']= 'Lưu và tiếp tục';
$string['saved']= 'Đã lưu';
$string['savedfile']= 'Tập tin \' {\\$a} \'đã được lưu';
$string['saveoptions']= 'lưu các tùy chọn';
$string['saving']= 'Tiết kiệm';
$string['scanactivity']= 'Hoạt động';
$string['scandirectory']= 'Thư mục';
$string['scanningdir']= 'Đang quét thư mục ...';
$string['scanoptions']= 'Tùy chọn quét';
$string['scanother']= 'Quét các điểm tương đồng trong các nguồn được thêm vào';
$string['scanzipfile']= 'Tập tin zip';
$string['sebkeys']= 'Khóa / s kỳ thi SEB';
$string['sebkeys_help']= '(Các) khóa kiểm tra SEB (tối đa 3) lấy được từ tệp .seb <br> Nó đáng tin cậy hơn chỉ kiểm tra trình duyệt. <br> https://safeexambrowser.org';
$string['sebrequired']= 'Yêu cầu trình duyệt WEB';
$string['sebrequired_help']= 'Cần phải sử dụng trình duyệt SEB được định cấu hình đúng cách';
$string['select_all']= 'Chọn tất cả';
$string['server']= 'Máy chủ';
$string['serverexecutionerror']= 'Lỗi thực thi máy chủ';
$string['shortcuts']= 'Các phím tắt';
$string['shortdescription']= 'Mô tả ngắn gọn';
$string['similarity']= 'Tương tự';
$string['similarto']= 'Tương tự với';
$string['startdate']= 'Có sẵn từ';
$string['submission']= 'Đệ trình';
$string['submissionperiod']= 'Thời gian gửi';
$string['submissionrestrictions']= 'Hạn chế gửi';
$string['submissions']= 'Bài gửi';
$string['submissionselection']= 'Lựa chọn đệ trình';
$string['submissionslist']= 'Danh sách gửi';
$string['submissionview']= 'Chế độ xem đệ trình';
$string['submittedby']= 'Đệ trình bởi {$a}';
$string['submittedon']= 'Đã nộp vào';
$string['submittedonp']= 'Đã gửi trên {$a}';
$string['sureresetfiles']= 'Bạn có muốn mất tất cả công việc của mình và đặt lại các tệp về trạng thái ban đầu không?';
$string['test']= 'Hoạt động thử nghiệm';
$string['testcases']= 'Các trường hợp kiểm tra';
$string['testcases_help']= 'This feature allows to run the student program and check its output for a given input. To set up the evaluation cases you must populate the file &quot;vpl_evaluate.cases&quot;.<br>

Tệp "vpl_evaluate.case" có định dạng sau: <br>
<ul>
<li> "<b> case </b> = Mô tả trường hợp": Đặt bắt đầu định nghĩa trường hợp thử nghiệm. </li>
<li> "<b> input </b> = text": có thể sử dụng nhiều dòng. Kết thúc với hướng dẫn khác. </li>
<li> "<b> output </b> = text": có thể sử dụng nhiều dòng. Kết thúc với hướng dẫn khác. Một trường hợp có thể có đầu ra chính xác sai khác. Có ba loại đầu ra: số, văn bản và kiểm tra chính xác:
<ul>
<li> <b> số </b>: được định nghĩa là một chuỗi số (số nguyên và số thực). Chỉ các số trong đầu ra được kiểm tra, các văn bản khác bị bỏ qua. Phao được kiểm tra với dung sai </li>
<li> <b> văn bản </b>: được định nghĩa là văn bản không có dấu ngoặc kép. Chỉ các từ được chọn và phần còn lại của ký tự bị bỏ qua, so sánh không phân biệt chữ hoa chữ thường </li>
<li> <b> văn bản chính xác </b>: được định nghĩa là văn bản thành dấu ngoặc kép. Kết quả khớp chính xác được sử dụng để kiểm tra đầu ra. </li>
</ Ul>
</li>
<li> "<b> giảm điểm </b> = [value |%%]": Theo mặc định, một lỗi làm giảm điểm của học sinh (bắt đầu với nâng cấp tối đa) xuống (cấp độ / số trường hợp) nhưng với hướng dẫn này
bạn có thể thay đổi giá trị giảm hoặc tỷ lệ phần trăm. </li>
</ul> ';
$string['timeleft']= 'Thời gian còn lại';
$string['timelimited']= 'Giới hạn thời gian';
$string['timeout']= 'Hết giờ';
$string['timeunlimited']= 'Không giới hạn thời gian';
$string['totalnumberoferrors']= 'Lỗi';
$string['undo']= 'Hoàn tác';
$string['unexpected_file_name']= 'Tên tệp không chính xác: dự kiến ​​\' {\\$a->expected} \'và được tìm thấy \' {\\$a->found} \'';
$string['unzipping']= 'Đang giải nén ...';
$string['uploadfile']= 'Tải lên tập tin';
$string['usevariations']= 'Sử dụng các biến thể';
$string['usewatermarks']= 'Sử dụng hình mờ';
$string['usewatermarks_description']= 'Thêm hình mờ vào tệp của sinh viên (chỉ cho các ngôn ngữ được hỗ trợ)';
$string['variation']= 'Biến thể {$a}';
$string['variation_options']= 'Tùy chọn biến thể';
$string['variations']= 'Các biến thể';
$string['variations_help']= '<p> Một tập hợp các biến thể có thể được xác định cho một hoạt động. Các biến thể này được chỉ định ngẫu nhiên cho học sinh. </p>
<p> Tại đây, bạn có thể cho biết hoạt động này có các biến thể hay không, đặt tiêu đề cho tập hợp các biến thể và thêm các biến thể mong muốn. </p>
<p> Mỗi biến thể có mã nhận dạng và mô tả. Mã nhận dạng được sử dụng bởi tệp <b> vpl_enviroment.sh </b> để vượt qua
biến thể được gán cho mỗi học sinh vào các tệp kịch bản. Mô tả, được định dạng bằng HTML, được hiển thị cho các sinh viên đã chỉ định
biến thể tương ứng. </p> ';
$string['variations_unused']= 'Hoạt động này có các biến thể, nhưng bị vô hiệu hóa';
$string['variationtitle']= 'Tiêu đề biến thể';
$string['varidentification']= 'Nhận dạng';
$string['visiblegrade']= 'Hiển thị';
$string['vpl']= 'Phòng thí nghiệm lập trình ảo';
$string['vpl:addinstance']= 'Thêm phiên bản vpl mới';
$string['VPL_COMPILATIONFAILED']= 'Quá trình biên dịch hoặc chuẩn bị thực thi không thành công';
$string['vpl_debug.sh']= 'Tập lệnh này chuẩn bị gỡ lỗi';
$string['vpl_evaluate.cases']= 'Các trường hợp kiểm tra để đánh giá';
$string['vpl_evaluate.sh']= 'Tập lệnh này chuẩn bị đánh giá';
$string['vpl:grade']= 'Phân cấp VPL';
$string['vpl:manage']= 'Quản lý phân công VPL';
$string['vpl_run.sh']= 'Tập lệnh này chuẩn bị thực thi';
$string['vpl:setjails']= 'Đặt máy chủ thực thi cho các trường hợp VPL cụ thể';
$string['vpl:similarity']= 'Tìm kiếm sự tương tự của phép gán VPL';
$string['vpl:submit']= 'Gửi bài tập VPL';
$string['vpl:view']= 'Xem mô tả bài tập VPL đầy đủ';
$string['websocket_protocol']= 'Giao thức WebSocket';
$string['websocket_protocol_description']= 'Loại giao thức WebSocket (ws: // hoặc wss: //) được trình duyệt sử dụng để kết nối với máy chủ thực thi.';
$string['workingperiods']= 'Thời gian làm việc';
$string['worktype']= 'Loại công việc';
