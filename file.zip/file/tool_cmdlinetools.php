<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_cmdlinetools', language 'en', branch 'MOODLE_30_STABLE'
 *
 * @package   tool_cmdlinetools
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['add_assignmentcapa_cli_capxcreated']= 'Khả năng {$a} được tạo';
$string['add_assignmentcapa_cli_choose_plugin']= 'chọn plugin có khả năng thêm phiên bản mới khi được tạo:';
$string['add_assignment_capa_cli_help']= 'thêm khả năng chịu trách nhiệm kiểm soát khả năng hiển thị của các plugin phản hồi hoặc phân công trên các ngữ cảnh
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php add_assignment_capa
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['add_assignmentcapa_cli_mustbeint']= 'giá trị đã nhập phải là int';
$string['add_assignmentcapa_cli_noassignplugin']= 'không có plugin chuyển nhượng';
$string['allow_assign_cli_allowed']= 'Được phép gán vai trò';
$string['allow_assign_cli_disallowed']= 'Chỉ định vai trò không được phép';
$string['allow_assign_cli_help']= 'Cho phép chỉ định một vai trò mục tiêu cho một vai trò
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php allow_assign role targetrole
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['allow_assign_cli_rolexnotexists']= 'Vai trò {$a} không tồn tại';
$string['apply_defaults_settings_to_all_plugins_cli_help']= 'Áp dụng cài đặt plugin mặc định cho các cài đặt plugin không được xác định, chẳng hạn như upgradedesettings.php
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php apply_defaults_settings_to_all_plugins
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['apply_defaults_settings_to_plugin_cli_notimplementedtype']= 'loại plugin {$a} không được triển khai';
$string['apply_defaults_settings_to_plugin_cli_pluginnotexists']= 'plugin loại {$a->type} với tên {$a->name} không tồn tại';
$string['apply_defaults_settings_to_plugin_cli_settingset']= 'plugin {$a->plugin} key {$a->key} giá trị {$a->value} set!';
$string['badnumberarguments']= 'Số lượng đối số không hợp lệ';
$string['badstoreinstancename_set_cache_cli']= 'Ánh xạ tên phiên bản lưu trữ không hợp lệ {$a}: không tồn tại hoặc không thể sử dụng cho chế độ bộ nhớ cache này';
$string['capabilitynotexists_set_capability_cli']= 'Khả năng $ a không tồn tại';
$string['clifailed_add_assignment_capa_cli']= 'Không thể thêm khả năng gán';
$string['clifailed_allow_assign_cli']= 'Không cho phép gán vai trò';
$string['clifailed_apply_defaults_settings_to_all_plugins_cli']= 'Không áp dụng được cài đặt plugin mặc định';
$string['clifailed_cmdlinecli']= 'Lỗi công cụ moodle dòng lệnh';
$string['clifailed_create_role_cli']= 'Không đặt được mức bối cảnh vai trò';
$string['clifailed_create_user_cli']= 'Tạo người dùng không thành công';
$string['clifailed_delete_js_cache_cli']= 'Không xóa được bộ đệm js';
$string['clifailed_delete_plugin_cli']= 'Không xóa được plugin';
$string['clifailed_delete_theme_cache_cli']= 'Không xóa được bộ đệm chủ đề';
$string['clifailed_hard_delete_js_cache_cli']= 'Không xóa được khó xóa bộ nhớ cache js';
$string['clifailed_hard_delete_theme_cache_cli']= 'Không xóa được phần cứng bộ nhớ cache của chủ đề';
$string['clifailed_hideshow_plugin_cli']= 'Ẩn / hiện plugin không thành công';
$string['clifailed_passwordaltmain_generator_cli']= 'Tạo mật khẩu không thành công';
$string['clifailed_remove_assignment_capa_cli']= 'Lập lịch tác vụ không thành công';
$string['clifailed_role_assign_cli']= 'Không thể gán vai trò cho người dùng';
$string['clifailed_set_cache_cli']= 'Bộ cài đặt ánh xạ bộ nhớ cache không thành công';
$string['clifailed_set_capability_cli']= 'Không thể thiết lập khả năng';
$string['clifailed_set_config_cli']= 'Bộ cài đặt cấu hình không thành công';
$string['clisuccessfull_add_assignment_capa_cli']= 'Thêm khả năng phân công đã hoàn thành thành công';
$string['clisuccessfull_allow_assign_cli']= 'Cho phép gán vai trò thành công';
$string['clisuccessfull_apply_defaults_settings_to_all_plugins_cli']= 'Áp dụng thành công cài đặt plugin mặc định';
$string['clisuccessfull_create_role_cli']= 'Tạo thành công vai trò';
$string['clisuccessfull_create_user_cli']= 'Tạo thành công người dùng';
$string['clisuccessfull_delete_js_cache_cli']= 'Xóa bộ nhớ cache js thành công';
$string['clisuccessfull_delete_plugin_cli']= 'Đã xóa PLugin thành công';
$string['clisuccessfull_delete_theme_cache_cli']= 'Đã xóa thành công bộ đệm chủ đề';
$string['clisuccessfull_hard_delete_js_cache_cli']= 'Hard delete js cache thành công';
$string['clisuccessfull_hard_delete_theme_cache_cli']= 'Bộ đệm chủ đề hầu như không được xóa thành công';
$string['clisuccessfull_hideshow_plugin_cli']= 'Ẩn / hiện plugin tiến hành thành công';
$string['clisuccessfull_passwordaltmain_generator_cli']= 'Mật khẩu được tạo thành công';
$string['clisuccessfull_remove_assignment_capa_cli']= 'Xóa khả năng gán đã hoàn thành thành công';
$string['clisuccessfull_role_assign_cli']= 'Chỉ định thành công vai trò cho người dùng';
$string['clisuccessfull_role_set_context_level_cli']= 'Đặt thành công mức bối cảnh vai trò';
$string['clisuccessfull_schedule_task_cli']= 'Công việc đã lên lịch đã hoàn thành thành công';
$string['clisuccessfull_set_cache_cli']= 'Bộ ánh xạ bộ nhớ cache';
$string['clisuccessfull_set_capability_cli']= 'Bộ khả năng';
$string['clisuccessfull_set_config_cli']= 'Bộ cấu hình';
$string['clititle_']= 'cli title';
$string['clititle_add_assignment_capa_cli']= 'Thêm khả năng phân công';
$string['clititle_allow_assign_cli']= 'Cho phép gán vai trò';
$string['clititle_apply_defaults_settings_to_all_plugins_cli']= 'Áp dụng cài đặt plugin mặc định';
$string['clititle_cmdlinecli']= 'Công cụ tâm trạng dòng lệnh';
$string['clititle_create_role_cli']= 'Tạo vai trò';
$string['clititle_create_user_cli']= 'Tạo người dùng';
$string['clititle_delete_js_cache_cli']= 'Xóa bộ nhớ cache js';
$string['clititle_delete_plugin_cli']= 'Xóa plugin';
$string['clititle_delete_theme_cache_cli']= 'Xóa bộ đệm chủ đề';
$string['clititle_hard_delete_js_cache_cli']= 'Khó xóa bộ nhớ cache js';
$string['clititle_hard_delete_theme_cache_cli']= 'Xóa bộ nhớ cache chủ đề khó xóa';
$string['clititle_hideshow_plugin_cli']= 'Ẩn / hiện plugin';
$string['clititle_passwordaltmain_generator_cli']= 'Trình tạo mật khẩu';
$string['clititle_remove_assignment_capa_cli']= 'Xóa khả năng phân công';
$string['clititle_role_assign_cli']= 'Gán vai trò cho người dùng';
$string['clititle_role_set_context_level_cli']= 'Đặt mức bối cảnh vai trò';
$string['clititle_schedule_task_cli']= 'Lên lịch tiện ích tác vụ';
$string['clititle_set_cache_cli']= 'Bộ cài đặt ánh xạ bộ nhớ cache để xác định bộ nhớ cache';
$string['clititle_set_capability_cli']= 'Thiết lập khả năng';
$string['clititle_set_config_cli']= 'Bộ định cấu hình';
$string['cmdlinecli_help']= 'công cụ dòng lệnh để khởi chạy các lệnh tâm trạng:
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php quản trị / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php [đối số]
Đối số (tùy chọn): tên lệnh để thực thi (liệt kê bên dưới)
6 một làn khói 4212-7 Đi 4 một làn khói 1 một pfd 14 một mốt 0 một chút
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['create_role_cli_createrolexid']= 'Vai trò được tạo với id {$a}';
$string['create_role_cli_help']= 'Tạo một vai trò với tên viết tắt đã cho
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php create_role shortname
Trường hợp tên viết tắt phải là duy nhất
Các tùy chọn:
-h, - trợ giúp in ra giúp đỡ
-n, - tên vai trò
-d, - mô tả vai trò mô tả
-a, - nguyên mẫu vai trò kiểu ';
$string['create_role_cli_rolexexists']= 'Vai trò {$a} đã tồn tại';
$string['create_user_cli_createuserxid']= 'Người dùng được tạo với id {$a}';
$string['create_user_cli_help']= 'Tạo người dùng với tên người dùng đã cho
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php create_user username
Tên người dùng phải là duy nhất
Các tùy chọn:
-h, - trợ giúp in ra giúp đỡ
-a, phương thức xác thực --auth (trống mặc định)
mật khẩu -p, --password nếu cần
-e, - email email (trống mặc định)
-c, --city city (trống mặc định)
-C, --country quốc gia (trống mặc định)
-f, --firstname firstname
-l, - họ tên cuối cùng
-i, --idnumber idnumber (trống mặc định)
-d, --digest maildigest (mặc định là 0) ';
$string['create_user_cli_userxexists']= 'Người dùng {$a} đã tồn tại';
$string['definitionmappingsrequired_set_cache_cli']= 'định nghĩa và mammpings được yêu cầu';
$string['delete_js_cache_cli_help']= 'Xóa bộ nhớ cache js
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php delete_js_cache
Các tùy chọn:
-h, --help In ra phần trợ giúp này ';
$string['delete_plugin_cli_badtype']= 'loại plugin xấu';
$string['delete_plugin_cli_cantremovexplugin']= 'không thể xóa các plugin {$a}';
$string['delete_plugin_cli_help']= 'Xóa một plugin
Sử dụng:
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php delete_plugin plugintype pluginname
Ở đâu :
plugintype là
mod,
khối,
qtype,
qbehaviour,
ghi danh,
bộ lọc,
biên tập viên,
auth,
giấy phép,
kho,
định dạng khóa học,
giao lại hoặc chuyển nhượng quyền
dụng cụ
pluginname là tên của plugin (tên của thư mục plugin)
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['delete_plugin_cli_notyetimplemented']= 'chưa được thực hiện vì tác động mạnh';
$string['delete_plugin_cli_undeletableplugintype']= '{$a->type} {$a->name} không thể bị xóa';
$string['delete_plugin_cli_undeletablerequiredplugintype']= '{$a->type} {$a->name} không thể bị xóa vì nó bắt buộc phải có';
$string['delete_plugin_cli_unreconizedplugintype']= 'không được công nhận {$a->type} {$a->name}';
$string['delete_theme_cache_cli_help']= 'Xóa bộ đệm chủ đề
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php delete_theme_cache
Các tùy chọn:
-h, --help In ra phần trợ giúp này ';
$string['hard_delete_js_cache_cli_help']= 'Khó xóa bộ nhớ cache js
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php hard_delete_cache
Các tùy chọn:
-h, --help In ra phần trợ giúp này ';
$string['hard_delete_theme_cache_cli_help']= 'hầu như không xóa bộ nhớ cache của chủ đề
Các tùy chọn:
-h, --help In ra phần trợ giúp này ';
$string['hideshow_plugin_cli_authpluginnotexists']= 'plugin {$a->type} {$a->name} không tồn tại';
$string['hideshow_plugin_cli_badplugintype']= 'loại plugin xấu';
$string['hideshow_plugin_cli_courseformatcantenabledisable']= 'không thể bật / tắt định dạng khóa học {$a}';
$string['hideshow_plugin_cli_courseformatnotexists']= 'định dạng khóa học {$a} không tồn tại';
$string['hideshow_plugin_cli_editorpluginnotexists']= 'trình soạn thảo {$a} không tồn tại';
$string['hideshow_plugin_cli_enrolmethodnotexists']= 'phương thức đăng ký {$a} không tồn tại';
$string['hideshow_plugin_cli_filterpluginnotexists']= 'bộ lọc {$a} không tồn tại';
$string['hideshow_plugin_cli_help']= 'ẩn hiển thị một plugin
Sử dụng:
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php hideshow_plugin plugintype pluginname hideshow
Ở đâu :
plugintype là
mod,
khối,
qtype,
qbehaviour,
ghi danh,
bộ lọc,
biên tập viên,
auth,
giấy phép,
kho,
định dạng khóa học,
giao lại hoặc chuyển nhượng quyền
pluginname là tên của plugin (tên của thư mục plugin)
hideshow là giá trị int 0 cho false hoặc tắt (plugin bộ lọc), 1 cho true hoặc bật (plugin bộ lọc), -9999 cho tắt (plugin bộ lọc)
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['hideshow_plugin_cli_licensecantenabledisable']= 'không thể bật / tắt giấy phép {$a}';
$string['hideshow_plugin_cli_licensepluginnotexists']= 'biên tập viên {$a} không tồn tại';
$string['hideshow_plugin_cli_parametervalues']= 'các giá trị có thể hiển thị / ẩn là {$a}';
$string['hideshow_plugin_cli_pluginnotexists']= '{$a->type} {$a->name} không tồn tại';
$string['hideshow_plugin_cli_qbehaviourcantenabledisable']= 'không thể bật / tắt qbehaviour {$a}';
$string['hideshow_plugin_cli_qbehaviournotexits']= 'qbehaviour {$a} không tồn tại';
$string['hideshow_plugin_cli_qtypenotexits']= 'qtype {$a} không tồn tại';
$string['hideshow_plugin_cli_repositorynotimplemented']= 'không được triển khai vì yêu cầu biểu mẫu thiết lập kho lưu trữ';
$string['manager_notexistingfilename']= 'tên tệp không tồn tại {$a}';
$string['namevaluerequired_set_config_cli']= 'bạn phải nhập các tham số --name et --value';
$string['notexistingdefinition_set_cache_cli']= 'Không có định nghĩa bộ nhớ cache {$a}';
$string['passwordaltmain_generator_cli_help']= 'Tạo khóa passwordaltmain cho config.php \\ $ CFG-> passwordaltmain
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php passwordaltmain_generator
Các tùy chọn:
-h, --help In ra phần trợ giúp này ';
$string['permissionvalues_set_capability_cli']= 'quyền phải là một int như sau {$CAP_INHERIT}, {$CAP_ALLOW}, {$CAP_PREVENT}, 4a12d795f456-a891b77596710';
$string['pluginname']= 'trình quản lý dòng lệnh';
$string['remove_assignmentcapa_cli_cannotunassignrolex']= 'không thể bỏ gán khả năng trên vai trò {$a}';
$string['remove_assignmentcapa_cli_capaxnotremoved']= 'Khả năng $ capaslist {$a} không bị xóa';
$string['remove_assignmentcapa_cli_capxremoved']= 'Đã loại bỏ khả năng {$a}';
$string['remove_assignmentcapa_cli_choose_plugin']= 'chọn plugin có khả năng thêm phiên bản mới trong khi bị xóa:';
$string['remove_assignment_capa_cli_help']= 'loại bỏ khả năng chịu trách nhiệm kiểm soát khả năng hiển thị của các plugin phản hồi hoặc phân công trên các ngữ cảnh
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php remove_assignment_capa
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['remove_assignmentcapa_cli_mustbeint']= 'giá trị đã nhập phải là int';
$string['remove_assignmentcapa_cli_noassignplugin']= 'không có plugin chuyển nhượng';
$string['role_assign_cli_contextxnotexists']= 'Ngữ cảnh {$a} không tồn tại';
$string['role_assign_cli_help']= 'Chỉ định một vai trò nhất định cho một người dùng nhất định trong một id ngữ cảnh nhất định
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php role_assign username shortname contextxtid
Ở đâu
tên người dùng: tên người dùng
tên viết tắt: tên viết tắt của vai trò
Contextid: id ngữ cảnh
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['role_assign_cli_rolexnotexists']= 'Vai trò {$a} không tồn tại';
$string['role_assign_cli_userxnotexists']= 'Người dùng {$a} không tồn tại';
$string['role_set_context_level_cli_help']= 'Đặt mức bối cảnh vai trò
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php set_role_context_level shortname Contextlevels
Ở đâu :
tên viết tắt phải là duy nhất
ngữ cảnh phải là danh sách các int được phân tách bằng, các giá trị CONTEXT_COURSE (50), CONTEXT_COURSECAT (40), CONTEXT_SYSTEM (10), CONTEXT_BLOCK (80), CONTEXT_MODULE (70), CONTEXT_USER (30)
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['role_set_context_level_cli_rolexnotexists']= 'Vai trò {$a} đã tồn tại';
$string['schedule_task_cli_badtaskname']= 'tác vụ {$a} không tồn tại';
$string['schedule_task_cli_help']= 'lên lịch tác vụ cho phép đặt các thông số cho một tác vụ đã lên lịch theo tâm trạng cụ thể
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php Sched_task taskname [options]
tên tác vụ được viết như sau: \\ plugin \\ task \\ tên tác vụ, ví dụ: \\ auth_cas \\ task \\ sync_task
Các tùy chọn:
-h, - trợ giúp in ra giúp đỡ
-M, --minute * Mỗi phút (giá trị mặc định)
* / 5 Cứ sau 5 phút
2-10 Mỗi phút từ 2 đến 10 giờ (bao gồm cả)
2,6,9 2 6 và 9 phút qua giờ
-H, --giờ * Mỗi giờ (giá trị mặc định)
* / 2 Cứ 2 giờ một lần
2-10 Mỗi giờ từ 2 giờ sáng đến 10 giờ sáng (bao gồm cả)
2,6,9 2 giờ sáng, 6 giờ sáng và 9 giờ sáng
-d, --day * Mỗi ngày (giá trị mặc định)
* / 2 Mỗi ngày thứ 2
1 Ngày đầu tiên của mỗi tháng
1,15 Ngày đầu tiên và ngày 15 hàng tháng
-m, --tháng * Hàng tháng (giá trị mặc định)
* / 2 Mỗi tháng thứ hai
1 Tháng 1 hàng năm
1,5 Tháng 1 và tháng 5 hàng năm
-w, --dayofweek * Mỗi ngày (giá trị mặc định)
0 Chủ nhật hàng tuần
6 Thứ Bảy hàng tuần
1,5 Thứ Hai và Thứ Sáu hàng tuần
-x, - vô hiệu hóa 0 không bị vô hiệu hóa (giá trị mặc định), 1 bị vô hiệu hóa
-r, --restoretodefaults 0 không khôi phục về mặc định (giá trị mặc định), 1 khôi phục về mặc định các tùy chọn khác sẽ không được tính đến ';
$string['schedule_task_cli_tasklist']= 'tên tác vụ có sẵn là:
{$a} ';
$string['set_cache_cli_help']= 'đặt ánh xạ bộ nhớ cache thành một định nghĩa bộ nhớ cache nhất định
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php quản trị / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php ánh xạ định nghĩa set_cache
Ở đâu :
định nghĩa: định nghĩa bộ nhớ cache chứa thành phần và khu vực được phân tách bằng /. ví dụ: lựa chọn cốt lõi / người dùng
ánh xạ: ánh xạ phiên bản tên cửa hàng được phân tách bằng và theo thứ tự, ví dụ: default_application, my_memcache_instance
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['set_capability_cli_help']= 'thiết lập khả năng cho một vai trò trong một ngữ cảnh cụ thể
Sử dụng:
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php set_capabiliy.php vai trò ngữ cảnh cho phép khả năng
Ở đâu :
khả năng là một khả năng tâm trạng hiện có
quyền là quyền khả năng dưới dạng giá trị int {$CAP_INHERIT}, {$CAP_ALLOW}, {$CAP_PREVENT} af 2322abc53-aec0-2719284f8eba0
ngữ cảnh là giá trị để áp dụng khả năng đó
vai trò là vai trò tên viết tắt để áp dụng khả năng đó
Các tùy chọn:
-h, --help in ra giúp đỡ này ';
$string['set_config_cli_help']= 'đặt một var cấu hình
Sử dụng :
\\ $ sudo -u www-data / usr / bin / php admin / cli / admin / tool / cmdlinetools / cli / cmdline_manager.php set_config [options]
Các tùy chọn:
-h, - trợ giúp in ra giúp đỡ
-n, --name = config_name tên cấu hình nếu không có chế độ nhắc như config_param_name nếu tham số cấu hình chung hoặc plugintype_pluginname / config_param_name nếu tên tham số plugin
-v, --value = giá trị cấu hình config_value nếu không có chế độ nhắc
-c, --check kiểm tra xem tên cấu hình có tồn tại hay không ';
$string['settingsnamenotexists_set_config_cli']= 'cài đặt tên {$a} không tồn tại';
$string['toofewargs']= 'đến vài đối số';
