<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_wp', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_wp
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['aboutexportfile']= 'Giới thiệu về tập tin này';
$string['activitycompletion']= 'Hoàn thành hoạt động';
$string['allcohorts']= 'Tất cả các nhóm';
$string['allcohorts_help']= 'Tất cả các nhóm mà người dùng này có thể quản lý';
$string['alldata']= 'Tất cả dữ liệu';
$string['allsystemcohorts']= 'Tất cả các nhóm hệ thống';
$string['certificates']= 'Chứng chỉ';
$string['certificatetemplates']= 'Mẫu chứng chỉ';
$string['certificatetemplatesdetails']= 'Chi tiết mẫu chứng chỉ';
$string['cleanupexpiredimportsexports']= 'Dọn dẹp hàng xuất khẩu và hàng nhập khẩu hết hạn sử dụng';
$string['codechanged']= 'Mã vấn đề đã được thay đổi từ \' {$a->from} \'thành \' {$a->to} \\';
$string['cohortdetails']= 'Chi tiết nhóm';
$string['cohortdetails_help']= 'Chi tiết nhóm cho từng trường hợp đã chọn';
$string['cohortmember']= 'Thành viên nhóm';
$string['cohortmembers']= 'Thành viên nhóm';
$string['cohortmembers_help']= 'Chỉ thông tin thành viên thuần tập mới được bao gồm, nhưng người dùng thực tế sẽ không được bao gồm';
$string['cohortsselectedcategory']= 'Nhóm thuần tập trong danh mục đã chọn';
$string['confighideparentlang']= 'Ẩn gói cha của Workplace';
$string['confighideparentlangdesc']= 'Nếu được bật, gói ngôn ngữ gốc của bất kỳ gói ngôn ngữ Workplace đã cài đặt nào sẽ không được hiển thị trong menu ngôn ngữ. Ví dụ: \'English (en) \' không được hiển thị nếu \'English for Workplace (en_wp) \' được cài đặt. ';
$string['confirmdeleteexport']= 'Bạn có chắc chắn muốn xóa bản xuất này không?';
$string['confirmdeleteimport']= 'Bạn có chắc chắn muốn xóa lần nhập này không?';
$string['confirmprevbutton']= 'Rời khỏi trang web? Những thay đổi bạn đã thực hiện có thể không được lưu. ';
$string['confirmprocess']= 'Bằng cách nhấp vào "Tiếp tục", quá trình sẽ bắt đầu trong thời gian ngắn. Bạn sẽ nhận được một thông báo khi nó kết thúc. ';
$string['conflictidnumber']= 'Thêm hậu tố số vào số id nhóm thuần tập';
$string['conflicts']= 'Xung đột';
$string['conflictshortname']= 'Thêm hậu tố số vào tên viết tắt của khóa học';
$string['content']= 'Nội dung';
$string['copiedtoclipboard']= 'Văn bản được sao chép vào khay nhớ tạm';
$string['copytoclipboard']= 'Sao chép vào khay nhớ tạm';
$string['coursereset']= 'Đặt lại khóa học cho người dùng cá nhân';
$string['coursesadmintab']= 'Đang học';
$string['createdby']= 'Được tạo bởi';
$string['csvcolumn']= 'Cột CSV';
$string['csvdefaultvalue']= 'Giá trị mặc định';
$string['csvfieldsmapping']= 'Ánh xạ trường';
$string['csvmappingnotspecified']= 'Không được chỉ định';
$string['csvwpcolumn']= 'Nơi làm việc Moodle';
$string['descriptionformat']= 'Định dạng mô tả';
$string['descriptionformatdefault']= 'Định dạng mô tả mặc định';
$string['destination']= 'Điểm đến';
$string['doexport']= 'Xuất';
$string['doimport']= 'Nhập';
$string['entitiescountpostfix']= A (9351 -) a;
$string['entitycertificateissues']= 'Các vấn đề về chứng chỉ';
$string['entitycertificateissueuser']= 'Cấp chứng chỉ: {$a}';
$string['entitycoursereset']= 'Dữ liệu đặt lại khóa học';
$string['entityidentifier']A
$string['errorcantdeleteexport']= 'Không thể xóa xuất';
$string['errorcantdeleteimport']= 'Không thể xóa nhập';
$string['errorcohortsameidnumber']= 'Các nhóm có cùng số id đã tồn tại';
$string['errorcouldnotallocatecohort']= 'Không thể phân bổ người dùng \' {$a->originaluserfullname} \'cho nhóm thuần tập \' {$a->name} \\';
$string['errorcouldnotimportissue']= 'Không thể nhập chứng chỉ đã cấp cho \' {$a} \\';
$string['errorcoursesdonotexist']= 'Một số khóa học không tồn tại';
$string['errorcoursessameshortname']= 'Các khóa học có cùng tên viết tắt đã tồn tại';
$string['errorcustomfielddoesnotexist']= 'Trường tùy chỉnh không tồn tại, không thể nhập dữ liệu \' {$a} \\';
$string['errorcustomfieldnotfound']= 'Không tìm thấy trường hợp trường tùy chỉnh';
$string['errorcustomfieldnotfounddetail']= 'Trường tùy chỉnh \' {$a} \'không tìm thấy';
$string['eventcoursemodulereset']= 'Đặt lại mô-đun khóa học cho người dùng cá nhân';
$string['eventcoursereset']= 'Đặt lại khóa học cho người dùng cá nhân';
$string['eventexportcreated']= 'Đã tạo xuất khẩu';
$string['eventexportdeleted']= 'Đã xóa xuất khẩu';
$string['eventexportupdated']= 'Đã cập nhật xuất khẩu';
$string['eventimportcreated']= 'Đã tạo nhập khẩu';
$string['eventimportdeleted']= 'Nhập đã xóa';
$string['eventimportupdated']= 'Đã cập nhật nhập khẩu';
$string['export_certificate_templates_help']= 'Xuất chi tiết mẫu bao gồm cả hình ảnh.';
$string['export_content']= 'Chi tiết mẫu chứng chỉ';
$string['export_content_help']= 'Mẫu, trang và phần tử chứng chỉ.';
$string['exportcoursecontent']= 'Bản sao lưu khóa học không bao gồm dữ liệu người dùng';
$string['exportcoursecontent_help']= 'Xuất bản sao lưu khóa học cho từng phiên bản đã chọn';
$string['exported']= 'Đã xuất';
$string['exporter']= 'Nhà xuất khẩu';
$string['exporterdesc']= 'Các chứng chỉ và mẫu đã cấp';
$string['exporterdescription']= 'Các khóa học không có dữ liệu người dùng, sử dụng cấu hình sao lưu khóa học mặc định';
$string['exporterdescriptioncohorts']= 'Nhóm thuần tập, bao gồm các thành viên nhóm không có dữ liệu người dùng';
$string['exporternotavailable']= 'Exporter \' {$a} \'không có sẵn ở đây';
$string['exporternotfound']= 'Không thể tìm thấy nhà xuất khẩu \' {$a} \\';
$string['exportgeneralsettings']= 'Cài đặt chung';
$string['exportgeneralsettingsdesc']= 'Chọn nhà xuất khẩu bạn muốn sử dụng. Trong bước tiếp theo, bạn sẽ có thể thu hẹp lựa chọn của mình và chỉ định phần tử nào bạn muốn xuất. ';
$string['exportimport']= 'Di chuyển';
$string['exportimportconflictheader']= 'Phiên bản trùng lặp \' {$a} \'đã tồn tại';
$string['exportimportconflictsuffix']= 'Thêm hậu tố số vào trường \' {$a} \'';
$string['exportimportentityunavailable']= '{$a} (Không có)';
$string['exportimporterrorentityexists']= 'Một phiên bản có cùng \' {$a} \'đã tồn tại';
$string['exportimportfieldchanged']= 'Đã thay đổi trường \' {$a->field} \'from \' {$a->from} \'to \' 84f370fd-4ff3-470f-abbf-a29a33\d74f5b \ a29a33\d74f5;
$string['exportimportstatuscompleted']= 'Thành công';
$string['exportimportstatuscreated']= 'Chưa sẵn sàng';
$string['exportimportstatuserror']= 'Lỗi';
$string['exportimportstatusinprogress']= 'Đang tiến hành';
$string['exportimportstatusscheduled']= 'Đã lên lịch';
$string['exportimportuserfieldserror']= 'Không thể nhập trường hồ sơ người dùng \' {$a} \\';
$string['exportimportusersall']= 'Chọn tất cả người dùng';
$string['exportimportusersdescription']= 'Người dùng trang web và người thuê nhà';
$string['exportimportuserserror']= 'Không thể tạo người dùng \' {$a} \\';
$string['exportimportusersmanual']= 'Chọn người dùng theo cách thủ công ...';
$string['exportimportuserspicture']= 'Hình ảnh người dùng';
$string['exportimportusersprofile']= 'Hồ sơ người dùng';
$string['exportimportuserssuccess']= 'Người dùng đã tạo \' {$a} \\';
$string['exportimportuserssuspended']= 'Bao gồm những người dùng bị tạm ngưng';
$string['exportimportuserstenant']= 'Chọn tất cả người dùng từ \' {$a} \\';
$string['export_issued']= 'Chứng chỉ đã cấp';
$string['export_issued_help']= 'Chứng chỉ được cấp cho người dùng. Bản sao của chính người dùng sẽ không được bao gồm. ';
$string['exportnotfound']= 'Không tìm thấy kết xuất';
$string['exportnotice']= 'Tệp được xuất sẽ chứa các cài đặt giống như cài đặt được đặt làm mặc định trên trang web này khi tạo bản sao lưu khóa học tiêu chuẩn. Không có dữ liệu người dùng sẽ được bao gồm ';
$string['exportoptions']= 'Tùy chọn';
$string['exportoptionsdesc']= 'Chỉ định phần tử bạn muốn xuất bằng cách chọn chúng.';
$string['exportreview']= 'Xem lại';
$string['exportreviewdesc']= 'Kiểm tra xem mọi thứ có chính xác không trước khi xuất tệp.';
$string['exports']= 'Xuất khẩu';
$string['exportstatus']= 'Trạng thái';
$string['filecontent']= 'Nội dung tập tin';
$string['grade']= 'Lớp';
$string['idnumberchanged']= 'Số ID đã được thay đổi từ \' {$a->from} \'thành \' {$a->to} \\';
$string['importallselectedcategory']= 'Nhập tất cả vào danh mục đã chọn';
$string['importallsystemcontext']= 'Nhập tất cả vào ngữ cảnh hệ thống';
$string['importchoosetenant']= 'Chọn người thuê';
$string['importconflictcreatecourse']= 'Tạo khóa học trống';
$string['importconflictcreatecourseincategory']= 'Tạo khóa học trống trong danh mục \' {$a} \\';
$string['importconflictincategory']= 'trong danh mục';
$string['importconflictinstances']= 'Phiên bản ({$a}):';
$string['importconflicts']= 'Xung đột';
$string['importconflictsdesc']= 'Giải quyết xung đột, nếu cần.';
$string['importconflictskip']= 'Không nhập';
$string['import_content']= 'Chi tiết mẫu chứng chỉ';
$string['import_content_help']= 'Mẫu, trang và phần tử chứng chỉ.';
$string['importcoursecontent']= 'Bản sao lưu khóa học không bao gồm dữ liệu người dùng';
$string['importcoursecontent_help']= 'Nhập sao lưu khóa học cho mỗi phiên bản đã chọn';
$string['importdestination']= 'Điểm đến';
$string['imported']= 'Đã nhập';
$string['importer']= 'Nhà nhập khẩu';
$string['importformat']= 'Định dạng tệp';
$string['importformatauto']= 'Tự động phát hiện';
$string['importformatcsv']= 'CSV';
$string['importformatworkplace']= 'Định dạng nơi làm việc';
$string['importfromfile']= 'Nhập mới từ tệp này';
$string['importgeneralsettings']= 'Cài đặt chung';
$string['importgeneralsettingsalt']= 'Chọn điểm đến cho dữ liệu đã nhập. Bạn sẽ có thể chỉ định phần tử nào bạn muốn nhập trong bước tiếp theo. ';
$string['importgeneralsettingsdesc']= 'Chọn điểm đến và chuyển ngày nếu cần. Bạn sẽ có thể chỉ định phần tử nào bạn muốn nhập trong bước tiếp theo. ';
$string['importincrementidnumber']= 'Thêm hậu tố số vào số ID';
$string['importintothecurrenttenant']= 'Nhập vào đối tượng thuê hiện tại';
$string['import_issued']= 'Chứng chỉ đã cấp';
$string['import_issued_help']= 'Các vấn đề của chứng chỉ này cho người dùng';
$string['importlogerror']= 'Không thể nhập mẫu chứng chỉ \' {$a->name} \\';
$string['importlogexception']= 'Ngoại lệ: {$a}';
$string['importlogfailed']= 'Không thể nhập khóa học \' {$a->fullname} \\';
$string['importlogfailedcohort']= 'Không thể nhập nhóm thuần tập \' {$a->name} \\';
$string['importlogsuccess']= 'Đã tạo khóa học mới \' <a href="{$a->url}"> {$a->fullname} </a> \\';
$string['importlogsuccesscertificates']= 'Đã tạo mẫu chứng chỉ mới \' <a href="{$a->url}"> {$a->name} </a> \'với {$a->pagescount} trang và {$a->elementscount} phần tử ';
$string['importlogsuccesscohort']= 'Đã tạo nhóm thuần tập mới \' <a href="{$a->url}"> {$a->name} </a> \\';
$string['importlogsuccesscohortallocations']= 'Đã phân bổ người dùng \' {$a->userfullname} \'vào nhóm thuần tập \' {$a->name} \\';
$string['importlogsuccessissue']= 'Đã tạo vấn đề chứng chỉ mới trên \' {$a->template} \'cho người dùng: \' {$a->originaluserfullname} \\';
$string['importnotenant']= 'Có sẵn cho tất cả người thuê nhà';
$string['importnotfound']= 'Không tìm thấy nhập khẩu';
$string['importoptions']= 'Tùy chọn';
$string['importoptionsdesc']= 'Chỉ định phần tử bạn muốn nhập bằng cách chọn chúng.';
$string['importproblem']= 'Bài toán: {$a}';
$string['importproblemaffects']= 'Nó ảnh hưởng đến:';
$string['importreview']= 'Xem lại';
$string['importreviewdesc']= 'Kiểm tra xem mọi thứ có chính xác không trước khi nhập tệp.';
$string['imports']= 'Nhập khẩu';
$string['importselectsource']= 'Chọn nguồn';
$string['importselectsourcedesc']= 'Tải lên tệp CSV hoặc Moodle Workplace hợp lệ. Trong các bước tiếp theo, bạn sẽ có thể xác định các phần tử bạn muốn nhập từ tệp. ';
$string['importselecttenant']= 'Chọn người thuê ...';
$string['importsetidnumbertoempty']= 'Đặt số ID thành chuỗi trống';
$string['importsolution']= 'Lời giải:';
$string['importstatus']= 'Trạng thái';
$string['importunknownerror']= 'Lỗi không xác định {$a}';
$string['importunknownformat']= 'Không thể phát hiện định dạng tệp từ phần mở rộng, vui lòng chọn định dạng';
$string['includecoursecontent']= 'Bao gồm nội dung khóa học';
$string['includecoursecontent_help']= 'Bao gồm tất cả nội dung khóa học như hoạt động, bộ lọc, sự kiện lịch, v.v.';
$string['instances']= 'Phiên bản';
$string['instancescount']= 'Phiên bản ({$a}):';
$string['invaliddevice']= 'Bạn đang cố gắng truy cập trang Moodle Workplace bằng ứng dụng Moodle. Vui lòng tải xuống ứng dụng Moodle Workplace để tiếp tục ';
$string['loading']= 'Đang tải ...';
$string['log']= 'Nhật ký';
$string['managecoursecategories']= 'Quản lý danh mục khóa học';
$string['mappingerrorbadgeheader']= 'Một số huy hiệu không tồn tại';
$string['mappingerrorbadgelog']= 'Không tìm thấy huy hiệu {$a}';
$string['mappingerrorcohortheader']= 'Một số nhóm không tồn tại';
$string['mappingerrorcohortlog']= 'Không tìm thấy nhóm {$a}';
$string['mappingerrorcompetencyheader']= 'Một số năng lực không tồn tại';
$string['mappingerrorcompetencylog']= 'Không tìm thấy năng lực {$a}';
$string['mappingerrorcontextnotfound']= 'Không tìm thấy ngữ cảnh';
$string['mappingerrorcoursenotfound']= 'Không tìm thấy khóa học {$a}';
$string['mappingerroruserfieldheader']= 'Một số trường hồ sơ người dùng không tồn tại';
$string['mappingerroruserfieldlog']= 'Không tìm thấy trường hồ sơ người dùng {$a}';
$string['mappingerrorusernotfound']= 'Không thể tìm thấy người dùng {$a} trong đối tượng thuê hiện tại';
$string['mappingnoticecoursecreated']= 'Khóa học trống <a href="{$a->courseurl}"> {$a->fullname} </a> đã được tạo';
$string['mappingnoticecourseidnumber']= 'Không tìm thấy khóa học có tên ngắn gọn \' {$a->shortname} \'. Đã tìm thấy <a href="{$a->courseurl}"> Một khóa học khác </a> với idnumber \'{$a->idnumber} \', nhưng khóa học này có một tên viết tắt khác ' ;
$string['mappingnoticeuseremail']= 'Không tìm thấy người dùng có tên người dùng \' {$a->username} \'. Đã tìm thấy <a href="{$a->profileurl}"> Người dùng khác </a> có email {$a->email} nhưng người dùng này có tên người dùng khác ';
$string['messagefullexportcomplete']= 'Quá trình xuất của bạn đã được hoàn tất vào {$a->date}
Trạng thái: {$a->status}
Nhấp vào <a href="{$a->url}"> đây </a> để xem chi tiết ';
$string['messagefullimportcomplete']= 'Quá trình nhập của bạn đã hoàn tất trên {$a->date}
Trạng thái: {$a->status}
Nhấp vào <a href="{$a->url}"> đây </a> để xem chi tiết ';
$string['messageprovider:exportcomplete']= 'Xuất hoàn tất';
$string['messageprovider:importcomplete']= 'Nhập xong';
$string['noavailableimporter']= 'Chúng tôi không thể tìm thấy trình nhập có sẵn cho tệp này.';
$string['noavailablepostfix']= '(Không có)';
$string['noconflictsfound']= 'Không tìm thấy xung đột nào';
$string['nodetails']= 'Không tìm thấy chi tiết nào';
$string['nopermissioncategoryimport']= 'Bạn không có quyền nhập danh mục này.';
$string['nopermissioncategoryrestore']= 'Bạn không có quyền khôi phục trên danh mục này.';
$string['nopermissionform']= 'Bạn không có quyền truy cập biểu mẫu này.';
$string['nopermissiontab']= 'Bạn không có quyền truy cập trang này.';
$string['nothing']= 'Không có gì';
$string['nothingtoexport']= 'Không có gì để xuất';
$string['nothingtoimport']= 'Không có gì để nhập';
$string['notpossible']= 'Không thể';
$string['outcomes']= 'Kết quả';
$string['performanceinfo']= 'Thông tin về hiệu suất của tab (DB đọc / ghi: {$a->reads} / {$a->writes})';
$string['pluginname']= 'Nơi làm việc';
$string['privacy:metadata:certificationid']= 'Id chứng nhận nơi xuất phát của khóa học này.';
$string['privacy:metadata:courseid']= 'Khóa học đã được đặt lại.';
$string['privacy:metadata:exportcreatedby']= 'ID của người dùng đã thực hiện xuất.';
$string['privacy:metadata:exportstatus']= 'Trạng thái xuất.';
$string['privacy:metadata:grade']= 'Xếp hạng người dùng đã có trong khóa học trước khi nó được đặt lại.';
$string['privacy:metadata:importcreatedby']= 'ID của người dùng đã thực hiện nhập.';
$string['privacy:metadata:importstatus']= 'Trạng thái nhập.';
$string['privacy:metadata:programid']= 'Id chương trình nơi bắt nguồn của khóa học này.';
$string['privacy:metadata:reason']= 'Lý do tại sao khóa học này được đặt lại.';
$string['privacy:metadata:resetinfo']= 'Thông tin về những gì đã được đặt lại trong khóa học.';
$string['privacy:metadata:resetstatus']= 'Trạng thái của thiết lập lại.';
$string['privacy:metadata:tenantid']= 'ID của người thuê liên quan.';
$string['privacy:metadata:timecreated']= 'Thời gian tạo.';
$string['privacy:metadata:timemodified']= 'Thời gian đã sửa đổi.';
$string['privacy:metadata:timerequested']= 'Thời gian đã được đặt lại đã được yêu cầu.';
$string['privacy:metadata:tool_wp_course_reset']= 'Đặt lại khóa học.';
$string['privacy:metadata:tool_wp_export']= 'Thông tin về các lần xuất được thực hiện trên trang web.';
$string['privacy:metadata:tool_wp_import']= 'Thông tin về các lần nhập được thực hiện trên trang web.';
$string['privacy:metadata:userid']= 'Người dùng đã đặt lại khóa học.';
$string['privacy:metadata:usermodified']= 'Người dùng đã sửa đổi.';
$string['privacy:metadata:userrequested']= 'Người dùng đã yêu cầu đặt lại khóa học.';
$string['privacy:metadata:wascompleted']= 'Nếu khóa học được người dùng hoàn thành trước khi đặt lại.';
$string['problem']= 'Vấn đề';
$string['proceed']= 'Tiếp tục';
$string['processing']= 'Đang xử lý';
$string['quotedentity']= A \'{$a} \\ a;
$string['reason']= 'Lý do thiết lập lại';
$string['refresh']= 'Làm mới';
$string['reg_moodleproduct']= 'Sản phẩm Moodle ({$a})';
$string['reg_wpactiveusers']= 'Số người dùng duy nhất đã đăng nhập vào tháng trước ({$a})';
$string['reg_wpparticipantnumberaverage']= 'Số người tham gia hoạt động trung bình trong tháng trước ({$a})';
$string['reg_wpplugins']= 'Danh sách các plugin được cài đặt và kích hoạt, số lượng phiên bản ({$a})';
$string['resetinfo']= 'Đặt lại thông tin';
$string['resetstatus']= 'Đặt lại trạng thái';
$string['safenavigation']= 'Sẽ an toàn khi tiếp tục điều hướng trên trang web.';
$string['selectallcohortsinthisfile']= 'Chọn tất cả các nhóm trong tệp này';
$string['selectallcourses']= 'Chọn tất cả các khóa học trong {$a} và các danh mục phụ';
$string['selectallcoursesinthisfile']= 'Chọn tất cả các khóa học trong tập tin này';
$string['selectalltemplates']= 'Chọn tất cả các mẫu chứng chỉ';
$string['selectalltemplatesinfile']= 'Chọn tất cả các mẫu chứng chỉ trong tệp này';
$string['selectatleastonecategory']= 'Chọn ít nhất một danh mục';
$string['selectatleastonecohort']= 'Chọn ít nhất một nhóm thuần tập';
$string['selectatleastonecourse']= 'Chọn ít nhất một khóa học';
$string['selectatleastonetemplate']= 'Chọn ít nhất một mẫu';
$string['selectcategoriesmanually']= 'Chọn danh mục theo cách thủ công ...';
$string['selectcoursecategory']= 'Chọn danh mục khóa học';
$string['selectcoursesmanually']= 'Chọn các khóa học theo cách thủ công ...';
$string['selectedcoursecategory']= 'Loại khóa học đã chọn: {$a}';
$string['selectexporter']= 'Chọn nhà xuất khẩu';
$string['selectimporter']= 'Chọn nhà nhập khẩu';
$string['selectmanually']= 'Chọn thủ công ...';
$string['selectmanuallycategories']= 'Chọn danh mục và danh mục phụ theo cách thủ công';
$string['selectmanuallycertificates']= 'Chọn mẫu chứng chỉ theo cách thủ công';
$string['shortnamechanged']= 'Tên viết tắt được thay đổi từ \' {$a->from} \'thành \' {$a->to} \\';
$string['showless']= 'Hiển thị ít hơn';
$string['showxmore']= 'Hiển thị thêm {$a} ...';
$string['solution']= 'Giải pháp';
$string['stepx']= 'Bước {$a}.';
$string['tenant']= 'Người thuê nhà';
$string['thissite']= '(Trang web này)';
$string['timerequested']= 'Thời gian được yêu cầu';
$string['timereseted']= 'Đặt lại thời gian';
$string['uploadimportfile']= 'Tải lên một tập tin';
$string['userrequested']= 'Người dùng đã yêu cầu';
$string['viewexport']= 'Xem xuất';
$string['viewimport']= 'Xem nhập';
$string['viewlicense']= 'Xem giấy phép';
$string['wascompleted']= 'Đã hoàn thành';
$string['workplacelicense']= 'Mã Moodle Workplace ™ được cấp phép kép theo các điều khoản của cả Giấy phép Công cộng GNU phiên bản 3.0, ngày 29 tháng 6 năm 2007 ("GPL") và các điều khoản của Giấy phép Moodle Workplace độc ​​quyền ("MWL") được kiểm soát chặt chẽ bởi Moodle Pty Ltd và các đối tác cao cấp được chứng nhận của nó. Bất cứ nơi nào tồn tại các điều khoản mâu thuẫn, các điều khoản của MWL là ràng buộc và sẽ được ưu tiên áp dụng.
Gói phần mềm mở Moodle® do GPL quản lý sẽ được Martin Dougiamas bảo vệ bản quyền từ năm 1999 trở đi với các phần do những người đóng góp khác đóng góp / có bản quyền. Nó có thể được tải xuống miễn phí tại "download.moodle.org". Phần mềm mở Moodle® như vậy và tài liệu tương ứng được phân phối với hy vọng rằng chúng sẽ hữu ích, nhưng không có bất kỳ bảo hành nào; mà không có bảo đảm ngụ ý về khả năng bán được hoặc tính phù hợp cho một mục đích cụ thể.
Bằng cách truy cập Moodle Workplace ™ được điều chỉnh bởi MWL, bạn đồng ý rằng bạn đã ký một MWL với Moodle Pty Ltd để đảm bảo (trong số những thứ khác) rằng bạn:
- sẽ không sở hữu Mã Moodle Workplace ™ nếu không tuân theo các điều khoản của MWL;
- sẽ ngừng sử dụng Moodle Workplace ™ và xóa ngay lập tức tất cả các bản sao của Mã Moodle Workplace ™ khỏi máy chủ và bất kỳ máy tính nào dưới sự kiểm soát của bạn nếu bạn không còn là khách hàng của Đối tác cao cấp được chứng nhận của Moodle. Bạn phải xác nhận điều này bằng văn bản cho Moodle trong vòng 7 ngày kể từ khi sự kiện đó xảy ra;
- sẽ không phân phối các bản sao của Mã Moodle Workplace ™ cho bất kỳ bên thứ ba nào không phải là một bên của MWL mà bạn đã ký và bạn phải bồi thường cho Moodle về bất kỳ tổn thất nào mà Moodle phải gánh chịu do bạn không tuân thủ MWL;
- đồng ý rằng bất kỳ cải tiến nào đối với Mã Moodle Workplace ™ phải được chia sẻ rõ ràng với Moodle Pty Ltd và các đối tác cao cấp được chứng nhận của nó, với các quyền đó trong các cải tiến được giao cho Moodle Pty Ltd, do đó cho phép Moodle Pty Ltd có toàn quyền bao gồm các cải tiến đó trong các phiên bản tương lai của Mã Moodle Workplace ™.
- bồi thường và giữ cho cả Moodle Pty Ltd và các đối tác cao cấp được chứng nhận của nó vô hại đối với bất kỳ thiệt hại, tiền phạt, hình phạt hoặc trách nhiệm pháp lý nào khác phát sinh từ bất kỳ dữ liệu đầu vào nào của bạn và người dùng cuối của bạn.
Các trang web Moodle Workplace ™ có thể bao gồm một pixel theo dõi cho các mục đích thống kê và giám sát tuân thủ. Không có dữ liệu cá nhân nào được thu thập hoặc xử lý, chỉ có URL của trang web.
Đây chỉ là bản tóm tắt: để biết các điều khoản đầy đủ của MWL, vui lòng tham khảo MWL mà bạn đã ký. ';
$string['workplacelicenseheader']= 'Giấy phép Moodle Workplace';
$string['workplacelicensenotagreed']= 'Bạn không thể xem nội dung này cho đến khi quản trị viên trang web đồng ý với giấy phép Moodle Workplace.';
$string['wp:manageexportimport']= 'Quản lý xuất / nhập nơi làm việc';
$string['wp:useexportimport']= 'Sử dụng xuất / nhập Workplace';
