<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_securityquestions', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_securityquestions
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['answerquestionspagestring']= 'Yêu cầu xác minh câu hỏi bảo mật';
$string['badconfigload']= 'Không thể tải tệp cấu hình mẫu. Kiểm tra các biến là chính xác và mẫu đó nằm trong thư mục mẫu. - ';
$string['configloc']= 'tại vị trí:';
$string['configpath']= '/config_policies/{$a}.php';
$string['forcedconfig']= 'Cài đặt chỉ được đọc, cấu hình bị ép buộc trong tệp mẫu:';
$string['formaddquestion']= 'Thêm câu hỏi';
$string['formalreadyanswered']= 'Câu hỏi với câu trả lời đã đặt';
$string['formanswerfailed']= 'Câu trả lời không khớp với câu trả lời đã ghi.';
$string['formanswerquestion']= 'Nhập câu trả lời cho câu hỏi {$a}:';
$string['formclearresponses']= 'Xóa phản hồi của người dùng:';
$string['formclearresponsesdesc']= 'Nhập tên người dùng hoặc email để xóa phản hồi cho người dùng.';
$string['formclearresponsestable']= 'Xóa câu trả lời';
$string['formcurrentquestions']= 'Câu hỏi hiện tại: {$a}';
$string['formdeleteresponse']= 'Xóa câu trả lời';
$string['formdeprecate']= 'Câu hỏi không được chấp nhận';
$string['formdeprecateentry']= 'Nhập ID câu hỏi để không dùng nữa:';
$string['formdeprecatenotfound']= 'Câu hỏi không tồn tại';
$string['formduplicateresponse']= 'Bạn không thể trả lời cùng một câu hỏi hai lần.';
$string['formgraceperiodtimerem']= 'Bạn hiện đang trong thời gian gia hạn cho các câu hỏi bảo mật. Trong thời gian này, bạn có thể chọn không trả lời các câu hỏi bảo mật và sẽ được nhắc vào lần đăng nhập tiếp theo.
Sau khi thời gian gia hạn kết thúc, bạn phải trả lời các câu hỏi bảo mật trước khi truy cập phần còn lại của hệ thống. Thời gian gia hạn làm lại: {$a} ';
$string['formlockedout']= 'Tài khoản bị khóa khi đặt lại mật khẩu. Vui lòng liên hệ với Quản trị viên hệ thống để được hỗ trợ thêm. ';
$string['formlockedoutusers']= 'Người dùng bị khóa';
$string['formnewquestion']= 'Câu hỏi mới:';
$string['formnolockedusers']= 'Không tìm thấy người dùng bị khóa nào';
$string['formnoquestions']= 'Không có câu hỏi nào được đặt ra';
$string['formquestionadded']= 'Đã thêm câu hỏi thành công: {$a}';
$string['formquestiondeleted']= 'Đã xóa thành công ID câu hỏi {$a}.';
$string['formquestiondeprecated']= 'Câu hỏi ID {$a} không được chấp nhận thành công.';
$string['formquestionentry']= 'Nhập câu hỏi để thêm vào nhóm câu hỏi:';
$string['formquestioninfo']= 'Để tăng cường bảo mật, bạn không thể xem các câu trả lời đã lưu. Bạn chỉ có thể lưu câu trả lời mới cho các câu hỏi hoặc xóa câu trả lời. ';
$string['formquestionnotdeleted']= 'Không thể xóa Câu hỏi {$a}.';
$string['formquestionnotdeprecated']= 'Không thể chấp nhận câu hỏi {$a}.';
$string['formquestionnumtext']= 'Câu hỏi: {$a}';
$string['formrecordnewresponse']= 'Ghi lại câu trả lời mới cho câu hỏi:';
$string['formremindme']= 'Nhắc tôi vào lần đăng nhập tiếp theo';
$string['formresetbutton']= 'Xóa câu trả lời';
$string['formresetid']= 'Nhập ID tài khoản để được mở khóa:';
$string['formresetlockout']= 'Đặt lại khóa';
$string['formresetnotfound']= 'Người dùng không tồn tại';
$string['formresetnotnumber']= 'ID phải là một số';
$string['formresponsedeleted']= 'Phản hồi đã được xóa thành công.';
$string['formresponseempty']= 'Câu trả lời không được để trống.';
$string['formresponseentrybox']= 'Nhập câu trả lời cho câu hỏi đã chọn:';
$string['formresponsenotdeleted']= 'Không thể xóa câu trả lời. Trước tiên, hãy thêm nhiều câu trả lời hoặc ghi lại câu trả lời mới cho câu hỏi. ';
$string['formresponsenotrecorded']= 'Đã xảy ra lỗi khi thiết lập (các) phản hồi. Vui lòng thử lại.';
$string['formresponserecorded']= '(Các) phản hồi được ghi lại thành công.';
$string['formresponseselectbox']= 'Chọn câu hỏi để trả lời:';
$string['formresponsesremaining']= '{$a} yêu cầu phản hồi bổ sung.';
$string['formsaveresponse']= 'Lưu (các) phản hồi';
$string['formselectquestion']= 'Chọn một câu hỏi';
$string['formstatusactive']= 'Đang hoạt động - {$a} câu hỏi bổ sung cần thiết.';
$string['formstatusnotactive']= 'Không hoạt động - {$a} yêu cầu câu hỏi bổ sung.';
$string['formtablecount']= 'Số lượng sử dụng';
$string['formtabledeprecate']= 'Không được dùng nữa';
$string['formtablequestion']= 'Câu hỏi';
$string['formusernameplaceholder']= 'Tên người dùng hoặc Email';
$string['formuserresponsescleared']= 'Đã xóa thành công câu trả lời của người dùng';
$string['formuserunlocked']= 'Người dùng đã mở khóa thành công.';
$string['injectedquestiontitle']= 'Câu hỏi bảo mật {$a->num}: {$a->content}';
$string['pluginname']= 'Câu hỏi bảo mật';
$string['privacy:metadata:preference:tool_securityquestions_logintime']= 'Thời gian người dùng đăng nhập lần đầu tiên và kích hoạt thời gian gia hạn trả lời câu hỏi bảo mật.';
$string['privacy:metadata:tool_securityquestions']= 'Dữ liệu câu hỏi bảo mật';
$string['privacy:metadata:tool_securityquestions_ans']= 'Bảng này lưu trữ thông tin về việc liệu câu hỏi ngẫu nhiên nào đã được chọn để trình bày cho người dùng, và lựa chọn ngẫu nhiên cuối cùng là khi nào.';
$string['privacy:metadata:tool_securityquestions_ans:qid']= 'ID câu hỏi của câu hỏi đã được chọn cho người dùng.';
$string['privacy:metadata:tool_securityquestions_ans:timecreated']= 'Thời gian câu hỏi này được chọn cho người dùng.';
$string['privacy:metadata:tool_securityquestions_ans:userid']= 'ID của người dùng để theo dõi các câu hỏi cần trả lời.';
$string['privacy:metadata:tool_securityquestions_loc']= 'Bảng này lưu trữ thông tin về việc người dùng có bị khóa khi đặt lại mật khẩu của họ hay không, cũng như số lần nhập câu hỏi bảo mật không thành công.';
$string['privacy:metadata:tool_securityquestions_loc:counter']= 'Số lần người dùng không xác thực được câu hỏi bảo mật kể từ lần đặt lại mật khẩu cuối cùng.';
$string['privacy:metadata:tool_securityquestions_loc:locked']= 'Trạng thái bị khóa của người dùng.';
$string['privacy:metadata:tool_securityquestions_loc:userid']= 'ID của người dùng để theo dõi trạng thái bị khóa.';
$string['privacy:metadata:tool_securityquestions_res']= 'Bảng này lưu trữ thông tin về câu trả lời của người dùng đối với các câu hỏi bảo mật, bao gồm câu trả lời được băm và câu hỏi nào đã được trả lời.';
$string['privacy:metadata:tool_securityquestions_res:qid']= 'Câu hỏi LÀ câu trả lời tương ứng với.';
$string['privacy:metadata:tool_securityquestions_res:response']= 'Câu trả lời được băm an toàn mà người dùng đã nhập làm câu trả lời cho một câu hỏi.';
$string['privacy:metadata:tool_securityquestions_res:userid']= 'ID của người dùng có phản hồi này.';
$string['questionaddedeventname']= 'Quản trị viên đã thêm câu hỏi bảo mật.';
$string['questiondeletedeventname']= 'Quản trị viên đã xóa câu hỏi bảo mật.';
$string['questiondeprecatedeventname']= 'Câu hỏi bảo mật quản trị viên không được chấp nhận.';
$string['resetuserpagename']= 'Đặt lại khóa câu hỏi bảo mật';
$string['securityquestions:questionsaccess']= 'Tương tác câu hỏi bảo mật';
$string['securityquestionssettings']= 'Cài đặt câu hỏi bảo mật';
$string['setquestionspagename']= 'Sửa đổi câu hỏi bảo mật';
$string['setresponsespagestring']= 'Đặt câu trả lời cho các câu hỏi bảo mật';
$string['setresponsessettingsmenu']= 'Câu trả lời câu hỏi bảo mật';
$string['setsecurityquestionspagestring']= 'Sửa đổi câu hỏi bảo mật';
$string['settingsanswerquestions']= 'Các câu hỏi cần thiết để xác minh';
$string['settingsanswerquestionsdesc']= 'Số lượng câu hỏi cần thiết để người dùng tự xác minh để thực hiện các hành động bảo mật tài khoản.';
$string['settingsenabledesc']= 'Kiểm tra để kích hoạt xác thực câu hỏi bảo mật';
$string['settingsenablename']= 'Bật plugin';
$string['settingsgraceperiod']= 'Thời gian gia hạn phản hồi';
$string['settingsgraceperioddesc']= 'Khoảng thời gian mà người dùng có thể chọn không đặt câu trả lời câu hỏi, ngay cả khi các câu hỏi bắt buộc được bật. Sau khoảng thời gian này, người dùng
chưa đặt câu trả lời sẽ buộc phải đặt câu trả lời. Đặt điều khiển này thành 0 để vô hiệu hóa thời gian gia hạn. ';
$string['settingsinjectchangepw']= 'Thay đổi hình thức mật khẩu.';
$string['settingsinjectpoints']= 'Điểm tiêm cho câu hỏi bảo mật';
$string['settingsinjectpointsdesc']= 'Chọn tất cả các biểu mẫu mà câu hỏi bảo mật sẽ được đưa vào.';
$string['settingsinjectsetpw']= 'Đặt dạng mật khẩu.';
$string['settingslockoutnum']= 'Trả lời lần thử trước khi khóa máy';
$string['settingslockoutnumdesc']= 'Số lần thử trả lời câu hỏi mà người dùng được phép trước khi bị khóa khi đặt lại mật khẩu. Đặt điều khiển này thành 0 để tắt khóa. ';
$string['settingsmandatoryquestions']= 'Câu hỏi bảo mật bắt buộc';
$string['settingsmandatoryquestionsdesc']= 'Bật kiểm soát này để làm cho các câu hỏi bảo mật trở nên bắt buộc. Nếu bị vô hiệu hóa, người dùng sẽ vẫn được nhắc trả lời các câu hỏi khi đăng nhập,
nhưng họ sẽ có thể điều hướng đi. Vào lần đăng nhập tiếp theo, họ sẽ lại được nhắc. ';
$string['settingsminquestions']= 'Số câu hỏi bảo mật hoạt động tối thiểu';
$string['settingsminquestionsdesc']= 'Nhập số câu hỏi bảo mật tối thiểu có thể hoạt động tại một thời điểm. Các câu hỏi khác phải được thêm vào trước khi các câu hỏi khác không được chấp nhận. ';
$string['settingsminuserquestions']= 'Số câu hỏi người dùng trả lời tối thiểu';
$string['settingsminuserquestionsdesc']= 'Nhập số câu hỏi bảo mật hoạt động tối thiểu mà người dùng phải trả lời trước khi họ không được nhắc nữa.';
$string['settingsquestionduration']= 'Thời lượng câu hỏi';
$string['settingsquestiondurationdesc']= 'Khoảng thời gian mà câu hỏi hoạt động khi được chọn trên trang bảo mật cao. Sau khoảng thời gian này, các câu hỏi mới sẽ được chọn. ';
$string['taskcleantables']= 'Làm sạch cơ sở dữ liệu plugin của những người dùng đã bị xóa';
$string['templateforced-on']= 'Mẫu này thực thi cài đặt mặc định cho các kiểm soát bảo mật và đảm bảo rằng người dùng sẽ luôn có đủ câu hỏi để trả lời và đủ câu trả lời để sử dụng cho việc xác nhận.';
$string['userlockedeventname']= 'Người dùng bị khóa không thể đặt lại mật khẩu do các lần đặt câu hỏi không thành công.';
$string['userunlockedeventname']= 'Người dùng được mở khóa từ việc đặt lại mật khẩu bởi Quản trị viên.';
