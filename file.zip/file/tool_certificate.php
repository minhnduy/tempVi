<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_certificate', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_certificate
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['addcertpage']= 'Trang mới';
$string['addelement']= 'Thêm phần tử';
$string['aissueswerecreated']= '{$a} vấn đề đã được tạo';
$string['aligncentre']= 'Trung tâm';
$string['alignleft']= 'Trái';
$string['alignment']= 'Căn chỉnh văn bản';
$string['alignment_help']= 'Căn phải của văn bản có nghĩa là tọa độ phần tử (Vị trí X và Vị trí Y) sẽ tham chiếu đến góc trên cùng bên phải của hộp văn bản, ở căn giữa chúng sẽ tham chiếu đến góc trên cùng giữa và căn trái ở góc trên cùng bên trái ';
$string['alignright']= 'Đúng';
$string['availableincourses']= 'Có sẵn trong các danh mục phụ và các khóa học';
$string['availableincourses_help']= 'Bằng cách bật tùy chọn này, người dùng (có khả năng phát hành) sẽ có thể sử dụng mẫu này trong mọi khóa học bên trong danh mục đã chọn và cả các khóa học bên trong danh mục phụ của nó. Nếu tùy chọn này bị vô hiệu hóa, mẫu này sẽ chỉ có sẵn cho người dùng có khả năng gặp sự cố trong danh mục đã chọn. ';
$string['certificate']= 'Giấy chứng nhận';
$string['certificatecopy']= '{$a} (copy)';
$string['certificate_customfield']= 'Các trường tùy chỉnh chứng nhận';
$string['certificate:image']= 'Quản lý hình ảnh chứng chỉ';
$string['certificateimages']= 'Hình ảnh chứng chỉ';
$string['certificate:issue']= 'Cấp chứng chỉ cho người dùng';
$string['certificate:manage']= 'Quản lý chứng chỉ';
$string['certificates']= 'Chứng chỉ';
$string['certificatesissued']= 'Chứng chỉ được cấp';
$string['certificatesissues']= 'Các vấn đề về chứng chỉ';
$string['certificatetemplate']= 'Mẫu chứng chỉ';
$string['certificatetemplatename']= 'Tên mẫu chứng chỉ';
$string['certificatetemplates']= 'Mẫu chứng chỉ';
$string['certificate:verify']= 'Xác minh bất kỳ chứng chỉ nào';
$string['certificate:viewallcertificates']= 'Xem tất cả các mẫu chứng chỉ và các vấn đề cho người thuê hiện tại';
$string['changeelementsequence']= 'Đưa về phía trước hoặc lùi lại';
$string['code']= 'Mã';
$string['codewithlink']= 'Mã có liên kết';
$string['coursecategorywithlink']= 'Hạng mục khóa học có liên kết';
$string['createtemplate']= 'Mẫu chứng chỉ mới';
$string['customfield_previewvalue']= 'Giá trị xem trước';
$string['customfield_previewvalue_help']= 'Giá trị được hiển thị khi xem trước mẫu chứng chỉ';
$string['customfieldsettings']= 'Cài đặt trường tùy chỉnh chứng chỉ chung';
$string['customfield_visible']= 'Hiển thị';
$string['customfield_visible_help']= 'Cho phép chọn trường này trên mẫu chứng chỉ';
$string['deleteelement']= 'Xóa phần tử';
$string['deleteelementconfirm']= 'Bạn có chắc chắn muốn xóa phần tử \' {$a} \'?';
$string['deletepage']= 'Xóa trang';
$string['deletepageconfirm']= 'Bạn có chắc chắn muốn xóa trang chứng chỉ này không?';
$string['deletetemplateconfirm']= 'Bạn có chắc chắn muốn xóa mẫu chứng chỉ \' {$a} \'và tất cả dữ liệu liên quan không? Hành động này không thể được hoàn tác.';
$string['duplicate']= 'Bản sao';
$string['duplicatetemplateconfirm']= 'Bạn có chắc chắn muốn sao chép mẫu \' {$a} \'?';
$string['editcertificate']= 'Chỉnh sửa mẫu chứng chỉ \' {$a} \\';
$string['editcontent']= 'Chỉnh sửa nội dung';
$string['editdetails']= 'Chỉnh sửa chi tiết';
$string['editelement']= 'Chỉnh sửa \' {$a} \\';
$string['editelementname']= 'Chỉnh sửa tên phần tử';
$string['editpage']= 'Chỉnh sửa trang {$a}';
$string['edittemplatename']= 'Chỉnh sửa tên mẫu';
$string['elementname']= 'Tên phần tử';
$string['elementname_help']= 'Đây sẽ là tên được sử dụng để xác định phần tử này khi chỉnh sửa chứng chỉ. Lưu ý rằng điều này sẽ không hiển thị trên PDF. ';
$string['elementwidth']= 'Chiều rộng, mm';
$string['elementwidth_help']= 'Chỉ định chiều rộng của phần tử. Không (0) có nghĩa là không có ràng buộc chiều rộng. ';
$string['entitycertificate']= 'Giấy chứng nhận';
$string['entitycertificateissue']= 'Cấp chứng chỉ';
$string['entitycertificateissues']= 'Các vấn đề về chứng chỉ';
$string['errornopermissionissuecertificate']= 'Bạn không được phép cấp chứng chỉ này';
$string['eventcertificateissued']= 'Chứng chỉ được cấp';
$string['eventcertificaterevoked']= 'Chứng chỉ bị thu hồi';
$string['eventcertificateverified']= 'Chứng chỉ đã được xác minh';
$string['eventtemplatecreated']= 'Đã tạo mẫu';
$string['eventtemplatedeleted']= 'Đã xóa mẫu';
$string['eventtemplateupdated']= 'Đã cập nhật mẫu';
$string['expired']= 'Đã hết hạn';
$string['expiredcertificate']= 'Chứng chỉ này đã hết hạn';
$string['expires']= 'Hết hạn vào';
$string['font']= 'Phông chữ';
$string['fontcolour']= 'Màu';
$string['fontcolour_help']= 'Màu của phông chữ.';
$string['font_help']= 'Phông chữ được sử dụng khi tạo phần tử này.';
$string['fontsize']= 'Kích thước, pt';
$string['fontsize_help']= 'Kích thước của phông chữ tính bằng điểm.';
$string['hideshow']= 'Ẩn / hiện';
$string['invalidcolour']= 'Màu đã chọn không hợp lệ. Vui lòng nhập tên màu HTML hợp lệ hoặc màu thập lục phân gồm sáu chữ số hoặc ba chữ số. ';
$string['invalidelementwidth']= 'Vui lòng nhập một số dương.';
$string['invalidheight']= 'Chiều cao phải là một số hợp lệ lớn hơn 0.';
$string['invalidmargin']= 'Biên phải là một số hợp lệ lớn hơn 0.';
$string['invalidposition']= 'Vui lòng chọn một số dương cho vị trí {$a}.';
$string['invalidwidth']= 'Chiều rộng phải là một số hợp lệ lớn hơn 0.';
$string['issuecertificates']= 'Cấp chứng chỉ';
$string['issuedon']= 'Được cấp trên';
$string['issuenewcertificate']= 'Cấp chứng chỉ từ mẫu này';
$string['issuenewcertificates']= 'Cấp chứng chỉ mới';
$string['issuenotallowed']= 'Bạn không được phép cấp chứng chỉ từ mẫu này.';
$string['issueormangenotallowed']= 'Bạn không được phép cấp chứng chỉ từ hoặc quản lý mẫu này.';
$string['leftmargin']= 'Lề trái, mm';
$string['leftmargin_help']= 'Đây là lề trái của PDF chứng chỉ tính bằng mm.';
$string['manageelementplugins']= 'Quản lý plugin phần tử chứng chỉ';
$string['managetemplates']= 'Quản lý mẫu chứng chỉ';
$string['mappingerrorcertificateheader']= 'Một số mẫu chứng chỉ không tồn tại';
$string['mappingerrorcertificatelog']= 'Không tìm thấy chứng chỉ {$a}';
$string['messageprovider:certificateissued']= 'Chứng chỉ đã nhận';
$string['mycertificates']= 'Chứng chỉ của tôi';
$string['mycertificatesdescription']= 'Đây là những chứng chỉ bạn đã được cấp qua email hoặc tải xuống theo cách thủ công.';
$string['name']= 'Tên';
$string['nametoolong']= 'Bạn đã vượt quá độ dài tối đa được phép cho tên';
$string['noimage']= 'Không có hình ảnh';
$string['noissueswerecreated']= 'Không có vấn đề nào được tạo ra';
$string['notificationmsgcertificateissued']= 'Xin chào {$a->fullname}, <br /> <br /> Chứng chỉ của bạn đã có! Bạn sẽ tìm thấy nó ở đây:
<a href="{$a->url}"> Chứng chỉ của tôi </a> ';
$string['notificationsubjectcertificateissued']= 'Chứng chỉ của bạn đã có!';
$string['notverified']= 'Chưa được xác minh';
$string['numberofpages']= 'Số trang';
$string['oneissuewascreated']= 'Một vấn đề đã được tạo ra';
$string['outcomecertificate']= 'Cấp chứng chỉ';
$string['outcomecertificatedescription']= 'Cấp chứng chỉ \' {$a} \'cho người dùng';
$string['page']= 'Trang {$a}';
$string['pageheight']= 'Chiều cao trang, mm';
$string['pageheight_help']= 'Đây là chiều cao của PDF chứng chỉ tính bằng mm. Để tham khảo, một mảnh giấy A4 cao 297mm và một bức thư cao 279mm. ';
$string['pagewidth']= 'Chiều rộng trang, mm';
$string['pagewidth_help']= 'Đây là chiều rộng của PDF chứng chỉ tính bằng mm. Để tham khảo, một mảnh giấy A4 có chiều rộng 210mm và một bức thư có chiều rộng 216mm. ';
$string['pluginname']= 'Công cụ chứng chỉ';
$string['posx']= 'Vị trí X, mm';
$string['posx_help']= 'Đây là vị trí tính bằng mm tính từ góc trên cùng bên trái mà bạn muốn điểm tham chiếu của phần tử định vị theo hướng x.';
$string['posy']= 'Vị trí Y, mm';
$string['posy_help']= 'Đây là vị trí tính bằng mm tính từ góc trên cùng bên trái mà bạn muốn điểm tham chiếu của phần tử định vị theo hướng y.';
$string['privacy:metadata:tool_certificate:issues']= 'Danh sách các chứng chỉ đã cấp';
$string['privacy:metadata:tool_certificate_issues:code']= 'Mã của chứng chỉ';
$string['privacy:metadata:tool_certificate_issues:expires']= 'Dấu thời gian khi chứng chỉ hết hạn. 0 nếu không hết hạn. ';
$string['privacy:metadata:tool_certificate_issues:templateid']= 'ID của chứng chỉ';
$string['privacy:metadata:tool_certificate_issues:timecreated']= 'Thời gian chứng chỉ được cấp';
$string['privacy:metadata:tool_certificate_issues:userid']= 'ID của người dùng được cấp chứng chỉ';
$string['receiveddate']= 'Được trao vào';
$string['regenerate']= 'Tạo lại';
$string['regeneratefileconfirm']= 'Bạn có chắc chắn muốn tạo lại chứng chỉ đã cấp cho người dùng này không?';
$string['regenerateissuefile']= 'Tạo lại tập tin sự cố';
$string['reg_wpcertificates']= 'Số chứng chỉ ({$a})';
$string['reg_wpcertificatesissues']= 'Số chứng chỉ đã cấp ({$a})';
$string['revoke']= 'Thu hồi';
$string['revokecertificateconfirm']= 'Bạn có chắc chắn muốn thu hồi vấn đề chứng chỉ này từ người dùng này không?';
$string['rightmargin']= 'Lề phải, mm';
$string['rightmargin_help']= 'Đây là lề phải của PDF chứng chỉ tính bằng mm.';
$string['selectcertificate']= 'Chọn chứng chỉ';
$string['selectuserstoissuecertificatefor']= 'Chọn người dùng để cấp chứng chỉ cho';
$string['shared']= 'Được chia sẻ';
$string['subplugintype_certificateelement_plural']= 'Phần bổ trợ phần tử';
$string['timecreated']= 'Thời gian được tạo';
$string['toomanycertificatestoshow']= 'Quá nhiều chứng chỉ ({$a}) để hiển thị';
$string['type']= 'Loại';
$string['uploadimage']= 'Tải lên hình ảnh';
$string['valid']= 'Hợp lệ';
$string['validcertificate']= 'Chứng chỉ này hợp lệ';
$string['verified']= 'Đã xác minh';
$string['verify']= 'Xác minh';
$string['verifycertificates']= 'Xác minh chứng chỉ';
$string['verifynotallowed']= 'Bạn không được phép xác minh chứng chỉ.';
$string['viewcertificate']= 'Xem chứng chỉ';
