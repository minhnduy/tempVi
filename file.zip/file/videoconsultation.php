<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'videoconsultation', language 'en', branch 'MOODLE_23_STABLE'
 *
 * @package   videoconsultation
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['adminkeydesc']= 'Khóa quản trị để quản lý phòng Tư vấn video của bạn';
$string['adminkeylabel']= 'Khóa quản trị';
$string['adminuserid']= 'Ai là quản trị viên (User_ID)';
$string['advancedCamSettings']= 'Cài đặt Máy ảnh Nâng cao';
$string['amfdesc']= 'RTMP AMF (AMF3: Red5, Wowza, FMIS3, FMIS3.5)';
$string['amflabel']= 'RTMP AMF';
$string['background_url']= 'Url nền';
$string['bufferFulldesc']= 'Đặt Bộ đệm Đầy đủ';
$string['bufferFulllabel']= 'Bộ đệm đầy đủ';
$string['bufferFullPlaybackdesc']= 'Đặt phát lại đầy đủ bộ đệm';
$string['bufferFullPlaybacklabel']= 'Phát lại đầy đủ bộ đệm';
$string['bufferLivedesc']= 'Đặt Bộ đệm Trực tiếp';
$string['bufferLivelabel']= 'Bộ đệm Trực tiếp';
$string['bufferLivePlaybackdesc']= 'Đặt phát lại trực tiếp bộ đệm';
$string['bufferLivePlaybacklabel']= 'Phát lại trực tiếp bộ đệm';
$string['camBandwidthdesc']= 'Đặt băng thông máy ảnh';
$string['camBandwidthlabel']= 'Băng thông máy ảnh';
$string['camFPS']= 'FPS máy ảnh';
$string['camFPSdesc']= 'Đặt FPS cho máy ảnh';
$string['camFPSlabel']= 'FPS máy ảnh';
$string['camHeight']= 'Chiều cao máy ảnh';
$string['camHeightdesc']= 'Đặt Chiều cao Máy ảnh';
$string['camHeightlabel']= 'Chiều cao máy ảnh';
$string['camMaxBandwidthdesc']= 'Đặt băng thông máy ảnh tối đa';
$string['camMaxBandwidthlabel']= 'Băng thông máy ảnh tối đa';
$string['camWidth']= 'Chiều rộng máy ảnh';
$string['camWidthdesc']= 'Đặt chiều rộng máy ảnh';
$string['camWidthlabel']= 'Chiều rộng máy ảnh';
$string['change_background']= 'Thay đổi nền';
$string['chat_enabled']= 'Bật Trò chuyện';
$string['configureSource']= 'Định cấu hình nguồn';
$string['desc']= 'Mô tả';
$string['disableBandwidthDetectiondesc']= 'Đặt vô hiệu hóa phát hiện băng thông';
$string['disableBandwidthDetectionlabel']= 'Tắt phát hiện băng thông';
$string['disableSound']= 'Tắt âm thanh';
$string['disableVideo']= 'Tắt video';
$string['enter']= 'Nhập';
$string['externalStream']= 'Dòng bên ngoài';
$string['file_delete']= 'Xóa tệp';
$string['files_enabled']= 'Kích hoạt tập tin';
$string['file_upload']= 'Tải lên tệp';
$string['fillWindow']= 'Điền cửa sổ';
$string['filterRegex']= 'Lọc regex';
$string['filterReplace']= 'Bộ lọc thay thế';
$string['floodProtection']= 'Chống lũ lụt';
$string['headersetting']= 'Cài đặt Phòng';
$string['layoutCode']= 'Mã bố cục';
$string['limitByBandwidthdesc']= 'Đặt giới hạn theo băng thông';
$string['limitByBandwidthlabel']= 'Giới hạn theo băng thông';
$string['micRate']= 'Tỷ lệ micrô';
$string['micRatedesc']= 'Đặt tỷ lệ micrô';
$string['micRatelabel']= 'Tỷ lệ micrô';
$string['modulename']= 'Tư vấn video';
$string['modulenameplural']= 'tư vấn video';
$string['moduletitle']= 'Tư vấn video';
$string['notallowenter']= 'Bạn không có quyền truy cập vào phòng này';
$string['novideoconsultation']= 'Không có phòng tư vấn video trong khóa học này';
$string['pluginadministration']= 'Quản trị tư vấn video';
$string['pluginname']= 'videoconsultation';
$string['privateTextchat']= 'Trò chuyện Văn bản Riêng tư';
$string['regularCams']= 'Cam thông thường';
$string['regularWatch']= 'Xem thường xuyên';
$string['room_limitdesc']= 'Đặt giới hạn phòng tối đa';
$string['room_limitlabel']= 'Giới hạn phòng';
$string['rtmpdesc']= 'Địa chỉ máy chủ RTMP';
$string['rtmplabel']= 'Máy chủ RTMP';
$string['showCamSettings']= 'Hiển thị Cài đặt Máy ảnh';
$string['slideShow']= 'Trình chiếu';
$string['users_enabled']= 'Kích hoạt Người dùng';
$string['videoconsultation']= 'Tư vấn video';
$string['videoconsultation:administrator']= 'người kiểm duyệt';
$string['videoconsultation:advancedcamsettings']= 'cài đặt cam trước';
$string['videoconsultation:change_background']= 'thay đổi nền';
$string['videoconsultation:chat_enabled']= 'xem bảng trò chuyện';
$string['videoconsultation:configuresource']= 'cho phép bộ mã hóa bên ngoài';
$string['videoconsultation:disablesound']= 'bật âm thanh';
$string['videoconsultation:disablevideo']= 'đã bật video';
$string['videoconsultationfieldset']= 'Bộ trường mẫu tùy chỉnh';
$string['videoconsultation:file_delete']= 'cho phép xóa tệp';
$string['videoconsultation:files_enabled']= 'xem bảng điều khiển tệp, có thể tải xuống';
$string['videoconsultation:file_upload']= 'cho phép tải tệp lên';
$string['videoconsultationname']= 'videoconsultation help';
$string['videoconsultationname_help']= 'Vui lòng nhập mô tả ngắn của phòng Tư vấn Video.';
$string['videoconsultation:privatetextchat']= 'có thể nhắn tin riêng cho người dùng';
$string['videoconsultation:regularcams']= 'khởi động webcam mà không ở trên màn hình';
$string['videoconsultation:regularwatch']= 'xem bất kỳ cam nào của người tham gia';
$string['videoconsultationroomname']= 'Tên phòng tư vấn video';
$string['videoconsultation:showcamsettings']= 'hiển thị cài đặt cam';
$string['videoconsultation:slideshow']= 'trình bày slide trên màn hình chính';
$string['videoconsultation:users_enabled']= 'xem danh sách người dùng';
$string['videoconsultation:view']= 'Truy cập phòng tư vấn video';
$string['videoconsultation:write_text']= 'có thể gửi tin nhắn văn bản';
$string['welcome']= 'Tin nhắn chào mừng';
$string['writeText']= 'Viết văn bản';
