<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_moodlebox', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_moodlebox
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['badpowersupply']= '<p> <b> Cảnh báo: phát hiện điện áp thấp! </b> Nguồn điện của MoodleBox không đủ, có thể gây ra nhiều vấn đề khác nhau, chẳng hạn như giới hạn số lượng máy khách Wi-Fi hoặc thậm chí là sự cố không mong muốn tắt thiết bị. </p> <p> Bạn nên <b> thay đổi nguồn điện </b>, ưu tiên cho <a href = "https://www.raspberrypi.org/products/ raspberry-pi-universal-power-supply / "target =" _ blank "> bộ cấp nguồn chính thức của Raspberry Foundation </a> và sử dụng cáp chất lượng tốt để kết nối với MoodleBox. </p> ';
$string['changepassworderror']= 'Mật khẩu MoodleBox không được thay đổi. Mật khẩu được cung cấp không khớp. ';
$string['changepasswordmessage']= 'Mật khẩu chính của MoodleBox (tài khoản Unix) và của máy chủ cơ sở dữ liệu đã được thay đổi thành công. <br /> <br /> Cảnh báo! Mật khẩu của người dùng Moodle mặc định <b> không được thay đổi </b>. Để thay đổi nó, vui lòng sử dụng trang tùy chọn của người dùng này. ';
$string['changepasswordsetting']= 'Thay đổi mật khẩu MoodleBox';
$string['changewifipassword']= 'Thay đổi mật khẩu Wifi';
$string['changewifisettings']= 'Thay đổi cài đặt Wi-Fi';
$string['configuration']= 'Cài đặt MoodleBox';
$string['cpufrequency']= 'Tần số CPU';
$string['cpuload']= 'Tải CPU';
$string['cputemperature']= 'Nhiệt độ CPU';
$string['currentwifipassword']= 'Mật khẩu Wi-Fi hiện tại';
$string['dashboard']= 'Bảng điều khiển MoodleBox';
$string['datetime']= 'Ngày và giờ';
$string['datetime_help']= 'Nếu MoodleBox không được kết nối với Internet, nó sẽ không đến đúng giờ. Nó có thể được đặt thủ công bằng cách sử dụng cài đặt này. ';
$string['datetimemessage']= 'Đồng hồ của MoodleBox đã được thiết lập. Để có được độ chính xác cao nhất, bạn nên kết nối MoodleBox với mạng được kết nối Internet qua cáp ethernet. ';
$string['datetimeset']= 'Đặt ngày và giờ';
$string['datetimesetmessage']= 'Đồng hồ của MoodleBox không đúng giờ. Rất nên đặt ngày và giờ thành thời gian hiện tại. ';
$string['datetimesetting']= 'Ngày và giờ';
$string['defaultgateway']= 'Cổng mặc định';
$string['dhcpclientinfo']= 'Tên và địa chỉ IP của ứng dụng khách';
$string['dhcpclientnumber']= 'số lượng khách hàng';
$string['dhcpclients']= 'Máy khách DHCP';
$string['documentation']= 'Tài liệu MoodleBox';
$string['documentation_desc']= '<p> Đối với các câu hỏi hỗ trợ, hãy duyệt qua <a href="https://moodlebox.net/vi/help/" title="MoodleBox document" target="_blank"> tài liệu MoodleBox </a> đầy đủ. < / p> ';
$string['ethernetdisconnected']= 'Đã ngắt kết nối Ethernet';
$string['forum']= 'Diễn đàn hỗ trợ MoodleBox';
$string['forum_desc']= '<p> Nếu bạn không thể tìm thấy câu trả lời cho câu hỏi của mình trong <a href="https://moodlebox.net/vi/help/" title="MoodleBox document" target="_blank"> MoodleBox tài liệu </a>, hãy tìm kiếm trong <a href="https://discuss.moodlebox.net/" title="MoodleBox forum" target="_blank"> diễn đàn hỗ trợ MoodleBox </a> để xem câu hỏi của bạn đã có chưa đã được trả lời. Nếu không, hãy mở một cuộc thảo luận mới. </p> ';
$string['hidden']= 'Ẩn';
$string['ihavedonated']= 'Tôi đã quyên góp! 🎉 ';
$string['ihavedonated_desc']= 'Chọn hộp này nếu <a href="https://moodlebox.net/en/donate/" title="Make a donate" target="_blank"> bạn đã quyên góp </a> cho dự án MoodleBox . <br /> Cài đặt này hoàn toàn không có tác dụng. Nó chỉ đơn giản cho phép bạn thể hiện niềm tự hào của mình vì đã đóng góp cho <a href="https://moodlebox.net/vi/" title="MoodleBox website" target="_blank"> dự án MoodleBox </a>. Cảm ơn nhiều!';
$string['infofileerror']= 'Thông tin không có sẵn';
$string['infoheading']= 'Thông tin hỗ trợ MoodleBox';
$string['information']= 'Thông tin';
$string['interfacename']= 'Tên giao diện';
$string['ipaddress']= 'Địa chỉ IP';
$string['kernelversion']= 'Phiên bản hạt nhân';
$string['missingconfigurationerror']= 'Phần này không có sẵn. Quá trình cài đặt plugin chưa hoàn tất, do đó MoodleBox không thể xử lý cài đặt này. Vui lòng đọc <a href="https://github.com/moodlebox/moodle-tool_moodlebox/blob/master/README.md" target="_blank"> tài liệu cài đặt </a> để khắc phục lỗi này. ';
$string['moodleboxinfo']= 'Phiên bản MoodleBox';
$string['moodleboxinfofileerror']= 'Thông tin không có sẵn';
$string['moodleboxpluginversion']= 'Phiên bản plugin MoodleBox';
$string['moodleboxsysteminfo']= 'Thông tin MoodleBox';
$string['moodleboxsysteminfo_help']= 'Bảng điều khiển thông tin MoodleBox hiển thị một số dữ liệu quan trọng về MoodleBox. Thông tin này bao gồm:
* Chi tiết hoạt động quan trọng của MoodleBox, chẳng hạn như dung lượng đĩa còn lại trên thẻ SD và tải bộ xử lý, nhiệt độ và tần số
* Cài đặt hiện tại của mạng Wi-Fi do MoodleBox cung cấp
* Số, địa chỉ IP và tên của tất cả các thiết bị được kết nối với MoodleBox
* Mô hình và hệ điều hành Raspberry Pi
* Phiên bản MoodleBox và phiên bản plugin MoodleBox ';
$string['moodlebox:viewbuttonsinfooter']= 'Xem các nút khởi động lại và tắt máy ở chân trang';
$string['networkinterface']= 'Giao diện mạng bị tắt';
$string['newwifipassword']= 'Mật khẩu Wi-Fi mới';
$string['nopassworddefined']= 'Không xác định mật khẩu Wifi';
$string['parameter']= 'Tham số';
$string['passwordprotected']= 'Được bảo vệ bằng mật khẩu';
$string['passwordsetting']= 'Mật khẩu MoodleBox';
$string['passwordsetting_help']= 'Mật khẩu chính của MoodleBox có thể được thay đổi tại đây. __Không khuyến khích giữ mật khẩu mặc định_. __Must__ của bạn chắc chắn thay đổi nó như một biện pháp bảo mật tối thiểu. ';
$string['pijuicebatterychargelevel']= 'Mức phí PiJuice';
$string['pijuicebatterystatus']= 'Trạng thái pin PiJuice';
$string['pijuicebatterytemp']= 'Nhiệt độ pin PiJuice';
$string['pijuiceinfo']= 'Thông tin trạng thái PiJuice';
$string['pijuiceisfault']= 'Lỗi PiJuice';
$string['pijuicestatuserror']= 'Trạng thái PiJuice';
$string['pluginname']= 'MoodleBox';
$string['pluginversion']= 'Phiên bản plugin MoodleBox';
$string['privacy:metadata']= 'Plugin MoodleBox hiển thị thông tin từ Raspberry Pi và cho phép một số thay đổi cấu hình, nhưng không ảnh hưởng hoặc lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['projectinfo']= '<p> <a href="https://moodlebox.net/en/" title="MoodleBox website" target="_blank"> Dự án MoodleBox </a> là một nguồn mở, phi lợi nhuận và tình nguyện dự án được thực hiện bởi <a href="https://blog.martignoni.net/a-propos/" title="Nicolas Martignoni" target="_blank"> Nicolas Martignoni </a> vào thời gian rảnh rỗi. </ p > <p> Chúng tôi cảm ơn bạn đã sử dụng MoodleBox. Bạn có thể thể hiện sự đánh giá cao của mình và ủng hộ dự án này bằng cách <a href="https://moodlebox.net/vi/donate/" title="Make a donate" target="_blank"> đóng góp </a> ❤. Khoản đóng góp của bạn sẽ giúp tài trợ thiết bị cần thiết để phát triển MoodleBox và lưu trữ tài liệu của nó. </p> ';
$string['raspberryhardware']= 'Mô hình Raspberry Pi';
$string['raspbianversion']= 'Phiên bản Raspbian';
$string['resizepartition']= 'Thay đổi kích thước phân vùng thẻ SD';
$string['resizepartition_help']= 'Sử dụng nút này để thay đổi kích thước phân vùng thẻ SD.';
$string['resizepartitionmessage']= 'Phân vùng thẻ SD đã được thay đổi kích thước thành kích thước tối đa. MoodleBox hiện đang khởi động lại. Nó sẽ trực tuyến trở lại trong giây lát. ';
$string['resizepartitionsetting']= 'Thay đổi kích thước phân vùng thẻ SD';
$string['restart']= 'Khởi động lại MoodleBox';
$string['restartmessage']= 'MoodleBox đang khởi động lại. Nó sẽ trực tuyến trở lại trong giây lát. ';
$string['restartstop']= 'Khởi động lại và tắt máy';
$string['restartstop_help']= 'Sử dụng các nút này để khởi động lại hoặc tắt MoodleBox. Bạn không nên rút nguồn điện để tắt MoodleBox. ';
$string['rpi1']= 'Raspberry Pi 1';
$string['rpi2']= 'Raspberry Pi 2B';
$string['rpi3']= 'Raspberry Pi 3B';
$string['rpi3aplus']= ARSPBER A + A;
$string['rpi3b']= 'Raspberry Pi 3B';
$string['rpi3bplus']= 'Raspberry Pi 3B +';
$string['rpi4eightgb']= 'Raspberry Pi 4B (RAM 8 GB)';
$string['rpi4fourgb']= 'Raspberry Pi 4B (RAM 4 GB)';
$string['rpi4fourmb']= 'Raspberry Pi 4B (RAM 4 MB)';
$string['rpi4onegb']= 'Raspberry Pi 4B (RAM 1 GB)';
$string['rpi4onemb']= 'Raspberry Pi 4B (RAM 1 MB)';
$string['rpi4twogb']= 'Raspberry Pi 4B (RAM 2 GB)';
$string['rpi4twomb']= 'Raspberry Pi 4B (RAM 2 MB)';
$string['rpiosversion']= 'Phiên bản hệ điều hành Raspberry Pi';
$string['rpizerow']= 'Raspberry Pi Zero W';
$string['sdcardavailablespace']= 'Dung lượng trống trên thẻ SD';
$string['showbuttonsinfooter']= 'Hiển thị các nút ở chân trang';
$string['showbuttonsinfooter_desc']= 'Nếu được bật, các nút khởi động lại và tắt được hiển thị ở chân trang của tất cả các trang của trang web khi đăng nhập với tư cách quản trị viên hoặc người quản lý.';
$string['shutdown']= 'Tắt MoodleBox';
$string['shutdownmessage']= 'MoodleBox đang ngừng hoạt động. Vui lòng đợi vài giây trước khi ngắt nguồn điện. ';
$string['softwareversions']= 'Phiên bản phần mềm';
$string['systeminfo']= 'Thông tin hệ thống';
$string['undervoltagedetected']= '<p> <b> Cảnh báo: phát hiện điện áp thấp! </b> Nguồn điện của MoodleBox không đủ, có thể gây ra nhiều vấn đề khác nhau, chẳng hạn như giới hạn số lượng máy khách Wi-Fi hoặc thậm chí là sự cố không mong muốn tắt thiết bị. </p> <p> Bạn nên <b> thay đổi nguồn điện </b>, ưu tiên cho <a href = "https://www.raspberrypi.org/products/ raspberry-pi-universal-power-supply / "target =" _ blank "> bộ cấp nguồn chính thức của Raspberry Foundation </a> và sử dụng cáp chất lượng tốt để kết nối với MoodleBox. </p> ';
$string['undervoltageoccurred']= '<p> Một tình huống điện áp thấp đã xảy ra kể từ lần khởi động cuối cùng của MoodleBox. Điều này có thể cho thấy nguồn cung cấp điện của MoodleBox không đủ, có thể gây ra nhiều sự cố khác nhau, chẳng hạn như giới hạn số lượng khách hàng Wi-Fi hoặc thậm chí là thiết bị tắt đột ngột. </p> <p> Chúng tôi khuyên bạn nên sử dụng để <b> thay đổi nguồn điện </b>, ưu tiên cho <a href = "https://www.raspberrypi.org/products/raspberry-pi-universal-power-supply/" target = "_ blank" > nguồn cung cấp chính thức của Raspberry Foundation </a> và sử dụng cáp chất lượng tốt để kết nối nó với MoodleBox. </p> ';
$string['unknownmodel']= 'Mô hình Raspberry Pi không xác định';
$string['unsupportedhardware']= 'Đã phát hiện phần cứng máy chủ không được hỗ trợ! Plugin này chỉ hoạt động trên Raspberry Pi ';
$string['uptime']= 'Thời gian hoạt động của hệ thống';
$string['version']= 'Phiên bản MoodleBox';
$string['visible']= 'Hiển thị';
$string['wifichannel']= 'Kênh Wi-Fi';
$string['wifichannel_help']= 'Không cần thiết phải thay đổi kênh phát sóng Wi-Fi trừ khi hiệu suất kém do nhiễu.';
$string['wificountry']= 'Quốc gia quản lý Wi-Fi';
$string['wificountry_help']= 'Vì lý do pháp lý, bạn nên đặt quốc gia của mình làm quốc gia quản lý Wi-Fi.';
$string['wifipassword']= 'Mật khẩu Wifi';
$string['wifipassworderror']= 'Mật khẩu mạng Wi-Fi phải có từ 8 đến 63 ký tự.';
$string['wifipassword_help']= 'Nếu bạn đã chọn mạng Wi-Fi được bảo vệ bằng mật khẩu, để ngăn những kẻ xâm nhập sử dụng mạng Wi-Fi MoodleBox, bạn nên thay đổi mật khẩu mặc định của mạng đó. Mật khẩu mạng Wi-Fi phải có từ 8 đến 63 ký tự ASCII có thể in được (chữ hoa và chữ thường, chữ số, dấu chấm câu và một vài ký hiệu khác). ';
$string['wifipasswordinvalid']= 'Mật khẩu mạng Wi-Fi không hợp lệ. Nó phải có từ 8 đến 63 ký tự ASCII có thể in được (chữ hoa và chữ thường, chữ số, dấu chấm câu và một vài ký hiệu khác). ';
$string['wifipasswordmessage']= 'Mật khẩu mạng Wi-Fi đã được thay đổi. Đừng quên truyền đạt nó cho học sinh của bạn. ';
$string['wifipasswordon']= 'Bảo vệ mạng Wi-Fi';
$string['wifipasswordonhelp']= 'Nếu được bật, người dùng phải nhập mật khẩu để kết nối với mạng Wi-Fi MoodleBox.';
$string['wifipasswordon_help']= 'Nếu được bật, người dùng phải nhập mật khẩu để kết nối với mạng Wi-Fi MoodleBox.';
$string['wifipasswordsetting']= 'Thay đổi mật khẩu mạng Wi-Fi';
$string['wifisettings']= 'Cài đặt Wi-Fi';
$string['wifisettingserror']= 'Cài đặt Wi-Fi không được thay đổi. Một số cài đặt không hợp lệ. ';
$string['wifisettingsmessage']= 'Cài đặt Wi-Fi đã được thay đổi. Đừng quên thông báo SSID và mật khẩu mới cho sinh viên của bạn. ';
$string['wifissid']= 'Tên mạng Wi-Fi';
$string['wifissid_help']= 'Tên của mạng Wi-Fi (SSID) của MoodleBox. Nó phải là một chuỗi có ít nhất 1 byte và nhiều nhất là 32 byte. Hãy nhớ rằng một số ký tự, chẳng hạn như biểu tượng cảm xúc, sử dụng nhiều hơn một byte. ';
$string['wifissidhidden']= 'Mạng Wi-Fi ẩn';
$string['wifissidhiddenstate']= 'Khả năng hiển thị SSID của Wi-Fi';
$string['wifissidhiddenstate_help']= 'Nếu được bật, Wi-Fi SSID sẽ bị ẩn khỏi người dùng, những người sẽ không biết rằng có MoodleBox xung quanh. Điều này sẽ làm giảm đáng kể khả năng sử dụng của thiết bị, nhưng cải thiện một chút tính bảo mật của nó. ';
$string['wifissidinvalid']= 'Tên của mạng Wi-Fi (SSID) được cung cấp không hợp lệ. Nó phải là một chuỗi có ít nhất 1 byte và nhiều nhất là 32 byte. ';
