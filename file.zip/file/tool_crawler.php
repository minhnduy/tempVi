<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_crawler', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_crawler
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['autocreate']= 'Tự động tạo';
$string['bigfilesize']= 'Kích thước của tệp lớn';
$string['bigfilesizedesc']= 'Tập tin cần phải lớn bao nhiêu (tính bằng MB) để được gắn cờ là quá kích thước.';
$string['botcantgettestpage']= 'Bot không thể yêu cầu trang kiểm tra';
$string['botpassword']= 'Mật khẩu bot';
$string['botpassworddesc']= 'Mật khẩu của người dùng Moodle để thu thập thông tin dưới dạng. Người dùng này phải có quyền xem trên toàn trang, nhưng quyền chỉnh sửa rất hạn chế và được định cấu hình để sử dụng xác thực cơ bản. ';
$string['bottestpagenotreturned']= 'Trang thử nghiệm bot không được trả lại';
$string['bottestpageredirected']= 'Trang kiểm tra bot đã được chuyển hướng đến {$a->resredirect}';
$string['botuser']= 'Người dùng bot';
$string['botusermissing']= 'Thiếu người dùng bot';
$string['botusername']= 'Tên người dùng bot';
$string['botusernamedesc']= 'Tên người dùng của người dùng Moodle để thu thập thông tin dưới dạng.';
$string['broken']= 'Liên kết / URL bị hỏng';
$string['broken_header']= '<p> Các URL trùng lặp sẽ chỉ được tìm kiếm một lần. </p>';
$string['clicrawlashelp']= 'Thu thập dữ liệu URL dưới dạng rô bốt và phân tích cú pháp.
Hữu ích khi một trang đã được sửa chữa và bạn muốn phản ánh điều này ngay lập tức.
Các tùy chọn:
-h, --help In ra phần trợ giúp này
-u, --url URL để thu thập thông tin và xử lý
Thí dụ:
$sudo-uwww-dataphpcrawl-as.php--url= https: //host.example/ ';
$string['clicrawlerhelp']= 'Chạy trình thu thập thông tin theo cách thủ công mà không cần phải đợi tác vụ đã lên lịch.
Các tùy chọn:
-h, --help In ra phần trợ giúp này
--verbose = <level> Mức độ chi tiết (0 = Yên lặng, 1 = Độ dài tiêu chuẩn, 2 = Độ dài mở rộng), Mặc định: 1
Thí dụ:
$sudo-uwww-dataphpcrawler.php--verbose= 1 ';
$string['clierror']= 'Lỗi: {$a}';
$string['cliscrapeashelp']= 'Xoá URL khi rô bốt sẽ nhìn thấy nó, nhưng không xử lý / xếp hàng nó.
Các tùy chọn:
-h, --help In ra phần trợ giúp này
-u, --url URL để cạo
Thí dụ:
$sudo-uwww-dataphpscrape-as.php--url= https: //host.example/ ';
$string['configmissing']= 'Thiếu cấu hình';
$string['course']= 'Khóa học';
$string['crawlend']= 'Kết thúc thu thập thông tin';
$string['crawlstart']= 'Bắt ​​đầu thu thập thông tin';
$string['crawl_task']= 'Tác vụ thu thập thông tin song song';
$string['cronticks']= 'Tích tắc cron';
$string['curcrawlstart']= 'Thu thập thông tin hiện tại đã bắt đầu lúc';
$string['custompriority']= 'Tùy chỉnh: {$a}';
$string['defaultpriority']= 'Thấp';
$string['disablebot']= 'Vô hiệu hóa robot trình thu thập liên kết';
$string['disablebotdesc']= 'Làm cho trình thu thập thông tin không làm gì khi một tác vụ đã lên lịch được thực thi. Điều này ngăn chặn hiệu quả việc thu thập các liên kết và chạy các chức năng dọn dẹp bot. Dự định hủy kích hoạt hoặc tạm dừng trình thu thập thông tin mà không cần phải tắt tất cả các tác vụ đã lên lịch của nó. ';
$string['duration']= 'Thời lượng';
$string['event:crawlstart']= 'Đã bắt đầu thu thập thông tin kiểm tra liên kết';
$string['event:crawlstartdesc']= 'Đã bắt đầu thu thập thông tin kiểm tra liên kết {$a}';
$string['eventrobotcleanupcompleted']= 'Hoàn thành dọn dẹp rô bốt Linkchecker';
$string['eventrobotcleanupstarted']= 'Đã bắt đầu dọn dẹp rô bốt Linkchecker';
$string['excludecourses']= 'Loại trừ các khóa học';
$string['excludecoursesdesc']= 'Một tên ngắn của khóa học trên mỗi dòng và cách sử dụng * wildchar cũng được chấp nhận.';
$string['excludeexturl']= 'Loại trừ các URL bên ngoài';
$string['excludeexturldesc']= 'Một URL trên mỗi dòng và ký tự đại diện * ở bất kỳ vị trí nào cũng được chấp nhận. Mỗi cái được so khớp với URL đầy đủ. ';
$string['excludemdldom']= 'Loại trừ các phần Moodle DOM';
$string['excludemdldomdesc']= 'Một biểu thức CSS hoặc XPath trên mỗi dòng. Các phần phù hợp của DOM sẽ bị xóa trước khi các liên kết được trích xuất. ';
$string['excludemdlparam']= 'Loại trừ các tham số URL Moodle';
$string['excludemdlparamdesc']= 'Một khóa tham số trên mỗi dòng. Các URL sử dụng điều này sẽ vẫn được thu thập thông tin nhưng với các thông số này đã bị loại bỏ để tránh trùng lặp. ';
$string['excludemdlurl']= 'Loại trừ các URL Moodle';
$string['excludemdlurldesc']= 'Một URL trên mỗi dòng và ký tự đại diện * ở bất kỳ vị trí nào cũng được chấp nhận. Mỗi cái được so khớp trừ wwwroot. ';
$string['fetcherror']= 'Lỗi Curl: {$a->errormessage}';
$string['found']= 'Đã tìm thấy';
$string['frompage']= 'Từ trang';
$string['good']= 'Tốt';
$string['greaterthansize']= '> {$a->size}';
$string['hellorobot']= 'Xin chào rô bốt: \' {$a->botusername} \\';
$string['hellorobotheading']= 'Xin chào robot!';
$string['highpriority']= 'Cao';
$string['idattr']= 'Ngữ cảnh HTML';
$string['incomingurls']= 'URL đến';
$string['incourse']= 'Tất nhiên';
$string['lastcrawledtime']= 'Lần thu thập thông tin cuối cùng';
$string['lastcrawlend']= 'Thu thập thông tin cuối cùng đã kết thúc lúc';
$string['lastcrawlproc']= 'Quá trình thu thập thông tin cuối cùng';
$string['lastqueuesize']= 'Kích thước hàng đợi cuối cùng';
$string['linktext']= 'Văn bản liên kết';
$string['maxcrontime']= 'Giới hạn chạy Cron';
$string['maxcrontimedesc']= 'Trình thu thập thông tin sẽ tiếp tục thu thập thông tin cho đến khi đạt đến giới hạn này (tính bằng giây) trên mỗi lần đánh dấu cron.';
$string['maxtime']= 'Thời gian thực hiện tối đa';
$string['maxtimedesc']= 'Thời gian chờ (tính bằng giây) cho mỗi yêu cầu thu thập thông tin.';
$string['max_workers']= 'Công nhân tối đa';
$string['max_workersdesc']= 'Số lượng tối đa các tác vụ thu thập thông tin adhoc (công nhân) sẽ chạy song song bất kỳ lúc nào.';
$string['mimetype']= 'Loại phương tiện';
$string['missing']= 'Thiếu';
$string['networkstrain']= 'Mức độ sử dụng tài nguyên mạng';
$string['networkstraindesc']= '<p> Sử dụng tài nguyên mạng đến mức nào để tăng độ chính xác của các báo cáo đã tạo. </p>
<dl>
<dt> hợp lý: </dt> <dd> Cài đặt hợp lý cho web. Có thể gây ra một số mục nhập báo cáo với độ dài tài liệu không xác định, nhưng tiết kiệm môi trường. <strong> Cài đặt được đề xuất nếu bạn không biết phải chọn. </strong> </dd>
<dt> Resolutionute: </dt> <dd> Cách xác định độ dài tài nguyên linh hoạt hơn (tải xuống tài liệu nếu độ dài của nó không được cung cấp trong tiêu đề HTTP). Thông tin về tệp lớn có thể trở nên không đầy đủ nếu bạn tăng kích thước của tệp lớn (xem ở trên). </dd>
<dt> quá mức: </dt> <dd> Luôn xác định độ dài chính xác của tất cả các tài liệu với chi phí của <strong> rất nhiều </strong> tài nguyên mạng. Có thể hữu ích cho một số cài đặt, nhưng thường thì việc chọn tùy chọn này không được khuyến khích. </dd>
<dt> lãng phí: </dt> <dd> Luôn xác định độ dài chính xác của tất cả các tài liệu và tiêu đề tài liệu HTML bằng mọi cách, ngay cả khi điều này có nghĩa là để <strong> tiêu thụ quá mức </strong> tài nguyên mạng và ô nhiễm môi trường của chúng ta . Đây là cài đặt mặc định, chỉ tương thích với các cài đặt hiện có. Vui lòng thay đổi nó nếu bạn có thể! </dd>
</dl>
<p> Giá trị mặc định cho tùy chọn này là "lãng phí", phần lớn giống với hành vi của trình thu thập thông tin kể từ phiên bản 2018070200 trở về trước, trước khi giới thiệu tùy chọn này. Chúng tôi rất khuyến khích thay đổi điều này thành “hợp lý” trên hệ thống sản xuất, điều này sẽ tiết kiệm được nhiều tài nguyên trong khi vẫn bao gồm tất cả các trường hợp hợp lý. </p> ';
$string['networkstrainexcessive']= 'quá mức';
$string['networkstrainreasonable']= 'hợp lý';
$string['networkstrainresolute']= 'kiên quyết';
$string['networkstrainwasteful']= 'lãng phí';
$string['neverfinished']= 'Chưa bao giờ kết thúc';
$string['neverrun']= 'Không bao giờ chạy';
$string['no']= 'Không';
$string['normalpriority']= 'Bình thường';
$string['notyetknown']= 'Chưa được biết đến';
$string['numberurlsfound']= 'Đã tìm thấy URL {$a->reports_number} {$a->report_type}';
$string['numlinks']= 'Tổng số liên kết';
$string['numurls']= 'Tổng số URL';
$string['outgoingurls']= 'URL đi';
$string['oversize']= 'Liên kết lớn / chậm';
$string['oversize_header']= '<p> Các tệp lớn có nhiều liên kết đến sẽ được sao chép. </p>';
$string['pluginname']= 'Liên kết rô bốt thu thập thông tin';
$string['priority']= 'Ưu tiên';
$string['privacy:no_data_reason']= 'Plugin trình thu thập thông tin không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['progress']= 'Tiến trình';
$string['progresseta']= '{$a->percent}; ETA là {$a->eta} ';
$string['queued']= 'URL được xếp hàng đợi';
$string['queued_header']= '<p> Tiêu đề và khóa học chỉ được biết nếu URL đã được nhìn thấy trong lần thu thập thông tin trước đó. </p>';
$string['recent']= 'Các URL được thu thập thông tin gần đây';
$string['recentactivity']= 'Số ngày hoạt động gần đây';
$string['recentactivitydesc']= 'Một khóa học sẽ chỉ được thu thập thông tin nếu nó đã được xem trong số ngày cuối cùng được đặt ở đây.';
$string['recent_header']= '';
$string['redirect']= 'Chuyển hướng: {$a->redirectlink}';
$string['resetprogress']= 'Đặt lại tiến trình';
$string['resetprogress_header']= 'Đặt lại Tiến trình Trình thu thập thông tin';
$string['resetprogress_warning']= 'Cảnh báo. Bạn sắp đặt lại trình thu thập thông tin. Bạn có chắc chắn muốn làm điều này?';
$string['resetprogress_warning_button']= 'Đặt lại trình thu thập thông tin';
$string['response']= 'Phản hồi';
$string['retentionperiod']= 'Thời gian lưu giữ cho các URL không hợp lệ';
$string['retentionperioddesc']= 'Bao nhiêu ngày để giữ các URL xấu trong cơ sở dữ liệu.';
$string['retry']= 'Thử lại';
$string['robotcleanup']= 'Dọn dẹp robot';
$string['robotstatus']= 'Trạng thái robot';
$string['seedurl']= 'URL gốc';
$string['seedurldesc']= 'Nơi trình thu thập thông tin sẽ bắt đầu.';
$string['settings']= 'Cài đặt';
$string['size']= 'Kích thước';
$string['slowurl']= 'URL chậm';
$string['status']= 'Trạng thái robot';
$string['strftimerecentsecondshtml']= '%h %e,&nbsp;%H:%M:%S';

$string['symbolforunknown']= '?';
$string['unknown']= 'Không xác định';
$string['url']= 'URL';
$string['urldetails']= 'Chi tiết URL';
$string['urldetails_help']= 'Điều này hiển thị tất cả các liên kết đến và đi cho URL này.
Các liên kết đã bị đưa vào danh sách đen hoặc nằm trong các phần tử DOM bị loại trừ sẽ không được hiển thị. ';
$string['usehead']= 'Kích hoạt các yêu cầu HTTP HEAD';
$string['useheaddesc']= '<p> Trước tiên, hãy thử các yêu cầu HTTP HEAD khi rà soát các liên kết, trước khi quay lại các yêu cầu HTTP GET. Điều này thường tiết kiệm thời gian và đường truyền mạng trên web trung bình. </p>
<p> Nếu tùy chọn này bị tắt, các yêu cầu HTTP HEAD sẽ không được gửi; trình thu thập thông tin sẽ chỉ sử dụng các yêu cầu HTTP GET. Điều này không được khuyến khích. </p>
<p> Cài đặt mặc định, tương thích với các bản phát hành 2018070200 trở về trước của rô bốt trình thu thập liên kết, bị tắt, trong khi giá trị được đề xuất, đặc biệt cho các cài đặt mới, được bật. </p> ';
$string['uselogs']= 'Sử dụng bảng nhật ký';
$string['uselogsdesc']= 'Nếu được kích hoạt, chỉ thu thập thông tin các liên kết thuộc các khóa học có hoạt động gần đây. Sử dụng bảng mdl_logstore_standard_log. ';
$string['useraccount']= 'Tài khoản người dùng';
$string['useragent']= 'Chuỗi tác nhân người dùng bot';
$string['useragentdesc']= 'Tên tác nhân người dùng để sử dụng trong tiêu đề HTTP, không có phiên bản. Phiên bản của plugin này tự động được thêm vào. Cài đặt này có thể để trống và sẽ mặc định là sử dụng Bot tích hợp sẵn. ';
$string['whenqueued']= 'Khi xếp hàng đợi';
$string['yes']= 'Có';
