<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'workshopallocation_random', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   workshopallocation_random
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['addselfassessment']= 'Thêm tự đánh giá';
$string['allocationaddeddetail']= 'Bài đánh giá mới sẽ được thực hiện: <strong> {$a->reviewername} </strong> là người đánh giá của <strong> {$a->authorname} </strong>';
$string['allocationdeallocategraded']= 'Không thể phân bổ bài đánh giá đã được xếp loại: người đánh giá <strong> {$a->reviewername} </strong>, tác giả bài nộp <strong> {$a->authorname} </strong>';
$string['allocationreuseddetail']= 'Đánh giá được sử dụng lại: <strong> {$a->reviewername} </strong> được giữ làm người đánh giá của <strong> {$a->authorname} </strong>';
$string['allocationsettings']= 'Cài đặt phân bổ';
$string['assessmentdeleteddetail']= 'Bài đánh giá được phân bổ: <strong> {$a->reviewername} </strong> không còn là người đánh giá của <strong> {$a->authorname} </strong>';
$string['assesswosubmission']= 'Người tham gia có thể đánh giá mà không cần nộp bất cứ thứ gì';
$string['confignumofreviews']= 'Số lượng bài nộp mặc định được phân bổ ngẫu nhiên';
$string['excludesamegroup']= 'Ngăn chặn đánh giá của các đồng nghiệp trong cùng một nhóm';
$string['noallocationtoadd']= 'Không có phân bổ để thêm';
$string['nogroupusers']= '<p> Cảnh báo: Nếu hội thảo ở chế độ \' nhóm hiển thị \'hoặc chế độ \' nhóm riêng biệt \', thì người dùng PHẢI là thành viên của ít nhất một nhóm để được công cụ này phân bổ đánh giá ngang hàng cho họ. Người dùng không được nhóm vẫn có thể được đưa ra các bài tự đánh giá mới hoặc bị xóa các bài đánh giá hiện có. </p>
<p> Những người dùng này hiện không thuộc nhóm: {$a} </p> ';
$string['numofdeallocatedassessment']= 'Đánh giá phân bổ {$a}';
$string['numofrandomlyallocatedsubmissions']= 'Phân bổ {$a} một cách ngẫu nhiên';
$string['numofreviews']= 'Số lượt đánh giá';
$string['numofselfallocatedsubmissions']= 'Gửi (các) {$a} tự phân bổ';
$string['numperauthor']= 'mỗi lần gửi';
$string['numperreviewer']= 'mỗi người đánh giá';
$string['pluginname']= 'Phân bổ ngẫu nhiên';
$string['privacy:metadata']= 'Plugin phân bổ ngẫu nhiên không lưu trữ bất kỳ dữ liệu cá nhân nào. Dữ liệu cá nhân thực tế về người sẽ đánh giá ai được lưu trữ bởi chính mô-đun Hội thảo và chúng là cơ sở để xuất các chi tiết đánh giá. ';
$string['randomallocationdone']= 'Phân bổ ngẫu nhiên được thực hiện';
$string['removecurrentallocations']= 'Xóa phân bổ hiện tại';
$string['resultnomorepeers']= 'Không còn bạn bè nào nữa';
$string['resultnomorepeersingroup']= 'Không còn đồng nghiệp nào trong nhóm riêng biệt này';
$string['resultnotenoughpeers']= 'Không có đủ đồng nghiệp có sẵn';
$string['resultnumperauthor']= 'Đang cố gắng phân bổ 94cf7383-0d19-4568-a270-5e73095552 (các) bài đánh giá đã đăng cho mỗi tác giả';
$string['resultnumperreviewer']= 'Đang cố gắng phân bổ {$a} đánh giá cho mỗi người đánh giá';
$string['stats']= 'Thống kê phân bổ hiện tại';
