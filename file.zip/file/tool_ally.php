<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_ally', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_ally
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['adminurl']= 'Khởi chạy URL';
$string['adminurldesc']= 'URL khởi chạy LTI được sử dụng để truy cập báo cáo Khả năng truy cập.';
$string['allyclientconfig']= 'Cấu hình đồng minh';
$string['ally:clientconfig']= 'Truy cập và cập nhật cấu hình máy khách';
$string['ally:viewlogs']= 'Trình xem nhật ký đồng minh';
$string['autoconfigapicall']= 'Bạn có thể kiểm tra xem dịch vụ web có hoạt động không qua url sau:';
$string['autoconfigsuccess']= 'Thành công - dịch vụ web Ally đã được cấu hình tự động.';
$string['autoconfigtoken']= 'Mã thông báo dịch vụ web như sau:';
$string['autoconfigure']= 'Tự động cấu hình dịch vụ web của Ally';
$string['autoconfigureconfirmation']= 'Tự động tạo vai trò và người dùng dịch vụ web cho đồng minh và kích hoạt dịch vụ web. Các hành động sau sẽ được thực hiện: <ul> <li> tạo một vai trò có tên \'ally_webservice \' và một người dùng có tên người dùng \'ally_webuser \' </li> <li> thêm người dùng \'ally_webuser \' vào vai trò \'ally_webservice \' </li> <li> kích hoạt các dịch vụ web </li> <li> kích hoạt giao thức dịch vụ web còn lại </li> <li> kích hoạt dịch vụ web đồng minh </li> <li> tạo mã thông báo cho tài khoản \'ally_webuser \' </li> </ul> ';
$string['autoconfiguredesc']= 'Tự động tạo vai trò và người dùng dịch vụ web cho đồng minh.';
$string['cachedef_request']= 'Bộ nhớ cache yêu cầu bộ lọc đồng minh';
$string['clientid']= 'Id khách hàng';
$string['clientiddesc']= 'Id khách hàng Ally';
$string['code']= 'Mã';
$string['contentauthors']= 'Tác giả nội dung';
$string['contentauthorsdesc']= 'Quản trị viên và người dùng được chỉ định cho các vai trò đã chọn này sẽ được đánh giá các tệp khóa học đã tải lên của họ về khả năng truy cập. Các tệp được đánh giá khả năng truy cập. Xếp hạng thấp có nghĩa là tệp cần thay đổi để dễ truy cập hơn. ';
$string['contentupdatestask']= 'Nhiệm vụ cập nhật nội dung';
$string['courseupdatestask']= 'Đẩy các sự kiện khóa học cho đồng minh';
$string['curlerror']= 'lỗi cURL: {$a}';
$string['curlinvalidhttpcode']= 'Mã trạng thái HTTP không hợp lệ: {$a}';
$string['curlnohttpcode']= 'Không thể xác minh mã trạng thái HTTP';
$string['error:componentcontentnotfound']= 'Không tìm thấy nội dung cho {$a}';
$string['error:invalidcomponentident']= 'Định danh thành phần không hợp lệ {$a}';
$string['error:pluginfilequestiononly']= 'Chỉ các thành phần câu hỏi được hỗ trợ cho url này';
$string['error:wstokenmissing']= 'Mã thông báo dịch vụ web bị thiếu. Có thể người dùng quản trị cần chạy cấu hình tự động? ';
$string['filecoursenotfound']= 'Tập tin được chuyển vào không thuộc bất kỳ khóa học nào';
$string['fileupdatestask']= 'Đẩy các cập nhật tệp cho Ally';
$string['hidedata']= 'Ẩn dữ liệu';
$string['hideexception']= 'Ẩn ngoại lệ';
$string['hideexplanation']= 'Ẩn lời giải thích';
$string['id']= 'Id';
$string['key']= 'Chìa khóa';
$string['keydesc']= 'Khóa người tiêu dùng LTI.';
$string['lessonanswertitle']= 'Đáp án bài "{$a}"';
$string['lessonresponsetitle']= 'Phản hồi cho bài "{$a}"';
$string['level']= 'Cấp độ';
$string['logger:addingconenttoqueue']= 'Thêm nội dung vào hàng đợi đẩy';
$string['logger:addingcourseevttoqueue']= 'Thêm sự kiện khóa học vào hàng đợi đẩy';
$string['logger:annotationmoderror']= 'Chú thích nội dung mô-đun đồng minh không thành công.';
$string['logger:annotationmoderror_exp']= 'Mô-đun không được xác định chính xác.';
$string['logger:autoconfigfailureteachercap']= 'Không thành công khi chỉ định khả năng kiểu mẫu giáo viên cho vai trò ally_webservice.';
$string['logger:autoconfigfailureteachercap_exp']= '<br> Khả năng: {$a->cap} <br> Quyền: {$a->permission}';
$string['logger:cmiderraticpremoddelete']= 'Id mô-đun khóa học có vấn đề khi xóa trước.';
$string['logger:cmiderraticpremoddelete_exp']= 'Mô-đun không được xác định chính xác, hoặc nó không tồn tại do bị xóa phần hoặc có yếu tố khác đã kích hoạt móc xóa và nó không được tìm thấy.';
$string['logger:cmidresolutionfailure']= 'Không giải quyết được id mô-đun khóa học';
$string['logger:cmvisibilityresolutionfailure']= 'Không giải quyết được khả năng hiển thị mô-đun khóa học';
$string['logger:failedtogetcoursesectionname']= 'Không lấy được tên phần khóa học';
$string['logger:moduleidresolutionfailure']= 'Không giải quyết được id mô-đun';
$string['logger:pushcontentliveskip']= 'Lỗi đẩy nội dung trực tiếp';
$string['logger:pushcontentliveskip_exp']= 'Bỏ qua quảng cáo nội dung trực tiếp do vấn đề giao tiếp. Đẩy nội dung trực tiếp sẽ được khôi phục khi tác vụ cập nhật nội dung thành công. Vui lòng xem lại cấu hình của bạn. ';
$string['logger:pushcontentserror']= 'Đẩy đến điểm cuối của đồng minh không thành công';
$string['logger:pushcontentserror_exp']= 'Các lỗi liên quan đến cập nhật nội dung đẩy đến các dịch vụ của Ally.';
$string['logger:pushcontentsuccess']= 'Đẩy nội dung thành công đến điểm cuối đồng minh';
$string['logger:pushcourseerror']= 'Thất bại đẩy sự kiện khóa học trực tiếp';
$string['logger:pushcourseliveskip']= 'Thất bại đẩy sự kiện khóa học trực tiếp';
$string['logger:pushcourseliveskip_exp']= 'Bỏ qua (các) sự kiện trực tiếp của khóa học do vấn đề liên lạc. Đẩy sự kiện khóa học trực tiếp sẽ được khôi phục khi tác vụ cập nhật sự kiện khóa học thành công. Vui lòng xem lại cấu hình của bạn. ';
$string['logger:pushcourseserror']= 'Đẩy đến điểm cuối của đồng minh không thành công';
$string['logger:pushcourseserror_exp']= 'Các lỗi liên quan đến cập nhật khóa học đẩy đến các dịch vụ của Ally.';
$string['logger:pushcoursesuccess']= 'Đẩy thành công (các) sự kiện đến điểm kết thúc của đồng minh';
$string['logger:pushfileliveskip']= 'Lỗi đẩy tệp trực tiếp';
$string['logger:pushfileliveskip_exp']= 'Bỏ qua (các) tập tin trực tiếp đẩy do sự cố liên lạc. Đẩy tệp trực tiếp sẽ được khôi phục khi tác vụ cập nhật tệp thành công. Vui lòng xem lại cấu hình của bạn. ';
$string['logger:pushfileserror']= 'Đẩy đến điểm cuối của đồng minh không thành công';
$string['logger:pushfileserror_exp']= 'Các lỗi liên quan đến cập nhật nội dung đẩy đến các dịch vụ của Ally.';
$string['logger:pushfilesuccess']= 'Đẩy (các) tệp thành công đến điểm cuối của đồng minh';
$string['logger:pushtoallyfail']= 'Đẩy đến điểm cuối của đồng minh không thành công';
$string['logger:pushtoallysuccess']= 'Đẩy thành công đến điểm kết thúc của đồng minh';
$string['logger:servicefailure']= 'Không thành công khi sử dụng dịch vụ.';
$string['logger:servicefailure_exp']= '<br> Lớp: {$a->class} <br> Thông số: {$a->params}';
$string['loglevel:all']= 'Tất cả';
$string['loglevel:light']= 'Ánh sáng';
$string['loglevel:medium']= 'Trung bình';
$string['loglevel:none']= 'Không có';
$string['logrange']= 'Phạm vi nhật ký';
$string['logs']= 'Nhật ký đồng minh';
$string['message']= 'Tin nhắn';
$string['pluginname']= 'Đồng minh';
$string['privacy:metadata:files:action']= 'Hành động được thực hiện trên tệp, EG: được tạo, cập nhật hoặc xóa.';
$string['privacy:metadata:files:contenthash']= 'Hàm băm nội dung của tệp để xác định tính duy nhất.';
$string['privacy:metadata:files:courseid']= 'ID khóa học chứa tệp đó.';
$string['privacy:metadata:files:externalpurpose']= 'Để tích hợp với Ally, các tệp cần được trao đổi với Ally.';
$string['privacy:metadata:files:filecontents']= 'Nội dung của tệp thực sự được gửi đến Ally để đánh giá xem nó có khả năng truy cập hay không.';
$string['privacy:metadata:files:mimetype']= 'Loại tệp MIME, EG: text / trơn, image / jpeg, v.v.';
$string['privacy:metadata:files:pathnamehash']= 'Băm tên đường dẫn của tệp để xác định duy nhất nó.';
$string['privacy:metadata:files:timemodified']= 'Thời điểm trường được sửa đổi lần cuối.';
$string['pushfilessummary']= 'Tóm tắt cập nhật tệp của đồng minh.';
$string['pushfilessummary:explanation']= 'Tóm tắt các cập nhật tệp được gửi đến Ally.';
$string['pushurl']= 'URL cập nhật tệp';
$string['pushurldesc']= 'Thông báo đẩy về các cập nhật tệp cho URL này.';
$string['queuesendmessagesfailure']= 'Đã xảy ra lỗi khi gửi tin nhắn tới AWS SQS. Dữ liệu lỗi: $ a ';
$string['secret']= 'Bí mật';
$string['secretdesc']= 'Bí mật LTI.';
$string['section']= 'Đoạn {$a}';
$string['showdata']= 'Hiển thị dữ liệu';
$string['showexception']= 'Hiển thị ngoại lệ';
$string['showexplanation']= 'Hiển thị lời giải thích';
$string['usercapabilitymissing']= 'Người dùng được cung cấp không có khả năng xóa tệp này.';
