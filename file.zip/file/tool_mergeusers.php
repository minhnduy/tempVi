<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_mergeusers', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   tool_mergeusers
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['choose_users']= 'Chọn người dùng để hợp nhất';
$string['clear_selection']= 'Xóa lựa chọn người dùng hiện tại';
$string['cligathering:description']= 'Giới thiệu các cặp id của người dùng để hợp nhất cái đầu tiên vào \\ n
cái thứ hai. Id người dùng đầu tiên (fromid) sẽ \'mất \' tất cả dữ liệu của nó để được \'di chuyển \' \\ n
vào cái thứ hai (toid). Người dùng \'toid \' sẽ bao gồm dữ liệu từ cả hai người dùng. ';
$string['cligathering:fromid']= 'Id người dùng nguồn (fromid):';
$string['cligathering:stopping']= 'Để dừng hợp nhất, Ctrl + C hoặc gõ -1 vào các trường fromid hoặc toid.';
$string['cligathering:toid']= 'Id người dùng mục tiêu (toid):';
$string['dbko_no_transactions']= '<strong> Hợp nhất không thành công! </strong> <br/> Công cụ cơ sở dữ liệu của bạn
không hỗ trợ giao dịch. Do đó, cơ sở dữ liệu của bạn <strong> đã được cập nhật </strong>.
Trạng thái cơ sở dữ liệu của bạn có thể không nhất quán. <br/> Nhưng, hãy xem nhật ký hợp nhất
và vui lòng thông báo về lỗi cho các nhà phát triển plugin. Bạn sẽ nhận được một giải pháp
trong thời gian ngắn. Sau khi cập nhật plugin lên phiên bản cuối cùng, sẽ bao gồm giải pháp
đối với vấn đề đó, hãy lặp lại hành động hợp nhất để hoàn thành nó thành công. ';
$string['dbko_transactions']= '<strong> Hợp nhất không thành công! </strong> <br/> Công cụ cơ sở dữ liệu của bạn
hỗ trợ các giao dịch. Do đó, toàn bộ giao dịch hiện tại đã được lùi lại
và <strong> không có sửa đổi nào được thực hiện đối với cơ sở dữ liệu của bạn </strong>. ';
$string['dbok']= 'Hợp nhất thành công';
$string['deleted']= 'Người dùng có ID {$a} đã bị xóa';
$string['error_return']= 'Quay lại biểu mẫu tìm kiếm';
$string['errorsameuser']= 'Đang cố gắng hợp nhất cùng một người dùng';
$string['errortransactionsonly']= 'Lỗi: giao dịch là bắt buộc, nhưng cơ sở dữ liệu của bạn loại {$a}
không hỗ trợ họ. Nếu cần, bạn có thể cho phép hợp nhất người dùng mà không cần giao dịch.
Vui lòng xem lại cài đặt plugin để thiết lập chúng cho phù hợp. ';
$string['eventusermergedfailure']= 'Hợp nhất không thành công';
$string['eventusermergedsuccess']= 'Hợp nhất thành công';
$string['excluded_exceptions']= 'Loại trừ các ngoại lệ';
$string['excluded_exceptions_desc']= 'Kinh nghiệm về chủ đề này cho thấy
rằng tất cả các bảng cơ sở dữ liệu này nên được loại trừ khỏi việc hợp nhất. Xem
ĐỌC để biết thêm chi tiết. <br>
Do đó, để áp dụng hành vi plugin mặc định, bạn cần chọn \'{$a} \'
để loại trừ tất cả các bảng đó khỏi quá trình hợp nhất (được khuyến nghị). <br>
Nếu muốn, bạn có thể loại trừ bất kỳ bảng nào trong số đó và đưa chúng vào
quá trình hợp nhất (không khuyến khích). ';
$string['finishtime']= 'Kết thúc xong tại {$a}';
$string['form_description']= '<p> Bạn có thể tìm kiếm người dùng ở đây nếu bạn không
biết tên người dùng / số id của người dùng. Nếu không, bạn có thể mở rộng biểu mẫu thành
nhập trực tiếp thông tin đó. Vui lòng xem trợ giúp về các lĩnh vực để biết thêm
thông tin </p> ';
$string['form_header']= 'Tìm người dùng để hợp nhất';
$string['header']= 'Hợp nhất hai người dùng thành một tài khoản duy nhất';
$string['header_help']= '<p> Cho phép người dùng bị xóa và người dùng được giữ lại, điều này sẽ hợp nhất dữ liệu người dùng
liên kết với người dùng cũ thành người dùng sau. Lưu ý rằng cả hai người dùng phải
đã tồn tại và không có tài khoản nào sẽ thực sự bị xóa. Quá trình đó được để lại cho
quản trị viên để thực hiện thủ công. </p>
<p> <strong> Chỉ làm điều này nếu bạn biết mình đang làm gì vì nó không thể hoàn tác được! </strong> </p> ';
$string['into']= 'thành';
$string['invalid_option']= 'Tùy chọn biểu mẫu không hợp lệ';
$string['invaliduser']= 'Người dùng không hợp lệ';
$string['logid']= 'Để tham khảo thêm, các kết quả này được ghi lại trong id nhật ký {$a}.';
$string['logko']= 'Một số lỗi xảy ra:';
$string['loglist']= 'Tất cả các bản ghi này là các hành động hợp nhất được thực hiện, hiển thị nếu chúng hoạt động tốt:';
$string['logok']= 'Đây là các truy vấn đã được gửi đến DB:';
$string['mergeusers']= 'Hợp nhất các tài khoản người dùng';
$string['mergeusersadvanced']= '<strong> Người dùng nhập trực tiếp </strong>';
$string['mergeusersadvanced_help']= 'Tại đây bạn có thể nhập các trường dưới đây nếu
bạn biết chính xác những người dùng mà bạn muốn hợp nhất. <br /> <br />
Nhấp vào nút "tìm kiếm" để xác minh / xác nhận rằng đầu vào đã nhập
trên thực tế là người dùng. ';
$string['mergeusers_confirm']= 'Sau khi xác nhận quá trình hợp nhất sẽ bắt đầu.
<br /> <strong> Điều này sẽ không thể hoàn nguyên! </strong>
Bạn có chắc chắn muốn tiếp tục không? ';
$string['mergeusers:mergeusers']= 'Hợp nhất các tài khoản người dùng';
$string['mergeusers:view']= 'Hợp nhất Tài khoản Người dùng';
$string['merging']= 'Hợp nhất';
$string['newuser']= 'Người dùng cần lưu giữ';
$string['newuserid']= 'ID người dùng được giữ lại';
$string['newuseridonlog']= 'Người dùng được lưu giữ';
$string['nologs']= 'Chưa có nhật ký hợp nhất nào. Tốt cho bạn!';
$string['no_saveselection']= 'Bạn đã không chọn người dùng cũ hay người dùng mới.';
$string['olduser']= 'Người dùng cần xóa';
$string['olduserid']= 'ID người dùng bị xóa';
$string['olduseridonlog']= 'Người dùng bị xóa';
$string['pluginname']= 'Hợp nhất các tài khoản người dùng';
$string['privacy:metadata']= 'Plugin Merge User Accounts không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['qa_action_delete_fromid']= 'Giữ các nỗ lực từ người dùng mới';
$string['qa_action_delete_toid']= 'Giữ lại các nỗ lực từ người dùng cũ';
$string['qa_action_remain']= 'Không làm gì: không hợp nhất cũng không xóa';
$string['qa_action_remain_log']= 'Dữ liệu người dùng từ bảng <strong> {$a} </strong> không được cập nhật.';
$string['qa_action_renumber']= 'Các nỗ lực hợp nhất từ ​​cả người dùng và đánh số lại';
$string['qa_chosen_action']= 'Tùy chọn hoạt động cho các lần thử đố: {$a}.';
$string['qa_grades']= 'Điểm được tính lại cho các câu đố: {$a}.';
$string['quizattemptsaction']= 'Làm thế nào để giải quyết các lần thử câu đố';
$string['quizattemptsaction_desc']= 'Khi hợp nhất các bài kiểm tra có thể tồn tại ba trường hợp:
<ol>
<li> Chỉ người dùng cũ mới có lần thử bài kiểm tra. Tất cả người tham dự sẽ xuất hiện như thể chúng được tạo bởi người dùng mới. </li>
<li> Chỉ người dùng mới có các thử nghiệm. Tất cả đều chính xác và không có gì được thực hiện. </li>
<li> Cả hai người dùng đều thử cùng một bài kiểm tra. <strong> Bạn phải chọn phải làm gì trong trường hợp xung đột này.
</strong> Bạn bắt buộc phải chọn một trong các hành động sau:
<ul>
<li> <strong> {$a->renumber} </strong>. Các nỗ lực từ người dùng cũ được hợp nhất với các nỗ lực của người dùng mới
và được đánh số lại vào thời điểm bắt đầu. </li>
<li> <strong> {$a->delete_fromid} </strong>. Các nỗ lực từ người dùng cũ bị xóa. Nỗ lực từ người dùng mới
được giữ lại, vì tùy chọn này coi chúng là quan trọng nhất. </li>
<li> <strong> {$a->delete_toid} </strong>. Các nỗ lực từ người dùng mới đã bị xóa. Nỗ lực từ
người dùng cũ được giữ lại vì tùy chọn này coi họ là người quan trọng nhất. </li>
<li> <strong> {$a->remain} </strong> (theo mặc định). Các nỗ lực không được hợp nhất cũng như không bị xóa, vẫn liên quan đến
người dùng đã tạo ra chúng. Đây là hành động an toàn nhất nhưng việc hợp nhất người dùng từ người dùng A sang người dùng B hoặc B thành A có thể
tạo ra các loại câu đố khác nhau. </li>
</ Ul>
</li>
</ol> ';
$string['results']= 'Hợp nhất kết quả và nhật ký';
$string['review_users']= 'Xác nhận người dùng hợp nhất';
$string['saveselection_submit']= 'Lưu lựa chọn';
$string['searchuser']= 'Tìm kiếm người dùng';
$string['searchuser_help']= 'Nhập tên người dùng, họ / tên, địa chỉ email
hoặc id người dùng để tìm kiếm người dùng tiềm năng. Bạn cũng có thể chỉ định nếu bạn chỉ
muốn tìm kiếm thông qua một trường cụ thể. ';
$string['starttime']= 'Đã bắt đầu hợp nhất tại {$a}';
$string['suspenduser_setting']= 'Tạm ngừng người dùng cũ';
$string['suspenduser_setting_desc']= 'Nếu được bật, nó sẽ tạm ngưng người dùng cũ
tự động khi quá trình hợp nhất thành công, ngăn người dùng
từ đăng nhập Moodle (được khuyến nghị). Nếu bị vô hiệu hóa, người dùng cũ vẫn hoạt động.
Trong cả hai trường hợp, người dùng cũ sẽ không có dữ liệu liên quan của họ. ';
$string['tableko']= 'Bảng {$a}: cập nhật KHÔNG OK!';
$string['tableok']= 'Bảng {$a}: cập nhật OK';
$string['tableskipped']= 'Vì lý do ghi nhật ký hoặc bảo mật, chúng tôi đang bỏ qua <strong> {$a} </strong>.
<br /> Để xóa các mục này, hãy xóa người dùng cũ sau khi tập lệnh này chạy thành công. ';
$string['timetaken']= 'Hợp nhất mất {$a} giây';
$string['transactions_not_supported']= 'Để biết thông tin của bạn, cơ sở dữ liệu của bạn
<strong> không hỗ trợ giao dịch </strong>. ';
$string['transactions_setting']= 'Chỉ cho phép giao dịch';
$string['transactions_setting_desc']= 'Nếu được bật, hợp nhất người dùng sẽ không hoạt động
trên cơ sở dữ liệu KHÔNG hỗ trợ giao dịch (khuyến nghị).
Việc kích hoạt nó là cần thiết để đảm bảo rằng cơ sở dữ liệu của bạn vẫn nhất quán
trong trường hợp hợp nhất lỗi. <br /> Nếu bị tắt, bạn sẽ luôn chạy các hành động hợp nhất.
Trong trường hợp có lỗi, nhật ký hợp nhất sẽ cho bạn biết vấn đề là gì.
Báo cáo nó cho những người hỗ trợ plugin sẽ cung cấp cho bạn một giải pháp trong ngắn hạn.
<br /> Trên hết, các bảng Moodle cốt lõi và một số plugin của bên thứ ba đã
được xem xét bởi plugin này. Nếu bạn không có bất kỳ plugin nào của bên thứ ba
trong cài đặt Moodle của bạn, bạn có thể yên tâm chạy plugin này
bật hoặc tắt tùy chọn này. ';
$string['transactions_supported']= 'Để biết thông tin của bạn, cơ sở dữ liệu của bạn
<strong> hỗ trợ giao dịch </strong>. ';
$string['uniquekeynewidtomaintain']= 'Giữ dữ liệu của người dùng mới';
$string['uniquekeynewidtomaintain_desc']= 'Trong trường hợp xung đột,
như khi cột liên quan đến user.id là một khóa duy nhất, plugin này sẽ giữ
dữ liệu từ người dùng mới (theo mặc định). Điều này cũng có nghĩa là dữ liệu từ người dùng cũ
đã xóa để giữ tính nhất quán. Ngược lại, nếu bạn bỏ chọn tùy chọn này,
dữ liệu từ người dùng cũ sẽ được giữ lại. ';
$string['usermergingheader']= '&laquo;{$a->username}&raquo; (user ID = {$a->id})';

$string['userreviewtable_legend']= '<b> Xem xét người dùng để hợp nhất </b>';
$string['userselecttable_legend']= '<b> Chọn người dùng để hợp nhất </b>';
$string['viewlog']= 'Xem nhật ký hợp nhất';
$string['wronglogid']= 'Nhật ký bạn đang yêu cầu không tồn tại.';
