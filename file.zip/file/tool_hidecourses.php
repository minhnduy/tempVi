<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_hidecourses', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_hidecourses
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['changevisibilityconfirm']= 'Trang này cho phép bạn đặt khả năng hiển thị của tất cả các khóa học trong danh mục <strong> {$a->category} </strong> và các danh mục phụ của nó thành <strong> {$a->state} </strong> >. Hành động này không thể được hoàn tác.';
$string['hidden']= 'ẩn với sinh viên';
$string['hideallcourses']= 'Ẩn tất cả các khóa học';
$string['hidecourses:hidecourses']= 'Ẩn tất cả các khóa học trong một danh mục.';
$string['invalidactionid']= 'Id hành động không hợp lệ';
$string['pluginname']= 'Ẩn các khóa học';
$string['privacy:metadata']= 'Plugin Ẩn các khóa học không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['showallcourses']= 'Hiển thị tất cả các khóa học';
$string['updatequeued']= 'Một nhiệm vụ adhoc đã được xếp hàng đợi để cập nhật tất cả các khóa học trong danh mục <strong> {$a} </strong>. Nó sẽ chạy vào lần tiếp theo cron thực thi. ';
$string['visible']= 'hiển thị cho sinh viên';
