<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_supporter', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_supporter
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['beingduplicated']= 'Khóa học đang được sao chép. Việc này có thể mất một lúc.';
$string['enable_selfenrolment']= 'Kích hoạt tự đăng ký và đặt mật khẩu';
$string['level']= 'Cấp độ';
$string['pagetitle']= 'Moodle-Người hỗ trợ';
$string['pluginname']= 'Người ủng hộ';
$string['privacy:metadata']= 'Plugin này không lưu dữ liệu dành riêng cho người dùng, chỉ lưu các cài đặt chung.';
$string['sett_course_details']= 'Chi tiết khóa học';
$string['sett_course_details_desc']= 'Chi tiết khóa học được hiển thị ở trên cùng bên trái khi khóa học được nhấp vào.';
$string['sett_course_detail_showrolesandamount']= 'Hiển thị tất cả các vai trò và số lượng của chúng';
$string['sett_course_detail_showrolesandamount_desc']= 'Hiển thị rõ ràng tất cả các vai trò và số lượng của chúng trong một hàng bảng riêng biệt cho mỗi vai trò, tức là số lượng giáo viên, số lượng học sinh, v.v.';
$string['sett_course_table']= 'Bảng khóa học';
$string['sett_course_table_desc']= 'Bảng khóa học liệt kê tất cả các khóa học và được hiển thị ở phía dưới bên trái.';
$string['sett_course_table_pagelength']= 'Số lượng các khóa học được hiển thị';
$string['sett_levels']= 'Ghi nhãn các cấp độ danh mục khóa học';
$string['sett_levels_default']= 'Học kỳ; Khoa';
$string['sett_levels_description']= 'Chỉ định tên hiển thị của các cấp độ khóa học. Theo thứ tự giảm dần (cấp trên cùng trước) và được phân tách bằng dấu chấm phẩy. ';
$string['sett_never']= 'không bao giờ';
$string['sett_sort_course_details']= 'Sắp xếp cột ID trong chế độ xem khóa học (người dùng đã đăng ký)';
$string['sett_sort_course_table']= 'Sắp xếp cột ID trong bảng khóa học';
$string['sett_sort_user_details']= 'Sắp xếp cột ID trong chế độ xem của người dùng (các khóa học đã đăng ký)';
$string['sett_sort_user_table']= 'Sắp xếp cột ID trong bảng người dùng';
$string['sett_title']= 'Cấu hình trình hỗ trợ';
$string['sett_user_details']= 'Chi tiết người dùng';
$string['sett_user_details_desc']= 'Chi tiết người dùng được hiển thị ở trên cùng bên phải khi người dùng được nhấp vào.';
$string['sett_user_table']= 'Bảng người dùng';
$string['sett_user_table_desc']= 'Bảng người dùng liệt kê tất cả người dùng và được hiển thị ở phía dưới bên phải.';
$string['sett_user_table_pagelength']= 'Số lượng các khóa học của người dùng được hiển thị';
$string['strftimesecondsdatetimeshort']= '% d /% m /% Y,% H:% M:% S';
$string['toolsupporter']= 'người hỗ trợ công cụ';
