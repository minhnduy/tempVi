<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_dynamicrule', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_dynamicrule
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['active']= 'Hoạt động';
$string['activerules']= 'Quy tắc hoạt động';
$string['addcondition']= 'Thêm điều kiện';
$string['addconditions']= 'Thêm điều kiện vào quy tắc này';
$string['addoutcome']= 'Thêm hành động';
$string['addoutcomes']= 'Thêm hành động vào quy tắc này';
$string['after']= 'Bật hoặc sau';
$string['archive']= 'Lưu trữ';
$string['archived']= 'Đã lưu trữ';
$string['archivedrules']= 'Quy tắc lưu trữ';
$string['archiverule']= 'Quy tắc lưu trữ \' {$a} \\';
$string['availableplaceholders']= 'Trình giữ chỗ có sẵn';
$string['before']= 'Trước';
$string['body']= 'Cơ thể';
$string['broken']= 'Bị hỏng';
$string['cachedef_eventsubscriptions']= 'Điều này lưu trữ danh sách các đăng ký sự kiện cho các điều kiện quy tắc.';
$string['cannotenablecomponentrule']= 'Không thể bật quy tắc \' {$a} \'trừ khi nó có các hành động và không chứa bất kỳ lỗi nào.';
$string['cannotenablerule']= 'Không thể bật quy tắc \' {$a} \'trừ khi nó có các điều kiện, hành động và không có bất kỳ lỗi nào.';
$string['cohort']= 'Nhóm thuần tập';
$string['conditioncohortmember']= 'Người dùng là thành viên của nhóm thuần tập';
$string['conditioncohortmemberdescription']= 'Người dùng là thành viên của nhóm thuần tập \' {$a} \\';
$string['conditioncohortmemberdescriptionwithdate']= 'Người dùng là thành viên của nhóm thuần tập \' {$a->name} \'<br />
Đã thêm vào nhóm thuần tập vào hoặc sau: \'{$a->conditiondate} \\';
$string['conditioncohortnotmember']= 'Người dùng không phải là thành viên của nhóm thuần tập';
$string['conditioncohortnotmemberdescription']= 'Người dùng không phải là thành viên của nhóm thuần tập \' {$a} \\';
$string['conditioncoursecompleted']= 'Khóa học đã hoàn thành';
$string['conditioncoursecompleteddescription']= 'Người dùng đã hoàn thành khóa học \' {$a} \\';
$string['conditioncoursecompleteddescriptionwithdate']= 'Người dùng đã hoàn thành khóa học \' {$a->coursename} \'<br />
Ngày hoàn thành vào hoặc \'{$a->datetype} \': \'{$a->conditiondate} \\';
$string['conditioncoursenotcompleted']= 'Khóa học chưa hoàn thành';
$string['conditioncoursenotcompleteddescription']= 'Người dùng chưa hoàn thành khóa học \' {$a} \\';
$string['conditionisbroken']= 'Điều kiện này có lỗi.';
$string['conditionisnotavailable']= 'Điều kiện này không có sẵn.';
$string['conditionnotsaved']= 'Điều kiện không được lưu.';
$string['conditions']= 'Điều kiện';
$string['conditionuserenrolled']= 'Người dùng đã đăng ký';
$string['conditionuserenrolleddescription']= 'Người dùng đã đăng ký khóa học \' {$a->course} \'<br />
Phương thức đăng ký: \'{$a->enrol} \\';
$string['conditionuserenrolleddescriptionwithdate']= 'Người dùng đã đăng ký khóa học \' {$a->course} \'<br />
Phương thức đăng ký: \'{$a->enrol} \' <br />
Ngày bắt đầu ghi danh vào hoặc sau: \'{$a->conditiondate} \\';
$string['conditionuserlastlogin']= 'Lần đăng nhập cuối cùng của người dùng';
$string['conditionuserlastlogindescriptionbefore']= 'Người dùng đăng nhập lần cuối hơn {$a} trước';
$string['conditionuserlastlogindescriptionever']= 'Người dùng đã đăng nhập ít nhất một lần';
$string['conditionuserlastlogindescriptioninlast']= 'Người dùng đã đăng nhập trong {$a} gần đây nhất';
$string['conditionuserlastlogindescriptionnever']= 'Người dùng chưa bao giờ đăng nhập';
$string['conditionusernotenrolled']= 'Người dùng chưa đăng ký';
$string['conditionusernotenrolleddescription']= 'Người dùng chưa đăng ký khóa học \' {$a->course} \'<br />
Phương thức đăng ký: \'{$a->enrol} \\';
$string['conditionusernotenrolleddescriptionwithenrol']= 'Người dùng chưa đăng ký khóa học \' {$a->course} \'với phương thức đăng ký \' {$a->enrol} \\';
$string['conditionuserprofilefield']= 'Trường hồ sơ người dùng';
$string['conditionuserprofilefielddescription']= 'Người dùng có giá trị cho trường hồ sơ \' {$a->fieldname} \'là \' {$a->fieldvalue} \\';
$string['conditionuserprofilefielddescriptiontext']= 'Người dùng có giá trị cho trường cấu hình \' {$a->fieldname} \'{$a->fieldvalue}';
$string['confirmarchiverule']= 'Bạn có chắc chắn muốn lưu trữ quy tắc \' {$a} \'không? Các quy tắc động đã lưu trữ sẽ vẫn có sẵn cho các báo cáo hiện tại và trong tương lai. ';
$string['confirmdeletecondition']= 'Bạn có chắc chắn muốn xóa điều kiện \' {$a} \'và tất cả dữ liệu liên quan không? Hành động này không thể được hoàn tác.';
$string['confirmdeleteoutcome']= 'Bạn có chắc chắn muốn xóa hành động \' {$a} \'và tất cả dữ liệu liên quan không? Hành động này không thể được hoàn tác.';
$string['confirmdeleterule']= 'Bạn có chắc chắn muốn xóa quy tắc \' {$a} \'và tất cả dữ liệu liên quan không? Hành động này không thể được hoàn tác.';
$string['confirmdisableruleforedit']= 'Quy tắc này sẽ tự động bị vô hiệu hóa để chỉnh sửa.';
$string['confirmduplicaterule']= 'Bạn có chắc chắn muốn sao chép quy tắc \' {$a} \'không?';
$string['confirmeditrule']= 'Vì trước đây một số người dùng đã đối sánh với quy tắc này, bạn sẽ chỉ có thể chỉnh sửa các hành động của quy tắc. Bạn có thể xem xét sao chép nó để sửa đổi các điều kiện của nó ';
$string['confirmenablecomponentrule']= 'Bạn có chắc chắn muốn bật quy tắc này không? Bật nó sẽ ảnh hưởng đến người dùng {$a}. ';
$string['confirmenablerule']= 'Các điều kiện sẽ bị khóa khi có ít nhất một người dùng bị ảnh hưởng bởi quy tắc này. Bạn có chắc chắn muốn bật quy tắc này không? ';
$string['countmatchingusers']= '{$a} tổng số trận đấu';
$string['courseinternalid']= 'ID khóa học nội bộ được sử dụng trong URL';
$string['courseurl']= 'URL khóa học';
$string['date']= 'Ngày';
$string['datetypeever']= 'Đã từng';
$string['datetypeinlast']= 'Cuối cùng';
$string['datetypenever']= 'Không bao giờ';
$string['datetypenone']= 'Chưa đặt';
$string['datetypepast']= 'Hết';
$string['deletecondition']= 'Xóa điều kiện';
$string['deleteoutcome']= 'Xóa hành động';
$string['deleterule']= 'Xóa quy tắc \' {$a} \\';
$string['details']= 'Chi tiết';
$string['disablerule']= 'Tắt quy tắc \' {$a} \\';
$string['duplicate']= 'Bản sao';
$string['duplicaterule']= 'Quy tắc trùng lặp \' {$a} \\';
$string['during']= 'trong khi';
$string['dynamicrule:manage']= 'Quản lý các quy tắc động';
$string['editactions']= 'Chỉnh sửa hành động của quy tắc \' {$a} \\';
$string['editanyway']= 'Vẫn chỉnh sửa';
$string['editcondition']= 'Chỉnh sửa điều kiện';
$string['editdetails']= 'Chỉnh sửa chi tiết quy tắc \' {$a} \\';
$string['editdetailsbutton']= 'Chỉnh sửa chi tiết';
$string['editoutcome']= 'Chỉnh sửa hành động';
$string['editrule']= 'Chỉnh sửa quy tắc \' {$a} \\';
$string['editrulename']= 'Chỉnh sửa tên quy tắc \' {$a} \\';
$string['enable']= 'Bật';
$string['enablehelp']= 'quy tắc kích hoạt';
$string['enablehelp_help']= 'Quy tắc yêu cầu ít nhất một điều kiện và một hành động để được kích hoạt. Ngoài ra, các điều kiện hoặc hành động không được có lỗi. ';
$string['enablehelpmodal']= 'quy tắc kích hoạt';
$string['enablehelpmodal_help']= 'Quy tắc yêu cầu ít nhất một hành động được kích hoạt.';
$string['enablerule']= 'Bật quy tắc \' {$a} \\';
$string['errorbadgehasextracriteria']= 'Huy hiệu này có một tiêu chí bắt buộc khác ngoài vấn đề thủ công, do đó không thể là vấn đề theo quy tắc động';
$string['errorbadgenopermission']= 'Bạn không có vai trò cần thiết để cấp huy hiệu này';
$string['errorcannotcreate']= 'Bạn không có quyền tạo quy tắc';
$string['errorcannotmanage']= 'Bạn không có quyền quản lý quy tắc này';
$string['errorcannotmanagecondition']= 'Bạn không có quyền quản lý điều kiện này';
$string['errorcannotmanageoutcome']= 'Bạn không có quyền quản lý hành động này';
$string['errorcompletionnotenabled']= 'Khóa học này không được hoàn thành';
$string['errorinvalidbadge']= 'Huy hiệu không hợp lệ';
$string['errorinvalidbody']= 'Nội dung thông báo không hợp lệ';
$string['errorinvalidcohort']= 'Nhóm thuần tập không hợp lệ';
$string['errorinvalidcompetency']= 'Năng lực không hợp lệ';
$string['errorinvalidcourse']= 'Khóa học không hợp lệ';
$string['errorinvalidenrolmentmethod']= 'Khóa học này không có phương thức ghi danh đã chọn hoặc chưa được kích hoạt';
$string['errorinvalidoperator']= 'Toán tử không hợp lệ. Chỉ trước và sau mới được phép. ';
$string['errorinvalidsubject']= 'Chủ đề thông báo không hợp lệ';
$string['errorinvaliduserlastlogin']= 'Ngày đăng nhập cuối cùng không hợp lệ';
$string['errorinvaliduserlastlogintype']= 'Kiểu đăng nhập cuối cùng không hợp lệ';
$string['errorinvaliduserprofilefield']= 'Trường hồ sơ không hợp lệ';
$string['errorinvaliduserprofilefieldvalue']= 'Giá trị trường hồ sơ không hợp lệ';
$string['errornopermissionissuecertificate']= 'Bạn không được phép cấp chứng chỉ này';
$string['ever']= 'đã từng';
$string['exporterdescription']= 'Định nghĩa quy tắc động, điều kiện và hành động';
$string['exportselectactive']= 'Chọn tất cả các quy tắc Động (không bao gồm lưu trữ)';
$string['exportselectall']= 'Chọn tất cả các quy tắc Động (kể cả đã lưu trữ)';
$string['exportselectenabled']= 'Chọn tất cả các quy tắc Động đã bật';
$string['exportsettings']= 'Định nghĩa quy tắc, điều kiện và hành động';
$string['exportsettings_help']= 'Tất cả các quy tắc sẽ bị vô hiệu hóa khi được nhập, bất kể trạng thái ban đầu của chúng.';
$string['field']= 'Trường';
$string['general']= 'Chung';
$string['importlogerror']= 'Không thể nhập quy tắc \' {$a} \\';
$string['importlogerrorinvalidcondition']= 'Điều kiện quy tắc bị thiếu hoặc không hợp lệ';
$string['importlogerrorinvalidoutcome']= 'Kết quả quy tắc bị thiếu hoặc không hợp lệ';
$string['importlogsuccess']= 'Đã tạo quy tắc mới \' {$a->name} \'với các điều kiện {$a->conditionscount} và {$a->outcomescount} hành động';
$string['importlogsuccesslink']= 'Đã tạo quy tắc mới \' <a href="{$a->url}"> {$a->name} </a> \'với điều kiện {$a->conditionscount} {$a->outcomescount} hành động ';
$string['importselectall']= 'Chọn tất cả các quy tắc Động trong tệp này';
$string['importselectspecified']= 'Chọn thủ công ...';
$string['lastlogin']= 'Lần đăng nhập cuối cùng của người dùng là';
$string['lastlogin_help']= 'Bạn có thể chọn ngày liên quan đến ngày hiện tại hoặc người dùng chưa bao giờ đăng nhập.';
$string['limitreached']= 'Đã đạt đến giới hạn quy tắc động';
$string['limitreacheddescr']= 'Bạn đã đạt đến giới hạn về số lượng quy tắc động trên trang web này. Xin lưu ý rằng các quy tắc đã lưu trữ cũng được tính vào giới hạn này. ';
$string['limitreachednumdescr']= 'Bạn chỉ có thể tạo (các) quy tắc động {$a} trên trang web này. Xin lưu ý rằng các quy tắc đã lưu trữ cũng được tính vào giới hạn này. ';
$string['managebadges']= 'Quản lý huy hiệu';
$string['managecohorts']= 'Quản lý nhóm thuần tập';
$string['managecompetencies']= 'Quản lý năng lực';
$string['managerules']= 'Quản lý các quy tắc';
$string['match']= 'Kết hợp';
$string['matchedtime']= 'Thời gian phù hợp';
$string['matchlimitinvalid']= 'Quy tắc cần được kích hoạt ít nhất một lần.';
$string['messageprovider:notificationoutcome']= 'Hành động thông báo cho công cụ quy tắc động';
$string['missingcondition']= 'Thiếu điều kiện';
$string['missingconditiondescr']= 'Điều kiện \' {$a->condition} \'không tồn tại trong plugin \' {$a->plugin} \'.';
$string['missingoutcome']= 'Thiếu hành động';
$string['missingoutcomedescr']= 'Action \' {$a->outcome} \'không tồn tại trong plugin \' {$a->plugin} \'.';
$string['newnameforrule']= 'Tên mới cho quy tắc \' {$a} \\';
$string['newrule']= 'Quy tắc mới';
$string['noavailablebadges']= 'Không có sẵn huy hiệu';
$string['noavailablecohorts']= 'Không có nhóm thuần tập nào';
$string['noavailablecompletioncourses']= 'Không có khóa học nào đã hoàn thành được bật';
$string['noavailableenrolledcourses']= 'Không có khóa học nào mà bạn có thể truy cập danh sách người tham gia';
$string['noruleconditions']= 'Không có điều kiện về quy tắc này';
$string['noruleoutcomes']= 'Không có hành động nào đối với quy tắc này';
$string['onorafter']= 'on or after';
$string['operator']= 'Điều kiện';
$string['operatorafter']= 'Sau khi';
$string['operatorbefore']= 'Trước';
$string['outcomebadge']= 'Huy hiệu giải thưởng';
$string['outcomebadgedescription']= 'Huy hiệu trao thưởng \' {$a} \'cho người dùng';
$string['outcomecertificate']= 'Cấp chứng chỉ';
$string['outcomecertificatedescription']= 'Cấp chứng chỉ \' {$a} \'cho người dùng';
$string['outcomecohort']= 'Thêm vào nhóm thuần tập';
$string['outcomecohortbroken']= 'Nhóm thuần tập có ID \' {$a} \'không tồn tại.';
$string['outcomecohortdescription']= 'Thêm người dùng vào nhóm thuần tập \' {$a} \\';
$string['outcomecompetency']= 'Năng lực giải thưởng';
$string['outcomecompetencybroken']= 'Năng lực với ID \' {$a} \'không tồn tại.';
$string['outcomecompetencydescription']= 'Trao giải năng lực \' {$a} \'cho người dùng';
$string['outcomeisbroken']= 'Hành động này có lỗi.';
$string['outcomeisnotavailable']= 'Thao tác này không khả dụng.';
$string['outcomenotification']= 'Thông báo';
$string['outcomenotificationdescription']= 'Gửi thông báo \' {$a} \'cho người dùng';
$string['outcomenotsaved']= 'Hành động không được lưu.';
$string['outcomes']= 'Hành động';
$string['per']= 'mỗi';
$string['placeholdersdesc']= 'Phần giữ chỗ';
$string['placeholdersdesc_help']= 'Phần giữ chỗ cho phép bạn thêm nội dung động, ví dụ: Trình giữ chỗ {{userfullname}} sẽ được thay thế bằng tên đầy đủ của người dùng trong thông báo được gửi đến người dùng. ';
$string['pluginname']= 'Quy tắc động';
$string['previewcoursefullname']= 'Tên đầy đủ của khóa học';
$string['previewcourseshortname']= 'Tên viết tắt của khóa học';
$string['privacy:metadata:tool_dynamicrule_match']= 'Thông tin về người dùng phù hợp với các điều kiện quy tắc cụ thể. Do người dùng phù hợp bị ảnh hưởng bởi các hành động được xác định trong quy tắc. ';
$string['privacy:metadata:tool_dynamicrule_match:matchedtime']= 'Dấu thời gian cho biết khi nào người dùng được đối sánh với các điều kiện quy tắc.';
$string['privacy:metadata:tool_dynamicrule_match:ruleid']= 'ID của quy tắc.';
$string['privacy:metadata:tool_dynamicrule_match:unmatchedtime']= 'Dấu thời gian cho biết khi nào người dùng không còn phù hợp với điều kiện quy tắc sau khi hành động đã được áp dụng.';
$string['privacy:metadata:tool_dynamicrule_match:userid']= 'ID của người dùng đã được khớp với các điều kiện quy tắc.';
$string['reg_wpdynamicrules']= 'Số quy tắc động ({$a})';
$string['reportmatchingusers']= 'Báo cáo với những người dùng phù hợp với quy tắc động';
$string['reportrulematches']= 'Báo cáo với những người dùng phù hợp và không phù hợp với quy tắc động';
$string['reportruleslist']= 'Báo cáo hệ thống cho danh sách quy tắc';
$string['rolemanager']= 'Trình quản lý quy tắc động';
$string['rolemanagerdescription']= 'Cho phép tạo và quản lý các quy tắc động trong đối tượng thuê hiện tại';
$string['ruledisabled']= 'Quy tắc này bị vô hiệu hóa.';
$string['ruleisbroken']= 'Quy tắc này bị phá vỡ. Ít nhất một trong các điều kiện hoặc hành động của nó bị hỏng. ';
$string['rulematchfreq']= 'Giới hạn hành động quy tắc';
$string['rulematchfreqdesc0']= 'Không thể áp dụng nhiều hơn';
$string['rulematchfreqdesc1']= 'lần';
$string['rulematchfreqenable']= 'Giới hạn số lần các hành động được áp dụng cho mỗi người dùng';
$string['rulematchfreq_help']= 'Ngay sau khi người dùng phù hợp với các điều kiện quy tắc, các hành động sẽ được áp dụng cho họ. Những hành động này sẽ không áp dụng lại nếu người dùng tiếp tục phù hợp với các điều kiện. Tuy nhiên, nếu người dùng ngừng đối sánh và sau đó đối sánh lại, các hành động có thể được áp dụng lại. Cài đặt này xác định số lần tối đa các hành động nên áp dụng. ';
$string['rulename']= 'Tên';
$string['rulenotfound']= 'Không tìm thấy quy tắc.';
$string['ruleselectitemarchived']= '{$a} (đã lưu trữ)';
$string['select']= 'Chọn';
$string['selectbadge']= 'Chọn huy hiệu';
$string['selectbadge_help']= 'Để được cấp bởi quy tắc động, huy hiệu trang web cần được bật và có thêm tiêu chí phát hành thủ công.';
$string['selectcertificate']= 'Chọn chứng chỉ';
$string['selectcompetency']= 'Chọn năng lực';
$string['selectcompetency_help']= 'Chọn năng lực để phát hành';
$string['subject']= 'Chủ đề';
$string['taskprocessrules']= 'Quy trình xử lý';
$string['timeadded']= 'Được thêm vào nhóm thuần tập vào hoặc sau ngày và giờ này';
$string['timecompleted']= 'Ngày và giờ hoàn thành vào hoặc sau';
$string['timeenrolled']= 'Ngày và giờ bắt đầu ghi danh vào hoặc sau';
$string['toomanybadgestoshow']= 'Quá nhiều huy hiệu để hiển thị';
$string['toomanycertificatestoshow']= 'Quá nhiều chứng chỉ ({$a}) để hiển thị';
$string['unarchiverule']= 'Quy tắc hủy lưu trữ \' {$a} \\';
$string['unmatchedtime']= 'Thời gian chưa từng có';
$string['userplaceholders']= 'Trình giữ chỗ của người dùng';
$string['value']= 'Giá trị';
$string['viewmatchingusers']= 'Xem những người dùng phù hợp';
$string['viewreport']= 'Xem báo cáo cho \' {$a} \\';
$string['warningchangeswillnotapplymatchedusers']= 'Những thay đổi sẽ không áp dụng cho những người dùng đã phù hợp với quy tắc này trong quá khứ';
