<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_coursesearch', language 'en', branch 'MOODLE_28_STABLE'
 *
 * @package   tool_coursesearch
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['actions']= 'Hành động';
$string['advancecoursesearch']= 'Trợ giúp tìm kiếm khóa học nâng cao';
$string['advancecoursesearch_help']= '<pre> <b> 1. Tự động đề xuất với hộp tìm kiếm </b>: - Bắt đầu nhập từ khóa tìm kiếm của bạn và bạn sẽ có các đề xuất tự động hoàn thành. Các trường đề xuất là isnumber, tên đầy đủ của khóa học, tên viết tắt.
<br/> <br/> </pre>
<pre> <b> 2. Tìm kiếm theo ký tự đại diện </b>: - bạn có thể sử dụng các thẻ đại diện (?, *) khi tìm kiếm các khóa học.
Ví dụ: - Moodle * tìm kiếm tất cả các khóa học bắt đầu từ từ "moodle".
<br/> <br/> </pre>
<pre> <b> 3. Đối sánh vùng lân cận </b>: - bạn có thể tìm kiếm theo các từ từ các khóa học nằm trong khoảng cách cụ thể.
Ví dụ: - Tìm kiếm "foo bar" cách nhau 4 từ.
"foo bar" ~ 4
<br/> <br/> </pre>
<pre> <b> 4. Đối sánh từ khóa (tìm kiếm trong trường cụ thể) </b>: - bạn có thể giới hạn tìm kiếm của mình trong trường cụ thể bằng cách sử dụng tính năng đối sánh từ khóa solr.
Ví dụ: - Tìm kiếm từ "PHP" trong trường tên đầy đủ và "hướng đối tượng" trong trường tóm tắt.
fullname: "PHP" VÀ tóm tắt: "hướng đối tượng"
<br/> <br/> </pre>
<pre> <b> 5. Lọc kết quả theo ngày bắt đầu </b>: - bạn có thể lọc kết quả tìm kiếm của mình bằng cách chọn phạm vi ngày gần đúng của khóa học.
<br/> <br/> </pre>
<pre> <b> 6. Sắp xếp kết quả </b>: - Theo mặc định, kết quả được sắp xếp theo mức độ liên quan (điểm số). bạn có thể sắp xếp kết quả theo mức độ liên quan, ngày bắt đầu, tên viết tắt.
<br/> <br/> </pre> ';
$string['changessaved']= 'Đã lưu cấu hình!';
$string['coursesearchintro']= 'Plugin Tìm kiếm Khóa học Nâng cao thay thế tìm kiếm Khóa học Moodle mặc định bằng tìm kiếm Solr mạnh mẽ.';
$string['coursesearchsettings']= 'Cài đặt Tìm kiếm Khóa học';
$string['defaulttext']= 'Nhập truy vấn tìm kiếm của bạn tại đây:';
$string['delete']= 'Xóa tất cả';
$string['didyoumean']= 'Did you mean&nbsp;';

$string['emptyqueryfield']= 'Truy vấn không được để trống!';
$string['enablespellcheck']= 'Bật trình kiểm tra chính tả và đề xuất';
$string['enablespellcheck_help']= 'Bật tính năng kiểm tra chính tả và nhận đề xuất từ. Còn được gọi là "Ý bạn là ...?" đặc tính.';
$string['filtercheckbox']= 'Tắt tất cả các bộ lọc';
$string['filtercheckbox_help']= 'Tắt tất cả các bộ lọc';
$string['filterresults']= 'kết quả lọc';
$string['go']= 'Đi';
$string['loadcontent']= 'Chỉ mục các khóa học';
$string['optimize']= 'Tối ưu hóa chỉ mục';
$string['options']= 'Tùy chọn';
$string['overviewindexing']= 'Lập chỉ mục các tệp tổng quan về khóa học';
$string['overviewindexing_help']= 'Lập chỉ mục các tệp tổng quan về khóa học và tìm kiếm các tên tệp đó và nội dung của chúng.';
$string['pingstatus']= 'Kiểm tra cài đặt phiên bản Solr';
$string['pluginname']= 'Tìm kiếm khóa học trước';
$string['pluginsettings']= 'Cài đặt tìm kiếm khóa học';
$string['savesettings']= 'Lưu cài đặt';
$string['searchcourses']= 'Tìm kiếm khóa học:';
$string['searchfromtime']= 'Bắt ​​đầu từ:';
$string['searchfromtime_help']= 'Lọc kết quả tìm kiếm của bạn từ ngày bắt đầu khóa học. Chọn phạm vi ngày bắt đầu gần đúng cho khóa học của bạn. ';
$string['searchlabel']= 'Tìm kiếm khóa học:';
$string['searchtilltime']= 'Bắt ​​đầu đến:';
$string['searchtilltime_help']= 'Lọc kết quả tìm kiếm của bạn từ ngày bắt đầu khóa học. Chọn phạm vi ngày bắt đầu gần đúng cho khóa học của bạn. ';
$string['searchurl']= 'Cài đặt tìm kiếm khóa học';
$string['settings']= 'Cài đặt Tìm kiếm Khóa học';
$string['showerrormessageno']= 'Hiển thị thông báo lỗi: Không';
$string['showerrormessageyes']= 'Hiển thị thông báo lỗi: Có';
$string['solrconfig']= 'Cài đặt tìm kiếm khóa học nâng cao';
$string['solrerrormessage']= 'Không thành công';
$string['solrerrormessage_help']= 'Hiển thị gì nếu không có tìm kiếm Apache Solr.';
$string['solrheading']= 'Cấu hình giải mã Apache';
$string['solrhost']= 'Máy chủ Solr';
$string['solrhost_help']= 'Tên máy chủ của máy chủ Solr của bạn, ví dụ: localhost hoặc example.com. ';
$string['solrpassword']= 'Mật khẩu Solr';
$string['solrpassword_help']= 'Nếu bạn đang sử dụng xác thực http, hãy cung cấp mật khẩu solr của bạn, nếu không hãy để trống.';
$string['solrpath']= 'Đường đi Solr';
$string['solrpath_help']= 'Đường dẫn xác định trình xử lý yêu cầu Solr được sử dụng.';
$string['solrpingerror']= 'Apache Solr: Trang web của bạn không thể liên hệ với
Máy chủ Apache Solr. Kết quả tìm kiếm sẽ xuất hiện từ tìm kiếm theo tâm trạng cốt lõi. ';
$string['solrport']= 'Cổng Solr';
$string['solrport_help']= 'Cổng mà máy chủ Solr lắng nghe. Máy chủ mẫu Jetty là 8983, trong khi Tomcat là 8080 theo mặc định. ';
$string['solrusername']= 'Tên người dùng Solr';
$string['solrusername_help']= 'Nếu bạn đang sử dụng xác thực http, hãy cung cấp tên người dùng solr của bạn, nếu không hãy để trống.';
$string['sortby']= 'Sắp xếp theo:';
$string['sortheading']= 'sắp xếp kết quả';
$string['sortmenu']= 'Sắp xếp kết quả';
$string['sortmenu_help']= 'Sắp xếp kết quả với các khía cạnh khác nhau';
$string['summaryindexing']= 'Lập chỉ mục tệp tóm tắt khóa học';
$string['summaryindexing_help']= 'Lập chỉ mục các tệp tóm tắt khóa học và tìm kiếm các tên tệp đó';
