<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_heartbeat', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_heartbeat
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['normal']= 'Giám sát bình thường';
$string['pluginname']= 'Nhịp tim';
$string['progress']= 'Kiểm tra thanh tiến trình';
$string['progresshelp']= 'Điều này kiểm tra rằng tất cả các bộ đệm đầu ra khác nhau trong toàn bộ ngăn xếp là đúng, bao gồm nhưng không giới hạn ở php, ob, gzip / deflat, varnish, nginx, v.v.';
$string['testerror']= 'Giả mạo một người chỉ trích';
$string['testing']= 'Kiểm tra nhịp tim';
$string['testingdesc']= 'Bạn có thể sử dụng điều này để tạm thời giả mạo một cảnh báo hoặc điều kiện lỗi để kiểm tra xem việc giám sát của bạn có hoạt động chính xác hay không.';
$string['testwarning']= 'Giả mạo cảnh báo';
