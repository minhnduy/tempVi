<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'videofile', language 'en', branch 'MOODLE_27_STABLE'
 *
 * @package   videofile
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['captions']= 'Chú thích';
$string['captions_help']= 'Thêm bản ghi lời thoại ở định dạng WebVTT tại đây. \\ n \\ nBạn có thể thêm một số tệp để cung cấp phụ đề đa ngôn ngữ. Tên tệp, không có phần mở rộng, sẽ được sử dụng cho tiêu đề tùy chọn phụ đề video. Nếu các tệp được đặt tên theo ISO 6392 (ví dụ: eng.vtt và swe.vtt), các tùy chọn sẽ được hiển thị dưới dạng tên ngôn ngữ đầy đủ tương ứng theo tùy chọn ngôn ngữ của người dùng (ví dụ: tiếng Anh và tiếng Thụy Điển, giả sử người dùng \' ngôn ngữ ưa thích của được đặt thành tiếng Anh). ';
$string['err_positive']= 'Bạn phải nhập một số dương ở đây.';
$string['filearea_captions']= 'Chú thích';
$string['filearea_posters']= 'Áp phích';
$string['filearea_videos']= 'Video';
$string['height']= 'Chiều cao';
$string['height_explain']= 'Chỉ định chiều cao mặc định của trình phát video.';
$string['height_help']= 'Nhập chiều cao của video tại đây (ví dụ: 500 cho chiều cao 500 pixel).';
$string['limitdimensions']= 'Giới hạn kích thước trong chế độ đáp ứng?';
$string['limitdimensions_explain']= 'Chỉ định xem chiều rộng và chiều cao có nên được sử dụng làm kích thước tối đa trong chế độ đáp ứng hay không.';
$string['modulename']= 'Tệp video';
$string['modulename_help']= 'Sử dụng mô-đun tệp video để thêm video html5 với dự phòng flash (sử dụng video.js). Mô-đun này cũng cho phép phụ đề đa ngôn ngữ. ';
$string['modulenameplural']= 'Tập tin video';
$string['pluginadministration']= 'Quản trị tệp video';
$string['pluginname']= 'Tệp video';
$string['posters']= 'Hình ảnh áp phích';
$string['posters_help']= 'Thêm hình ảnh ở đây sẽ được hiển thị trước khi video bắt đầu phát.';
$string['responsive']= 'Có phản hồi không?';
$string['responsive_explain']= 'Chỉ định xem chế độ đáp ứng có nên được đặt làm mặc định hay không.';
$string['responsive_help']= 'Chọn để video tự động thay đổi kích thước với kích thước cửa sổ trình duyệt. \\ n \\ nSử dụng các trường chiều rộng và chiều cao để xác định tỷ lệ video (ví dụ: 16/9 hoặc 800/450).';
$string['responsive_label']= '';
$string['video_fieldset']= 'Video';
$string['videofile:addinstance']= 'Thêm tệp video mới';
$string['videofile_defaults_heading']= 'Giá trị mặc định cho cài đặt tệp video';
$string['videofile_defaults_text']= 'Các giá trị bạn đặt ở đây xác định các giá trị mặc định được sử dụng trong biểu mẫu cài đặt tệp video khi bạn tạo một tệp video mới.';
$string['videofile:view']= 'Xem tệp video';
$string['video_not_playing']= 'Video không phát? Hãy thử {$a}. ';
$string['videos']= 'Video';
$string['videos_help']= 'Thêm tệp video vào đây. \\ n \\ nBạn có thể thêm các định dạng thay thế để đảm bảo nó có thể phát bất kể trình duyệt nào đang được sử dụng (thường là .mp4, .ogv và .webm bao gồm nó.)';
$string['width']= 'Chiều rộng';
$string['width_explain']= 'Chỉ định chiều rộng mặc định của trình phát video.';
$string['width_help']= 'Nhập chiều rộng của video tại đây (ví dụ: 800 cho chiều rộng 800 pixel).';
