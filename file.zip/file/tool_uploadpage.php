<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_uploadpage', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_uploadpage
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['cachedef_helper']= 'Tải lên bộ nhớ đệm của trình trợ giúp trang';
$string['columnsheader']= 'Cột';
$string['confirm']= 'Xác nhận';
$string['confirmcolumnmappings']= 'Xác nhận ánh xạ cột';
$string['coursescreated']= 'Các khóa học được tạo: {$a}';
$string['coursesdeleted']= 'Các khóa học đã bị xóa: {$a}';
$string['courseserrors']= 'Lỗi khóa học: {$a}';
$string['coursesnotupdated']= 'Các khóa học chưa được cập nhật: {$a}';
$string['coursestotal']= 'Tổng số khóa học: {$a}';
$string['coursesupdated']= 'Các khóa học được cập nhật: {$a}';
$string['csvdelimiter']= 'Dấu phân cách CSV';
$string['csvdelimiter_help']= 'Dấu phân cách CSV của tệp CSV.';
$string['csvline']= 'Dòng';
$string['encoding']= 'Mã hóa';
$string['encoding_help']= 'Mã hóa tệp CSV.';
$string['id']= 'ID';
$string['import']= 'Nhập';
$string['importfile']= 'Tệp CSV';
$string['importvaluesheader']= 'Nhập cài đặt';
$string['invalidcsvfile']= 'Định dạng tệp không hợp lệ.';
$string['invalidencoding']= 'Đã chỉ định mã hóa không hợp lệ.';
$string['invalidfileexception']= 'Định dạng tệp không hợp lệ. {$a} ';
$string['invalidimportfile']= 'Định dạng tệp không hợp lệ.';
$string['invalidimportfileheaders']= 'Tiêu đề tệp không hợp lệ. Không đủ cột, vui lòng xác minh cài đặt dấu phân cách. ';
$string['invalidimportfilenorecords']= 'Không có bản ghi nào trong tệp nhập.';
$string['invalidimportrecord']= 'Bản ghi nhập không hợp lệ.';
$string['invalidparentcategoryid']= 'Danh mục chính không hợp lệ.';
$string['pluginname']= 'Tải lên các khóa học trên một trang';
$string['result']= 'Kết quả';
$string['statuscoursecreated']= 'Khóa học đã được tạo.';
$string['statuscoursenotupdated']= 'Khóa học không được cập nhật.';
$string['statuscourseupdated']= 'Đã cập nhật khóa học.';
$string['statuspagecreated']= 'Hoạt động trên trang đã được tạo.';
$string['statuspageupdated']= 'Đã cập nhật hoạt động trang.';
$string['uploadpageresult']= 'Tải lên kết quả';
