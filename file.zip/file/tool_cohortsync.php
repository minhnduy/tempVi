<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_cohortsync', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_cohortsync
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['cohortidentifier']= 'Định danh nhóm thuần tập';
$string['cohortidentifierdesc']= 'Tham số này được sử dụng để xác định nhóm để chèn thành viên.';
$string['cohortmembersyncheader']= 'Cấu hình thành viên nhóm thuần tập';
$string['cohortscreated']= '"{$a}" (các) nhóm được tạo';
$string['cohortsyncheader']= 'Cấu hình nhóm thuần tập';
$string['csvdelimiter']= 'Dấu phân cách CSV';
$string['encoding']= 'Mã hóa';
$string['errordefaultcontext']= 'Ngữ cảnh mặc định không tồn tại';
$string['errordelimiterfile']= 'Chỉ cho phép các dấu phân cách sau: dấu phẩy, dấu chấm phẩy, dấu hai chấm, tab';
$string['errorreadingfile']= 'Tệp "{$a}" không thể đọc được hoặc không tồn tại.';
$string['filepathsource']= 'Đường dẫn đến tệp nguồn';
$string['flatfiledelimiter']= 'Dấu phân cách tệp phẳng';
$string['formatcsv']= 'Định dạng tệp CSV';
$string['formatcsvdesc']= '';
$string['pluginname']= 'Đồng bộ hóa theo nhóm';
$string['privacy:metadata']= 'Plugin đồng bộ hóa Nhóm thuần tập không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['useridentifier']= 'Định danh người dùng';
$string['useridentifierdesc']= 'Tham số này được sử dụng để xác định người dùng sẽ được thêm vào nhóm thuần tập.';
