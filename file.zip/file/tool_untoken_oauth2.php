<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_untoken_oauth2', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_untoken_oauth2
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['cancelsearchtag']= 'Thao tác đã bị hủy bỏ';
$string['confirmsearchtag']= 'Bạn sắp xóa tất cả các liên kết liên kết hiện có cho tài khoản email được cung cấp, điều này sẽ loại bỏ liên kết với các dịch vụ đã tích hợp trước đó <br> <br> Bạn có muốn xóa liên kết khỏi tài khoản được liên kết hoặc các tài khoản không?';
$string['delbutton']= 'Xóa liên kết';
$string['deleted']= 'Đã xóa';
$string['descriptionlogtag']= 'Dưới đây là tất cả các hành động được thực hiện trên các thẻ ràng buộc';
$string['descriptionmanagertag']= 'Nhấp vào chức năng bạn muốn sử dụng:';
$string['descriptionprocestag']= 'Tất cả các mã thông báo liên kết với tài khoản e-mail được chỉ định đã được xóa thành công, bây giờ bạn có thể thực hiện lại quá trình liên kết. <br> <br> Nhấp vào tiếp tục sẽ được chuyển đến trang tìm kiếm mã thông báo để xóa. ';
$string['descriptionsearchtag']= 'Dưới đây là tất cả các hành động được thực hiện trên các thẻ ràng buộc:';
$string['emaillog']= 'Email';
$string['emailsearchtag']= 'Địa chỉ thư:';
$string['eventlbmanagertag']= 'Nhật ký liên kết mã thông báo';
$string['eventlog']= 'Mô tả sự kiện';
$string['fromlog']= 'Từ tên người dùng';
$string['header']= 'phát hành mã thông báo vinculation';
$string['headeventtag']= 'Nhật ký sự kiện Oauth2';
$string['headprocestag']= 'Xóa ràng buộc oauth2';
$string['headsearchtag']= 'Tìm kiếm tài khoản được liên kết oauth2';
$string['idlog']= 'Id';
$string['infologtag']= 'Nhật ký các hành động được thực hiện';
$string['infomanagertag']= 'Các hành động có sẵn';
$string['infoprocestag']= 'Quá trình loại bỏ';
$string['information']= 'Thông tin';
$string['logevent']= 'Hủy liên kết mã thông báo oauth2 Xem nhật ký sự kiện';
$string['manager']= 'Hủy liên kết mã thông báo oauth2';
$string['managerinfo']= 'Chọn tùy chọn quan tâm: Tìm kiếm nhằm mục đích tìm các liên kết của các tài khoản để xóa.
Nhật ký sự kiện sẽ hiển thị tất cả các hành động của người dùng có đặc quyền đối với mã thông báo liên kết. ';
$string['notfoundsearchtag']= 'Không tìm thấy hồ sơ liên kết nào cho tài khoản email được cung cấp';
$string['notsearchtag']= 'Tài khoản được chỉ định không tương ứng với địa chỉ email';
$string['pluginname']= 'Sự kiện hủy liên kết mã thông báo Oauth2';
$string['privacy:metadata:tool_untoken_oauth2:email']= 'Địa chỉ email của bên bị ảnh hưởng';
$string['privacy:metadata:tool_untoken_oauth2:eventname']= 'Mô tả sự kiện';
$string['privacy:metadata:tool_untoken_oauth2:from_username']= 'người dùng thực hiện hành động';
$string['privacy:metadata:tool_untoken_oauth2:id']= 'Hàng nhận dạng';
$string['privacy:metadata:tool_untoken_oauth2_log']= 'Thông tin về các liên kết bị xóa trên tài khoản email, cho biết ai thực hiện hành động, sự kiện và ngày thực hiện hành động.';
$string['privacy:metadata:tool_untoken_oauth2:pluginmeta']= 'Công cụ thông tin plugin_untoken_oauth2';
$string['privacy:metadata:tool_untoken_oauth2:timecreated']= 'Ngày tạo';
$string['privacy:metadata:tool_untoken_oauth2:to_username']= 'người dùng bị ảnh hưởng';
$string['privacy:metadata:tool_untoken_oauth2:userid']= 'id người dùng bị ảnh hưởng';
$string['reqemailsearchtag']= 'Địa chỉ email yêu cầu';
$string['search']= 'Mã thông báo hủy liên kết oauth2 Tìm kiếm email';
$string['searchbmanagertag']= 'Tìm kiếm liên kết mã thông báo';
$string['searchbutton']= 'Tìm kiếm email';
$string['settings']= 'Plugin cấu hình';
$string['timecreatedlog']= 'Ngày tạo';
$string['title']= 'oauth2 chưa thành văn';
$string['titlesearchtag']= 'Các bản ghi sau đã được tìm thấy:';
$string['tolog']= 'Tên người dùng bị ảnh hưởng';
$string['untoken_oauth2:action']= 'Chế độ xem liên kết mã thông báo và vai trò hành động';
$string['untoken_oauth2:search']= 'Vai trò tìm kiếm liên kết mã thông báo';
$string['useridlog']= 'Userid bị ảnh hưởng';
