<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_opencast', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_opencast
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['apipassword']= 'Mật khẩu cho người dùng API';
$string['apipassworddesc']= 'Thiết lập mật khẩu cho siêu người dùng, người thực hiện cuộc gọi api.';
$string['apipasswordempty']= 'Mật khẩu cho người dùng API không được thiết lập chính xác, hãy vào cài đặt của công cụ opencast để sửa lỗi này';
$string['apiurl']= 'Url API Opencast';
$string['apiurldesc']= 'Thiết lập url cơ sở của hệ thống Opencast, ví dụ: opencast.example.com';
$string['apiurlempty']= 'Url cho API Opencast không được thiết lập chính xác, hãy chuyển đến cài đặt của công cụ opencast để sửa lỗi này';
$string['apiusername']= 'Tên người dùng cho lệnh gọi API';
$string['apiusernamedesc']= 'Đối với tất cả các lệnh gọi tới tâm trạng API đều sử dụng người dùng này. Việc ủy ​​quyền được thực hiện bằng cách thêm các vai trò phù hợp vào cuộc gọi ';
$string['apiusernameempty']= 'Tên người dùng cho người dùng API Opencast không được thiết lập chính xác, hãy chuyển đến cài đặt của công cụ opencast để sửa lỗi này';
$string['connecttimeout']= 'Hết giờ kết nối';
$string['connecttimeoutdesc']= 'Thiết lập thời gian tính bằng giây trong khi moodle đang cố gắng kết nối với opencast cho đến khi hết giờ';
$string['needphp55orhigher']= 'Cần có phiên bản PHP 5.5 trở lên';
$string['opencast:externalapi']= 'Truy cập vào các dịch vụ web tool_opencast';
$string['opencast:instructor']= 'Cung cấp vai trò của một người hướng dẫn trong opencast';
$string['opencast:learner']= 'Cung cấp vai trò của một người học trong opencast';
$string['pluginname']= 'API Opencast';
$string['privacy:metadata']= 'Công cụ quản trị chỉ cung cấp điểm cuối API và cài đặt chung cho bộ plugin opencast.
Nó lưu, loạt opencast thuộc về khóa học nào, nhưng nó không lưu trữ bất kỳ dữ liệu cá nhân nào. ';
$string['serverconnectionerror']= 'Đã xảy ra sự cố với kết nối với máy chủ opencast. Vui lòng kiểm tra thông tin đăng nhập và cài đặt mạng của bạn. ';
$string['wrongmimetypedetected']= 'Đã phát hiện thấy loại mimety sai khi cố tải lên {$a->filename} từ khóa học {$a->coursename},
Bạn chỉ có thể tải lên các tệp video! ';
