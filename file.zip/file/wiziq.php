<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'wiziq', language 'en', branch 'MOODLE_32_STABLE'
 *
 * @package   wiziq
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['access_key']= 'Khóa truy cập';
$string['access_key_desc']= '<p style = "color: red"> Không có phím WizIQ. Nhận các <a href="https://www.wiziq.com/api/" target="_blank"> tại đây </a>. </p> Đây là điều bắt buộc để xác thực người dùng. Chúng tôi đặc biệt khuyên bạn không nên chia sẻ hoặc thay đổi các khóa này ';
$string['allowed_content']= '<b> Loại Nội dung Được phép </b>';
$string['assesstimefinish_help']= 'Ngày kết thúc của chuỗi lặp lại. Chỉ bắt buộc khi tham số class_occection không được cung cấp. ';
$string['attendance_report']= '<b> Báo cáo chuyên cần </b>';
$string['attended_minutes']= 'Thời gian có mặt';
$string['attendee_name']= 'Tên người tham dự';
$string['attendence_file']= 'Danh sách tham dự lớp học';
$string['attendencereport']= '<b> Báo cáo chuyên cần </b>';
$string['audio']= 'Âm thanh';
$string['available']= 'Có sẵn';
$string['class_end_date']= 'Ngày kết thúc lớp học';
$string['class_final_req']= 'Yêu cầu lịch học';
$string['class_id']= 'ID lớp';
$string['classnotheld']= '';
$string['class_occurrence']= 'Sự xuất hiện của lớp';
$string['class_occurrence_help']= 'Số lớp định kỳ cần lên lịch. Chỉ bắt buộc khi tham số class_end_date không được cung cấp. ';
$string['class_repeat_type']= 'Chọn khi lớp lặp lại';
$string['class_schedule']= 'Lịch học';
$string['class_schedule_help']= 'Số lớp định kỳ cần lên lịch. Chỉ bắt buộc khi tham số class_end_date không được cung cấp. ';
$string['classtype']= 'Lớp vĩnh viễn';
$string['classtype_help']= 'Một lớp vĩnh viễn không kết thúc trừ khi bạn chọn kết thúc nó. Nó có thể được hiển thị bất cứ lúc nào. ';
$string['classviewdetail']= 'Chi tiết của lớp';
$string['classwithoutrec']= 'Ghi âm không được chọn';
$string['content_delete']= 'Xóa';
$string['contentfail']= 'Không thành công';
$string['create_recording_false']= 'Không';
$string['create_recording_true']= 'Có';
$string['creating_dnld_rcd']= 'Đang ghi âm';
$string['creatingrecording']= 'Tạo Ghi âm';
$string['datatempered']= 'Dữ liệu đã thay đổi';
$string['date_time']= 'Ngày-giờ';
$string['days_of_week']= 'Ngày trong tuần';
$string['days_of_week_help']= 'Các ngày trong tuần để sắp xếp lớp học';
$string['delete_class']= '<b> Xóa lớp </b>';
$string['deleteconfirm']= 'Bạn có chắc chắn xóa lớp học không';
$string['deleteconfirmcontent']= 'Bạn có chắc chắn xóa không';
$string['deletefromwiziq']= 'Đã xóa khỏi WizIQ';
$string['deleteheading']= 'Xóa';
$string['discription']= 'Mô tả Giới thiệu về Lớp học';
$string['dontrecord']= 'Không';
$string['download_file']= 'Danh sách người dùng cho lớp tải xuống';
$string['download_pagetitle']= 'Tải xuống chi tiết người dùng';
$string['download_recording']= '<b> Tải xuống-Ghi âm </b>';
$string['dtime']= 'Thời gian';
$string['duration']= 'Thời lượng của lớp.';
$string['duration_error']= 'Chỉ có thể là số';
$string['duration_help']= 'Thời lượng của lớp học sẽ tính bằng phút. Thời lượng tối thiểu là 30 phút và tối đa là 300 phút. Bạn có thể kéo dài thời lượng của lớp học từ trong phòng học ảo ';
$string['duration_number']= 'Phải là một số hợp lệ';
$string['duration_req']= 'Phải nhập một số';
$string['dusername']= 'Tên người dùng';
$string['editconfirm']= 'Bạn có chắc chắn chỉnh sửa lớp không';
$string['entry_time']= 'Thời gian vào cửa';
$string['errorcrtingfolder']= 'Lỗi khi tạo thư mục';
$string['error_in_curl']= 'Vui lòng bật phần mở rộng curl trong tệp php.ini.';
$string['error_in_downloadrec']= 'Có một số lỗi khi tải xuống Bản ghi.';
$string['error_in_fileext']= 'Tải lên loại tệp được phép';
$string['errorinfileupload']= 'Lỗi khi tải lên tệp';
$string['error_in_langread']= 'Không thể đọc Language Xml.';
$string['error_in_languagexml']= 'Kiểm tra Cài đặt của bạn. Không thể đọc Language Xml ';
$string['errorinservice']= 'Không thể gửi yêu cầu đến Wiziq API kiểm tra Cài đặt Wiziq. Dữ liệu hiển thị không hợp lệ ';
$string['error_in_timeread']= 'Không thể đọc Múi giờ Xml.';
$string['error_in_timezonexml']= 'Kiểm tra Cài đặt của bạn. Không thể đọc Múi giờ Xml ';
$string['error_in_update']= 'Đã xảy ra lỗi khi cập nhật lớp học của Bạn. <br /> Vui lòng Thử lại.';
$string['errormsg']= 'đây là lỗi thời gian lịch trình';
$string['errormsg_session_missing']= 'Thiếu mã phiên liên hệ với hỗ trợ WizIQ về lớp này';
$string['exit_time']= 'Thời gian thoát';
$string['explaingeneralconfig']= 'Thông tin đăng nhập API: - Cần thiết để xác thực';
$string['fetchdata_upgarde']= 'Nâng cấp Dữ liệu Tìm nạp';
$string['folder_alrdy_exist']= 'đã tồn tại ở cấp độ này';
$string['foldernamestring']= 'Tên thư mục';
$string['generalconfig']= 'Cấu hình chung';
$string['inprogress']= 'Đầu vào';
$string['join_class']= '<b> Tham gia Lớp học </b>';
$string['language_name']= 'Ngôn ngữ trong ClassRoom';
$string['launch_class']= '<b> Khởi chạy lớp </b>';
$string['links']= 'Liên kết';
$string['manage']= 'Quản lý lớp học';
$string['manage_classes']= 'Quản lý lớp học';
$string['manage_classes_file']= 'Danh sách Lớp học cho Khóa học';
$string['manage_content']= 'Quản lý nội dung';
$string['modulename']= 'Lớp sống WizIQ';
$string['modulename_help']= 'Mô-đun wiziq cho phép bạn sắp xếp một lớp học. Bạn có thể lên lịch các lớp học trực tuyến, thuyết trình có tác động cao và xem các bản ghi âm lớp học chỉ bằng một cú nhấp chuột từ bên trong Moodle ';
$string['modulenameplural']= 'Lớp Wiziq';
$string['monthly_date']= 'Ngày hàng tháng';
$string['monthly_date_help']= 'Ngày lên lịch học hàng tháng';
$string['name']= 'Tên lớp';
$string['nameheading']= 'Tên';
$string['namerequired']= 'Vui lòng thêm tên lớp';
$string['new_attendee']= '<b> Bạn đang xem lớp học lần đầu tiên </b>';
$string['nocapability']= 'Không có khả năng';
$string['no_delete_xml']= 'Không trả về xml khi xóa nội dung';
$string['no_download_recording']= '<b> Tạo-Ghi âm </b>';
$string['notknown']= 'Không biết';
$string['nowiziqs']= 'Không có lớp Wiziq nào được tạo trong khóa học này';
$string['parent_not_fould']= 'Không tìm thấy thư mục chính';
$string['perma_class']= 'Lớp Perma';
$string['perma_class_type']= 'Lớp vĩnh viễn';
$string['per_page_classes']= 'Lớp trên mỗi trang';
$string['per_page_content']= 'Nội dung trên mỗi trang';
$string['pluginadministration']= 'quản trị wiziq';
$string['pluginname']izi
$string['presenter']= 'Người trình bày';
$string['presenter_email']= 'Email của Người trình bày';
$string['presenter_id']= 'Chọn giáo viên';
$string['presenter_name']= 'Giáo viên';
$string['presenter_required']= 'Yêu cầu người trình bày';
$string['recmsg']= '<b> Bản ghi âm sẽ có trong một lúc nào đó </b>';
$string['recnotcreatedyet']= 'Tải xuống Ghi âm chưa khả dụng';
$string['record']= 'Có';
$string['recording_link']= 'Tải xuống bản ghi âm';
$string['recording_option']= 'Ghi lại lớp này';
$string['recordingtype']= 'Tùy chọn ghi âm';
$string['recordingtype_help']= 'Theo mặc định lớp được lên lịch là lớp được ghi lại, nếu bạn không muốn ghi lớp thì hãy chọn "Không" được cung cấp tùy chọn';
$string['recording_value']= 'Đã chọn ghi âm';
$string['recurring_class_type']= 'Lớp định kỳ';
$string['refresh_page']= 'Nhấp vào đây để nhận trạng thái mới nhất';
$string['schedule_class']= 'Lên lịch lớp';
$string['schedule_class_type']= 'Lớp dựa trên thời gian';
$string['schedule_for_now']= 'Lên lịch ngay bây giờ';
$string['schedule_for_now_help']= 'Kiểm tra nếu bạn muốn sắp xếp lớp học cho thời gian hiện tại';
$string['scheduleforother']= 'Lịch trình cho việc khác';
$string['scheduleforother_help']= 'Theo lịch học mặc định cho quản trị viên. Bằng cách đánh dấu chọn vào hộp kiểm, bạn có thể lên lịch lớp học cho giáo viên của mình bằng cách chọn giáo viên từ menu thả xuống ';
$string['scheduleforself']= 'Lên lịch cho bản thân';
$string['scheduleforself_help']= 'Admin có thể cập nhật lớp học để lên lịch cho mình';
$string['secretacesskey']= 'Khóa truy cập bí mật';
$string['secretacesskey_desc']= '<p style = "color: red"> Không có phím WizIQ. Nhận các <a href="https://www.wiziq.com/api/" target="_blank"> tại đây </a>. </p> Đây là điều bắt buộc để xác thực người dùng. Chúng tôi đặc biệt khuyên bạn không nên chia sẻ hoặc thay đổi các khóa này ';
$string['select_class_type']= 'Ngày và giờ';
$string['select_monthly_repeat_type']= 'Chọn loại lặp lại hàng tháng';
$string['setting_discription']= '<p> WiZiQ là một nền tảng giảng dạy và học tập trực tuyến kết nối các nhà giáo dục và sinh viên thông qua công nghệ lớp học ảo. WizIQ cho phép bất kỳ ai cung cấp các lớp học trực tiếp, chia sẻ bản trình bày, tệp PDF, bảng trắng ảo, giọng nói, video và thậm chí cả máy tính để bàn của họ qua Internet, trong thời gian thực, chỉ với trình duyệt web - Không cần tải xuống hoặc phần mềm máy khách cồng kềnh. Tắt các điều khiển chia sẻ âm thanh-video, bảng trắng và màn hình cho người dùng để tăng mức độ tương tác hoặc trả lời các câu hỏi được đặt ra thông qua trò chuyện tích hợp. </p>
<p> WizIQ Virtual Classroom tích hợp với Moodle để tạo ra các khả năng mới cho việc học đồng bộ - tất cả đều từ bên trong môi trường LMS. Giáo viên có thể lên lịch và khởi chạy các buổi học trực tiếp từ bên trong Moodle, thông qua lớp học ảo WizIQ. Các phiên đã lên lịch sẽ được liệt kê tự động trên lịch khóa học Moodle. Học sinh có thể dễ dàng tham gia các buổi học trực tiếp của giáo viên và học trong thời gian thực. </p>
<p> Truy cập http://www.wiziq.com để biết thông tin về hỗ trợ Doanh nghiệp </p> ';
$string['specific_week']= 'Tuần cụ thể';
$string['specific_week_help']= 'Số tuần sau đó lớp học lặp lại.';
$string['status']= 'Trạng thái';
$string['status_of_class']= 'Trạng thái lớp học';
$string['subcontenterror']= 'Xóa nội dung bên trong trước tiên';
$string['teacher_you']= 'Bạn';
$string['timezone_required']= 'Múi giờ bắt buộc';
$string['timezone_xml']= uvizia Múi giờ hmlü;
$string['timezone_xml_desc']= 'Mô tả về Wiziq TimeZone xml';
$string['unable_to_create']= 'Sự cố khi tạo thư mục';
$string['unable_to_delete']= 'Vấn đề trong việc xóa nội dung';
$string['unable_to_get_url']= 'Thiếu url';
$string['update_class']= '<b> Chỉnh sửa Lớp </b>';
$string['uploaderror']= 'Lỗi khi tải lên Nội dung';
$string['vc_class_timezone']= 'Múi giờ';
$string['vc_class_timezone_help']= 'Chọn múi giờ mà bạn muốn sắp xếp lớp học';
$string['vc_language']= 'Ngôn ngữ lớp ảo';
$string['vc_language_help']= 'Theo ngôn ngữ mặc định trong phòng học ảo là En-US, bạn có thể thay đổi ngôn ngữ bằng cách chọn ngôn ngữ từ menu thả xuống';
$string['vc_language_xml']= 'Ngôn ngữ xml';
$string['vc_language_xml_desc']= 'Điều này cho phép bạn chọn từ các ngôn ngữ được hỗ trợ khác nhau của lớp học ảo. Chúng tôi thực sự khuyên bạn không nên thay đổi điều này. ';
$string['viewclassnotheld']= 'Lớp không được tổ chức';
$string['viewrec']= 'Xem ghi âm';
$string['view_recording']= '<b> Xem-Ghi </b>';
$string['webserviceurl']= 'URL dịch vụ trang web';
$string['webserviceurl_desc']= 'Dịch vụ web này được sử dụng để tương tác với máy chủ WizIQ để sắp xếp các lớp học.';
$string['week']= 'Tuần';
$string['wiziq']izi
$string['wiziq:addinstance']= 'Thêm một wiziq mới. Chỉ dành cho Moodle 2.3 ';
$string['wiziq_attendancereport']= 'Báo cáo tham dự Wiziq cho';
$string['wiziq_attendence_file']= 'wiziq_attendence_for_class';
$string['wiziq_class']= 'Lớp Wiziq';
$string['wiziq_classes']= 'Lớp Wiziq';
$string['wiziq_classes_file']= 'wiziq_listing_for_course';
$string['wiziqclasssettings']= 'Thiết lập của Lớp Wiziq.';
$string['wiziq_class_timezone']= 'Múi giờ';
$string['wiziq_content']= 'Nội dung Wiziq';
$string['wiziq_content_webservice']= 'URL Dịch vụ Trang web Nội dung';
$string['wiziq_content_webservice_desc']= 'Điều này được sử dụng để tải lên nội dung trong lớp học ảo. Chúng tôi thực sự khuyên bạn không nên thay đổi điều này. ';
$string['wiziq_datetime']= 'Ngày và giờ.';
$string['wiziq_datetime_help']= 'Chọn ngày và giờ cho lớp học. Bạn không thể sắp xếp lớp học trong thời gian vừa qua. Đừng thêm thời gian tiết kiệm ánh sáng ban ngày vào thời điểm này ';
$string['wiziqdatetimesetting']= 'Đặt thời gian của lớp.';
$string['wiziq_download_file']= 'wiziq_users_for_class';
$string['wiziq_duration']= 'Thời lượng (tính bằng phút)';
$string['wiziq_emailsetting']= 'Bật thông báo qua email';
$string['wiziqfieldset']= 'Bộ trường mẫu tùy chỉnh';
$string['wiziq_headtag']= 'Hồ sơ Người dùng';
$string['wiziqname']= 'Tiêu đề';
$string['wiziqname_help']= 'Nhập tên lớp';
$string['wiziq_recur_class_repeat_req']= 'Yêu cầu tần suất lặp lại lớp học';
$string['wiziq_recur_class_repeat_type_help']= 'Loại lặp lại của lớp. Giá trị có thể từ 1 đến 5. 1 cho hàng ngày (Tất cả 7 ngày), 2 cho 6 ngày (Thứ Hai-Thứ Bảy), 3 trong 5 ngày (Thứ Hai-Thứ Sáu), 4 cho Hàng tuần, 5 cho Một lần mỗi tháng ';
$string['wiziq_recur_datetime_req']= 'Thời gian Bắt đầu Yêu cầu';
$string['wiziqrecurringclasssettings']= 'Cài đặt Lớp Định kỳ Wiziq';
$string['wiziq_start_time']= 'Thời gian của lớp';
$string['wiziq_start_time_class']= 'Thời gian bắt đầu';
$string['wiziq:view_attendance_report']= 'Khả năng xem báo cáo tham dự';
$string['wiziq:wiziq_content_upload']= 'Khả năng tải lên nội dung';
$string['wiziq:wiziq_download_rec']= 'Khả năng tải xuống bản ghi lớp';
$string['wiziq:wiziq_view_rec']= 'Khả năng xem bản ghi lớp';
$string['writing']= 'Đang viết';
$string['wrongduration']= 'Thời lượng nên từ 30 phút đến 300 phút';
$string['wrongtime']= 'Không thể sắp xếp lớp học trong thời gian vừa qua';
