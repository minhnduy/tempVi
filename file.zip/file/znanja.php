<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'znanja', language 'en', branch 'MOODLE_24_STABLE'
 *
 * @package   znanja
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['localsyncdisabled']= 'The znanja content plugin requires downloadable SCORM packages to be enabled, but they are currently disabled.  Please enable the "Downloaded package type" setting for the SCORM package activity module (found under: Site administration -&gt; Plugins -&gt; Activity modules -&gt; SCORM package).';

$string['modulename']= 'hoạt động nội dung znanja';
$string['modulename_help']= '<div style = "padding-bottom: 2em; text-align: center;"> <a href="https://znanja.com"> <img src = "https://znanja.com/logo. png? width = 226 & height = 46 "> </a> </div><p> <strong> znanja </strong> giúp bạn dễ dàng chuyển đổi tài liệu đào tạo do người hướng dẫn hiện có sang eLearning, vì vậy bạn có thể tập trung vào việc cung cấp đào tạo bạn muốn, cho sinh viên bạn muốn, ở bất kỳ đâu trên thế giới. </p> <p> Plugin này sẽ nhập nội dung từ znanja dưới dạng hoạt động của gói SCORM. </p> <p> Bạn sẽ cần có tài khoản người dùng tại znanja . Nếu bạn chưa có tài khoản, hãy truy cập <a href="https://znanja.com"> znanja.com </a> để thiết lập một tài khoản hoặc hỏi quản trị viên của bạn về cách tạo tài khoản trong tổ chức znanja của họ. </ P > ';
$string['modulenameplural']= 'hoạt động nội dung znanja';
$string['pluginname']= 'nội dung znanja';
$string['scormmodulenotfound']= 'Không tìm thấy mô-đun hoạt động SCORM. Hãy đảm bảo rằng nó đã được kích hoạt. ';
