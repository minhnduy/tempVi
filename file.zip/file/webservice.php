<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'webservice', language 'vi', branch 'MOODLE_39_STABLE'
 *
 * @package   webservice
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['accessexception']= 'Truy cập kiểm soát lỗi';
$string['actwebserviceshhdr']= 'Kích hoạt web dịch vụ giao thức';
$string['addaservice']= 'Thêm dịch vụ';
$string['addcapabilitytousers']= 'Kiểm tra quyền hạn người dùng';
$string['addcapabilitytousersdescription']= 'Người dùng nên có hai quyền hạn - webservice: Createtoken và một quyền phù hợp với giao thức được sử dụng, ví dụ webservice / rest: use, webservice / soap: use. To đạt được, tạo một web dịch vụ vai trò với phù hợp quyền hạn được cho phép và phân bổ nó cho người dùng web dịch vụ như một hệ thống trò chơi. ';
$string['addfunction']= 'Thêm chức năng';
$string['addfunctions']= 'Thêm chức năng';
$string['addfunctionsdescription']= 'Chọn yêu cầu chức năng cho dịch vụ tạo mới';
$string['addservice']= 'Thêm dịch vụ mới: {$a->name} (id: {$a->id})';
$string['addservicefunction']= 'Thêm chức năng vào dịch vụ "{$a}"';
$string['allusers']= 'Tất cả người dùng';
$string['arguments']= 'Tham số';
$string['authmethod']= 'Phương thức xác thực';
$string['cannotcreatetoken']= 'Không cho phép tạo dịch vụ mã thông báo cho dịch vụ {$a}.';
$string['cannotgetcoursecontents']= 'Không thể lấy nội dung chính';
$string['checkusercapability']= 'Kiểm tra quyền hạn người dùng';
$string['checkusercapabilitydescription']= 'Người dùng nên có các quyền phù hợp theo giao thức được sử dụng, ví dụ như webservice / rest: use, webservice / soap: use. To đạt được, tạo một web dịch vụ vai trò với các quyền hạn giao thức và bổ sung cho web dịch vụ người dùng như một hệ thống trò chơi. ';
$string['configwebserviceplugins']= 'Vì lí do bảo mật, chỉ những giao thức còn lại được sử dụng mới được kích hoạt.';
$string['context']= 'Bối cảnh';
$string['createservicedescription']= 'Dịch vụ là web dịch vụ chức năng. You will allow user to access new service. Trang <strong> Thêm dịch vụ </strong> chọn các lựa chọn trang \'Kích hoạt \' và \'Những người sử dụng đã được xác thực \'. Select \'No co the permissions request \'. ';
$string['createserviceforusersdescription']= 'Dịch vụ là web dịch vụ chức năng. You will allow user to access new service. Trang <strong> Thêm dịch vụ </strong> chọn các lựa chọn trang \'Kích hoạt \' và chọn các lựa chọn \'Những người thực hiện được xác nhận là người dùng \'. Select \'No co the permissions request \'. ';
$string['createtoken']= 'Tạo mã thông báo';
$string['createtokenforuser']= 'Tạo mã thông báo cho người dùng';
$string['createtokenforuserdescription']= 'Tạo mã thông báo cho web dịch vụ người dùng.';
$string['createuser']= 'Tạo chuyên biệt người dùng';
$string['createuserdescription']= 'Người dùng web dịch vụ được yêu cầu để đại diện cho Moodle hệ thống kiểm tra.';
$string['criteriaerror']= 'Thiếu quyền tìm kiếm theo tiêu chuẩn';
$string['default']= 'Mặc định thành "{$a}"';
$string['deleteservice']= 'Xóa dịch vụ: {$a->name} (id: {$a->id})';
$string['deleteserviceconfirm']= 'Delete service also will delete this service links token. Bạn thật sư muốn xóa bên ngoài dịch vụ "{$a}"? ';
$string['deletetokenconfirm']= 'Bạn thật sự muốn xóa token này của dịch vụ cho <strong> {$a->user} </strong> on service <strong> {$a->service} </strong>?' ;
$string['disabledwarning']= 'Tất cả web dịch vụ giao thức đều bị vô hiệu hóa. Setting "Web service kích hoạt" có thể được tìm thấy trong cao cấp Tính năng. ';
$string['doc']= 'Tài liệu';
$string['docaccessrefused']= 'Bạn không được phép xem tài liệu cho mã thông báo này';
$string['documentation']= 'web dịch vụ tài liệu';
$string['downloadfiles']= 'Có thể tải tập tin';
$string['downloadfiles_help']= 'Nếu đang hoạt động, bất kỳ người dùng nào cũng có thể tải xuống tệp bằng khóa bảo mật của họ. Chúng tôi được giới hạn để được sử dụng trong trang. ';
$string['editaservice']= 'Chỉnh sửa dịch vụ';
$string['editservice']= 'Dịch vụ chỉnh sửa: {$a->name} (id: {$a->id})';
$string['enabled']= 'Đã được kích hoạt';
$string['enabledocumentation']= 'Kích hoạt tài liệu nhà phát triển';
$string['enabledocumentationdescription']= 'Chi tiết web dịch vụ tài liệu tồn tại với các giao thức đã được kích hoạt.';
$string['enableprotocols']= 'Kích hoạt các giao thức';
$string['enableprotocolsdescription']= 'Ít nhất một giao thức, được kích hoạt. Vì bảo mật an ninh, chỉ các giao thức được sử dụng, được kích hoạt. ';
$string['enablews']= 'Kích hoạt web dịch vụ';
$string['enablewsdescription']= 'Web dịch vụ phải được kích hoạt trong cao cấp Tính năng.';
$string['error']= 'Lỗi: {$a}';
$string['errorcatcontextnotvalid']= 'Bạn không thực hiện chức năng trong cảnh tốt nhất (id danh mục: {$a->catid}). Lỗi thông báo là: {$a->message} ';
$string['errorcodes']= 'Thông báo Lỗi';
$string['errorcoursecontextnotvalid']= 'Bạn không thể thực hiện chức năng trong khóa học (id khóa học: {$a->courseid}). Thông báo lỗi là: {$a->message} ';
$string['errorinvalidparam']= 'No invalid Tham số "{$a}".';
$string['errornotemptydefaultparamarray']= 'Tham số web dịch vụ mô tả có tên \' {$a} \'là một đơn hoặc đa cấu trúc. Mặc định chỉ có thể là mảng trống. Kiểm tra web dịch vụ mô tả. ';
$string['erroroptionalparamarray']= 'Tham số web dịch vụ mô tả có tên \' {$a} \'là một đơn hoặc đa cấu trúc. Nó không được đặt VALUE_OPTIONAL. Kiểm tra web dịch vụ của ta. ';
$string['eventwebservicefunctioncalled']= 'Web service Hàm được gọi';
$string['eventwebserviceloginfailed']= 'Đăng nhập bất thành dịch vụ web';
$string['eventwebserviceservicecreated']= 'Dịch vụ dịch vụ web đã được tạo';
$string['eventwebserviceservicedeleted']= 'Web service service đã bị xóa';
$string['eventwebserviceserviceupdated']= 'Web server service đã được cập nhật';
$string['eventwebserviceserviceuseradded']= 'Người dùng dịch vụ web đã được thêm';
$string['eventwebserviceserviceuserremoved']= 'Người dùng dịch vụ web đang bị xóa';
$string['eventwebservicetokencreated']= 'Web dịch vụ mã thông báo đã được tạo';
$string['eventwebservicetokensent']= 'Web dịch vụ mã thông báo đã được gửi đi';
$string['execute']= 'Thực thi';
$string['executewarnign']= 'NGUY HIỂM: Nếu bạn bấm vào thực thi CSDL của bạn, bạn sẽ được thay đổi và chúng tôi không thể hoàn thành tự động lại được!';
$string['externalservice']= 'Bên ngoài dịch vụ';
$string['externalservicefunctions']= 'Bên ngoài dịch vụ chức năng';
$string['externalservices']= 'Bên ngoài dịch vụ';
$string['externalserviceusers']= 'Bên ngoài dịch vụ người dùng';
$string['failedtolog']= 'Ghi nhật ký bất thành';
$string['filenameexist']= 'File name tồn tại: {$a}';
$string['forbiddenwsuser']= 'Cannot create token for a user not secure, đã bị xóa, bị đình chỉ hoặc là khách hàng.';
$string['function']= 'Hàm';
$string['functions']= 'Các hàm';
$string['generalstructure']= 'Cấu trúc chung';
$string['information']= 'Thông tin';
$string['installexistingserviceshortnameerror']= 'Một web dịch vụ với short name "{$a}" đã tồn tại. Cannot install / update a other web service with this short name. ';
$string['installserviceshortnameerror']= 'Source code error: short service name "{$a}" nên chỉ chứa số, kí tự và _- ..';
$string['invalidextparam']= 'Số api không hợp lệ: {$a}';
$string['invalidextresponse']= 'Phản hồi api không hợp lệ: {$a}';
$string['invalidiptoken']= 'Không hợp lệ mã thông báo - IP của bạn không được hỗ trợ';
$string['invalidtimedtoken']= 'Không hợp lệ mã thông báo - mã thông báo đã hết hạn';
$string['invalidtoken']= 'Không hợp lệ mã thông báo - không tìm thấy mã thông báo';
$string['iprestriction']= 'IP giới hạn';
$string['iprestriction_help']= 'Người dùng sẽ cần gọi web dịch vụ từ IP theo danh sách (ngăn bởi dấu phẩy).';
$string['key']= 'Chìa khóa';
$string['keyshelp']= 'Các key được sử dụng để truy cập Moodle tài khoản của bạn từ bên ngoài ứng dụng.';
$string['manageprotocols']= 'Giao thức quản lý';
$string['managetokens']= 'Mã thông báo quản lý';
$string['missingcaps']= 'Thiếu các quyền hạn';
$string['missingcaps_help']= 'Danh sách các quyền được yêu cầu đối với dịch vụ mà người dùng được chọn không có. Các quyền hạn thiếu sót phải được thêm vào trò chơi của người dùng để sử dụng dịch vụ. ';
$string['missingpassword']= 'Không có mật khẩu';
$string['missingrequiredcapability']= 'Quyền hạn {$a} được yêu cầu.';
$string['missingusername']= 'Thiếu tài khoản tên';
$string['missingversionfile']= 'Lỗi mã nguồn: thiếu tệp version.php cho {$a} thành phần';
$string['nocapabilitytouseparameter']= 'Người dùng không có quyền hạn được yêu cầu để sử dụng tham số {$a}.';
$string['nofunctions']= 'Dịch vụ này không có chức năng.';
$string['norequiredcapability']= 'Không có quyền hạn được yêu cầu';
$string['notoken']= 'Danh sách mã thông báo trống.';
$string['onesystemcontrolling']= 'Moodle hệ thống kiểm soát cho phép';
$string['onesystemcontrollingdescription']= 'Các bước sau giúp bạn thiết lập các web dịch vụ Moodle nhằm cho phép một hệ thống bên ngoài tương tác với Moodle. Nó bao gồm thiết lập một mã thông báo xác thực phương thức (bảo mật khóa). ';
$string['operation']= 'Thao tác';
$string['optional']= 'Tùy chọn';
$string['passwordisexpired']= 'Mật khẩu hết hạn.';
$string['phpparam']= 'XML-RPC (PHP Cấu trúc)';
$string['phpresponse']= 'XML-RPC (Cấu trúc)';
$string['potusers']= 'Những người dùng không xác thực';
$string['potusersmatching']= 'Những người dùng trùng khớp không xác thực';
$string['print']= 'Trong all';
$string['protocol']= 'Giao thức';
$string['removefunction']= 'Xóa';
$string['removefunctionconfirm']= 'Bạn thật sự muốn xóa hàm "{$a->function}" khỏi dịch vụ "{$a->service}"?';
$string['required']= 'Được yêu cầu';
$string['requiredcapability']= 'Quyền hạn được yêu cầu';
$string['requiredcapability_help']= 'If are set, only the people with the permissions are yêu cầu cấu hình có thể truy cập dịch vụ.';
$string['requiredcaps']= 'Các quyền hạn được yêu cầu';
$string['resettokenconfirm']= 'Bạn thật sự muốn đặt lại web dịch vụ khóa cho <strong> {$a->user} </strong> trên dịch vụ <strong> {$a->service} </strong>? ';
$string['resettokenconfirmsimple']= 'Bạn thật sự muốn đặt lại khóa này? Bất kỳ liên kết nào được lưu trữ đều chứa cũ khóa sẽ không hoạt động nữa. ';
$string['response']= 'Phản hồi';
$string['restcode']= 'REST';
$string['restexception']= 'REST';
$string['restoredaccountresetpassword']= 'Tài khoản được phục hồi cần đặt lại mật khẩu trước khi lấy mã thông báo.';
$string['restparam']= 'REST (POST tham số)';
$string['restrictedusers']= 'Chỉ những người dùng đã được xác thực';
$string['restrictedusers_help']= 'Cài đặt này mà tất cả người dùng được sử dụng để tạo web dịch vụ mã thông báo có thể bắt đầu mã thông báo cho dịch vụ mà thông tin thông qua bảo mật khóa trang của họ hoặc chỉ những người từng là xác thực mới có ". ';
$string['securitykeys']= 'Khoá bảo mật';
$string['selectauthorisedusers']= 'Chọn người dùng đã được xác thực';
$string['selectedcapabilitydoesntexit']= 'Yêu cầu hạn chế quyền được đặt hiện tại ({$a}) không tồn tại nữa. Please change it and back up. ';
$string['selectservice']= 'Chọn dịch vụ';
$string['selectspecificuser']= 'Select the user Cụ thể';
$string['selectspecificuserdescription']= 'Thêm web dịch vụ người dùng thành một người dùng đã được xác thực.';
$string['service']= 'Dịch vụ';
$string['servicehelpexplanation']= 'Service is a function. Một dịch vụ có thể được truy cập bởi tất cả người dùng hoặc chỉ những người dùng nhất định. ';
$string['servicename']= 'Tên dịch vụ';
$string['servicenotavailable']= 'Web dịch vụ không hiện hữu (nó không tồn tại hoặc có thể bị vô hiệu hóa)';
$string['servicesbuiltin']= 'Tích hợp các dịch vụ';
$string['servicescustom']= 'Dịch vụ tùy chỉnh';
$string['serviceusers']= 'Những người dùng đã được xác thực';
$string['serviceusersettings']= 'Cài đặt người dùng';
$string['serviceusersmatching']= 'Những người dùng đã được trùng khớp xác thực';
$string['serviceuserssettings']= 'Thay đổi cài đặt cho những người đang được xác minh';
$string['shortnametaken']= 'Tên viết tắt đã được sử dụng cho một dịch vụ khác ({$a})';
$string['simpleauthlog']= 'Đăng ký đăng nhập đơn giản';
$string['step']= 'Bước';
$string['supplyinfo']= 'Add chi tiết';
$string['testauserwithtestclientdescription']= 'Giả lập bên ngoài truy cập đến dịch vụ sử dụng ứng dụng khách, thử nghiệm web dịch vụ. Trước khi làm vậy, hãy đăng nhập làm người dùng với các quyền hạn chế trên moodle / webservice: Createtoken và nhận khóa bảo mật (token) thông qua thiết lập Hồ sơ của tôi. You will use this token in client try. Trong thử nghiệm khách hàng, cũng phải chọn một giao thức được kích hoạt với mã thông báo xác thực. <strong> CẢNH BÁO: Các chức năng mà bạn thử nghiệm SẼ THỰC THI đối với người dùng này, vậy hãy cẩn thận cái bạn chọn để thử! </strong> ';
$string['testclient']= 'Khách hàng thử nghiệm web dịch vụ';
$string['testclientdescription']= '* Khách hàng thử nghiệm web dịch vụ <strong> thực thi </strong> các hàm <strong> THẬT </strong>. Không thử các chức năng mà bạn không biết. <br/> * Tất cả web dịch vụ chức năng chưa được thực thi trong thử nghiệm khách hàng. <br/> * Để kiểm tra người dùng đó không thể truy cập một số hàm, bạn có thể thử một số vốn hàm mà bạn không cho phép. <br/> * Để xem các thông báo lỗi hơn đặt kiểm tra lỗi thành < strong> {$a->mode} </strong> vào {$a->atag} <br/> * Truy cập {$a->amfatag}. ';
$string['testwithtestclient']= 'Thử nghiệm dịch vụ';
$string['testwithtestclientdescription']= 'Giả lập bên ngoài truy cập đến dịch vụ sử dụng ứng dụng khách, thử nghiệm web dịch vụ. Sử dụng một giao thức đã được kích hoạt với mã thông báo xác thực. <strong> CẢNH BÁO: Các chức năng mà bạn thử nghiệm SẼ THỰC THI, vì vậy hãy cẩn thận cái bạn chọn để thử! </strong> ';
$string['token']= 'Mã thông báo';
$string['tokenauthlog']= 'Mã thông báo xác thực';
$string['tokencreator']= 'Người tạo';
$string['unknownoptionkey']= 'Không xác định khóa ({$a})';
$string['unnamedstringparam']= 'Một tên chưa đặt chuỗi tham số.';
$string['updateusersettings']= 'Cập nhật';
$string['uploadfiles']= 'Có thể đăng tải tập tin';
$string['uploadfiles_help']= 'If being active, anybody used to be upload file with the key security to the khu tập tin thuộc chủ sở hữu hoặc khu tập hợp. Bất kỳ file nào cũng được sử dụng để áp dụng. ';
$string['userasclients']= 'Người dùng là khách hàng với mã thông báo';
$string['userasclientsdescription']= 'Các bước sau giúp bạn thiết lập Moodle web dịch vụ cho người dùng là khách hàng. Các bước này cũng giúp thiết lập mã thông báo xác thực phương thức (bảo mật khóa) được khuyến nghị. Trong trường hợp này, người dùng sẽ tạo mã thông báo của mình từ trang bảo mật thông qua thiết lập Hồ sơ của tôi. ';
$string['usermissingcaps']= 'Thiếu các quyền hạn: {$a}';
$string['usernameorid']= 'Tên tài khoản / id người dùng';
$string['usernameorid_help']= 'Nhập tài khoản tên hoặc id người dùng';
$string['usernameoridnousererror']= 'Không tìm thấy người dùng nào có tên tài khoản / id này.';
$string['usernameoridoccurenceerror']= 'Nhiều hơn một người dùng được tìm thấy với tài khoản tên này. Please enter the id user. ';
$string['usernotallowed']= 'User not allow with this service. Trước tiên bạn cần cho phép người dùng này trên trang quản lý người dùng được phép của {$a} ';
$string['usersettingssaved']= 'Người dùng thiết lập đã được lưu';
$string['validuntil']= 'Hợp lệ cho đến khi';
$string['validuntil_help']= 'Nếu được đặt, dịch vụ sẽ được rút hoạt động sau ngày này giờ với người dùng này.';
$string['webservice']= 'Web dịch vụ';
$string['webservices']= 'Dịch vụ web';
$string['webservicesoverview']= 'Tổng quan';
$string['webservicetokens']= 'Mã thông báo dịch vụ web';
$string['wrongusernamepassword']= 'Tên tài khoản hoặc mật khẩu xấu';
$string['wsaccessuserdeleted']= 'Từ khóa truy cập web dịch vụ đối với tài khoản tên bị xóa: {$a}';
$string['wsaccessuserexpired']= 'Từ khóa truy cập web dịch vụ đối với tài khoản tên có mật khẩu hết hạn: {$a}';
$string['wsaccessusernologin']= 'Từ khóa truy cập web dịch vụ đối với xác thực tài khoản tên không đăng nhập: {$a}';
$string['wsaccessusersuspended']= 'Từ khóa truy cập web dịch vụ đối với tài khoản tên bị đình chỉ: {$a}';
$string['wsaccessuserunconfirmed']= 'Từ bỏ web dịch vụ truy cập đối với tài khoản tên chưa được xác nhận: {$a}';
$string['wsclientdoc']= 'Moodle web service client tài liệu';
$string['wsdocapi']= 'API tài liệu';
$string['wsdocumentationdisable']= 'Web service document bị vô hiệu hóa.';
$string['wsdocumentationintro']= 'To create a client, tôi đề nghị bạn đọc {$a->doclink}';
$string['wspassword']= 'Mật khẩu dịch vụ web';
$string['wsusername']= 'Tên tài khoản dịch vụ web';
