<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_brcli', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_brcli
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['directoryerror']= 'Lỗi: Thư mục đích không tồn tại hoặc không ghi được!';
$string['helpoptionbck']= 'Thực hiện sao lưu các khóa học của một danh mục cụ thể.
Các tùy chọn:
--categoryid = INTEGER Category ID để sao lưu.
--destination = STRING Đường dẫn nơi lưu trữ tệp sao lưu.
-h, --help In ra phần trợ giúp này.
Thí dụ:
sudo -u www-data / usr / bin / php admin / tool / brcli / backup.php --categoryid = 1 --destination = / moodle / backup / ';
$string['helpoptionres']= 'Khôi phục tất cả các tệp sao lưu thuộc một thư mục cụ thể.
Các tùy chọn:
--categoryid = INTEGER Category ID nơi bản sao lưu phải được khôi phục.
--source = STRING Đường dẫn chứa các tệp sao lưu (.mbz).
-h, --help In ra phần trợ giúp này.
Thí dụ:
sudo -u www-data / usr / bin / php admin / tool / brcli / restore.php --categoryid = 1 --source = / moodle / backup / ';
$string['invalidbackupfile']= 'Tập tin sao lưu không hợp lệ: {$a}';
$string['noadminaccount']= 'Lỗi: Không tìm thấy tài khoản quản trị viên!';
$string['nocategory']= 'Lỗi: Không tìm thấy danh mục!';
$string['operationdone']= 'Đã xong!';
$string['performingbck']= 'Thực hiện sao lưu khóa học {$a} ...';
$string['performingres']= 'Đang khôi phục bản sao lưu của khóa học {$a} ...';
$string['pluginname']= 'Sao lưu và khôi phục giao diện dòng lệnh';
$string['unknowoption']= 'Tùy chọn không xác định: {$a}';
