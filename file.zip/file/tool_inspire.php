<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_inspire', language 'en', branch 'MOODLE_33_STABLE'
 *
 * @package   tool_inspire
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['accuracy']= 'Độ chính xác';
$string['allindicators']= 'Tất cả các chỉ số';
$string['analysablenotused']= 'Có thể phân tích {$a->analysableid} không được sử dụng: {$a->errors}';
$string['analysablenotvalidfortarget']= 'Có thể phân tích {$a->analysableid} không hợp lệ cho mục tiêu này: {$a->result}';
$string['analysingsitedata']= 'Phân tích trang web';
$string['bettercli']= 'Đánh giá và thực thi mô hình \' là các quá trình nặng, tốt hơn là chạy chúng thông qua giao diện dòng lệnh ';
$string['cantguessenddate']= 'Không thể đoán ngày kết thúc';
$string['cantguessstartdate']= 'Không thể đoán ngày bắt đầu';
$string['clienablemodel']= 'Bạn có thể kích hoạt mô hình bằng cách chọn phương pháp chia nhỏ thời gian theo id của nó. Lưu ý rằng bạn cũng có thể kích hoạt nó sau này bằng giao diện web (\'none \' để thoát) ';
$string['coursenotyetfinished']= 'Khóa học vẫn chưa kết thúc';
$string['coursenotyetstarted']= 'Khóa học vẫn chưa bắt đầu';
$string['coursetoolong']= 'Thời hạn hơn 1 năm';
$string['disabledmodel']= 'Xin lỗi, mô hình này đã bị quản trị viên vô hiệu hóa';
$string['editmodel']= 'Chỉnh sửa mô hình {$a}';
$string['edittrainedwarning']= 'Mô hình này đã được đào tạo, lưu ý rằng việc thay đổi các chỉ số hoặc phương pháp phân chia thời gian của nó sẽ xóa các dự đoán trước đó và bắt đầu tạo các dự đoán mới';
$string['enabled']= 'Đã bật';
$string['enabledtimesplittings']= 'Phương pháp phân chia thời gian';
$string['enabledtimesplittings_help']= 'Phương pháp chia nhỏ thời gian chia thời lượng khóa học thành các phần, công cụ dự đoán sẽ chạy khi kết thúc các phần này. Bạn chỉ nên bật các phương pháp chia nhỏ thời gian mà bạn có thể quan tâm đến việc sử dụng; quá trình đánh giá sẽ lặp lại qua tất cả chúng nên càng có nhiều phương pháp phân chia thời gian để trải qua quá trình đánh giá càng chậm. ';
$string['erroralreadypredict']= '{$a} tệp đã được sử dụng để dự đoán';
$string['errorcantenablenotimesplitting']= 'Bạn cần chọn phương pháp chia nhỏ thời gian trước khi bật mô hình';
$string['errordisabledmodel']= '{$a} mô hình bị tắt và không thể được sử dụng để dự đoán';
$string['errorinvalidindicator']= 'Chỉ báo {$a} không hợp lệ';
$string['errorinvalidtimesplitting']= 'Chia thời gian không hợp lệ, vui lòng đảm bảo bạn đã thêm tên lớp đủ điều kiện vào lớp';
$string['errornoenabledandtrainedmodels']= 'Không có mô hình được kích hoạt và đào tạo để dự đoán';
$string['errornoenabledmodels']= 'Không có mô hình nào được kích hoạt để đào tạo';
$string['errornoindicators']= 'Mô hình này không có bất kỳ chỉ báo nào';
$string['errornopredictresults']= 'Không có kết quả trả về từ bộ xử lý dự đoán, hãy kiểm tra nội dung thư mục đầu ra để biết thêm thông tin';
$string['errornoroles']= 'Vai trò của học sinh hoặc giáo viên chưa được xác định. Xác định chúng trong trang cài đặt plugin truyền cảm hứng. ';
$string['errornorunrecord']= 'Không thể định vị bản ghi chạy hiện tại trong cơ sở dữ liệu';
$string['errornotarget']= 'Mô hình này không có bất kỳ mục tiêu nào';
$string['errornotimesplittings']= 'Mô hình này không có bất kỳ phương pháp chia tách thời gian nào';
$string['errornottrainedmodel']= '{$a} người mẫu chưa được đào tạo';
$string['errorpredictionformat']= 'Định dạng tính toán dự đoán sai';
$string['errorpredictionnotfound']= 'Không tìm thấy dự đoán';
$string['errorpredictionsprocessor']= 'Lỗi bộ xử lý dự đoán: {$a}';
$string['errorpredictwrongformat']= 'Không thể giải mã trả về của bộ xử lý dự đoán: "{$a}"';
$string['errorprocessornotready']= 'Bộ xử lý dự đoán đã chọn chưa sẵn sàng: {$a}';
$string['errorsamplenotavailable']= 'Mẫu dự đoán không còn nữa';
$string['errorunexistingtimesplitting']= 'Phương pháp phân chia thời gian đã chọn không khả dụng';
$string['errorunknownaction']= 'Hành động không xác định';
$string['evaluate']= 'Đánh giá';
$string['evaluatemodel']= 'Đánh giá mô hình';
$string['evaluationinbatches']= 'Nội dung trang web được tính toán và lưu trữ theo lô, trong quá trình đánh giá, bạn có thể dừng quá trình bất cứ lúc nào, lần sau khi bạn chạy nó, nó sẽ tiếp tục từ thời điểm bạn dừng nó.';
$string['eventactionclicked']= 'Hành động dự đoán được nhấp vào';
$string['executemodel']= 'Thực hiện';
$string['executingmodel']= 'Mô hình đào tạo và tính toán dự đoán';
$string['executionresults']= 'Kết quả sử dụng {$a->name} chia nhỏ thời lượng khóa học';
$string['executionresultscli']= 'Kết quả sử dụng {$a->name} (id: {$a->id}) chia nhỏ thời lượng khóa học';
$string['extrainfo']= 'Thông tin';
$string['generalerror']= 'Lỗi đánh giá. Mã trạng thái {$a} ';
$string['goodmodel']= 'Đây là một mô hình tốt và nó có thể được sử dụng để dự đoán, kích hoạt nó và thực thi nó để bắt đầu nhận dự đoán.';
$string['indicator:accessesafterend']= 'Truy cập sau ngày kết thúc';
$string['indicator:accessesbeforestart']= 'Truy cập trước ngày bắt đầu';
$string['indicator:anywrite']= 'Bất kỳ hành động viết nào';
$string['indicator:cognitivedepthassign']= 'Nhận thức nhiệm vụ';
$string['indicator:cognitivedepthbook']= 'Sách nhận thức';
$string['indicator:cognitivedepthchat']= 'Trò chuyện nhận thức';
$string['indicator:cognitivedepthchoice']= 'Nhận thức lựa chọn';
$string['indicator:cognitivedepthdata']= 'Nhận thức cơ sở dữ liệu';
$string['indicator:cognitivedepthfeedback']= 'Nhận thức phản hồi';
$string['indicator:cognitivedepthfolder']= 'Nhận thức thư mục';
$string['indicator:cognitivedepthforum']= 'Diễn đàn nhận thức';
$string['indicator:cognitivedepthglossary']= 'Nhận thức thuật ngữ';
$string['indicator:cognitivedepthimscp']= 'Gói nội dung IMS \' nhận thức ';
$string['indicator:cognitivedepthlabel']= 'Nhãn nhận thức';
$string['indicator:cognitivedepthlesson']= 'Bài học nhận thức';
$string['indicator:cognitivedepthlti']= 'LTI nhận thức';
$string['indicator:cognitivedepthpage']= 'Trang nhận thức';
$string['indicator:cognitivedepthquiz']= 'Câu đố về nhận thức';
$string['indicator:cognitivedepthresource']= 'Nhận thức tệp';
$string['indicator:cognitivedepthscorm']= 'Nhận thức SCORM';
$string['indicator:cognitivedepthsurvey']= 'Khảo sát nhận thức';
$string['indicator:cognitivedepthurl']= 'URL nhận thức';
$string['indicator:cognitivedepthwiki']= 'Wiki nhận thức';
$string['indicator:cognitivedepthworkshop']= 'Hội thảo nhận thức';
$string['indicator:completeduserprofile']= 'Hồ sơ người dùng đã hoàn thành';
$string['indicator:readactions']= 'Số lượng hành động đọc';
$string['indicators']= 'Các chỉ số';
$string['indicator:socialbreadthassign']= 'Chuyển nhượng xã hội';
$string['indicator:socialbreadthbook']= 'Sách xã hội';
$string['indicator:socialbreadthchat']= 'Trò chuyện xã hội';
$string['indicator:socialbreadthchoice']= 'Lựa chọn xã hội';
$string['indicator:socialbreadthdata']= 'Cơ sở dữ liệu xã hội';
$string['indicator:socialbreadthfeedback']= 'Phản hồi xã hội';
$string['indicator:socialbreadthfolder']= 'Thư mục xã hội';
$string['indicator:socialbreadthforum']= 'Diễn đàn xã hội';
$string['indicator:socialbreadthglossary']= 'Thuật ngữ xã hội';
$string['indicator:socialbreadthimscp']= 'Gói nội dung IMS \' xã hội ';
$string['indicator:socialbreadthlabel']= 'Gắn nhãn xã hội';
$string['indicator:socialbreadthlesson']= 'Bài học xã hội';
$string['indicator:socialbreadthlti']= 'LTI xã hội';
$string['indicator:socialbreadthpage']= 'Trang xã hội';
$string['indicator:socialbreadthquiz']= 'Câu đố xã hội';
$string['indicator:socialbreadthresource']= 'Tệp mạng xã hội';
$string['indicator:socialbreadthscorm']= 'SCORM xã hội';
$string['indicator:socialbreadthsurvey']= 'Khảo sát xã hội';
$string['indicator:socialbreadthurl']= 'URL xã hội';
$string['indicator:socialbreadthwiki']= 'Mạng xã hội Wiki';
$string['indicator:socialbreadthworkshop']= 'Hội thảo xã hội';
$string['indicator:userforumstracking']= 'Người dùng đang theo dõi diễn đàn';
$string['info']= 'Thông tin';
$string['insightinfo']= '{$a->insightname} - {$a->contextname}';
$string['insightinfomessage']= 'Có một số thông tin chi tiết mà bạn có thể thấy hữu ích. Kiểm tra {$a} ';
$string['insightmessagesubject']= 'Thông tin chi tiết mới cho "{$a->contextname}": {$a->insightname}';
$string['insights']= 'Thông tin chi tiết';
$string['inspire:listinsights']= 'Liệt kê thông tin chi tiết';
$string['inspire:managemodels']= 'Quản lý mô hình';
$string['inspiremodels']= 'Truyền cảm hứng cho các mô hình';
$string['invalidanalysablefortimesplitting']= 'Không thể phân tích nó bằng phương pháp chia tách thời gian {$a}';
$string['invalidtimesplitting']= 'Mô hình có id {$a} cần một phương pháp tách thời gian trước khi nó có thể được sử dụng để huấn luyện';
$string['labelstudentdropoutno']= 'Không có rủi ro';
$string['labelstudentdropoutyes']= 'Học sinh có nguy cơ bỏ học';
$string['loginfo']= 'Ghi thông tin bổ sung';
$string['lowaccuracy']= 'Độ chính xác của mô hình thấp';
$string['messageprovider:insights']= 'Thông tin chi tiết được tạo bởi các mô hình dự đoán';
$string['modeloutputdir']= 'Thư mục đầu ra mô hình';
$string['modeloutputdirinfo']= 'Thư mục nơi bộ xử lý dự đoán lưu trữ tất cả thông tin đánh giá. Hữu ích cho việc gỡ lỗi và nghiên cứu. ';
$string['modelresults']= '{$a} kết quả';
$string['modelslist']= 'Danh sách kiểu máy';
$string['modeltimesplitting']= 'Tách thời gian';
$string['nocompletiondetection']= 'Không có phương pháp nào để phát hiện việc hoàn thành khóa học (không hoàn thành, không hoàn thành năng lực cũng như không đạt điểm khóa học)';
$string['nocourseactivity']= 'Không đủ hoạt động của khóa học từ khi bắt đầu và kết thúc khóa học';
$string['nocourseendtime']= 'Khóa học không có thời gian kết thúc';
$string['nocourses']= 'Không có khóa học nào để phân tích';
$string['nocoursesections']= 'Không có phần khóa học';
$string['nocoursestudents']= 'Không có học sinh';
$string['nodata']= 'Không có sẵn dữ liệu';
$string['nodatatoevaluate']= 'Không có dữ liệu để đánh giá mô hình';
$string['nodatatopredict']= 'Không có dữ liệu nào để sử dụng cho các dự đoán';
$string['nodatatotrain']= 'Không có dữ liệu nào để sử dụng làm dữ liệu huấn luyện';
$string['nonewdata']= 'Không có dữ liệu mới';
$string['nonewtimeranges']= 'Không có khoảng thời gian mới, không có gì để dự đoán';
$string['nopredictionsyet']= 'Chưa có dự đoán nào';
$string['notdefined']= 'Chưa được xác định';
$string['novaliddata']= 'Không có sẵn dữ liệu hợp lệ';
$string['pluginname']= 'Truyền cảm hứng';
$string['prediction']= 'Dự đoán';
$string['predictiondetails']= 'Chi tiết dự đoán';
$string['predictionprocessfinished']= 'Quá trình dự đoán kết thúc';
$string['predictionresults']= 'Kết quả dự đoán';
$string['predictions']= 'Dự đoán';
$string['predictionsprocessor']= 'Bộ xử lý dự đoán';
$string['predictionsprocessor_help']= 'Bộ xử lý dự đoán là phần phụ trợ học máy xử lý các tập dữ liệu được tạo ra bằng cách tính toán các mô hình \' chỉ số và mục tiêu. ';
$string['predictmodels']= 'Dự đoán mô hình';
$string['predictorresultsin']= 'Dự đoán đã ghi thông tin vào thư mục {$a}';
$string['processingsitecontents']= 'Đang xử lý nội dung trang web';
$string['sameenddate']= 'Ngày kết thúc hiện tại là tốt';
$string['samestartdate']= 'Ngày bắt đầu hiện tại là tốt';
$string['selectotherinsights']= 'Chọn thông tin chi tiết khác ...';
$string['skippingcourse']= 'Đang bỏ qua khóa học {$a}';
$string['studentroles']= 'Vai trò sinh viên';
$string['subplugintype_predict']= 'Bộ xử lý dự đoán';
$string['subplugintype_predict_plural']= 'Bộ xử lý dự đoán';
$string['successfullyanalysed']= 'Đã phân tích thành công';
$string['target']= 'Mục tiêu';
$string['target:coursedropout']= 'Học sinh có nguy cơ bỏ học';
$string['target:coursedropoutinfo']= 'Ở đây bạn có thể tìm thấy danh sách các sinh viên có nguy cơ bỏ học.';
$string['teacherroles']= 'Vai trò của giáo viên';
$string['timemodified']= 'Lần sửa đổi cuối cùng';
$string['timesplitting:deciles']= 'Phân đoạn';
$string['timesplitting:decilesaccum']= 'Tích lũy số thập phân';
$string['timesplittingmethod']= 'Phương pháp phân chia thời gian';
$string['timesplittingmethod_help']= 'Phương pháp chia nhỏ thời gian chia thời lượng khóa học thành các phần, công cụ dự đoán sẽ chạy khi kết thúc các phần này. Bạn chỉ nên bật các phương pháp chia nhỏ thời gian mà bạn có thể quan tâm đến việc sử dụng; quá trình đánh giá sẽ lặp lại qua tất cả chúng nên càng có nhiều phương pháp phân chia thời gian để trải qua quá trình đánh giá càng chậm. ';
$string['timesplitting:nosplitting']= 'Không chia thời gian';
$string['timesplitting:quarters']= 'Khu';
$string['timesplitting:quartersaccum']= 'Tích lũy các phần tư';
$string['timesplitting:singlerange']= 'Phạm vi đơn';
$string['timesplitting:weekly']= 'Hàng tuần';
$string['timesplitting:weeklyaccum']= 'Tích lũy hàng tuần';
$string['trainingprocessfinished']= 'Quá trình đào tạo đã kết thúc';
$string['trainingresults']= 'Kết quả đào tạo';
$string['trainmodels']= 'Mô hình xe lửa';
$string['viewlog']= 'Nhật ký';
$string['viewprediction']= 'Xem chi tiết dự đoán';
$string['viewpredictions']= 'Xem dự đoán mô hình';
$string['weeksenddateautomaticallyset']= 'Ngày kết thúc tự động được đặt dựa trên ngày bắt đầu và số phần';
$string['weeksenddatedefault']= 'Ngày kết thúc sẽ được tự động tính từ ngày bắt đầu khóa học';
