<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_abconfig', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_abconfig
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['abconfigsettings']= 'Cài đặt cấu hình A / B';
$string['adminenabled']= 'Đã bật cho quản trị viên';
$string['cachedef_experiments']= 'Bộ nhớ cache để lưu trữ các thử nghiệm và điều kiện trong.';
$string['edit']= 'Chỉnh sửa';
$string['editexperimentconds']= 'Chỉnh sửa điều kiện thử nghiệm';
$string['editexperimentpagename']= 'Chỉnh sửa thử nghiệm';
$string['enabled']= 'Đã bật';
$string['formaddexperiment']= 'Thêm thử nghiệm';
$string['formaddrepeat']= 'Thêm bộ điều kiện';
$string['formdeleteexperiment']= 'Xóa thử nghiệm';
$string['formdeleterepeat']= 'Xóa';
$string['formeditconditions']= 'Chỉnh sửa điều kiện';
$string['formexperimentadminenable']= 'Bật thử nghiệm này cho quản trị viên trang web.';
$string['formexperimentalreadyexists']= 'Tên viết tắt của thử nghiệm đã tồn tại';
$string['formexperimentcommands']= 'Các lệnh thử nghiệm';
$string['formexperimentconds']= 'Điều kiện thử nghiệm';
$string['formexperimentcondsset']= 'Đặt điều kiện';
$string['formexperimentenabled']= 'Bật thử nghiệm';
$string['formexperimentforceurl']= 'Buộc tham số URL';
$string['formexperimentinfo']= 'Thông tin thử nghiệm';
$string['formexperimentname']= 'Tên thí nghiệm:';
$string['formexperimentnamereq']= 'Tên thử nghiệm được yêu cầu';
$string['formexperimentscopeselect']= 'Phạm vi:';
$string['formexperimentshortname']= 'Tên thử nghiệm ngắn:';
$string['formexperimentshortnamereq']= 'Cần có tên thử nghiệm ngắn gọn';
$string['formexperimentvalue']= '% giá trị của lưu lượng truy cập được nhắm mục tiêu';
$string['formexperimentvalueerror']= 'Giá trị% phải là một số trong phạm vi 0-100';
$string['formexperimentvalueexceed']= 'Tổng tất cả các giá trị đặt điều kiện phải <= 100. Hiện tại là {$a}';
$string['formheader']= 'Bộ điều kiện {$a}';
$string['formipwhitelist']= 'Danh sách trắng IP';
$string['formnnewconditions']= 'Bộ điều kiện mới';
$string['formnocommands']= 'Không có lệnh';
$string['formnoips']= 'Không có IP';
$string['manageexperimentspagename']= 'Quản lý thử nghiệm';
$string['name']= 'Tên thí nghiệm';
$string['no']= 'Không';
$string['pluginname']= 'Cấu hình A / B';
$string['privacy:metadata']= 'Plugin này không thu thập hoặc lưu trữ bất kỳ thông tin người dùng nào.';
$string['request']= 'Yêu cầu';
$string['scope']= 'Phạm vi thử nghiệm';
$string['session']= 'Phiên';
$string['settingsenabledesc']= 'Bật plugin. Trong khi điều này không được chọn, người dùng sẽ không tương tác với plugin. Thử nghiệm vẫn có thể được thiết lập. ';
$string['settingsenablename']= 'Bật plugin';
$string['shortname']= 'Tên thử nghiệm ngắn gọn';
$string['yes']= 'Có';
