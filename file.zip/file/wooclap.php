<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'wooclap', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   wooclap
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['accesskeyid']= 'Id nền tảng (accessKeyId)';
$string['accesskeyid-description']= 'Id khóa truy cập được sử dụng để giao tiếp với Wooclap. Nên bắt đầu bằng \'ak. \'. ';
$string['baseurl']= 'URL cơ sở';
$string['baseurl-description']= 'Cái này chỉ dùng để gỡ lỗi hoặc thử nghiệm. Chỉ thay đổi giá trị này theo yêu cầu của nhóm hỗ trợ Wooclap. ';
$string['customcompletion']= 'Trạng thái hoàn thành chỉ được cập nhật bởi Wooclap';
$string['customcompletiongroup']= 'Hoàn thành tùy chỉnh Wooclap';
$string['error-auth-nosession']= 'Thiếu phiên trong xác thực';
$string['error-callback-is-not-url']= 'Tham số gọi lại không phải là URL hợp lệ';
$string['error-couldnotauth']= 'Không thể lấy người dùng hoặc khóa học trong quá trình xác thực';
$string['error-couldnotloadevents']= 'Không thể tải các sự kiện Wooclap của người dùng';
$string['error-couldnotredirect']= 'Không thể chuyển hướng';
$string['error-couldnotupdatereport']= 'Không thể cập nhật báo cáo';
$string['error-invalidjoinurl']= 'URL tham gia không hợp lệ';
$string['error-invalidtoken']= 'Mã thông báo không hợp lệ';
$string['error-missingparameters']= 'Thiếu tham số';
$string['error-noeventid']= 'Không thể xác định id sự kiện';
$string['gradeupdatefailed']= 'Cập nhật điểm không thành công';
$string['gradeupdateok']= 'Cập nhật điểm thành công';
$string['modulename']= 'Wooclap';
$string['modulename_help']= 'Mô-đun này cung cấp tích hợp nền tảng tương tác Wooclap với Moodle';
$string['modulenameplural']= 'Wooclap';
$string['modulenamepluralformatted']= 'Danh sách các hoạt động của Wooclap';
$string['nowooclap']= 'Không có phiên bản Wooclap nào';
$string['pingNOTOK']= 'Không thể thiết lập kết nối với Wooclap. Vui lòng kiểm tra cài đặt của bạn. ';
$string['pingOK']= 'Kết nối được thiết lập với Wooclap';
$string['pluginadministration']= 'Quản trị Wooclap';
$string['pluginname']= 'Wooclap';
$string['privacy:metadata:wooclap_server']= 'Để tích hợp với Wooclap, dữ liệu người dùng cần được trao đổi.';
$string['privacy:metadata:wooclap_server:userid']= 'Id người dùng được gửi từ Moodle để cho phép bạn truy cập dữ liệu của mình trên Wooclap.';
$string['quiz']= 'Nhập câu đố Moodle';
$string['secretaccesskey']= 'Khóa API (secretAccessKey)';
$string['secretaccesskey-description']= 'Khóa truy cập bí mật dùng để giao tiếp với Wooclap. Nên bắt đầu bằng \'sk. \'. ';
$string['testconnection']= 'Kết nối thử nghiệm';
$string['wooclap:addinstance']= 'Thêm một hoạt động Wooclap vào một khóa học';
$string['wooclapeventid']= 'Nhân bản sự kiện Wooclap';
$string['wooclapintro']= 'Mô tả';
$string['wooclapname']= 'Tên';
$string['wooclapsettings']= 'Cài đặt';
$string['wooclap:view']= 'Truy cập một hoạt động Wooclap';
