<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'workshopeval_credit', language 'en', branch 'MOODLE_36_STABLE'
 *
 * @package   workshopeval_credit
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['mode']= 'Chế độ đánh giá';
$string['modeall']= 'Tất cả hoặc không có gì';
$string['mode_desc']= 'Chế độ đánh giá chấm điểm mặc định được sử dụng bởi phương pháp _Participation credit_.';
$string['mode_help']= 'Chế độ xác định cách tính điểm đánh giá.
* Tất cả hoặc không có gì - Người đánh giá phải đánh giá tất cả các bài nộp được phân bổ để đạt được điểm tối đa; nếu không thì họ sẽ bị điểm 0.
* Tỷ lệ thuận - Điểm thu được tỷ lệ thuận với số lượng đánh giá. Nếu tất cả các bài nộp được phân bổ đều được đánh giá, người đánh giá sẽ đạt được điểm tối đa; nếu một nửa số bài nộp được phân bổ được đánh giá, người đánh giá sẽ đạt được 50% điểm tối đa.
* Ít nhất một - Người đánh giá phải đánh giá ít nhất một bài nộp được phân bổ để đạt được điểm tối đa. ';
$string['modeone']= 'Ít nhất một';
$string['modeproportional']= 'Tỷ lệ';
$string['pluginname']= 'Tín dụng tham gia';
$string['privacy:metadata']= 'Tín dụng tham gia không lưu trữ bất kỳ dữ liệu cá nhân nào';
