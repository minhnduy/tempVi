<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_adhoc', language 'en', branch 'MOODLE_31_STABLE'
 *
 * @package   tool_adhoc
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['adhoctasks']= 'Nhiệm vụ Adhoc';
$string['availqueues']= 'Hàng đợi có sẵn';
$string['blocking']= 'Chặn?';
$string['customdata']= 'Dữ liệu tùy chỉnh';
$string['deletetask']= 'Xóa công việc';
$string['error_cron_lock']= 'Không thể lấy cron lock!';
$string['error_task_lock']= 'Không thể lấy khóa tác vụ!';
$string['id']= 'ID';
$string['managequeues']= 'Quản lý hàng đợi';
$string['notasks']= 'Không có nhiệm vụ adhoc nào được lên lịch.';
$string['plugindesc']= 'Trình quản lý tác vụ adhoc cho phép quản trị viên quản lý hàng đợi adhoc.';
$string['pluginname']= 'Trình quản lý tác vụ Adhoc';
$string['run']= 'Chạy';
$string['runtask']= 'Chạy tác vụ';
$string['subplugintype_queue']= 'Hàng đợi';
$string['subplugintype_queue_plural']= 'Hàng đợi';
$string['task_complete']= 'Hoàn thành công việc!';
