<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_rebuildcoursecache', language 'en', branch 'MOODLE_24_STABLE'
 *
 * @package   tool_rebuildcoursecache
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['areyousure']= 'Bạn có chắc chắn muốn tiếp tục không?';
$string['disclaimer']= 'Công cụ này sẽ xây dựng lại Bộ nhớ cache của khóa học (modinfo và sectioncache) cho tất cả các khóa học trên trang web của bạn. <br /> Việc này có thể mất nhiều thời gian trên các trang web lớn nên bạn có thể muốn thực hiện việc này trong đêm hoặc thời gian ngừng hoạt động.';
$string['fail']= 'FAIL - Không thể tìm thấy ID khóa học: {$a} <br />';
$string['notifyfinished']= 'Bộ nhớ cache của khóa học đã được xây dựng lại';
$string['notifyrebuilding']= 'Bắt ​​đầu xây dựng lại bộ nhớ cache của khóa học';
$string['pageheader']= 'Xây dựng lại bộ nhớ cache của khóa học';
$string['pluginname']= 'Xây dựng lại bộ nhớ cache của khóa học';
$string['specifyids']= 'Để trống hộp văn bản này để xây dựng lại tất cả các khóa học hoặc chỉ định id khóa học riêng lẻ nào sẽ được xây dựng lại (Phân cách bằng dấu phẩy hoặc dấu cách) <br /> Ví dụ: 1,2,30,100 hoặc 1 2 30 100';
$string['success']= 'THÀNH CÔNG - ID khóa học: {$a} <br />';
