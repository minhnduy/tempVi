<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_legacyfilesmigration', language 'en', branch 'MOODLE_30_STABLE'
 *
 * @package   tool_legacyfilesmigration
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['backtoindex']= 'Quay lại chỉ mục';
$string['batchmigrate']= 'Di chuyển các tệp kế thừa cho nhiều khóa học';
$string['batchoperations']= 'Hoạt động hàng loạt';
$string['confirmbatchmigrate']= 'Xác nhận các khóa học di chuyển hàng loạt';
$string['courseid']= 'Id khóa học';
$string['coursenotfound']= 'không tìm thấy khóa học {$a}';
$string['coursidnotcollapse']= 'cột khóa học phải được mở!';
$string['empty_owner']= 'Tên người dùng của chủ sở hữu mặc định để thay thế chủ sở hữu trống';
$string['foldername']= 'tên thư mục được tạo trong kho lưu trữ người dùng riêng tư';
$string['foldername_desc']= 'tên thư mục được tạo trong kho lưu trữ người dùng riêng tư sẽ được đánh giá bằng php eval bằng cách sử dụng các đối tượng $ course và $ usercontext';
$string['listnotmigrated']= 'Liệt kê các khóa học có chứa các tệp kế thừa sẽ được di chuyển';
$string['listnotmigrated_desc']= 'Bạn có thể di chuyển các tệp kế thừa cho các khóa học riêng lẻ từ đây';
$string['migrateall']= 'Di chuyển các tệp kế thừa cho tất cả các khóa học';
$string['migrateallconfirm']= 'Di chuyển các tệp kế thừa cho tất cả các khóa học?';
$string['migratecoursesuccess']= 'Kết quả: Di chuyển các tệp kế thừa thành công';
$string['migratecoursesummary']= 'Di chuyển các tệp kế thừa cho khóa học với id id {$a->id} và tên "{$a->fullname}":';
$string['migrateprogress']= 'Di chuyển tệp kế thừa cho các khóa học n ° {$a->current} trong tổng số {$a->total}';
$string['migrateselected']= 'Di chuyển các tệp kế thừa cho các khóa học đã chọn';
$string['migrateselectedcount']= 'Di chuyển tệp kế thừa cho {$a} các khóa học đã chọn?';
$string['migratetable']= 'Di chuyển bảng';
$string['migrationfailed']= 'Di chuyển tệp kế thừa không thành công. <br/> Nhật ký từ bản nâng cấp là: <br /> {$a}';
$string['nocoursesselected']= 'Không có khóa học nào được chọn';
$string['nocoursestoupgrade']= 'Không có khóa học nào yêu cầu di chuyển tệp kế thừa';
$string['notmigratedintro']= 'Danh sách các khóa học có chứa các tệp kế thừa để chuyển sang tệp người dùng riêng tư ';
$string['notmigratedtitle']= 'Các khóa học chứa các tệp kế thừa cần di chuyển';
$string['notsupported']= 'không được hỗ trợ';
$string['owner']= 'Chủ sở hữu';
$string['pluginname']= 'Di chuyển tệp kế thừa';
$string['preselect_owner']= 'Chọn trước và điền chủ sở hữu';
$string['select']= 'Chọn';
$string['supported']= 'Di cư';
$string['toollegacyfilesmigrationsettings']= 'Cài đặt di chuyển tệp kế thừa';
$string['unchoosenowner']= 'Vui lòng chọn người dùng cho khóa học có id {$a}';
$string['unknown']= 'không xác định';
$string['usernotfound']= 'không tìm thấy người dùng {$a}';
$string['viewcourse']= 'Xem khóa học với các tệp kế thừa được di chuyển';
