<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_lifecycle', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_lifecycle
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['abortdisableworkflow']= 'Tắt quy trình làm việc (hủy bỏ quy trình, có thể không an toàn!)';
$string['abortdisableworkflow_confirm']= 'Dòng công việc sẽ bị vô hiệu hóa và tất cả các quá trình đang chạy của dòng công việc này sẽ bị hủy bỏ. Bạn có chắc không?';
$string['abortprocesses']= 'Hủy các tiến trình đang chạy (có thể không an toàn!)';
$string['abortprocesses_confirm']= 'Tất cả các quá trình đang chạy của dòng công việc này sẽ bị hủy bỏ. Bạn có chắc không?';
$string['activateworkflow']= 'Kích hoạt';
$string['active_automatic_workflows_heading']= 'Dòng công việc tự động đang hoạt động';
$string['active_manual_workflows_heading']= 'Quy trình làm việc thủ công đang hoạt động';
$string['active_processes_list_header']= 'Các quy trình đang hoạt động';
$string['active_workflow_not_changeable']= 'Phiên bản dòng công việc đã được kích hoạt. Không thể thay đổi bất kỳ bước nào của nó nữa. ';
$string['active_workflow_not_removeable']= 'Phiên bản dòng công việc đang hoạt động. Không thể gỡ bỏ nó. ';
$string['active_workflows_list']= 'Liệt kê các dòng công việc đang hoạt động và các định nghĩa dòng công việc';
$string['add_new_step_instance']= 'Thêm phiên bản bước mới ...';
$string['add_new_trigger_instance']= 'Thêm phiên bản trình kích hoạt mới ...';
$string['add_workflow']= 'Thêm quy trình làm việc';
$string['adminsettings_edit_step_instance_heading']= 'Phiên bản bước cho quy trình làm việc \' {$a} \\';
$string['adminsettings_edit_trigger_instance_heading']= 'Kích hoạt quy trình làm việc \' {$a} \\';
$string['adminsettings_edit_workflow_definition_heading']= 'Định nghĩa quy trình làm việc';
$string['adminsettings_heading']= 'Cài đặt quy trình làm việc';
$string['adminsettings_workflow_definition_steps_heading']= 'Các bước quy trình làm việc';
$string['all_delays']= 'Tất cả sự chậm trễ';
$string['anonymous_user']= 'Người dùng ẩn danh';
$string['apply']= 'Áp dụng';
$string['backupcreated']= 'Được tạo lúc';
$string['backupworkflow']= 'Quy trình làm việc dự phòng';
$string['cannot_trigger_workflow_manually']= 'Không thể kích hoạt quy trình công việc được yêu cầu theo cách thủ công.';
$string['config_backup_path']= 'Đường dẫn của thư mục sao lưu vòng đời';
$string['config_backup_path_desc']= 'Cài đặt này xác định vị trí lưu trữ của các bản sao lưu được tạo bởi bước sao lưu.
Đường dẫn phải được chỉ định là đường dẫn tuyệt đối trên máy chủ của bạn. ';
$string['config_delay_duration']= 'Thời gian trì hoãn mặc định của khóa học';
$string['config_delay_duration_desc']= 'Cài đặt này xác định khoảng thời gian trễ mặc định của quy trình làm việc
trong trường hợp một trong các quy trình của nó bị lùi lại hoặc kết thúc.
Thời gian trì hoãn xác định khoảng thời gian mà một khóa học sẽ không được xử lý lại trong một trong hai trường hợp. ';
$string['course_backups_list_header']= 'Bản sao lưu khóa học';
$string['coursename']= 'Tên khóa học';
$string['date']= 'Ngày đến hạn';
$string['deactivated_workflows_list']= 'Liệt kê các dòng công việc đã hủy kích hoạt';
$string['deactivated_workflows_list_header']= 'Dòng công việc bị vô hiệu hóa';
$string['delayed_courses_header']= 'Các khóa học bị trì hoãn';
$string['delayed_for_workflows']= 'Bị trì hoãn cho quy trình công việc {$a}';
$string['delayed_for_workflow_until']= 'Bị hoãn đối với "{$a->name}" cho đến {$a->date}';
$string['delayed_globally']= 'Bị trì hoãn trên toàn cầu cho đến {$a}';
$string['delayed_globally_and_seperately']= 'Bị trì hoãn trên toàn cầu và riêng đối với quy trình công việc {$a}';
$string['delayed_globally_and_seperately_for_one']= 'Bị trì hoãn trên toàn cầu và riêng biệt cho 1 quy trình làm việc';
$string['delays']= 'Chậm trễ';
$string['delays_for_workflow']= 'Độ trễ cho "{$a}"';
$string['delete_all_delays']= 'Xóa tất cả sự chậm trễ';
$string['delete_delay']= 'Xóa độ trễ';
$string['deleteworkflow']= 'Xóa dòng công việc';
$string['deleteworkflow_confirm']= 'Dòng công việc sẽ bị xóa. Không thể hoàn tác điều này. Bạn có chắc không?';
$string['disableworkflow']= 'Tắt quy trình làm việc (các quy trình tiếp tục chạy)';
$string['disableworkflow_confirm']= 'Quy trình làm việc sẽ bị vô hiệu hóa. Bạn có chắc không?';
$string['download']= 'Tải xuống';
$string['duplicateworkflow']= 'Dòng công việc trùng lặp';
$string['editworkflow']= 'Chỉnh sửa cài đặt chung';
$string['error_wrong_trigger_selected']= 'Bạn đã cố gắng yêu cầu một trình kích hoạt không thủ công.';
$string['followedby_none']= 'Không có';
$string['general_config_header']= 'Chung & subplugins';
$string['general_settings_header']= 'Cài đặt chung';
$string['globally']= 'Sự chậm trễ toàn cầu';
$string['globally_until_date']= 'Trên toàn cầu cho đến {$a}';
$string['interaction_success']= 'Hành động được lưu thành công.';
$string['invalid_workflow']= 'Cấu hình dòng công việc không hợp lệ';
$string['invalid_workflow_cannot_be_activated']= 'Định nghĩa dòng công việc không hợp lệ, do đó nó không thể được kích hoạt.';
$string['invalid_workflow_details']= 'Chuyển đến chế độ xem chi tiết, để tạo kích hoạt cho quy trình làm việc này';
$string['lastaction']= 'Hành động cuối cùng trên';
$string['lifecycle_cleanup_task']= 'Xóa các mục nhập trì hoãn cũ cho quy trình công việc vòng đời';
$string['lifecycle:managecourses']= 'Có thể quản lý các khóa học trong tool_lifecycle';
$string['lifecyclestep']= 'Bước xử lý';
$string['lifecycle_task']= 'Chạy các quy trình vòng đời';
$string['lifecycletrigger']= 'Kích hoạt';
$string['managecourses_link']= 'Quản lý các khóa học';
$string['manual_trigger_process_existed']= 'Một quy trình làm việc cho khóa học này đã tồn tại.';
$string['manual_trigger_success']= 'Dòng công việc đã bắt đầu thành công.';
$string['name_until_date']= '"{$a->name}" cho đến khi {$a->date}';
$string['nocoursestodisplay']= 'Hiện tại không có khóa học nào yêu cầu bạn chú ý!';
$string['nointeractioninterface']= 'Không có giao diện tương tác!';
$string['noprocessfound']= 'Không thể tìm thấy quá trình với processid đã cho!';
$string['nostepfound']= 'Không thể tìm thấy bước với bước đã cho!';
$string['pluginname']= 'Vòng đời';
$string['plugintitle']= 'Vòng đời của khóa học';
$string['privacy:metadata:tool_lifecycle_action_log']= 'Nhật ký các hành động được thực hiện bởi người quản lý khóa học.';
$string['privacy:metadata:tool_lifecycle_action_log:action']= 'Định danh của hành động đã được thực hiện.';
$string['privacy:metadata:tool_lifecycle_action_log:courseid']= 'ID của Khóa học mà hành động đã được thực hiện cho';
$string['privacy:metadata:tool_lifecycle_action_log:processid']= 'ID của Quy trình mà hành động đã được thực hiện trong.';
$string['privacy:metadata:tool_lifecycle_action_log:stepindex']= 'Chỉ mục của Bước trong Quy trình làm việc, hành động đã được thực hiện cho.';
$string['privacy:metadata:tool_lifecycle_action_log:time']= 'Thời gian khi hành động được thực hiện.';
$string['privacy:metadata:tool_lifecycle_action_log:userid']= 'ID của người dùng đã thực hiện hành động.';
$string['privacy:metadata:tool_lifecycle_action_log:workflowid']= 'ID của Dòng công việc mà hành động đã được thực hiện.';
$string['process_proceeded_event']= 'Một quá trình đã được tiến hành';
$string['process_rollback_event']= 'Một quá trình đã được khôi phục lại';
$string['process_triggered_event']= 'Một quá trình đã được kích hoạt';
$string['restore']= 'Khôi phục';
$string['restore_step_does_not_exist']= 'Bước {$a} chưa được cài đặt, nhưng được bao gồm trong tệp sao lưu. Vui lòng cài đặt nó trước và thử lại. ';
$string['restore_subplugins_invalid']= 'Định dạng tệp sao lưu không đúng. Cấu trúc của các phần tử của subplugin không như mong đợi. ';
$string['restore_trigger_does_not_exist']= 'Trình kích hoạt {$a} chưa được cài đặt, nhưng được bao gồm trong tệp sao lưu. Vui lòng cài đặt nó trước và thử lại. ';
$string['restore_workflow_not_found']= 'Định dạng tệp sao lưu không đúng. Không thể tìm thấy quy trình làm việc. ';
$string['show_delays']= 'Kiểu xem';
$string['status']= 'Trạng thái';
$string['step']= 'Bước xử lý';
$string['step_delete']= 'Xóa';
$string['step_edit']= 'Chỉnh sửa';
$string['step_instancename']= 'Tên phiên bản';
$string['step_instancename_help']= 'Tiêu đề phiên bản bước (chỉ hiển thị cho quản trị viên).';
$string['step_settings_header']= 'Cài đặt cụ thể của loại bước';
$string['step_show']= 'Hiển thị';
$string['step_sortindex']= 'Lên / Xuống';
$string['step_subpluginname']= 'Tên chương trình phụ';
$string['step_subpluginname_help']= 'Step subplugin / trigger title (chỉ hiển thị cho quản trị viên).';
$string['step_type']= 'Loại';
$string['subplugintype_lifecyclestep']= 'Bước trong một quy trình vòng đời';
$string['subplugintype_lifecyclestep_plural']= 'Các bước trong quy trình vòng đời';
$string['subplugintype_lifecycletrigger']= 'Kích hoạt để bắt đầu một quy trình vòng đời';
$string['subplugintype_lifecycletrigger_plural']= 'Kích hoạt để bắt đầu một quy trình vòng đời';
$string['tablecourseslog']= 'Hành động trong quá khứ';
$string['tablecoursesremaining']= 'Các khóa học còn lại';
$string['tablecoursesrequiringattention']= 'Các khóa học yêu cầu sự chú ý của bạn';
$string['tools']= 'Công cụ';
$string['trigger']= 'Kích hoạt';
$string['trigger_does_not_exist']= 'Không tìm thấy trình kích hoạt được yêu cầu.';
$string['trigger_enabled']= 'Đã bật';
$string['trigger_instancename']= 'Tên phiên bản';
$string['trigger_instancename_help']= 'Tiêu đề phiên bản trình kích hoạt (chỉ hiển thị cho quản trị viên).';
$string['trigger_settings_header']= 'Cài đặt cụ thể của loại trình kích hoạt';
$string['trigger_sortindex']= 'Lên / Xuống';
$string['trigger_subpluginname']= 'Tên chương trình phụ';
$string['trigger_subpluginname_help']= 'Step subplugin / trigger title (chỉ hiển thị cho quản trị viên).';
$string['trigger_workflow']= 'Quy trình làm việc';
$string['upload_workflow']= 'Tải lên quy trình làm việc';
$string['viewheading']= 'Quản lý các khóa học';
$string['viewsteps']= 'Xem các bước quy trình làm việc';
$string['workflow']= 'Quy trình làm việc';
$string['workflow_active']= 'Hoạt động';
$string['workflow_definition_heading']= 'Định nghĩa quy trình làm việc';
$string['workflow_delayforallworkflows']= 'Độ trễ cho tất cả quy trình làm việc?';
$string['workflow_delayforallworkflows_help']= 'Nếu được đánh dấu, thời lượng ở trên không chỉ làm chậm quá trình thực thi
quy trình làm việc này cho một khóa học, nhưng cho tất cả các quy trình công việc khác. Vì vậy, cho đến khi thời gian trôi qua không có quá trình nào có thể được bắt đầu
cho khóa học tương ứng. ';
$string['workflow_displaytitle']= 'Tiêu đề dòng công việc được hiển thị';
$string['workflow_displaytitle_help']= 'Tiêu đề này được hiển thị cho người dùng khi quản lý các khóa học của họ.';
$string['workflow_duplicate_title']= '{$a} (Sao chép)';
$string['workflow_finishdelay']= 'Trì hoãn trong trường hợp khóa học đã kết thúc';
$string['workflow_finishdelay_help']= 'Nếu một khóa học đã hoàn thành một phiên bản quy trình của dòng công việc này,
giá trị này mô tả thời gian cho đến khi một quy trình cho sự kết hợp giữa khóa học và quy trình làm việc này có thể được bắt đầu lại. ';
$string['workflow_is_running']= 'Dòng công việc đang chạy.';
$string['workflownotfound']= 'Không tìm thấy dòng công việc có id {$a}';
$string['workflow_not_removeable']= 'Không thể xóa phiên bản dòng công việc này. Có thể nó vẫn còn các tiến trình đang chạy? ';
$string['workflow_processes']= 'Các quy trình đang hoạt động';
$string['workflow_rollbackdelay']= 'Trì hoãn trong trường hợp quay lại';
$string['workflow_rollbackdelay_help']= 'Nếu một khóa học được khôi phục trong một phiên bản quy trình của dòng công việc này,
giá trị này mô tả thời gian cho đến khi một quy trình cho sự kết hợp giữa khóa học và quy trình làm việc này có thể được bắt đầu lại. ';
$string['workflow_sortindex']= 'Lên / Xuống';
$string['workflow_started']= 'Dòng công việc bắt đầu.';
$string['workflow_timeactive']= 'Hoạt động kể từ khi';
$string['workflow_timedeactive']= 'Đã hủy kích hoạt kể từ khi';
$string['workflow_title']= 'Tiêu đề';
$string['workflow_title_help']= 'Tiêu đề quy trình làm việc (chỉ hiển thị cho quản trị viên).';
$string['workflow_tools']= 'Hành động';
$string['workflow_trigger']= 'Kích hoạt quy trình làm việc';
