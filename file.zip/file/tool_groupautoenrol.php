<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_groupautoenrol', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_groupautoenrol
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['auto_group_enrol_form_no_group_found']= 'Tạo nhóm trước!';
$string['auto_group_form_enable_enrol']= 'Cho phép đăng ký tự động theo nhóm cho khóa học này';
$string['auto_group_form_groupslist']= 'Chọn nhóm:';
$string['auto_group_form_page_title']= 'Cài đặt tự động đăng ký';
$string['auto_group_form_rand_method']= 'Đăng ký ngẫu nhiên';
$string['auto_group_form_rolelist']= 'Chọn (các) vai trò liên quan';
$string['auto_group_form_usegroupslist']= 'Chỉ đăng ký người dùng trong các nhóm đã chọn:';
$string['coursemenu_item']= 'Tự động đăng ký vào nhóm';
$string['menu_auto_groups']= 'Tự động đăng ký vào nhóm';
$string['pluginname']= 'Đăng ký tự động theo nhóm';
$string['privacy:null_reason']= 'Không có dữ liệu người dùng nào được thu thập bởi plugin này.';
