<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_mentordatabase', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   tool_mentordatabase
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['dbencoding']= 'Mã hóa cơ sở dữ liệu';
$string['dbhost']= 'Máy chủ cơ sở dữ liệu';
$string['dbhost_desc']= 'Nhập địa chỉ IP máy chủ cơ sở dữ liệu hoặc tên máy chủ. Sử dụng tên DSN hệ thống nếu sử dụng ODBC. ';
$string['dbname']= 'Tên cơ sở dữ liệu';
$string['dbname_desc']= 'Để trống nếu sử dụng tên DSN trong máy chủ cơ sở dữ liệu.';
$string['dbpass']= 'Mật khẩu cơ sở dữ liệu';
$string['dbsetupsql']= 'Lệnh thiết lập cơ sở dữ liệu';
$string['dbsetupsql_desc']= 'Lệnh SQL để thiết lập cơ sở dữ liệu đặc biệt, thường được sử dụng để thiết lập mã hóa giao tiếp - ví dụ cho MySQL và PostgreSQL: <em> SET NAMES \' utf8 \'</em>';
$string['dbsybasequoting']= 'Sử dụng dấu ngoặc kép sybase';
$string['dbsybasequoting_desc']= 'Thoát trích dẫn đơn kiểu Sybase - cần thiết cho Oracle, MS SQL và một số cơ sở dữ liệu khác. Không sử dụng cho MySQL! ';
$string['dbtype']= 'Trình điều khiển cơ sở dữ liệu';
$string['dbtype_desc']= 'Tên trình điều khiển cơ sở dữ liệu ADOdb, loại công cụ cơ sở dữ liệu bên ngoài.';
$string['dbuser']= 'Người dùng cơ sở dữ liệu';
$string['debugdb']= 'Gỡ lỗi ADOdb';
$string['debugdb_desc']= 'Gỡ lỗi kết nối ADOdb với cơ sở dữ liệu bên ngoài - sử dụng khi nhận được trang trống trong khi đăng nhập. Không phù hợp với nơi sản xuất! ';
$string['keepmentor']= 'Giữ cố vấn';
$string['localuserfield']= 'Trường người dùng cục bộ';
$string['mentorrole']= 'Chọn vai trò để gán ở đây';
$string['mentorrole_desc']= 'Nhấp vào trình đơn thả xuống để chọn vai trò';
$string['minrecords']= 'Bản ghi tối thiểu';
$string['minrecords_desc']= 'Ngăn không cho chạy đồng bộ nếu số bản ghi được trả về trong bảng bên ngoài thấp hơn số này (giúp ngăn chặn việc xóa người dùng khi bảng bên ngoài trống).';
$string['pluginname']= 'Cơ sở dữ liệu bên ngoài cố vấn';
$string['pluginname_desc']= 'Bạn có thể sử dụng cơ sở dữ liệu bên ngoài (gần như bất kỳ loại nào) để kiểm soát người cố vấn của bạn.';
$string['privacy:metadata']= 'Plugin cơ sở dữ liệu Mentor không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['remotementoridfield']= 'Trường id cố vấn từ xa';
$string['remotementoridfield_desc']= 'Tên của trường trong bảng từ xa mà chúng tôi đang sử dụng để khớp với các mục trong bảng cố vấn.';
$string['remotementortable']= 'Bảng cố vấn người dùng từ xa';
$string['remotementortable_desc']= 'Chỉ định tên của bảng chứa danh sách cố vấn người dùng.';
$string['remoteuserfield']= 'Trường người dùng từ xa';
$string['remoteuserfield_desc']= 'Tên của trường trong bảng từ xa mà chúng tôi đang sử dụng để khớp với các mục nhập trong bảng người dùng.';
$string['removedaction']= 'Hành động xóa bên ngoài';
$string['removedaction_desc']= 'Chọn hành động để thực hiện khi người dùng biến mất khỏi nguồn cố vấn bên ngoài.';
$string['removementor']= 'Xóa người cố vấn';
$string['settings']= 'Cài đặt';
$string['settingsheaderdb']= 'Kết nối cơ sở dữ liệu bên ngoài';
$string['settingsheaderlocal']= 'Ánh xạ trường cục bộ';
$string['settingsheaderremote']= 'Đồng bộ cố vấn từ xa';
$string['sync']= 'Đồng bộ hóa trình cố vấn với cơ sở dữ liệu bên ngoài';
$string['testsettings']= 'Cài đặt kiểm tra';
$string['testsettingsheading']= 'Cài đặt kiểm tra';
