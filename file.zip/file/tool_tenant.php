<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_tenant', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_tenant
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['accent']= 'Dấu';
$string['accent_help']= 'Màu dùng để cho biết mục nào đang hoạt động trong ngăn điều hướng.';
$string['activetenants']= 'Người thuê nhà đang hoạt động';
$string['addtenant']= 'Người thuê nhà mới';
$string['adduser']= 'Người dùng mới';
$string['admin']= 'Quản trị viên';
$string['administrators']= 'Quản trị viên';
$string['advanced']= 'Nâng cao';
$string['allocateusers']= 'Phân bổ người dùng';
$string['archivedtenants']= 'Người thuê đã lưu trữ';
$string['archivetenant']= 'Người thuê lưu trữ';
$string['assigntenantadmins']= 'Chỉ định vai trò quản trị viên của Người thuê';
$string['basicinformation']= 'Thông tin cơ bản';
$string['brand']= 'Thanh điều hướng';
$string['brand_help']= 'Màu được sử dụng cho thanh điều hướng trên cùng.';
$string['button']= 'Các nút chính';
$string['button_help']= 'Màu của các nút tác vụ chính.';
$string['cachedef_mytenant']= 'Thông tin về người thuê nhà hiện tại';
$string['cachedef_tenants']= 'Danh sách người thuê';
$string['cannotarchivetenant']= 'Không thể lưu trữ đối tượng thuê mặc định.';
$string['category']= 'Hạng mục khóa học';
$string['category_help']= 'Quản trị viên người thuê sẽ tự động được chỉ định \' Quản trị viên người thuê trong danh mục khóa học \'vai trò trong danh mục khóa học này, họ sẽ có thể tạo khóa học, chỉ định vai trò, v.v.
Tất cả người dùng đối tượng thuê sẽ tự động được chỉ định vai trò \'Người dùng đối tượng \' trong danh mục này. <br> <br> Chỉ các danh mục ở cấp cao nhất mới có thể được chọn làm danh mục Đối tượng thuê. <br>
Nếu \'Danh mục mới \' được chọn, một danh mục có cùng tên với tên Người thuê sẽ được tạo. ';
$string['categorynameexist']= 'Danh mục có tên \' {$a} \'đã tồn tại ở cấp cao nhất. Vui lòng chọn danh mục này hoặc chọn một tên khác ';
$string['categorytaken']= 'Hạng mục này được chỉ định cho người thuê khác.';
$string['chooseexistingcategory']= 'Chọn một danh mục hiện có';
$string['colours']= 'Màu sắc';
$string['confirmallocateusers']= 'Bạn có chắc chắn muốn phân bổ những người dùng đã chọn cho người thuê đã chọn không?';
$string['confirmarchivetenant']= 'Bạn có chắc chắn muốn lưu trữ đối tượng thuê \' {$a} \'? Tất cả người dùng được phân bổ cho đối tượng thuê này sẽ được chuyển đến đối tượng thuê mặc định. ';
$string['confirmassigntenantadmins']= 'Bạn có chắc chắn muốn chỉ định vai trò quản trị viên của đối tượng thuê cho những người dùng đã chọn không?';
$string['confirmdeletetenant']= 'Bạn có chắc chắn muốn xóa đối tượng thuê \' {$a} \'không? Hành động này không thể được hoàn tác.';
$string['confirmdeleteuser']= 'Bạn có chắc chắn muốn xóa người dùng này không? Hành động này không thể được hoàn tác.';
$string['confirmdeleteusers']= 'Bạn có chắc chắn muốn xóa những người dùng đã chọn không? Hành động này không thể được hoàn tác.';
$string['confirmrestoretenant']= 'Bạn có chắc chắn muốn khôi phục đối tượng thuê \' {$a} \'không?';
$string['confirmsuspenduser']= 'Bạn có chắc chắn muốn tạm ngưng người dùng này không?';
$string['confirmsuspendusers']= 'Bạn có chắc chắn muốn tạm ngưng những người dùng đã chọn không?';
$string['confirmunassigntenantadmins']= 'Bạn có chắc chắn muốn bỏ gán vai trò quản trị viên của đối tượng thuê cho những người dùng đã chọn không?';
$string['confirmunsuspenduser']= 'Bạn có chắc chắn muốn hủy sử dụng người dùng này không?';
$string['confirmunsuspendusers']= 'Bạn có chắc chắn muốn hủy sử dụng những người dùng đã chọn không?';
$string['createnewcategory']= 'Tạo một danh mục mới';
$string['customcss']= 'CSS tùy chỉnh';
$string['defaultname']= 'Người thuê mặc định';
$string['deletetenant']= 'Xóa đối tượng thuê';
$string['deleteuser']= 'Xóa người dùng';
$string['deleteusers']= 'Xóa người dùng';
$string['drawer']= 'Ngăn kéo';
$string['drawer_help']= 'Màu được sử dụng cho nền ngăn điều hướng.';
$string['drawertext']= 'Văn bản ngăn kéo';
$string['drawertext_help']= 'Màu được sử dụng cho các liên kết và biểu tượng ngăn điều hướng khi không hoạt động.';
$string['editdetails']= 'Chỉnh sửa chi tiết';
$string['edittenant']= 'Chỉnh sửa đối tượng thuê \' {$a} \\';
$string['edittenantname']= 'Chỉnh sửa tên';
$string['edituser']= 'Chỉnh sửa tài khoản người dùng';
$string['edituserwithname']= 'Chỉnh sửa người dùng \' {$a} \\';
$string['enrolinseparategroups']= 'Khóa học này có thể được chia sẻ với những người thuê khác nhưng người dùng từ những người thuê khác nhau sẽ được phân bổ vào các nhóm riêng biệt';
$string['enrolwithoutgroups']= 'Người dùng từ những người thuê khác có thể đăng ký khóa học này và có thể gặp nhau vì khóa học này không ở chế độ nhóm riêng biệt';
$string['errorcannotallocate']= 'Không thể phân bổ cho người thuê nhà';
$string['errorinvalidtenant']= 'Đối tượng thuê không hợp lệ \' {$a} \\';
$string['eventtenantcreated']= 'Đã tạo người thuê';
$string['eventtenantdeleted']= 'Đã xóa người thuê';
$string['eventtenantupdated']= 'Đã cập nhật người thuê';
$string['eventtenantusercreated']= 'Người dùng được phân bổ cho người thuê nhà';
$string['eventtenantuserupdated']= 'Phân bổ người dùng cho người thuê đã được thay đổi';
$string['favicon']= 'Yêu thích';
$string['footer']= 'Chân trang';
$string['footer_help']= 'Màu được sử dụng cho nền cuối trang.';
$string['footertext']= 'Văn bản chân trang';
$string['headerlogo']= 'Biểu trưng tiêu đề';
$string['idnumber']= 'Số ID';
$string['idnumber_help']= 'Số ID của người thuê chỉ được sử dụng khi khớp với hệ thống bên ngoài hoặc trong công cụ Tải lên người dùng và không được hiển thị ở bất kỳ đâu trên trang web. Nếu người thuê có tên mã chính thức, nó có thể được nhập, nếu không trường có thể được để trống. ';
$string['images']= 'Hình ảnh';
$string['invalidcolour']= 'Mã màu này không đúng định dạng. Vui lòng sử dụng định dạng # 000 hoặc # 000000. ';
$string['loginbackground']= 'Hình nền đăng nhập';
$string['loginlogo']= 'Logo đăng nhập';
$string['loginurl']= 'URL đăng nhập';
$string['loginurl_help']= 'Các URL đã chọn sẽ được hiển thị cho quản trị viên của người thuê và họ có thể chuyển chúng cho người dùng của họ để áp dụng chủ đề của người thuê ngay từ đầu. Nếu \'ID number \' không được chỉ định, liên kết idnumber sẽ không khả dụng ngay cả khi được chọn. Lưu ý rằng trong quá trình tạo đối tượng thuê, id đối tượng thuê không có sẵn. ';
$string['management']= 'Quản lý';
$string['managetenants']= 'Quản lý người thuê nhà';
$string['managetheme']= 'Cá nhân hóa người thuê';
$string['managethemewpmenu']= 'Người thuê nhà';
$string['movebetweentenants']= 'Di chuyển giữa những người thuê nhà';
$string['movetenant']= 'Di chuyển đối tượng thuê \' {$a} \\';
$string['name']= 'Tên người thuê';
$string['newname']= 'Người thuê mới \' {$a} \\';
$string['newnamefor']= 'Tên mới cho \' {$a} \\';
$string['nocategory']= 'Không có danh mục';
$string['nomanualassignment']= 'Vai trò này không thể được chỉ định theo cách thủ công trong bất kỳ ngữ cảnh nào';
$string['notspecified']= 'Không được chỉ định';
$string['organisationadmintab']= 'Tổ chức';
$string['pluginname']= 'Cho thuê nhiều lần';
$string['primary']= 'Liên kết';
$string['primary_help']= 'Màu được sử dụng cho các liên kết và các phần tử tương tác.';
$string['privacy:metadata:user']= 'Phân bổ người dùng cho người thuê';
$string['privacy:metadata:user:component']= 'Thành phần chịu trách nhiệm phân bổ';
$string['privacy:metadata:user:id']= 'ID';
$string['privacy:metadata:user:reason']= 'Lý do phân bổ';
$string['privacy:metadata:user:tenantid']= 'Người thuê nhà';
$string['privacy:metadata:user:timecreated']= 'Thời gian được phân bổ';
$string['privacy:metadata:user:timemodified']= 'Thời gian đã sửa đổi';
$string['privacy:metadata:user:userid']= 'Người dùng';
$string['privacy:metadata:user:usermodified']= 'Người dùng đã sửa đổi bản ghi';
$string['reg_wptenants']= 'Số người thuê ({$a})';
$string['restoretenant']= 'Khôi phục người thuê';
$string['selectuser']= 'Chọn người dùng \' {$a} \\';
$string['separatetenantsingroups']= 'Trong các khóa học được chia sẻ giữa những người thuê, hãy thêm người dùng từ mỗi người thuê vào các nhóm riêng biệt';
$string['sitename']= 'Tên trang web';
$string['sitename_help']= 'Cho phép ghi đè tên mặc định của trang web cho người dùng từ đối tượng thuê này';
$string['siteshortname']= 'Tên viết tắt của trang web';
$string['siteshortname_help']= 'Cho phép ghi đè tên ngắn mặc định của trang web cho người dùng từ đối tượng thuê này';
$string['suspenduser']= 'Đình chỉ người dùng';
$string['suspendusers']= 'Tạm ngưng người dùng';
$string['tenantadmin']= 'Quản trị viên người thuê';
$string['tenantadmincapabilitieslimit']= 'Các khả năng không tương thích với Chế độ thuê nhiều lần không được liệt kê ở đây. <a href="{$a}"> Thông tin khác </a> ';
$string['tenantadmindescription']= 'Vai trò quản trị viên của người thuê nơi làm việc. Được chỉ định tự động cho quản trị viên đối tượng thuê trong ngữ cảnh hệ thống. ';
$string['tenantadministration']= 'Quản lý người thuê';
$string['tenantadministrator']= 'Người dùng này là quản trị viên đối tượng thuê';
$string['tenant:allocate']= 'Phân bổ người dùng cho tất cả người thuê';
$string['tenant:browseusers']= 'Duyệt qua người dùng trong đối tượng thuê hiện tại';
$string['tenantcategorycapabilitieslimit']= 'Chỉ những khả năng có thể được đặt trong ngữ cảnh danh mục khóa học được liệt kê ở đây';
$string['tenantdetails']= 'Chi tiết';
$string['tenantlimit']= 'Giới hạn người thuê';
$string['tenantlimit1']= '1 (Vô hiệu hóa nhiều hợp đồng thuê nhà)';
$string['tenantlimit_desc']= 'Số lượng người thuê tối đa được phép trong hệ thống, cả người thuê đang hoạt động và người thuê được lưu trữ đều được tính.';
$string['tenantlimitenabled']= 'Bật giới hạn đối tượng thuê';
$string['tenantlimitenabled_desc']= 'Nếu điều này được bật thì có thể giới hạn số lượng người thuê trên trang web này.';
$string['tenantlimitreached']= 'Đã đạt đến giới hạn số người thuê';
$string['tenantlimitreached1']= 'Tính năng cho thuê nhiều lần không được kích hoạt trên trang web này';
$string['tenantlimitreachedmult']= 'Bạn chỉ có thể tạo {$a} người thuê trên trang web này. Xin lưu ý rằng người thuê lưu trữ cũng được tính vào giới hạn này ';
$string['tenantlimitunlimited']= 'Không giới hạn';
$string['tenant:manage']= 'Quản lý việc thêm và chỉnh sửa người thuê';
$string['tenantmanager']= 'Quản trị viên người thuê trong danh mục khóa học';
$string['tenantmanagerdescription']= 'Vai trò quản trị viên của người thuê nơi làm việc thứ hai. Được chỉ định tự động cho quản trị viên đối tượng thuê trong ngữ cảnh trên danh mục khóa học của họ. ';
$string['tenant:managetheme']= 'Quản lý cài đặt chủ đề cho người thuê hiện tại';
$string['tenant:manageusers']= 'Thêm và chỉnh sửa người dùng cho người thuê hiện tại';
$string['tenantnotfound']= 'Không tìm thấy người thuê';
$string['tenants']= 'Người thuê nhà';
$string['tenantuser']= 'Người dùng thuê nhà';
$string['tenantuserdescription']= 'Vai trò người dùng của người thuê nơi làm việc. Được chỉ định tự động cho tất cả người dùng thuê trong ngữ cảnh trên danh mục khóa học của họ. ';
$string['themesettingssaved']= 'Cài đặt chủ đề đã được lưu. Có thể mất vài phút trước khi các thay đổi được hiển thị trên trang web. ';
$string['unassigntenantadmins']= 'Bỏ chỉ định vai trò quản trị viên của Người thuê nhà';
$string['unsuspenduser']= 'Người dùng không sử dụng';
$string['unsuspendusers']= 'Bỏ sử dụng người dùng';
$string['userdeletedfail']= '{$a} (các) người dùng không được tìm thấy hoặc không thể bị xóa';
$string['userdeletedsuccess']= '{$a} người dùng đã bị xóa';
$string['usermovetotenant']= '{$a->count} người dùng đã được chuyển sang đối tượng thuê: {$a->tenant}';
$string['usersassignedtenantadminfail']= 'Vai trò quản trị viên của người thuê chưa được chỉ định cho (các) người dùng {$a}';
$string['usersassignedtenantadminsuccess']= 'Vai trò quản trị viên của người thuê đã được chỉ định cho {$a} người dùng';
$string['userscount']= 'Người dùng';
$string['userssuspendedfail']= '{$a} (các) người dùng không được tìm thấy hoặc không thể bị tạm ngưng';
$string['userssuspendedsuccess']= '{$a} người dùng đã bị tạm ngưng';
$string['usersunassignedtenantadminfail']= 'Vai trò quản trị viên của đối tượng thuê không được bỏ gán từ người dùng {$a}';
$string['usersunassignedtenantadminsuccess']= 'Vai trò quản trị viên của người thuê chưa được chỉ định từ người dùng {$a}';
$string['usersunsuspendedfail']= '{$a} (các) người dùng không được tìm thấy hoặc không thể bị tạm dừng';
$string['usersunsuspendedsuccess']= '{$a} (các) người dùng chưa bị tạm dừng';
$string['usersuspendedsuccess']= 'Người dùng bị tạm ngưng thành công';
$string['userunsuspendedsuccess']= 'Đã hủy tạm dừng người dùng thành công';
$string['viewusers']= 'Quản lý đối tượng thuê \' {$a} \\';
