<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_uploadpageresults', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_uploadpageresults
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['cachedef_helper']= 'Tải lên bộ nhớ đệm của trang';
$string['columnsheader']= 'Cột';
$string['completionsadded']= 'Đã thêm hoàn thành: {$a}';
$string['completionserrors']= 'Lỗi hoàn thành: {$a}';
$string['completionsprocessed']= 'Hoàn thành được xử lý thành công';
$string['completionsskipped']= 'Hoàn thành bị bỏ qua: {$a}';
$string['completionstotal']= 'Tổng số lần hoàn thành: {$a}';
$string['confirm']= 'Xác nhận';
$string['confirmcolumnmappings']= 'Xác nhận ánh xạ cột';
$string['csvdelimiter']= 'Dấu phân cách CSV';
$string['csvdelimiter_help']= 'Dấu phân cách CSV của tệp CSV.';
$string['csvline']= 'Dòng';
$string['encoding']= 'Mã hóa';
$string['encoding_help']= 'Mã hóa tệp CSV.';
$string['id']= 'ID';
$string['import']= 'Nhập';
$string['importfile']= 'Tệp CSV';
$string['invalidcsvfile']= 'Định dạng tệp không hợp lệ.';
$string['invalidencoding']= 'Đã chỉ định mã hóa không hợp lệ';
$string['invalidfileexception']= 'Định dạng tệp không hợp lệ. {$a} ';
$string['invalidimportfile']= 'Định dạng tệp không hợp lệ.';
$string['pluginname']= 'Hoàn thành các hoạt động tải lên trang';
$string['result']= 'Kết quả';
$string['uploadpageresultsresult']= 'Tải lên kết quả';
