<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_capexplorer', language 'en', branch 'MOODLE_31_STABLE'
 *
 * @package   tool_capexplorer
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['assigned']= 'Đã chỉ định';
$string['autoassign']= 'Được chỉ định tự động';
$string['autoassignment']= 'Chuyển nhượng tự động';
$string['autoassignment_help']= 'Một số vai trò có thể được tự động gán cho người dùng trong ngữ cảnh hệ thống. Các vai trò có thể được đặt từ Quản trị trang> Người dùng> Quyền> Chính sách người dùng ';
$string['capability']= 'Khả năng';
$string['capability_help']= '<p> Chọn một khả năng để kiểm tra. </p> <p> Trường này sử dụng tính năng tự động điền, vì vậy hãy bắt đầu nhập tên của một khả năng rồi chọn từ các tùy chọn xuất hiện. </p>';
$string['capabilityplaceholder']= 'Nhập khả năng';
$string['capdenied']= 'Sai (Bị từ chối)';
$string['capexplorerresult']= 'Kết quả tổng thể';
$string['capexplorersummary']= '<p> Capability Explorer là một công cụ giúp giải thích cách hoạt động của hệ thống năng lực của Moodle. Gửi biểu mẫu bên dưới để được giải thích về cách tính kiểm tra năng lực. </p> ';
$string['capexplorer:view']= 'Xem trình khám phá khả năng';
$string['capgranted']= 'Đúng (Được cấp)';
$string['change']= 'Thay đổi';
$string['combineusingcontextaggregation']= '<p> Kết hợp các quyền riêng lẻ bằng cách sử dụng các quy tắc tổng hợp ngữ cảnh{$a} để có được một tập hợp các tổng số vai trò. </p>';
$string['context']= 'Bối cảnh';
$string['contextaggrrules']= 'Quy tắc tổng hợp ngữ cảnh';
$string['contextaggrrules_help']= '<p> Để xác định tổng số vai trò cho một vai trò cụ thể, hãy tổng hợp các quyền ở mỗi ngữ cảnh bằng cách sử dụng các quy tắc bên dưới: </p>
<ol>
<li> Nếu "Cấm" xuất hiện trong bất kỳ ngữ cảnh nào thì tổng vai trò là "Cấm". </li>
<li> Nếu tất cả các ngữ cảnh có quyền "Chưa đặt", thì tổng số vai trò là "Chưa đặt". </li>
<li> Nếu không, tổng số vai trò giống với quyền cụ thể nhất được đặt (tức là cho phép hoặc ngăn chặn điều đó gần nhất với ngữ cảnh mà khả năng đang được kiểm tra). </li>
</ol> ';
$string['context_help']= '<p> Bạn phải cung cấp một <em> trường hợp ngữ cảnh </em> để kiểm tra khả năng chống lại. Cây được hiển thị hiển thị thứ bậc của tất cả các trường hợp ngữ cảnh trên trang web của bạn. </p>
<p> Mở rộng các nút bằng cách nhấp vào mũi tên để xem các ngữ cảnh con cụ thể hơn. Chọn một phiên bản bằng cách nhấp vào tên. </p>
<p> Các biểu tượng đại diện cho <em> mức ngữ cảnh </em> của mỗi trường hợp: </p>
<p>
<div class = "capexplorer-tree-label capexplorer-tree-system"> Ngữ cảnh hệ thống (Trang web) </div>
<div class = "capexplorer-tree-label capexplorer-tree-user"> Ngữ cảnh người dùng </div>
<div class = "capexplorer-tree-label capexplorer-tree-category"> Ngữ cảnh danh mục </div>
<div class = "capexplorer-tree-label capexplorer-tree-course"> Ngữ cảnh khóa học </div>
<div class = "capexplorer-tree-label capexplorer-tree-module"> Ngữ cảnh mô-đun </div>
<div class = "capexplorer-tree-label capexplorer-tree-block"> Ngữ cảnh khối </div>
</p> ';
$string['contextinfo']= '{$a->contextstring} ({$a->contextlevel} ngữ cảnh)';
$string['contextlevel']= 'Mức ngữ cảnh';
$string['error:invalidcapability']= 'Không có khả năng nào được gọi là "{$a}"';
$string['error:invalidcontext']= 'Bạn phải chọn một trường hợp ngữ cảnh';
$string['error:invalidusername']= 'Không có người dùng nào có tên người dùng là "{$a}"';
$string['error:missingcapability']= 'Bạn phải nhập một khả năng';
$string['error:missingusername']= 'Bạn phải nhập tên người dùng';
$string['exploreanother']= '&laquo; Explore another capability';

$string['finalresultsummary']= '<p> Cuối cùng, kết hợp các tổng số vai trò bằng cách sử dụng các quy tắc tổng hợp vai trò{$a} để có được kết quả tổng thể. </p>';
$string['guestaccessblocked']= '<p> Lưu ý: Là một biện pháp an toàn bổ sung, Moodle ngăn người dùng không có đặc quyền được cấp các khả năng "rủi ro". "{$a->capability}" được coi là rủi ro vì nó có thể được sử dụng để chỉnh sửa hoặc xóa dữ liệu, sửa đổi cấu hình trang web hoặc thêm các đoạn mã độc hại tiềm ẩn vào các trang của trang web. Kết quả dưới đây cho thấy cách tính quyền truy cập của họ nếu khả năng này không được coi là rủi ro. </p> ';
$string['instancename']= 'Tên phiên bản';
$string['manualassign']= 'Được chỉ định thủ công';
$string['manualassignment']= 'Chuyển nhượng thủ công';
$string['manualassignment_help']= 'Các vai trò được chỉ định trực tiếp cho một người dùng cụ thể, ví dụ qua \' Gán các vai trò hệ thống \', hoặc thông qua đăng ký khóa học.';
$string['none']= 'Không có';
$string['nopermtoassign']= 'Không được phép';
$string['nopermtoassign_help']= '<p>Not all users have permission to assign roles to other users. The ability to assign roles is dependent on your own roles and can be controlled here:</p><p><em>Site admin &gt; Users &gt; Permissions &gt; Define roles &gt; Allow role assignments</em></p><p>In addition the user must have the capability "moodle/role:assign" in the context where the role assignment is taking place.</p><p>Site administrators can assign all roles.</p>';

$string['nopermtoautoassign']= 'Không được phép';
$string['nopermtoautoassign_help']= 'Không phải tất cả người dùng đều có quyền thay đổi các vai trò được chỉ định tự động. Khả năng thay đổi thiết lập các chính sách người dùng này được kiểm soát bởi khả năng "moodle / site: config" trong ngữ cảnh hệ thống. ';
$string['nopermtodefinerole']= 'Không được phép';
$string['nopermtodefinerole_help']= 'The ablity to define role permissions requires the capability "moodle/role:manage" in the system context. Users with permission can control role definitions here:</p><p><em>Site admin &gt; Users &gt; Permissions &gt; Define roles </p><p>The current user does not have this permission so is not able to change role definitions.</p>';

$string['nopermtooverride']= 'Không được phép';
$string['nopermtooverride_help']= 'Not all users have permission to override roles. The ability to override roles is dependent on your own roles and can be controlled here:</p><p><em>Site admin &gt; Users &gt; Permissions &gt; Define roles &gt; Allow role overrides</em></p><p>In addition the user must have the capability "moodle/role:override" or "moodle/role:safeoverride" in the context where the override is taking place.</p><p>Site administrators can override all roles.</p>';

$string['notassignable']= 'Không thể chuyển nhượng';
$string['notassignable_help']= '<p>Each role defines the context levels where the role can be assigned.</p><p>This can be customised by changing the "Context types where this role may be assigned" setting in the role definition:</p><p><em>Site admin &gt; Users &gt; Permissions &gt; Define Roles &gt; [Role name] &gt; Edit</em>.</p>';

$string['notassigned']= 'Không được chỉ định';
$string['notoverridable']= 'Không thể ghi đè';
$string['notoverridable_help']= '<p> Mỗi khả năng xác định một mức ngữ cảnh là mức thấp nhất mà ngữ cảnh sẽ được kiểm tra. Dưới mức này, khả năng ghi đè sẽ không khả dụng vì việc ghi đè sẽ không có bất kỳ tác dụng nào. </p> <p> Điều này ngăn không cho các khả năng rõ ràng không áp dụng được ở các ngữ cảnh cụ thể hơn làm lộn xộn trang ghi đè. </p> <p> Trong trường hợp này, khả năng đang được kiểm tra đã chỉ định mức ngữ cảnh cao hơn nên không thể ghi đè khả năng này ở mức này . </p> ';
$string['overallresult']= 'Kết quả tổng thể';
$string['parentcontexts']= 'Ngữ cảnh chính';
$string['parentcontexts_help']= '<p> Do tính chất phân cấp của hệ thống quyền, các nhiệm vụ ở bất kỳ ngữ cảnh mẹ nào có thể ảnh hưởng đến việc kiểm tra khả năng trong ngữ cảnh con. Do đó, bước đầu tiên là xác định tất cả các ngữ cảnh giữa cấp hệ thống và ngữ cảnh đang được kiểm tra. </p> ';
$string['parentcontextssummary']= '<p> Xác định tất cả các mức ngữ cảnh giữa mức hệ thống và ngữ cảnh đang được kiểm tra. </p>';
$string['permission']= 'Quyền';
$string['permissionallow']= 'Cho phép';
$string['permissioninherit']= 'Kế thừa';
$string['permissionnotset']= 'Chưa đặt';
$string['permissionprevent']= 'Ngăn chặn';
$string['permissionprohibit']= 'Cấm';
$string['permissionunknown']= 'Không xác định';
$string['pluginname']= 'Trình khám phá khả năng';
$string['result']= 'Kết quả';
$string['resultdiffersfromaccesslib']= '<p> Kết quả do công cụ này tính toán không khớp với kết quả từ mã lõi! </p> <p> Bạn có thể thử <a href="{$a->cacheurl}"> xóa bộ nhớ cache của mình < / a> nhưng nếu điều đó không giúp được gì thì đây có thể là một lỗi trong Capability Explorer. Vui lòng <a href="{$a->bugurl}"> cho chúng tôi biết về vấn đề này </a> và nếu bạn có thể bao gồm ảnh chụp màn hình của trang này để giúp chúng tôi tìm ra sự cố. </p> ';
$string['role']= 'Vai trò';
$string['roleaggrrules']= 'Quy tắc tổng hợp vai trò';
$string['roleaggrrules_help']= '<p> Để xác định kết quả tổng thể, hãy tổng hợp các quyền từ tất cả các tổng số vai trò bằng cách sử dụng các quy tắc bên dưới: </p>
<ol>
<li> Nếu "Cấm" xuất hiện trong tổng số vai trò, thì kết quả chung là "Bị từ chối". </li>
<li> Ngược lại, nếu tổng số một vai trò bất kỳ là "Cho phép" thì kết quả chung là "Được cấp". </li>
<li> Nếu không có tổng số vai trò nào là "Cho phép", thì kết quả chung là "Bị từ chối". </li>
</ol> ';
$string['roleassignmentsforuserx']= '<p> Dưới đây là tất cả các vai trò có nhiệm vụ cho "{$a}" trong bất kỳ ngữ cảnh nào được liệt kê ở trên: </p>';
$string['roleassignmentsummary']= '<p> Xác định vai trò nào được chỉ định cho người dùng trong bất kỳ bối cảnh chính nào. Chỉ những vai trò được chỉ định trong một trong các bối cảnh chính mới đóng góp vào kết quả cuối cùng. </p> ';
$string['rolepermissionsandoverridesforcapx']= '<p> Tất cả các quyền và ghi đè vai trò cho khả năng "{$a}" </p>';
$string['rolepermissionsummary']= '<p> Đối với mỗi vai trò được chỉ định, hãy liệt kê quyền từ định nghĩa vai trò cho ngữ cảnh hệ thống. Đồng thời liệt kê mọi ghi đè vai trò trong bất kỳ bối cảnh chính nào. </p> ';
$string['roletotal']= 'Tổng số vai trò';
$string['roletotals']= 'Tổng số vai trò';
$string['step1']= 'Bước 1: Bối cảnh chính';
$string['step2']= 'Bước 2: Phân vai';
$string['step3']= 'Bước 3: Quyền và ghi đè vai trò';
$string['step4']= 'Bước 4: Tổng hợp các ngữ cảnh';
$string['step5']= 'Bước 5: Tổng hợp các vai trò';
$string['systemcontext']= 'Bối cảnh hệ thống (trang web)';
$string['user']= 'Người dùng';
$string['usercontext']= 'Ngữ cảnh người dùng';
$string['userisadmin']= '<p> Lưu ý: "{$a->user}" là <a href="{$a->url}"> quản trị viên trang web </a> và như vậy họ sẽ tự động được cấp tất cả các khả năng. Kết quả bên dưới cho thấy cách tính quyền truy cập của họ mà không có đặc quyền của quản trị viên trang web. </p> ';
$string['username']= 'Tên người dùng';
$string['username_help']= '<p> Chọn người dùng để kiểm tra. </p> <p> Trường này sử dụng tính năng tự động điền, vì vậy hãy bắt đầu nhập tên người dùng, địa chỉ email hoặc tên người dùng và chọn từ các tùy chọn xuất hiện. </p>';
$string['usernameplaceholder']= 'Nhập tên, tên người dùng hoặc email';
$string['xfrontpage']= '{$a} (Trang đầu)';
