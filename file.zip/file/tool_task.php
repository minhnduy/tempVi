<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_task', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_task
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['adhocempty']= 'Hàng đợi nhiệm vụ đặc biệt trống';
$string['adhocqueueold']= 'Nhiệm vụ cũ nhất là {$a->age}, nhiều hơn {$a->max}';
$string['adhocqueuesize']= 'Hàng đợi nhiệm vụ đặc biệt có {$a} nhiệm vụ';
$string['asap']= 'CÀNG SỚM CÀNG TỐT';
$string['backtoscheduledtasks']= 'Quay lại nhiệm vụ đã lên lịch';
$string['blocking']= 'Chặn';
$string['cannotfindthepathtothecli']= 'Không thể tìm thấy đường dẫn đến tệp thực thi PHP CLI nên việc thực thi tác vụ bị hủy bỏ. Đặt cài đặt \'Đường dẫn đến PHP CLI \' trong Quản trị trang web / Đường dẫn máy chủ / Hệ thống. ';
$string['checkadhocqueue']= 'Hàng đợi nhiệm vụ đặc biệt';
$string['checkcronrunning']= 'Cron đang chạy';
$string['checkmaxfaildelay']= 'Độ trễ tối đa của nhiệm vụ không thành công';
$string['clearfaildelay_confirm']= 'Bạn có chắc chắn muốn xóa độ trễ thất bại cho tác vụ \' {$a} \'? Sau khi xóa độ trễ, nhiệm vụ sẽ chạy theo lịch trình bình thường của nó. ';
$string['component']= 'Thành phần';
$string['corecomponent']= 'Cốt lõi';
$string['cronok']= 'Cron đang chạy thường xuyên';
$string['default']= 'Mặc định';
$string['defaultx']= 'Mặc định: {$a}';
$string['disabled']= 'Đã tắt';
$string['disabled_help']= 'Các tác vụ đã lên lịch đã tắt không được thực thi từ cron, tuy nhiên chúng vẫn có thể được thực thi thủ công thông qua công cụ CLI.';
$string['edittaskschedule']= 'Chỉnh sửa lịch trình tác vụ: {$a}';
$string['enablerunnow']= 'Cho phép \' Chạy ngay bây giờ \'cho các tác vụ đã lên lịch';
$string['enablerunnow_desc']= 'Cho phép quản trị viên chạy một tác vụ đã lên lịch ngay lập tức, thay vì đợi nó chạy theo lịch trình. Tính năng này yêu cầu đặt \'Đường dẫn đến PHP CLI \' (pathtophp) trong Đường dẫn hệ thống. Tác vụ chạy trên máy chủ web, vì vậy bạn có thể muốn tắt tính năng này để tránh các vấn đề về hiệu suất tiềm ẩn. ';
$string['faildelay']= 'Độ trễ không thành công';
$string['fromcomponent']= 'Từ thành phần: {$a}';
$string['lastruntime']= 'Lần chạy cuối cùng';
$string['nextruntime']= 'Chạy tiếp theo';
$string['plugindisabled']= 'Đã tắt plugin';
$string['pluginname']= 'Cấu hình nhiệm vụ đã lên lịch';
$string['privacy:metadata']= 'Plugin cấu hình tác vụ đã lên lịch không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['resettasktodefaults']= 'Đặt lại lịch trình tác vụ về mặc định';
$string['resettasktodefaults_help']= 'Thao tác này sẽ loại bỏ mọi thay đổi cục bộ và hoàn nguyên lịch trình cho nhiệm vụ này về cài đặt ban đầu.';
$string['runagain']= 'Chạy lại';
$string['runnow']= 'Chạy ngay bây giờ';
$string['runnow_confirm']= 'Bạn có chắc chắn muốn chạy tác vụ này \' {$a} \'ngay bây giờ không? Nhiệm vụ sẽ chạy trên máy chủ web và có thể mất một khoảng thời gian để hoàn thành. ';
$string['runpattern']= 'Mẫu chạy';
$string['scheduledtaskchangesdisabled']= 'Các sửa đổi đối với danh sách các nhiệm vụ đã lên lịch đã bị ngăn chặn trong cấu hình Moodle';
$string['scheduledtasks']= 'Nhiệm vụ đã lên lịch';
$string['taskdisabled']= 'Đã tắt tác vụ';
$string['taskfailures']= '{$a} (các) nhiệm vụ không thành công';
$string['tasklogs']= 'Nhật ký công việc';
$string['tasknofailures']= 'Không có nhiệm vụ nào bị lỗi';
$string['taskscheduleday']= 'Ngày';
$string['taskscheduleday_help']= 'Trường ngày trong tháng cho lịch trình tác vụ. Trường sử dụng cùng một định dạng với unix cron. Một số ví dụ:
* <strong> * </strong> Mỗi ngày
* <strong> * / 2 </strong> Ngày thứ 2 hàng tuần
* <strong> 1 </strong> Ngày đầu tiên của mỗi tháng
* <strong> 1,15 </strong> Ngày đầu tiên và ngày 15 hàng tháng ';
$string['taskscheduledayofweek']= 'Ngày trong tuần';
$string['taskscheduledayofweek_help']= 'Trường ngày trong tuần cho lịch trình tác vụ. Trường sử dụng cùng một định dạng với unix cron. Một số ví dụ:
* <strong> * </strong> Mỗi ngày
* <strong> 0 </strong> Chủ nhật hàng tuần
* <strong> 6 </strong> Thứ Bảy hàng tuần
* <strong> 1,5 </strong> Thứ Hai và Thứ Sáu hàng tuần ';
$string['taskschedulehour']= 'Giờ';
$string['taskschedulehour_help']= 'Trường giờ cho lịch trình tác vụ. Trường sử dụng cùng một định dạng với unix cron. Một số ví dụ:
* <strong> * </strong> Mỗi giờ
* <strong> * / 2 </strong> 2 giờ một lần
* <strong> 2-10 </strong> Mỗi giờ từ 2 giờ sáng đến 10 giờ sáng (bao gồm cả)
* <strong> 2,6,9 </strong> 2 giờ sáng, 6 giờ sáng và 9 giờ sáng ';
$string['taskscheduleminute']= 'Phút';
$string['taskscheduleminute_help']= 'Trường phút cho lịch trình tác vụ. Trường sử dụng cùng một định dạng với unix cron. Một số ví dụ:
* <strong> * </strong> Mỗi phút
* <strong> * / 5 </strong> 5 phút một lần
* <strong> 2-10 </strong> Mỗi phút từ 2 đến 10 giờ qua (bao gồm cả)
* <strong> 2,6,9 </strong> 2, 6 và 9 phút qua giờ ';
$string['taskschedulemonth']= 'Tháng';
$string['taskschedulemonth_help']= 'Trường tháng cho lịch trình tác vụ. Trường sử dụng cùng một định dạng với unix cron. Một số ví dụ:
* <strong> * </strong> Hàng tháng
* <strong> * / 2 </strong> Mỗi tháng thứ hai
* <strong> 1 </strong> Tháng 1 hàng năm
* <strong> 1,5 </strong> Tháng 1 và tháng 5 hàng năm ';
$string['viewlogs']= 'Xem nhật ký cho {$a}';
