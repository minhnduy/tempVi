<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'userkey', language 'vi', branch 'MOODLE_39_STABLE'
 *
 * @package   userkey
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['createnewkey']= 'Tạo khóa người dùng mới';
$string['createuserkey']= 'Tạo khóa người dùng';
$string['deletekeyconfirm']= 'Bạn thật sự muốn xóa this user key?';
$string['edituserkey']= 'Chỉnh sửa khóa người dùng';
$string['keyiprestriction']= 'IP giới hạn';
$string['keyiprestriction_help']= 'Nhập một công cụ IP địa chỉ, hoặc một IP địa chỉ khoảng sẽ là IP địa chỉ được phép truy cập vào dữ liệu này. To blank to IP giới hạn hóa vô hiệu hóa (không khuyến nghị). ';
$string['keymanager']= 'Khoá quản lý';
$string['keyvaliduntil']= 'Khóa hợp lệ đến';
$string['keyvaliduntil_help']= 'Select a option date that key after it will not be valid (khuyến nghị đối với gia tăng bảo mật).';
$string['keyvalue']= 'Giá trị khóa';
$string['newuserkey']= 'Khóa người dùng mới';
$string['userkey']= 'Người dùng key';
$string['userkey_help']= 'Chọn khóa được lưu cho dữ liệu truy cập của người dùng đã được đăng ký bởi plug-in đầu ra, mà không phải đăng nhập vào Moodle. Chọn "Tạo khóa người dùng mới" để bắt đầu khóa mới khi gửi mẫu này. ';
$string['userkeys']= 'Khóa người dùng';
