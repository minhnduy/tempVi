<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_moodledt', language 'en', branch 'MOODLE_27_STABLE'
 *
 * @package   tool_moodledt
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['action_label']= 'Hành động:';
$string['bookmarks_add']= 'Thêm vào dấu trang';
$string['bookmarks_del']= 'Xóa khỏi dấu trang';
$string['bookmarks_del_all']= 'Xóa tất cả';
$string['bookmarks_empty']= 'Không có plugin lưu trong dấu trang.';
$string['bookmarks_header']= 'Dấu trang';
$string['bookmarks_header_help']= '<p> Dấu trang là để chèn các liên kết tới plugin để truy cập nhanh. </p> <p> Để chỉnh sửa dấu trang của bạn, hãy nhấp vào nút <b> Bật chỉnh sửa khối </b> để mở chế độ chỉnh sửa. </ p > ';
$string['date_modified']= 'Từ:';
$string['date_modified_help']= '<p> Chọn ngày bạn muốn lọc tệp theo sửa đổi của chúng. </p>';
$string['description_label']= 'Mô tả:';
$string['execute_button']= 'Thực hiện';
$string['files']= 'Tập tin';
$string['files_label']= 'Tệp:';
$string['files_text']= 'tập tin';
$string['index_description']= 'Công cụ này phân tích việc thiếu tệp index.html trong thư mục plugin.';
$string['index_empty']= 'Tất cả các thư mục chứa chỉ mục tệp.';
$string['index_fix']= 'Thư mục đúng';
$string['index_fix_help']= '<p> Thao tác này sẽ chèn một tệp index.php vào mỗi thư mục được chỉ định. </p> <p> <em> Cảnh báo: công cụ này không thể hoàn tác thao tác này. </em> </p>' ;
$string['index_fix_ok']= 'Chỉ mục đã được chèn vào tất cả các thư mục thành công.';
$string['index_header']= 'Chỉ mục trong thư mục';
$string['index_label']= 'Các thư mục không có chỉ mục:';
$string['index_option']= 'Chỉ mục của Thư mục';
$string['in_file_empty']= 'Tất cả các thẻ được sử dụng trong tập lệnh.';
$string['in_file_header']= 'Các thẻ không được sử dụng trong tập lệnh';
$string['in_file_text']= 'Thẻ <b> {$a} </b> không được sử dụng.';
$string['lang_default_label']= 'Mặc định:';
$string['lang_default_label_help']= '<p> Chọn ngôn ngữ mặc định sẽ là cơ sở để so sánh với các ngôn ngữ khác của plugin. </p>';
$string['language_description']= 'Công cụ này phân tích các gói ngôn ngữ để tìm kiếm sự mâu thuẫn trong các ngôn ngữ được hỗ trợ.';
$string['language_option']= 'Ngôn ngữ Analize';
$string['languages_label']= 'Ngôn ngữ:';
$string['last_mod_label']= 'Sửa lần cuối:';
$string['lines_header']= 'Các dòng trong tệp ngôn ngữ';
$string['lines_text']= 'dòng';
$string['name_label']= 'Tên:';
$string['ok_text']= 'Được';
$string['package_description']= 'Công cụ này tạo một gói với tất cả các tệp plugin được chọn. <br> Lưu ý:. Các tệp không cần thiết sẽ không được đưa vào. ';
$string['package_header']= 'Gói tập tin';
$string['package_label']= 'Gói:';
$string['package_option']= 'Gói Plugin';
$string['package_type']= 'Nén:';
$string['package_type_help']= '<p> Chọn kiểu nén để xuất gói plugin. </p> <p> Một số kiểu bảo vệ các thuộc tính của tệp. </p>';
$string['path_label']= 'Đường dẫn:';
$string['plugin_description']= '<br> Plugin này là một bộ công cụ hỗ trợ phát triển các plugin trong Moodle. <br> <br> Lưu ý: Plugin này đang trong giai đoạn phát triển beta. <br> <br>';
$string['plugin_header']= 'Trình cắm';
$string['pluginname']= 'MoodleDT - Plugin Công cụ phát triển cho Moodle';
$string['select_button']= 'Chọn';
$string['tags_empty']= 'Không còn tệp ngôn ngữ nào để so sánh.';
$string['tags_header']= 'Không tìm thấy thẻ trong tệp ngôn ngữ';
$string['tags_order']= 'Thứ tự thẻ';
$string['tags_order_help']= '<p> Thao tác này sẽ đặt tất cả các thẻ trong tệp ngôn ngữ theo thứ tự. </p> <p> <em> Xin lưu ý nếu bạn có thông tin không chuẩn khác trong tệp này có thể bị mất, nhưng nhận xét vẫn còn hàng đầu. </em> </p> ';
$string['tags_order_ok']= 'Các thẻ đã được sắp xếp thành công trong các tệp ngôn ngữ.';
$string['title_label']= 'Tiêu đề:';
$string['tool_header']= 'Công cụ';
$string['type_label']= 'Loại:';
$string['update_files_description']= 'Công cụ này tạo một gói với các tệp đã sửa đổi của plugin đã chọn. <br> Lưu ý:. Các tệp không cần thiết sẽ không được đưa vào. ';
$string['update_files_empty']= 'Không có tập tin nào được sửa đổi ngày.';
$string['update_files_header']= 'Tệp Cập nhật Gói';
$string['update_files_option']= 'Gói tệp đã thay đổi';
$string['version_label']= 'Phiên bản:';
