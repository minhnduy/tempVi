<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_uploadexternalcontentresults', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_uploadexternalcontentresults
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['cachedef_helper']= 'Tải lên bộ nhớ đệm nội dung bên ngoài';
$string['columnsheader']= 'Cột';
$string['completionsadded']= 'Đã thêm / cập nhật các hoàn thành: {$a}';
$string['completionserrors']= 'Lỗi hoàn thành: {$a}';
$string['completionsprocessed']= 'Hoàn thành được xử lý thành công';
$string['completionsskipped']= 'Hoàn thành bị bỏ qua: {$a}';
$string['completionstotal']= 'Tổng số lần hoàn thành: {$a}';
$string['confirm']= 'Xác nhận';
$string['confirmcolumnmappings']= 'Xác nhận ánh xạ cột';
$string['coursedoesnotexist']= 'Khóa học có idnumber {$a} không tồn tại.';
$string['csvdelimiter']= 'Dấu phân cách CSV';
$string['csvdelimiter_help']= 'Dấu phân cách CSV của tệp CSV.';
$string['csvline']= 'Dòng';
$string['encoding']= 'Mã hóa';
$string['encoding_help']= 'Mã hóa tệp CSV.';
$string['externalcontentdoesnotexist']= 'Nội dung bên ngoài có idnumber {$a} không tồn tại.';
$string['id']= 'ID';
$string['import']= 'Nhập';
$string['importfile']= 'Tệp CSV';
$string['invalidcsvfile']= 'Định dạng tệp không hợp lệ.';
$string['invalidencoding']= 'Đã chỉ định mã hóa không hợp lệ';
$string['invalidfileexception']= 'Định dạng tệp không hợp lệ. {$a} ';
$string['invalidimportfile']= 'Định dạng tệp không hợp lệ.';
$string['invalidimportfileheaders']= 'Tiêu đề tệp không hợp lệ. Không đủ cột, vui lòng xác minh cài đặt dấu phân cách. ';
$string['invalidimportfilenorecords']= 'Không có bản ghi nào trong tệp nhập.';
$string['invalidimportrecord']= 'Bản ghi nhập không hợp lệ.';
$string['pluginname']= 'Tải lên nội dung hoàn chỉnh bên ngoài';
$string['result']= 'Kết quả';
$string['statuscompletionadded']= 'Đã thêm / cập nhật dữ liệu hoàn thành nội dung bên ngoài.';
$string['statuscompletionskipped']= 'Đã bỏ qua hoàn thành nội dung bên ngoài.';
$string['uploadexternalcontentresultsresult']= 'Tải lên kết quả';
$string['userdoesnotexist']= 'Người dùng có tên người dùng {$a} không tồn tại.';
