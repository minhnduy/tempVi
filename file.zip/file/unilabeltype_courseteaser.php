<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'unilabeltype_courseteaser', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   unilabeltype_courseteaser
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['carousel']= 'Băng chuyền';
$string['carouselinterval']= 'Khoảng thời gian';
$string['columns']= 'Cột';
$string['columns_help']= 'Cài đặt này chỉ được sử dụng nếu bản trình bày là "băng chuyền"';
$string['courses']= 'Các khóa học';
$string['custombutton']= 'Nút tùy chỉnh';
$string['default_carouselinterval']= 'Khoảng thời gian mặc định';
$string['default_columns']= 'Các cột mặc định';
$string['default_presentation']= 'Bản trình bày mặc định';
$string['default_showintro']= 'Mặc định hiển thị văn bản unilabel';
$string['grid']= 'Lưới';
$string['nocontent']= 'Không có nội dung';
$string['pluginname']= 'Đoạn giới thiệu khóa học';
$string['pluginname_help']= 'Loại nội dung này hiển thị cho bạn hình ảnh và / hoặc tiêu đề của các khóa học đã chọn. Phần tử được hiển thị là một nút bấm lớn đưa người dùng đến khóa học liên quan. ';
$string['presentation']= 'Trình bày';
$string['privacy:metadata']= 'Loại unilabel Đoạn giới thiệu khóa học không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['showunilabeltext']= 'Hiển thị văn bản đơn nhãn';
