<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_wincache', language 'en', branch 'MOODLE_30_STABLE'
 *
 * @package   tool_wincache
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['add_time']= 'Thêm thời gian';
$string['add_time_desc']= 'Cho biết tổng thời gian tính bằng giây mà tệp đã ở trong bộ nhớ cache';
$string['app_pool_id']= 'ID nhóm ứng dụng';
$string['available_memory']= 'Bộ nhớ khả dụng';
$string['cached_entries']= 'Mục nhập được lưu trong bộ nhớ cache';
$string['cached_files']= 'Tệp được lưu trong bộ nhớ cache';
$string['cache_scope']= 'Phạm vi bộ nhớ cache';
$string['cache_settings']= 'Cài đặt bộ nhớ cache';
$string['cache_uptime']= 'Thời gian hoạt động của bộ nhớ cache';
$string['class_count']= 'Số lớp';
$string['class_count_desc']= 'Số lớp PHP trong tệp';
$string['disabled']= 'bị vô hiệu hóa';
$string['doc_root']= 'Gốc tài liệu';
$string['enabled']= 'đã bật';
$string['enable_gd_lib']= 'Bật thư viện GD (<em> php_gd2.dll </em>) để xem các biểu đồ.';
$string['fcache_chart']= 'Bộ nhớ cache tệp';
$string['fcache_entries']= 'Các mục vào bộ nhớ cache của tệp';
$string['fcache_overview']= 'Tổng quan về bộ nhớ cache của tệp';
$string['fcache_title']= 'Bộ nhớ cache hệ thống tệp';
$string['fcgi_impersonation']= 'Mạo danh FastCGI';
$string['file_name']= 'Tên tệp';
$string['file_name_desc']= 'Tên của tập tin';
$string['file_size']= 'Kích thước tệp';
$string['file_size_desc']= 'Kích thước của tệp tính bằng KB';
$string['free_memory']= 'Bộ nhớ trống';
$string['function_count']= 'Hàm đếm';
$string['function_count_desc']= 'Số lượng hàm PHP trong tệp';
$string['general_info']= 'Thông tin chung';
$string['global']= 'toàn cầu';
$string['hit_count']= 'Lượt truy cập';
$string['hit_count_desc']= 'Số lần bộ nhớ cache đã bị tấn công';
$string['hitmiss_chart_default']= 'Lượt truy cập & Bỏ lỡ (tính bằng%)';
$string['hitmiss_chart_desc']= 'biểu đồ phần trăm trúng và bỏ lỡ';
$string['hitmiss_chart_title']= '{$a} Lượt xem & Bỏ lỡ (tính theo%)';
$string['hits']= 'Lượt truy cập';
$string['host_name']= 'Tên máy chủ';
$string['hours']= '{$a} giờ';
$string['key']= 'Chìa khóa';
$string['key_name']= 'Tên khóa';
$string['key_name_desc']= 'Tên khóa đối tượng';
$string['key_nonexistent']= 'Biến có khóa này không tồn tại trong bộ nhớ cache của người dùng.';
$string['last_check']= 'Kiểm tra lần cuối';
$string['last_check_desc']= 'Cho biết tổng thời gian tính bằng giây đã trôi qua kể từ khi tệp được kiểm tra lần cuối để thay đổi tệp';
$string['local']= 'địa phương';
$string['machine_name']= 'Tên máy';
$string['memory_chart_default']= 'Bộ nhớ trống & đã sử dụng (tính theo%)';
$string['memory_chart_desc']= 'biểu đồ phần trăm sử dụng bộ nhớ';
$string['memory_chart_title']= 'Mức sử dụng bộ nhớ của {$a} (tính bằng%)';
$string['memory_overhead']= 'Chi phí bộ nhớ';
$string['minutes']= '{$a} phút';
$string['misses']= 'Hoa hậu';
$string['not_available']= 'Không có sẵn';
$string['not_defined']= 'Không xác định';
$string['not_loaded']= 'Phần mở rộng WinCache PHP không được tải hoặc phiên bản nhỏ hơn 1.1.0!';
$string['not_set']= 'Chưa đặt';
$string['num_of_classes']= 'Số lớp';
$string['num_of_functions']= 'Số chức năng';
$string['ocache_chart']= 'Bộ nhớ đệm Opcode';
$string['ocache_entries']= 'Mục nhập bộ nhớ cache Opcode';
$string['ocache_overview']= 'Tổng quan về bộ nhớ đệm Opcode';
$string['ocache_size_increased']= 'Kích thước bộ nhớ cache opcode đã được tự động tăng lên lớn hơn ít nhất 3 lần so với kích thước bộ nhớ cache của tệp.';
$string['ocache_title']= 'Bộ nhớ đệm Opcode';
$string['operating_sys']= 'Hệ điều hành';
$string['page_title']= 'Phần mở rộng Bộ nhớ cache của Windows cho PHP - Thống kê';
$string['phprc']= 'PHPRC';
$string['php_version']= 'Phiên bản PHP';
$string['pluginname']= 'Thông tin WinCache';
$string['processor_info']= 'Thông tin bộ xử lý';
$string['processor_num']= 'Số lượng bộ xử lý';
$string['rcache_entries']= 'Giải quyết các mục nhập bộ nhớ cache đường dẫn';
$string['rcache_overview']= 'Giải quyết Tổng quan về Bộ nhớ đệm Đường dẫn';
$string['rcache_title']= 'Giải quyết bộ nhớ cache đường dẫn';
$string['resolve_path']= 'Giải quyết đường dẫn';
$string['scache_chart']= 'Bộ nhớ cache phiên';
$string['scache_entries']= 'Các mục nhập trong bộ đệm phiên';
$string['scache_overview']= 'Tổng quan về bộ nhớ cache của phiên';
$string['scache_title']= 'Bộ nhớ cache phiên';
$string['scache_unavailable']= 'Bộ nhớ cache của phiên không được kích hoạt. Để bật bộ đệm phiên, hãy đặt trình xử lý phiên trong <strong> php.ini </strong> thành <strong> wincache </strong>, ví dụ: <strong> session.save_handler = wincache </strong>. ';
$string['seconds']= '{$a} giây';
$string['server_software']= 'Phần mềm máy chủ';
$string['session_handler']= 'Trình xử lý phiên PHP';
$string['show_all_entries']= 'Hiển thị tất cả các mục nhập';
$string['site_id']= 'ID trang web';
$string['size']= 'Kích thước';
$string['subkey_data']= 'Dữ liệu khóa con';
$string['summery_title']= 'Tóm tắt';
$string['total_age']= 'Tổng số tuổi';
$string['total_age_desc']= 'Tổng thời gian tính bằng giây đã trôi qua kể từ khi đối tượng được thêm vào bộ nhớ đệm';
$string['total_age_sec']= 'Tổng số tuổi (tính bằng giây)';
$string['total_file_size']= 'Tổng kích thước tệp';
$string['total_memory']= 'Tổng bộ nhớ';
$string['total_ttl']= 'Tổng TTL';
$string['total_ttl_desc']= 'Tổng thời gian tính bằng giây cho đến khi đối tượng được xóa khỏi bộ nhớ cache';
$string['total_ttl_sec']= 'Tổng thời gian sống (tính bằng giây)';
$string['ucache_chart']= 'Bộ nhớ đệm người dùng';
$string['ucache_content']= 'Nội dung mục nhập bộ nhớ đệm của người dùng';
$string['ucache_entries']= 'Mục nhập bộ nhớ cache của người dùng';
$string['ucache_entry_info']= 'Thông tin mục nhập bộ nhớ cache của người dùng';
$string['ucache_overview']= 'Tổng quan về bộ nhớ cache của người dùng';
$string['ucache_title']= 'Bộ nhớ đệm người dùng';
$string['ucache_unavailable']= 'Bộ nhớ cache của người dùng không khả dụng. Bật bộ nhớ cache của người dùng bằng cách sử dụng lệnh <strong> wincache.ucenabled </strong> trong tệp <strong> php.ini </strong>. ';
$string['unknown']= 'Không xác định';
$string['used_memory']= 'Bộ nhớ đã sử dụng';
$string['use_time']= 'Sử dụng thời gian';
$string['use_time_desc']= 'Tổng lượng thời gian tính bằng giây đã trôi qua kể từ khi tệp được sử dụng lần cuối';
$string['value_size']= 'Kích thước giá trị';
$string['value_size_desc']= 'Kích thước của đối tượng được lưu trữ';
$string['value_type']= 'Kiểu giá trị';
$string['value_type_desc']= 'Loại đối tượng được lưu trữ';
$string['wincache_version']= 'Phiên bản WinCache';
