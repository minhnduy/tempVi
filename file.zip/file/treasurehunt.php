<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'treasurehunt', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   treasurehunt
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['activitytoend']= 'Hoàn thành hoạt động đã chọn trước đó';
$string['activitytoend_help']= 'Hoạt động đã chọn phải được hoàn thành trước khi đầu mối hiện tại được hiển thị.
Để các hoạt động của khóa học được hiển thị trong danh sách, nó phải được kích hoạt hoạt động hoàn thành trong
Cấu hình của Moodle, trong khóa học và chính hoạt động. ';
$string['activitytoendovercome']= 'Hoạt động \' <strong> {$a} </strong> \'vượt qua';
$string['activitytoendwarning']= 'Trước tiên bạn phải hoàn thành hoạt động cần giải quyết';
$string['actnotavailableyet']= 'Hoạt động vẫn chưa có sẵn';
$string['add']= 'Thêm';
$string['addingroad']= 'Thêm đường';
$string['addingstage']= 'Đang thêm giai đoạn';
$string['addroad_tour']= 'Thêm một hoặc nhiều con đường mà học sinh của bạn theo dõi.';
$string['addsimplequestion']= 'Thêm câu hỏi đơn giản';
$string['addsimplequestion_help']= 'Thêm một câu hỏi đơn giản trước khi hiển thị manh mối của giai đoạn này';
$string['addstage_tour']= 'Mỗi con đường phải có hai hoặc nhiều chặng. Mỗi giai đoạn cung cấp một manh mối để tìm ra tiếp theo. ';
$string['aerialmap']= 'Trên không';
$string['aerialview']= 'Trên không';
$string['allowattemptsfromdate']= 'Cho phép các lần thử từ';
$string['allowattemptsfromdate_help']= 'Nếu được bật, học sinh sẽ không thể chơi trước ngày này.
Nếu bị vô hiệu hóa, học sinh sẽ có thể bắt đầu chơi ngay lập tức. ';
$string['alwaysshowdescription']= 'Luôn hiển thị mô tả';
$string['alwaysshowdescription_help']= 'Nếu bị tắt, Mô tả truy tìm kho báu ở trên sẽ chỉ hiển thị với học sinh
tại ngày "Cho phép lần thử từ". ';
$string['answerwarning']= 'Trước tiên bạn phải trả lời câu hỏi';
$string['areyousure']= 'Bạn có chắc không?';
$string['attempt']= 'Cố gắng';
$string['attempthistory']= 'Cố gắng lịch sử {$a}';
$string['attemptsdeleted']= 'Đã xóa nỗ lực truy tìm kho báu';
$string['autolocate_tour']= 'Hiển thị <b> vị trí hiện tại </b> của bạn. <br> (cấp quyền sử dụng "vị trí" khi được yêu cầu)';
$string['availability']= 'Tính khả dụng';
$string['availableplayerstyles']= 'Các kiểu màn hình trò chơi có sẵn.';
$string['back']= 'Quay lại';
$string['backtocourse']= 'Quay lại khóa học';
$string['basemaps']= 'Bản đồ cơ sở';
$string['bigbutton_play_tour']= 'Đây là người bạn tốt nhất của bạn. <br> Một cú nhấp chuột và bạn được hiển thị <b> thử thách </b> hoặc <b> gợi ý </b> có giá trị.';
$string['browsemode']= 'Duyệt qua';
$string['cancel']= 'Hủy bỏ';
$string['changecamera']= 'Thay đổi máy ảnh';
$string['changetogroupmode']= 'Chế độ chơi đã thay đổi để chơi theo nhóm';
$string['changetoindividualmode']= 'Chế độ trò chơi đã thay đổi thành chơi cá nhân';
$string['changetoplaywithmove']= 'Chế độ trò chơi đã thay đổi thành chơi động';
$string['changetoplaywithoutmoving']= 'Chế độ trò chơi đã chuyển sang chơi tĩnh';
$string['cleartreasurehunt']= 'Đặt lại Truy tìm Kho báu';
$string['cleartreasurehuntconfirm']= 'Hãy coi chừng hành động này. Tất cả hoạt động được ghi lại sẽ bị xóa nếu bạn tiếp tục. Thông thường, hành động này chỉ cần thiết nếu bạn cần thay đổi số đường hoặc giai đoạn nhưng hoạt động bị chặn vì ai đó đã bắt đầu chơi trò chơi. ';
$string['cleartreasurehunt_done']= 'Hoạt động đã được đặt lại. Tất cả hoạt động của những người tham gia đã bị xóa. ';
$string['clue']= 'Đầu mối';
$string['completionfinish']= 'Yêu cầu hoàn thành đường.';
$string['completionfinish_help']= 'Hoàn thành khi người dùng vượt qua tất cả các giai đoạn trên một con đường.';
$string['configintro']= 'Các giá trị bạn đặt ở đây xác định các giá trị mặc định được sử dụng trong biểu mẫu cài đặt khi bạn
tạo một cuộc truy tìm kho báu mới. ';
$string['configmaximumgrade']= 'Cấp độ mặc định mà cấp độ truy tìm kho báu được thay đổi tỷ lệ.';
$string['confirm']= 'Xác nhận';
$string['confirmdeletestage']= 'Giai đoạn đã được xóa thành công';
$string['continue']= 'Tiếp tục';
$string['correctanswer']= 'Câu trả lời đúng.';
$string['customlayername']= 'Tiêu đề lớp';
$string['customlayername_help']= 'Nếu bạn sử dụng lớp tùy chỉnh, cần có tiêu đề để hiển thị nó trong bản đồ hoặc người dùng của bạn. Nếu tiêu đề trống, lớp tùy chỉnh bị vô hiệu hóa hoàn toàn. ';
$string['customlayertype']= 'Loại lớp';
$string['customlayertype_help']= 'Lớp có thể là lớp duy nhất được nhìn thấy trong nền hoặc có thể được xếp lớp trên các bản đồ cơ sở tiêu chuẩn.';
$string['customlayerwms']= 'Dịch vụ WMS';
$string['customlayerwms_help']= 'Sử dụng lớp bản đồ từ dịch vụ OGC WMS. (Ví dụ: Hệ sinh thái rừng EUNIS WMS có thể được định cấu hình bằng: WMS: <code style = "flow-wrap: break-word; word-wrap: break-word; "> http://bio.discomap.eea.europa.eu / arcgis / services / Ecosystem / Ecosystems / MapServer / WMSServer </code> PARAMS: <code> LAYERS = 4 </code>) ';
$string['custommapbaselayer']= 'Hình ảnh được hiển thị dưới dạng tùy chọn nền bản đồ BỔ SUNG';
$string['custommapimagefile']= 'Hình ảnh tùy chỉnh cho bản đồ';
$string['custommapimagefile_help']= 'Tải lên hình ảnh đủ độ phân giải và điền vào 4 trường tiếp theo với tọa độ hình chiếu trên mặt đất';
$string['custommapmaxlat']= 'Vĩ độ Bắc';
$string['custommapmaxlat_help']= 'Vĩ độ Bắc của hình ảnh. Sử dụng "." dưới dạng dấu thập phân. Thấp hơn 85 độ và lớn hơn vĩ độ nam. ';
$string['custommapmaxlon']= 'Kinh độ Đông';
$string['custommapmaxlon_help']= 'Kinh độ Đông của hình ảnh. Sử dụng "." dưới dạng dấu thập phân. Nhỏ hơn 180 độ và lớn hơn kinh độ Tây. ';
$string['custommapminlat']= 'Vĩ độ Nam';
$string['custommapminlat_help']= 'Vĩ độ Nam của hình ảnh. Sử dụng "." dưới dạng dấu thập phân. Lớn hơn -85 độ và thấp hơn vĩ độ bắc. ';
$string['custommapminlon']= 'Kinh độ Tây';
$string['custommapminlon_help']= 'Kinh độ Tây của hình ảnh. Sử dụng "." dưới dạng dấu thập phân. Lớn hơn -180 độ và thấp hơn kinh độ Đông. ';
$string['custommapnongeographic']= 'Hình ảnh không phải là địa lý';
$string['custommaponlybaselayer']= 'Hình ảnh được hiển thị dưới dạng tùy chọn nền bản đồ DUY NHẤT';
$string['custommapoverlaylayer']= 'Hình ảnh được hiển thị trên bản đồ tiêu chuẩn';
$string['custommapping']= 'Bản đồ tùy chỉnh';
$string['customwmsparams']= 'Thông số WMS';
$string['customwmsparams_help']= 'Những thông số này xác định giao diện của bản đồ. Định dạng tuân theo định dạng sau: "LAYERS = background, street & STYLES = blue, default" (Ví dụ: Hệ sinh thái rừng EUNIS WMS có thể được định cấu hình bằng: WMS: <code style = "tràn-wrap: break-word; word-wrap: break -word; "> http://bio.discomap.eea.europa.eu/arcgis/services/Ecosystem/Ecosystems/MapServer/WMSServer </code> THÔNG SỐ: <code> LAYERS = 4 </code>) ';
$string['cutoffdate']= 'Ngày khóa sổ';
$string['cutoffdatefromdatevalidation']= 'Ngày giới hạn phải sau ngày cho phép gửi.';
$string['cutoffdate_help']= 'Nếu được đặt, cuộc truy tìm kho báu sẽ không chấp nhận những lần thử sau ngày này mà không được gia hạn.';
$string['defaultplayerstyle']= 'Kiểu màn hình trò chơi mặc định';
$string['discoveredlocation']= 'Vị trí được khám phá';
$string['donetutorial']= 'Kết thúc';
$string['drawmode']= 'Vẽ';
$string['editactivity_help']= 'Bạn có thể tìm thấy hướng dẫn từng bước về cách tạo hoạt động tìm kiếm kho báu tại <a href="http://juacas.github.io/moodle-mod_treasurehunt/create_activity.html"> trang này. </a>';
$string['editend_tour']= 'Thích tạo các trò chơi thú vị cho học sinh của bạn!';
$string['editingroad']= 'Chỉnh sửa đường';
$string['editingstage']= 'Giai đoạn chỉnh sửa';
$string['editingtreasurehunt']= 'Chỉnh sửa truy tìm kho báu';
$string['edition']= 'Bảng điều khiển phiên bản';
$string['edition_help']= 'Để cho phép tạo hình học và các nút trong bảng điều khiển ấn bản, bạn phải chọn vùng bạn muốn chỉnh sửa';
$string['editmode']= 'Chỉnh sửa';
$string['editroad']= 'Chỉnh sửa đường';
$string['editstage']= 'Chỉnh sửa giai đoạn';
$string['edittreasurehunt']= 'Thay đổi đường và chặng';
$string['errcorrectanswers']= 'Bạn phải chọn một câu trả lời đúng';
$string['errcorrectsetanswerblank']= 'Câu trả lời đúng được thiết lập, nhưng câu trả lời trống';
$string['erremptystage']= 'Tất cả các giai đoạn phải có ít nhất một hình dạng để con đường là hợp lệ';
$string['errnocorrectanswers']= 'Chỉ có một câu trả lời đúng';
$string['errnumeric']= 'Bạn phải nhập một số thập phân hợp lệ';
$string['error']= 'Lỗi';
$string['errpenalizationexceed']= 'Hình phạt không được lớn hơn 100';
$string['errpenalizationfall']= 'Hình phạt không được nhỏ hơn 0';
$string['errsendinganswer']= 'Đường đã được cập nhật trong khi bạn gửi câu trả lời, hãy thử lại';
$string['errsendinglocation']= 'Đường đã được cập nhật khi bạn đang gửi vị trí, hãy thử lại';
$string['errvalidroad']= 'Phải có ít nhất hai giai đoạn có ít nhất một hình học để con đường có giá trị';
$string['eventattemptsubmitted']= 'Đã thử gửi';
$string['eventattemptsucceded']= 'Giai đoạn đã qua';
$string['eventhuntsucceded']= 'Truy tìm kho quỹ đã hoàn thành thành công';
$string['eventplayerentered']= 'Trình phát đã bắt đầu';
$string['eventroadcreated']= 'Đường được tạo';
$string['eventroaddeleted']= 'Đường đã bị xóa';
$string['eventroadupdated']= 'Đã cập nhật đường';
$string['eventstagecreated']= 'Giai đoạn được tạo';
$string['eventstagedeleted']= 'Giai đoạn bị xóa';
$string['eventstageupdated']= 'Giai đoạn được cập nhật';
$string['exit']= 'Quay lại khóa học';
$string['failedlocation']= 'Vị trí không thành công';
$string['faillocation']= 'Nó không phải là nơi thích hợp';
$string['findplace']= 'Tìm một địa điểm';
$string['gamemodeinfo']= 'Chế độ trò chơi: {$a}';
$string['gameupdatetime']= 'Thời gian cập nhật trò chơi';
$string['gameupdatetime_help']= 'Khoảng thời gian tính bằng giây giữa bản cập nhật trò chơi của người dùng và bản cập nhật khác.
Các yêu cầu cập nhật lớn hơn, ít hơn sẽ được thực hiện, nhưng sẽ có nhiều thời gian hơn để báo cáo một thay đổi có thể xảy ra.
Nó phải lớn hơn 0 giây, nhưng thời gian sẽ được đặt theo mặc định. ';
$string['geolocation_needed']= 'Để chơi trò chơi này, vị trí địa lý của bạn là cần thiết.
<p> Để kích hoạt nó, hãy đi tới Cài đặt trình duyệt của bạn-> Cài đặt trang web-> Vị trí và loại bỏ trục xuất đối với trang web này.
<p> Vui lòng tải lại trang này và trả lời "CÓ" khi trình duyệt của bạn hỏi bạn có muốn chia sẻ vị trí của mình không.
<p> Để sử dụng GPS để định vị thiết bị này trong Treasurehunt, máy chủ phải được truy cập bằng các URL HTTPS an toàn.
Trong trường hợp khác, chỉ có thể sử dụng chế độ "Chơi mà không di chuyển" và người chơi cần chỉ tay theo từng giai đoạn trên bản đồ.
Vui lòng liên hệ với quản trị viên của bạn nếu bạn không thể giải quyết vấn đề này. ';
$string['geolocation_needed_title']= 'Ứng dụng này cần định vị địa lý.';
$string['grade_explaination_fromabsolutetime']= '{$a->rawscore}-{$a->penalization}%: Bạn đã kết thúc cuộc săn ở {$a->yourtime}. Thời điểm tốt nhất là at{$a->besttime}. Bạn phạt {$a->penalization}% do {$a->nolocationsfailed} sai chỗ và {$a->noanswersfailed} câu trả lời sai. ';
$string['grade_explaination_fromposition']= '{$a->rawscore}-{$a->penalization}%: Bạn đã phát hiện ra {$a->nosuccessfulstages} các giai đoạn ở vị trí ec33d9d3d395-4e559bbda9d395e-989bbda9d395. Bạn phạt {$a->penalization}% do {$a->nolocationsfailed} câu trả lời sai và {$a->noanswersfailed} câu trả lời sai. ';
$string['grade_explaination_fromstages']= '{$a->rawscore}-{$a->penalization}%: Bạn đã phát hiện ra {$a->nosuccessfulstages} trong số 5c3c3c05d-72fe1b3c5c05d-72fe3c3ce05d-72fe3c5c5cf9 Bạn phạt {$a->penalization}% do {$a->nolocationsfailed} câu trả lời sai và {$a->noanswersfailed} câu trả lời sai. ';
$string['grade_explaination_fromtime']= '{$a->rawscore}-{$a->penalization}%: Bạn cần {$a->yourtime} để hoàn thành cuộc săn. Thời điểm tốt nhất là {$a->besttime}. Bạn phạt {$a->penalization}% do {$a->nolocationsfailed} câu trả lời sai và {$a->noanswersfailed} câu trả lời sai. ';
$string['grade_explaination_temporary']= 'Cuộc săn chưa hoàn thành, nhận 50% điểm số từ các giai đoạn: {$a->rawscore}-{$a->penalization}%: Bạn đã phát hiện ra {$a->nosuccessfulstages}a trong tổng số 999c57e736c -4042-9e1d-5bcb3829e99b giai đoạn. Bạn phạt {$a->penalization}% do {$a->nolocationsfailed} câu trả lời sai và {$a->noanswersfailed} câu trả lời sai.
$string['gradefromabsolutetime']= 'Xếp hạng từ thời gian của cuộc săn lùng';
$string['gradefromposition']= 'Hạng từ vị trí';
$string['gradefromstages']= 'Xếp hạng từ các giai đoạn';
$string['gradefromtime']= 'Xếp hạng tính từ thời điểm kết thúc';
$string['grademethod']= 'Phương pháp chấm điểm';
$string['grademethod_help']= '<P> <B> Xếp hạng từ các giai đoạn </B> <P>
<UL>
<P> Mỗi người chơi (hoặc đội) điểm số tương ứng với số màn đã giải quyết,
100% khi một con đường được giải quyết hoàn toàn và 0% khi không có bước nào được giải quyết. </UL>
<P> <B> Xếp hạng theo thời gian của cuộc săn </B> <P>
<UL>
<P> Người đi săn kết thúc con đường trong thời gian ngắn hơn sẽ thắng cuộc đi săn và đánh dấu thời điểm tốt nhất.
Thời gian được đo từ thời điểm mở khóa đoạn đường bắt đầu.
Điều này có nghĩa là những người tham gia có thể chơi ở những thời điểm khác nhau.
Điểm được tính bằng cách nội suy thời gian kết thúc là 50% thời gian kết thúc cuộc săn
và 100% thời gian hoàn thiện tốt nhất. Những người chơi đã không hoàn thành
săn sẽ nhận được điểm dưới 50 tính theo số màn đã giải. </UL>
<P> <B> Lớp từ thời điểm hoàn thiện </B> <P>
<UL>
<P> Người đi săn kết thúc trước là người chiến thắng cuộc đi săn.
Người ta cho rằng mọi thợ săn đều chơi đồng thời.
Điểm được tính bằng cách nội suy thời gian kết thúc là 50% thời gian kết thúc cuộc săn
và 100% thời gian hoàn thiện tốt nhất. Những người chơi đã không hoàn thành
săn sẽ nhận được điểm dưới 50 tính theo số màn đã giải. </UL>
<P> <B> Xếp loại từ vị trí </B> <P>
<UL>
<P> Điểm được tính bằng cách nội suy vị trí trong bảng xếp hạng,
là 100% điểm cho người chơi đầu tiên và 50% cho người chơi cuối cùng.
Những người chơi không hoàn thành cuộc săn sẽ nhận được điểm tính toán dưới 50%
chỉ bằng số giai đoạn được giải quyết. </UL> ';
$string['grademethodinfo']= 'Phương pháp chấm điểm: {$a->type}. Vị trí phạt: {$a->gradepenlocation}%. Đáp án phạt: {$a->gradepenanswer}% ';
$string['gradepenanswer']= 'Hình phạt khi trả lời không thành công';
$string['gradepenlocation']= 'Hình phạt cho lỗi ở vị trí';
$string['gradepenlocation_help']= 'Mức phạt được biểu thị bằng% của lớp.
Ví dụ, nếu mức phạt là 5,4, người chơi có 3 lần không thành công sẽ bị phạt
điểm của anh ta tăng 16,2%, tức là sẽ nhận được 83,8% điểm tính theo các tiêu chí còn lại. ';
$string['gradesdeleted']= 'Đã xóa điểm truy tìm kho báu';
$string['gradingsummary']= 'Tóm tắt chấm điểm';
$string['group']= 'Nhóm';
$string['groupactivityovercome']= 'Hoạt động cho giai đoạn {$a->position} đã hoàn tất thành công trước {$a->user} {$a->date}';
$string['groupid']= 'Nhóm được chỉ định cho đường';
$string['groupid_help']= 'Người dùng trong nhóm này được chỉ định đến con đường này khi trò chơi bắt đầu.
Nếu chỉ có một con đường và tùy chọn đã chọn là "không có", tất cả những người tham gia hoạt động sẽ chơi vì nó ';
$string['groupingid']= 'Nhóm được chỉ định cho đường';
$string['groupingid_help']= 'Các nhóm trong nhóm này được chỉ định đến con đường này khi trò chơi bắt đầu';
$string['groupinvalidroad']= '{$a} đã chỉ định một đường không hợp lệ.';
$string['grouplocationfailed']= '<b> Không thành công "giai đoạn {$a->position}" vị trí </b> bởi {$a->user} trong tổng số {$a->date}';
$string['grouplocationovercome']= '<b> Vị trí {$a->position} thành công </b> bởi {$a->user} {$a->date}';
$string['groupmode']= 'Học sinh chơi theo nhóm';
$string['groupmode_help']= 'Nếu được kích hoạt, sinh viên sẽ được chia thành các nhóm dựa trên cấu hình của các nhóm khóa học.
Mọi thành viên trong nhóm đều có thể giải quyết giai đoạn hiện tại và tiến độ là chung cho mọi đối tác. <br/>
Điều này cho phép "song song hóa" cuộc săn và bao phủ nhiều lãnh thổ hơn. Những người tham gia xem cùng một thông tin nhưng theo định hướng nhóm. ';
$string['groupmultipleroads']= '{$a} có nhiều đường được chỉ định.';
$string['groupquestionfailed']= '<b> Câu trả lời không thành công {$a->position} </b> bởi {$a->user} {$a->date}';
$string['groupquestionovercome']= '<b> Giai đoạn thành công {$a->position} answer </b> bởi {$a->user} {$a->date}';
$string['groups']= 'Nhóm';
$string['groupstageovercome']= '<b> Giai đoạn {$a->position} vượt qua </b> bởi {$a->user} {$a->date}';
$string['hello']= 'Xin chào';
$string['history']= 'Lịch sử';
$string['huntcompleted']= 'Bạn đã hoàn thành cuộc truy tìm kho báu này';
$string['incorrectanswer']= 'Câu trả lời không chính xác.';
$string['info']= 'Thông tin';
$string['infovalidatelocation']= 'Xác thực vị trí của giai đoạn này';
$string['invalidassignedroad']= 'Đường được giao không được xác thực';
$string['invalroadid']= 'Con đường không được xác nhận';
$string['lastsuccessfulstage_tour']= 'Trong bảng điều khiển này, bạn có thể tìm ra giai đoạn thành công cuối cùng của mình. Nó có thể là của bạn trong giai đoạn thành công của nhóm bạn. ';
$string['layers']= 'Lớp';
$string['loading']= 'Đang tải';
$string['lockedaclue']= 'Bạn phải thực hiện hoạt động \' <strong> {$a} </strong> \'để mở ra manh mối';
$string['lockedaqclue']= 'Bạn phải thực hiện hoạt động \' <strong> {$a} </strong> \'và trả lời chính xác câu sau
câu hỏi để mở đầu mối ';
$string['lockedclue']= 'Đầu mối bị khóa';
$string['lockedqclue']= 'Bạn phải trả lời đúng câu hỏi sau để mở ra manh mối';
$string['locktimeediting']= 'Khóa thời gian chỉnh sửa';
$string['locktimeediting_help']= 'Thời gian tính bằng giây mà người dùng có thể chỉnh sửa một phiên bản mà không cần gia hạn khóa.
Càng lớn, càng ít yêu cầu khóa gia hạn phải được thực hiện, nhưng sẽ có nhiều thời gian hơn để khóa trang chỉnh sửa sau khi người dùng hoàn thành.
Nó phải lớn hơn 5 giây, nhưng thời gian sẽ được đặt theo mặc định. ';
$string['mapplay_tour']= '<b> Bản đồ </b> cho bạn thấy tất cả các nỗ lực của bạn! <br> Những nỗ lực thành công: <img src = "pix / success_mark.png" width = "28" /> <br> Những nỗ lực không thành công: <img src = "pix / fail_mark.png" width = "28" /> ';
$string['map_tour']= 'Trong bản đồ này, bạn có thể quản lý tất cả các thành phần của một trò chơi định vị địa lý vui nhộn!';
$string['mapview']= 'Chế độ xem bản đồ';
$string['modify']= 'Sửa đổi';
$string['modulename']= 'Truy tìm kho báu';
$string['modulename_help']= 'Mô-đun này sẽ được sử dụng để thực hiện định vị địa lý hoạt động.
Rượt đuổi kho báu ngoài trời, trong nhà và trên bản đồ ảo với định vị địa lý và mã QR.
Mô-đun này dành cho Moodle cho phép tổ chức các trò chơi nghiêm túc ngoài trời với học sinh của bạn.
TreasureHunt triển khai ứng dụng chơi dựa trên trình duyệt (không cần cài đặt bất kỳ ứng dụng gốc nào) và trình chỉnh sửa địa lý để mã hóa các giai đoạn của trò chơi.
Trò chơi có thể được định cấu hình với một loạt các tùy chọn làm cho mô-đun trở nên rất linh hoạt và hữu ích trong nhiều tình huống: cá nhân / nhóm,
di chuyển / đánh dấu máy tính để bàn, chấm điểm theo thời gian, vị trí, hoàn thành, v.v.
<p> <b> <a href = "https://juacas.github.io/moodle-mod_treasurehunt/index.html"> Thông tin khác và hướng dẫn từng bước trong bản trình bày trực tuyến này. </a> </ b> </p> ';
$string['modulenameplural']= 'Săn kho báu';
$string['movingplay']= 'Chơi di chuyển';
$string['multiplegroupingsplay']= 'Nhóm của bạn đã chỉ định nhiều con đường, vì vậy bạn không thể chơi hoạt động.';
$string['multiplegroupsplay']= 'Bạn đã chỉ định nhiều con đường, vì vậy bạn không thể chơi hoạt động.';
$string['multiplegroupssameroadplay']= 'Bạn thuộc nhiều nhóm được chỉ định trên cùng một con đường, vì vậy bạn không thể chơi hoạt động.';
$string['multipleteamsplay']= 'Thành viên của nhiều hơn một nhóm, vì vậy không thể thực hiện hoạt động.';
$string['mustanswerquestion']= 'Bạn phải trả lời chính xác câu hỏi trước khi tiếp tục';
$string['mustcompleteactivity']= 'Bạn phải vượt qua hoạt động để hoàn thành trước khi tiếp tục';
$string['mustcompleteboth']= 'Bạn phải trả lời câu hỏi một cách chính xác và vượt qua hoạt động để hoàn thành trước khi tiếp tục';
$string['nextcamera']= 'Thay đổi máy ảnh';
$string['nextstep']= 'Tiếp theo';
$string['noanswerselected']= 'Bạn phải chọn một câu trả lời';
$string['noattempts']= 'Bạn đã không thực hiện bất kỳ nỗ lực nào';
$string['noexsitsstage']= 'Không có số giai đoạn {$a} trong cơ sở dữ liệu. Tải lại trang ';
$string['nogroupassigned']= 'Không có nhóm nào được chỉ định đến con đường này';
$string['nogroupingplay']= 'Bạn không có nhóm nào được chỉ định cho một con đường, vì vậy bạn không thể chơi hoạt động.';
$string['nogroupplay']= 'Bạn không có con đường được chỉ định, vì vậy bạn không thể chơi hoạt động.';
$string['nogrouproad']= '{$a} không có đường nào được chỉ định.';
$string['nomarks']= 'Đầu tiên hãy đánh dấu điểm mong muốn trên bản đồ. Đặt <img src = "pix / my_location.png" width = "28" /> ';
$string['noresults']= 'Không tìm thấy kết quả nào.';
$string['noroads']= 'Chưa có đường nào được thêm vào';
$string['notchangeorderstage']= 'Bạn không thể thay đổi thứ tự của các giai đoạn sau khi đã thử trên đường';
$string['notcreatestage']= 'Các nỗ lực đã được thực hiện trên con đường này, bạn không thể thêm các chặng nữa';
$string['notdeletestage']= 'Các nỗ lực đã được thực hiện trên con đường này, bạn không thể xóa bất kỳ giai đoạn nào';
$string['noteam']= 'Không phải là thành viên của bất kỳ nhóm nào';
$string['notreasurehunts']= 'Không có cuộc truy tìm kho báu nào trong khóa học này';
$string['nouserassigned']= 'Không có người dùng nào được chỉ định cho con đường này';
$string['nouserattempts']= '{$a} chưa thực hiện bất kỳ nỗ lực nào';
$string['nouserroad']= '{$a} không có đường nào được chỉ định.';
$string['nousersprogress']= 'Không có người dùng / nhóm nào có tiến bộ trên con đường này.';
$string['outoftime']= 'Hết thời gian';
$string['overcomefirststage']= 'Để khám phá giai đoạn đầu tiên, bạn nên bắt đầu từ khu vực được đánh dấu trên bản đồ';
$string['play']= 'Chơi';
$string['playend_tour']= '<span style = "font-size: 1.5rem; font-weight: bold"> Tận hưởng Truy tìm Kho báu </span> <br> cùng bạn bè của bạn!';
$string['playerbootstrap']= 'Bootstrap';
$string['playerclassic']= 'Cổ điển';
$string['playerfancy']= 'Fanzy';
$string['playerhelp_tour']= 'Có thể xem lại chuyến tham quan này bất cứ khi nào bạn muốn.';
$string['playerstyle']= 'Kiểu màn hình trò chơi';
$string['playerstyle_help']= 'Có một số kiểu màn hình trò chơi mà giáo viên có thể chọn';
$string['playstagewithoutmoving']= 'Khám phá giai đoạn mà không cần di chuyển';
$string['playstagewithoutmoving_help']= 'Nếu tùy chọn này được bật, sinh viên có thể khám phá giai đoạn này mà không cần di chuyển đến bất kỳ nơi nào.
Để thực hiện điều này, mỗi khi học sinh thực hiện một cú nhấp chuột đơn giản trên bản đồ, một dấu hiệu sẽ được tạo ra, xóa phần trước đó
nếu có, cho biết điểm mong muốn cuối cùng. Sau khi hoàn thành màn chơi, trò chơi sẽ chuyển sang chế độ mặc định
cài đặt của hoạt động ';
$string['playstagewithqr']= 'Giai đoạn khám phá bằng cách đọc văn bản QR này';
$string['playstagewithqr_help']= 'Nếu tùy chọn này có giá trị, sinh viên có thể khám phá giai đoạn này bằng cách quét mã QR có sẵn tại vị trí đó.';
$string['playwithoutmoving']= 'Đang chơi mà không di chuyển';
$string['playwithoutmoving_help']= 'Nếu tùy chọn này được bật, học sinh có thể chơi từ máy tính của họ mà không cần chuyển sang
nơi. Để thực hiện điều này, mỗi khi học sinh thực hiện một cú nhấp chuột đơn giản trên bản đồ, một dấu hiệu sẽ được tạo ra, xóa phần trước đó
nếu có, cho biết điểm mong muốn cuối cùng. ';
$string['pluginadministration']= 'Quản lý truy tìm kho báu';
$string['pluginname']= 'Truy tìm kho báu';
$string['prevstep']= 'Trước đó';
$string['privacy:metadata_treasurehunt_attempts']= 'Truy tìm kho báu lưu trữ loại, thời gian và địa điểm của những nỗ lực, thành công và thất bại của người dùng trong hoạt động';
$string['privacy:metadata_treasurehunt_attempts_groupid']= 'Nhóm mà người dùng đã chơi hoạt động.';
$string['privacy:metadata_treasurehunt_attempts_stageid']= 'LÀ giai đoạn mà người dùng đang cố gắng giải quyết.';
$string['privacy:metadata_treasurehunt_attempts_timecreated']= 'Thời điểm người dùng thực hiện.';
$string['privacy:metadata_treasurehunt_attempts_userid']= 'ID của người dùng đã thử.';
$string['privacy:metadata_treasurehunt_track']= 'Truy tìm kho báu lưu trữ chuỗi các vị trí được người dùng theo dõi trong quá trình hoạt động.';
$string['privacy:metadata_treasurehunt_track_location']= 'Vị trí của người dùng tại một thời điểm cụ thể.';
$string['privacy:metadata_treasurehunt_track_timestamp']= 'Thời gian người dùng được theo dõi.';
$string['privacy:metadata_treasurehunt_track_treasurehuntid']= 'ID của cuộc truy tìm Kho báu mà người dùng đang chơi.';
$string['privacy:metadata_treasurehunt_track_userid']= 'ID của người dùng đang được theo dõi.';
$string['question']= 'Câu hỏi';
$string['remove']= 'Xóa';
$string['removealltreasurehuntattempts']= 'Xóa tất cả nỗ lực truy tìm kho báu';
$string['removedactivitytoend']= 'Hoạt động cần hoàn thành đã bị xóa';
$string['removedquestion']= 'Câu hỏi đã bị xóa';
$string['removeroadwarning']= 'Nếu bạn xóa con đường, tất cả các giai đoạn liên quan đã bị xóa và bạn không thể khôi phục được nữa';
$string['remove_tour']= 'Bạn có thể xóa các phần của hình vị trí. Chỉ cần chọn một đa giác và sau đó nhấn nút này. ';
$string['removewarning']= 'Nếu bạn xóa nó, bạn không thể lấy lại nó';
$string['restrictionsdiscoverstage']= 'Hạn chế để khám phá giai đoạn';
$string['reviewofplay']= 'Xem lại vở kịch';
$string['road']= 'Đường';
$string['roadended']= 'Con đường này đã hoàn thành. Xin chúc mừng! Bạn đã hoàn thành cuộc truy tìm kho báu. Bạn có thể kiểm tra lịch sử của mình trong bản đồ. ';
$string['roadmap']= 'Đường';
$string['roadname']= 'Tên đường';
$string['roads_tour']= 'Trong khu vực này, bạn sẽ tìm thấy những con đường khác nhau trong trò chơi của mình. Chọn một trong số chúng để chỉnh sửa các giai đoạn. ';
$string['roadview']= 'Đường';
$string['save']= 'Lưu';
$string['saveemptyridle']= 'Tất cả các giai đoạn sửa đổi phải có hình học trước khi lưu';
$string['save_tour']= 'Sau khi vẽ các vị trí của bạn, đừng quên lưu các thay đổi của bạn.';
$string['savewarning']= 'Bạn chưa lưu các thay đổi.';
$string['scanQR_generatebutton']= 'Tạo mã QRCode';
$string['scanQR_scanbutton']= 'Quét mã QRCode';
$string['search']= 'Tìm kiếm';
$string['searching']= 'Đang tìm kiếm';
$string['searchlocation']= 'Tìm kiếm vị trí';
$string['searchlocation_tour']= 'Với khu vực tìm kiếm này, bạn có thể tìm đường nhanh chóng';
$string['send']= 'Gửi';
$string['sendlocationcontent']= 'Không thể hoàn tác hành động này.';
$string['sendlocationtitle']= 'Bạn có chắc chắn muốn gửi vị trí này không?';
$string['showclue']= 'Hiển thị đầu mối';
$string['skiptutorial']= 'Thoát';
$string['stage']= 'Giai đoạn';
$string['stageclue']= 'Đầu mối xác định vị trí giai đoạn tiếp theo';
$string['stageclue_help']= 'Ở đây bạn nên mô tả manh mối để đến địa điểm tiếp theo.
Trong trường hợp là chặng cuối cùng, phải để lại tin nhắn phản hồi cho biết cuộc truy tìm kho báu đã kết thúc. ';
$string['stagename']= 'Tên sân khấu';
$string['stageovercome']= 'Giai đoạn vượt qua';
$string['stages']= 'Các giai đoạn';
$string['stages_tour']= 'Trong khu vực này, bạn sẽ tìm thấy các giai đoạn của con đường đã chọn. Chọn từng giai đoạn để thu phóng đến vị trí thực trong bản đồ và bắt đầu chỉnh sửa hình dạng của nó bằng cách nhấp vào chúng và các nút Chỉnh sửa / Vẽ ở trên. ';
$string['start']= 'Bắt ​​đầu';
$string['startfromhere']= 'Bạn chỉ có thể bắt đầu từ đây';
$string['state']= 'Bang';
$string['successlocation']= 'Đó là nơi thích hợp!';
$string['timeago']= '{$a->shortduration} trước';
$string['timeagolong']= '{$a->shortduration} trước ({$a->date})';
$string['timeat']= 'tại {$a->date}';
$string['timeexceeded']= 'Bạn đã vượt quá giới hạn thời gian cho hoạt động. Màn hình này chỉ dùng để xem lại trò chơi ';
$string['timetocome']= 'trong {$a->shortduration}';
$string['timetocomelong']= 'trong {$a->shortduration} ({$a->date})';
$string['totaltime']= 'Tổng thời gian';
$string['trackusers']= 'Theo dõi quỹ đạo';
$string['trackusers_help']= 'Đăng ký các đường dẫn do người dùng tạo. Chúng có thể được nhìn thấy trong màn hình “Trình xem theo dõi”. <br/>
Vị trí của người dùng được ghi lại giữa các lần xác thực (với mọi yêu cầu thăm dò ý kiến). <br/>
Nếu người dùng đã tắt GPS thì vị trí duy nhất mà anh ta có thể báo cáo là vị trí của Mã QR được quét. <br/>
Nếu tùy chọn này bị <b> vô hiệu hóa </b>, các vị trí duy nhất được ghi lại là vị trí của các lần thử xác thực. ';
$string['trackviewer']= 'Trình xem theo dõi';
$string['trackviewerrefreshtracks']= 'Làm mới bản nhạc mỗi {$a} giây.';
$string['treasurehunt']= 'Truy tìm kho báu';
$string['treasurehunt:addinstance']= 'Thêm một kho báu mới';
$string['treasurehunt:addroad']= 'Thêm đường';
$string['treasurehunt:addstage']= 'Thêm giai đoạn';
$string['treasurehuntclosed']= 'Cuộc săn tìm kho báu này đã đóng {$a}';
$string['treasurehuntcloses']= 'Truy tìm kho báu kết thúc';
$string['treasurehuntcloseson']= 'Cuộc truy tìm kho báu này sẽ kết thúc {$a}';
$string['treasurehunt:editroad']= 'Chỉnh sửa đường';
$string['treasurehunt:editstage']= 'Chỉnh sửa giai đoạn';
$string['treasurehuntislocked']= '{$a} đang chỉnh sửa công cụ tìm kiếm kho báu này ngay bây giờ. Cố gắng chỉnh sửa nó trong vài phút. ';
$string['treasurehunt:managetreasure']= 'Quản lý kho quỹ';
$string['treasurehunt:managetreasurehunt']= 'Quản lý kho quỹ';
$string['treasurehuntname']= 'Tên truy tìm kho báu';
$string['treasurehuntnotavailable']= 'Truy tìm kho báu sẽ có {$a}';
$string['treasurehuntopenedon']= 'Cuộc truy tìm kho báu này đã mở {$a}';
$string['treasurehuntopens']= 'Truy tìm kho báu mở ra';
$string['treasurehunt:play']= 'Chơi';
$string['treasurehunt:view']= 'Xem kho báu';
$string['treasurehunt:viewusershistoricalattempts']= 'Xem lịch sử người dùng thử ';
$string['updates']= 'Cập nhật';
$string['updatetimes']= 'Cập nhật thời gian';
$string['user']= 'Người dùng';
$string['useractivityovercome']= '<b> Hoạt động Moodle cho "giai đoạn {$a->position}" đã hoàn tất thành công </b> {$a->date}';
$string['userinvalidroad']= '{$a} đã chỉ định một đường không hợp lệ.';
$string['userlocationfailed']= '<b> Không thành công "giai đoạn {$a->position}" vị trí </b> {$a->date}';
$string['userlocationovercome']= '<b> Giai đoạn thành công "{$a->position}" location </b> {$a->date}';
$string['usermultipleroads']= '{$a} có nhiều đường được chỉ định.';
$string['usermultiplesameroad']= '{$a} thuộc nhiều nhóm được chỉ định trên cùng một con đường.';
$string['userprogress']= 'Tiến trình người dùng được cập nhật thành công';
$string['userquestionfailed']= '<b> Không thành công "giai đoạn {$a->position}" answer </b> {$a->date}';
$string['userquestionovercome']= '<b> Giai đoạn thành công "{$a->position}" answer </b> {$a->date}';
$string['usersprogress']= 'Tiến trình của người dùng';
$string['usersprogress_help']= 'Cho biết tiến trình các giai đoạn của từng học sinh / nhóm theo các màu: <br/>
Màu <B> xanh </B> cho biết rằng giai đoạn đã được khắc phục mà không có lỗi. <br/>
Màu <B> vàng </B> cho biết rằng giai đoạn đã được khắc phục với các lỗi. <br/>
Màu <B> đỏ </B> cho biết giai đoạn này chưa được khắc phục và đã xảy ra lỗi. <br/>
Màu <B> xám </B> cho biết giai đoạn chưa được khắc phục và không có lỗi nào được thực hiện. ';
$string['userstageovercome']= '<b> Giai đoạn {$a->position} vượt qua </b>: {$a->date}';
$string['validatelocation']= 'Xác thực vị trí';
$string['validatelocation_tour']= 'Tự tin về vị trí của một giai đoạn? <br> <b> Hãy gửi vị trí của bạn </b> và khám phá xem bạn có đúng không.';
$string['validateqr']= 'Quét QR';
$string['warmatchanswer']= 'Câu trả lời không khớp với câu hỏi';
$string['warnqrscanner']= '<table> <tr> <td> Treasurehunt này bao gồm {$a} giai đoạn với QRCodes.
Hãy chắc chắn rằng thiết bị của bạn có thể quét mã từ trình duyệt web. Chế độ xem camera của bạn sẽ xuất hiện ở phía dưới. Cố gắng đọc bất kỳ mã qrcode nào
như thế này. </td> <td> <a href="pix/qr.png">
<img src = "pix / qr.png" align = "top" width = "100"> </a> </td> </tr> </table> ';
$string['warnqrscannererror']= 'Treasurehunt này bao gồm các giai đoạn {$a} với QRCodes.
Có vẻ như thiết bị của bạn không thể sử dụng máy ảnh với ứng dụng này. Vui lòng cấp quyền truy cập máy ảnh.
Nếu bạn không thể kích hoạt camera, thiết bị này có thể không thích hợp để chơi Treasurehunt. ';
$string['warnqrscannersuccess']= 'Treasurehunt này bao gồm các giai đoạn {$a} với QRCodes.
Có vẻ như bạn đã vượt qua bài kiểm tra QR với thiết bị này. ';
$string['warnunsecuregeolocation']= 'Vị trí địa lý có thể không hoạt động trong máy chủ của bạn. Đây là một <b> cấu hình sai SEVERE </b> do
cấu hình máy chủ. Vị trí địa lý bị cấm đối với các máy chủ không Bảo mật sử dụng HTTP thay vì HTTPS. Để sử dụng GPS của
để xác định vị trí của sinh viên trong Treasurehunt, máy chủ phải được truy cập bằng các URL HTTPS an toàn. Trong trường hợp khác, chỉ có chế độ "Chơi mà không di chuyển"
có thể được sử dụng và người chơi cần phải chỉ tay theo từng giai đoạn trên bản đồ.
Vui lòng liên hệ với quản trị viên của bạn.
(Tham khảo <a href="https://www.chromestatus.com/feature/5636088701911040"> Chrome </a>, <a href = "https://blog.mozilla.org/security/2015/04/30 / phản đối-không an toàn-http / "> Firefox </a>) ';
$string['warnusersgroup']= 'Những người dùng sau thuộc nhiều nhóm: {$a}, do đó không thể chơi hoạt động.';
$string['warnusersgrouping']= 'Các nhóm sau thuộc nhiều nhóm: {$a}, do đó không thể chơi hoạt động.';
$string['warnusersoutside']= 'Những người dùng sau không thuộc bất kỳ nhóm / nhóm nào: {$a}, vì vậy không thể chơi hoạt động.';
$string['welcome_edit_tour']= 'Chào mừng đến với trang tác giả của TreasureHunt.';
$string['welcome_play_tour']= '<span style = "font-size: 1.5rem; font-weight: bold"> Chào mừng bạn đến với Truy tìm kho báu! </span> <br> Bản đồ và manh mối này sẽ là hướng dẫn cho bạn.';
