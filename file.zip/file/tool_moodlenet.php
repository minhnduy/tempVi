<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_moodlenet', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_moodlenet
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['addingaresource']= 'Thêm nội dung từ MoodleNet';
$string['aria:enterprofile']= 'Nhập URL hồ sơ MoodleNet của bạn';
$string['aria:footermessage']= 'Duyệt nội dung trên MoodleNet';
$string['browsecontentmoodlenet']= 'Hoặc duyệt nội dung trên MoodleNet';
$string['clearsearch']= 'Xóa tìm kiếm';
$string['connectandbrowse']= 'Kết nối và duyệt:';
$string['defaultmoodlenet']= 'URL MoodleNet';
$string['defaultmoodlenet_desc']= 'URL của phiên bản MoodleNet có sẵn thông qua trình chọn hoạt động.';
$string['defaultmoodlenetname']= 'Tên phiên bản MoodleNet';
$string['defaultmoodlenetname_desc']= 'Tên của phiên bản MoodleNet có sẵn thông qua trình chọn hoạt động.';
$string['defaultmoodlenetnamevalue']= 'MoodleNet Central';
$string['enablemoodlenet']= 'Bật tích hợp MoodleNet';
$string['enablemoodlenet_desc']= 'Nếu được bật, người dùng có khả năng tạo và quản lý các hoạt động có thể duyệt MoodleNet qua trình chọn hoạt động và nhập các tài nguyên MoodleNet vào khóa học của họ. Ngoài ra, người dùng có khả năng khôi phục các bản sao lưu có thể chọn một tập tin sao lưu trên MoodleNet và khôi phục nó vào Moodle. ';
$string['errorduringdownload']= 'Đã xảy ra lỗi khi tải xuống tệp: {$a}';
$string['footermessage']= 'Hoặc duyệt nội dung trên';
$string['forminfo']= 'Hồ sơ MoodleNet của bạn sẽ được tự động lưu vào hồ sơ của bạn trên trang web này.';
$string['importconfirm']= 'Bạn sắp nhập nội dung "{$a->resourcename} ({$a->resourcetype})" vào khóa học "{$a->coursename}". Bạn có chắc chắn muốn tiếp tục không? ';
$string['importconfirmnocourse']= 'Bạn sắp nhập nội dung "{$a->resourcename} ({$a->resourcetype})" vào trang web của bạn. Bạn có chắc chắn muốn tiếp tục không? ';
$string['importformatselectguidingtext']= 'Bạn muốn thêm nội dung "{$a->name} ({$a->type})" vào khóa học của mình ở định dạng nào?';
$string['importformatselectheader']= 'Chọn định dạng hiển thị nội dung';
$string['inputhelp']= 'Hoặc nếu bạn đã có tài khoản MoodleNet, hãy nhập hồ sơ MoodleNet của bạn:';
$string['instancedescription']= 'MoodleNet là một nền tảng truyền thông xã hội mở dành cho các nhà giáo dục, tập trung vào việc hợp tác quản lý các bộ sưu tập tài nguyên mở.';
$string['instanceplaceholder']= '@ yourprofile @ moodle.net';
$string['invalidmoodlenetprofile']= '$ userprofile không được định dạng đúng';
$string['missinginvalidpostdata']= 'Thông tin tài nguyên từ MoodleNet bị thiếu hoặc ở định dạng không chính xác.
Nếu điều này xảy ra nhiều lần, vui lòng liên hệ với quản trị viên trang web. ';
$string['mnetprofile']= 'Hồ sơ MoodleNet';
$string['mnetprofiledesc']= '<p> Nhập chi tiết hồ sơ MoodleNet của bạn tại đây để được chuyển hướng đến hồ sơ của bạn khi truy cập MoodleNet. </p>';
$string['moodlenetnotenabled']= 'Tích hợp MoodleNet phải được kích hoạt trong Quản trị trang / MoodleNet trước khi việc nhập tài nguyên có thể được xử lý.';
$string['moodlenetsettings']= 'Cài đặt MoodleNet';
$string['notification']= 'Bạn sắp nhập nội dung "{$a->name} ({$a->type})" vào trang web của bạn. Chọn khóa học cần thêm hoặc <a href="{$a->cancellink}"> hủy </a>. ';
$string['pluginname']= 'MoodleNet';
$string['privacy:metadata']= 'Công cụ MoodleNet chỉ hỗ trợ giao tiếp với MoodleNet. Nó không lưu trữ dữ liệu. ';
$string['profilevalidationerror']= 'Đã xảy ra sự cố khi cố gắng xác thực hồ sơ của bạn';
$string['profilevalidationfail']= 'Vui lòng nhập hồ sơ MoodleNet hợp lệ';
$string['profilevalidationpass']= 'Có vẻ ổn!';
$string['saveandgo']= 'Lưu và truy cập';
$string['searchcourses']= 'Tìm kiếm các khóa học';
$string['selectpagetitle']= 'Chọn trang';
$string['uploadlimitexceeded']= 'Kích thước tệp {$a->filesize} vượt quá giới hạn tải lên của người dùng là {$a->uploadlimit} byte.';
