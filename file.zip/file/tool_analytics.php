<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_analytics', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_analytics
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['accuracy']= 'Độ chính xác';
$string['actionexecutedgroupedusefulness']= 'Hành động được nhóm';
$string['actions']= 'Hành động';
$string['actionsexecutedbyusers']= 'Các hành động được thực hiện bởi người dùng';
$string['actionsexecutedbyusersfor']= 'Các hành động được thực thi bởi người dùng cho "{$a}" model ';
$string['allpredictions']= 'Tất cả các dự đoán';
$string['alltimesplittingmethods']= 'Tất cả các khoảng thời gian phân tích';
$string['analysingsitedata']= 'Phân tích trang web';
$string['analysis']= 'Phân tích';
$string['analyticmodels']= 'Mô hình phân tích';
$string['bettercli']= 'Đánh giá mô hình và tạo dự đoán có thể đòi hỏi quá trình xử lý nặng. Bạn nên chạy các hành động này từ dòng lệnh. ';
$string['cantguessenddate']= 'Không thể đoán ngày kết thúc';
$string['cantguessstartdate']= 'Không thể đoán ngày bắt đầu';
$string['classdoesnotexist']= 'Lớp {$a} không tồn tại';
$string['clearmodelpredictions']= 'Bạn có chắc chắn muốn xóa tất cả các dự đoán "{$a}" không?';
$string['clearpredictions']= 'Dự đoán rõ ràng';
$string['clienablemodel']= 'Bạn có thể kích hoạt mô hình bằng cách chọn khoảng thời gian phân tích theo ID của nó. Lưu ý rằng bạn cũng có thể bật nó sau này bằng giao diện web (\'none \' để thoát). ';
$string['clievaluationandpredictions']= 'Một nhiệm vụ đã lên lịch lặp lại qua các mô hình đã bật và nhận các dự đoán. Đánh giá mô hình qua giao diện web bị tắt. Bạn có thể cho phép các quá trình này được thực thi theo cách thủ công thông qua giao diện web bằng cách tắt cài đặt phân tích <a href="{$a}"> \'onlycli \' </a>. ';
$string['clievaluationandpredictionsnoadmin']= 'Một nhiệm vụ đã lên lịch lặp lại qua các mô hình đã bật và nhận các dự đoán. Đánh giá mô hình qua giao diện web bị tắt. Nó có thể được kích hoạt bởi quản trị viên trang web. ';
$string['component']= 'Thành phần';
$string['componentcore']= 'Cốt lõi';
$string['componentselect']= 'Chọn tất cả các kiểu được cung cấp bởi thành phần \' {$a} \'';
$string['componentselectnone']= 'Bỏ chọn tất cả';
$string['contexts']= 'Biểu đồ';
$string['contexts_help']= 'Mô hình sẽ được giới hạn trong tập hợp các bối cảnh này. Không có giới hạn ngữ cảnh nào sẽ được áp dụng nếu không có ngữ cảnh nào được chọn. ';
$string['createmodel']= 'Tạo mô hình';
$string['currenttimesplitting']= 'Khoảng thời gian phân tích hiện tại';
$string['delete']= 'Xóa';
$string['deletemodelconfirmation']= 'Bạn có chắc chắn muốn xóa "{$a}" không? Không thể hoàn nguyên những thay đổi này. ';
$string['disabled']= 'Đã tắt';
$string['editmodel']= 'Chỉnh sửa "{$a}" mô hình ';
$string['edittrainedwarning']= 'Mô hình này đã được đào tạo. Lưu ý rằng việc thay đổi các chỉ số hoặc khoảng thời gian phân tích của nó sẽ xóa các dự đoán trước đó và bắt đầu tạo ra các dự đoán mới. ';
$string['enabled']= 'Đã bật';
$string['errorcantenablenotimesplitting']= 'Bạn cần chọn khoảng thời gian phân tích trước khi bật mô hình';
$string['errornoenabledandtrainedmodels']= 'Không có mô hình được kích hoạt và đào tạo nào để dự đoán.';
$string['errornoenabledmodels']= 'Không có mô hình nào được kích hoạt để đào tạo.';
$string['errornoexport']= 'Chỉ những người mẫu được đào tạo mới có thể được xuất khẩu';
$string['errornostaticevaluated']= 'Không thể đánh giá các mô hình dựa trên các giả định. Chúng luôn đúng 100% theo cách chúng được xác định. ';
$string['errornostaticlog']= 'Không thể đánh giá mô hình dựa trên các giả định vì không có nhật ký hoạt động.';
$string['erroronlycli']= 'Chỉ được phép thực thi thông qua dòng lệnh';
$string['errortrainingdataexport']= 'Không thể xuất dữ liệu huấn luyện mô hình';
$string['evaluate']= 'Đánh giá';
$string['evaluatemodel']= 'Đánh giá mô hình';
$string['evaluationinbatches']= 'Nội dung trang web được tính toán và lưu trữ theo lô. Quá trình đánh giá có thể bị dừng bất cứ lúc nào. Lần chạy tiếp theo, nó sẽ tiếp tục từ điểm khi nó bị dừng. ';
$string['evaluationmode']= 'Chế độ đánh giá';
$string['evaluationmodecolconfiguration']= 'Cấu hình';
$string['evaluationmodecoltrainedmodel']= 'Mô hình được đào tạo';
$string['evaluationmodeconfiguration']= 'Đánh giá cấu hình mô hình';
$string['evaluationmode_help']= 'Có hai chế độ đánh giá:
* Mô hình được đào tạo - Dữ liệu trang web được sử dụng làm dữ liệu thử nghiệm để đánh giá độ chính xác của mô hình được đào tạo.
* Cấu hình - Dữ liệu trang web được chia thành dữ liệu đào tạo và kiểm tra, để vừa đào tạo vừa kiểm tra độ chính xác của cấu hình mô hình.
Mô hình được đào tạo chỉ khả dụng nếu một mô hình được đào tạo đã được nhập vào trang web và chưa được đào tạo lại bằng cách sử dụng dữ liệu trang web. ';
$string['evaluationmodeinfo']= 'Mô hình này đã được nhập vào trang web. Bạn có thể đánh giá hiệu suất của mô hình hoặc bạn có thể đánh giá hiệu suất của cấu hình mô hình bằng cách sử dụng dữ liệu trang web. ';
$string['evaluationmodetrainedmodel']= 'Đánh giá mô hình được đào tạo';
$string['executescheduledanalysis']= 'Thực hiện phân tích theo lịch trình';
$string['export']= 'Xuất';
$string['exportincludeweights']= 'Bao gồm trọng lượng của mô hình được đào tạo';
$string['exportmodel']= 'Xuất cấu hình';
$string['exporttrainingdata']= 'Xuất dữ liệu đào tạo';
$string['extrainfo']= 'Thông tin';
$string['generalerror']= 'Lỗi đánh giá. Mã trạng thái {$a} ';
$string['getpredictions']= 'Nhận dự đoán';
$string['goodmodel']= 'Đây là một mô hình tốt để sử dụng để thu được các dự đoán. Kích hoạt nó để bắt đầu nhận các dự đoán. ';
$string['ignoreversionmismatches']= 'Bỏ qua phiên bản không khớp';
$string['ignoreversionmismatchescheckbox']= 'Bỏ qua sự khác biệt giữa phiên bản trang web này và phiên bản trang web gốc.';
$string['importedsuccessfully']= 'Mô hình đã được nhập thành công.';
$string['importmodel']= 'Nhập mô hình';
$string['indicators']= 'Các chỉ số';
$string['indicators_help']= 'Các chỉ số là những gì bạn nghĩ sẽ dẫn đến dự đoán chính xác về mục tiêu.';
$string['indicators_link']= 'Các chỉ số';
$string['indicatorsnum']= 'Số chỉ số: {$a}';
$string['info']= 'Thông tin';
$string['insights']= 'Thông tin chi tiết';
$string['insightsreport']= 'Báo cáo thông tin chi tiết';
$string['invalidanalysables']= 'Phần tử trang web không hợp lệ';
$string['invalidanalysablesinfo']= 'Trang này liệt kê các yếu tố có thể phân tích được mà mô hình dự đoán này không thể sử dụng. Không thể sử dụng các phần tử được liệt kê để đào tạo mô hình dự đoán cũng như không thể sử dụng mô hình dự đoán để thu được các dự đoán cho chúng. ';
$string['invalidanalysablestable']= 'Bảng yếu tố có thể phân tích trang web không hợp lệ';
$string['invalidcurrenttimesplitting']= 'Khoảng thời gian phân tích hiện tại không hợp lệ cho mục tiêu của mô hình này. Vui lòng chọn một khoảng thời gian khác. ';
$string['invalidindicatorsremoved']= 'Một mô hình mới đã được thêm vào. Các chỉ báo không hoạt động với mục tiêu đã chọn sẽ tự động bị loại bỏ. ';
$string['invalidprediction']= 'Không hợp lệ để nhận dự đoán';
$string['invalidtimesplitting']= 'Khoảng thời gian phân tích đã chọn không hợp lệ cho mục tiêu đã chọn.';
$string['invalidtimesplittinginmodels']= 'Khoảng thời gian phân tích được sử dụng bởi một số mô hình không hợp lệ. Vui lòng chọn khoảng thời gian khác cho các kiểu máy sau: {$a} ';
$string['invalidtraining']= 'Không hợp lệ để huấn luyện mô hình';
$string['loginfo']= 'Ghi thông tin bổ sung';
$string['missingmoodleversion']= 'Tệp đã nhập không xác định số phiên bản';
$string['modelid']= 'ID kiểu máy';
$string['modelinvalidanalysables']= 'Các phần tử có thể phân tích không hợp lệ cho "{$a}" model ';
$string['modelname']= 'Tên kiểu máy';
$string['modelresults']= '{$a} kết quả';
$string['modeltimesplitting']= 'Khoảng phân tích';
$string['newmodel']= 'Mô hình mới';
$string['nextpage']= 'Trang tiếp theo';
$string['noactionsfound']= 'Người dùng chưa thực hiện bất kỳ hành động nào đối với thông tin chi tiết đã tạo.';
$string['nodatatoevaluate']= 'Không có dữ liệu để đánh giá mô hình';
$string['nodatatopredict']= 'Không có phần tử mới nào để nhận dự đoán.';
$string['nodatatotrain']= 'Không có dữ liệu mới nào có thể được sử dụng để đào tạo.';
$string['noinvalidanalysables']= 'Trang web này không chứa bất kỳ phần tử có thể phân tích không hợp lệ nào.';
$string['notdefined']= 'Chưa được xác định';
$string['pluginname']= 'Mô hình phân tích';
$string['predictionprocessfinished']= 'Quá trình dự đoán kết thúc';
$string['predictionresults']= 'Kết quả dự đoán';
$string['predictmodels']= 'Dự đoán mô hình';
$string['predictorresultsin']= 'Dự đoán đã ghi thông tin vào thư mục {$a}';
$string['previouspage']= 'Trang trước';
$string['privacy:metadata']= 'Plugin mô hình phân tích không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['restoredefault']= 'Khôi phục các mô hình mặc định';
$string['restoredefaultempty']= 'Vui lòng chọn mô hình để được khôi phục.';
$string['restoredefaultinfo']= 'Các mô hình mặc định này bị thiếu hoặc đã thay đổi kể từ khi được cài đặt. Bạn có thể khôi phục các mô hình mặc định đã chọn. ';
$string['restoredefaultnone']= 'Tất cả các mô hình mặc định được cung cấp bởi các plugin chính và được cài đặt đã được tạo. Không có mô hình mới được tìm thấy; không có gì để khôi phục. ';
$string['restoredefaultsome']= 'Đã tạo lại thành công {$a->count} (các) mẫu mới.';
$string['restoredefaultsubmit']= 'Khôi phục đã chọn';
$string['sameenddate']= 'Ngày kết thúc hiện tại là tốt';
$string['samestartdate']= 'Ngày bắt đầu hiện tại là tốt';
$string['scheduledanalysisresults']= 'Kết quả sử dụng khoảng thời gian phân tích {$a->name}';
$string['scheduledanalysisresultscli']= 'Kết quả sử dụng khoảng phân tích {$a->name} (id: {$a->id})';
$string['selecttimesplittingforevaluation']= 'Chọn khoảng thời gian phân tích bạn muốn sử dụng để đánh giá cấu hình mô hình.';
$string['target']= 'Mục tiêu';
$string['target_help']= 'Mục tiêu là những gì mô hình sẽ dự đoán.';
$string['target_link']= 'Mục tiêu';
$string['timesplittingnotdefined']= 'Không có khoảng phân tích nào được xác định.';
$string['timesplittingnotdefined_help']= 'Bạn cần chọn khoảng thời gian phân tích trước khi bật mô hình.';
$string['trainandpredictmodel']= 'Mô hình đào tạo và tính toán dự đoán';
$string['trainingprocessfinished']= 'Quá trình đào tạo đã kết thúc';
$string['trainingresults']= 'Kết quả đào tạo';
$string['trainmodels']= 'Mô hình xe lửa';
$string['versionnotsame']= 'Tệp được nhập từ phiên bản khác ({$a->importedversion}) với phiên bản hiện tại ({$a->version})';
$string['viewlog']= 'Nhật ký đánh giá';
$string['weeksenddateautomaticallyset']= 'Ngày kết thúc tự động được đặt dựa trên ngày bắt đầu và số phần';
$string['weeksenddatedefault']= 'Ngày kết thúc tự động được tính từ ngày bắt đầu khóa học.';
