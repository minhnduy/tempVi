<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_usersuspension', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_usersuspension
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['action:confirm-delete-exclusion']= 'Bạn có chắc chắn muốn xóa mục này khỏi danh sách loại trừ không?';
$string['action:delete-exclusion']= 'Xóa mục khỏi danh sách loại trừ';
$string['action:exclude:add:cohort']= 'Thêm loại trừ nhóm thuần tập';
$string['action:exclude:add:user']= 'Thêm loại trừ người dùng';
$string['button:backtocourse']= 'Quay lại khóa học';
$string['button:backtoexclusions']= 'Quay lại tổng quan về loại trừ';
$string['button:backtouploadform']= 'Quay lại để tải lên biểu mẫu';
$string['button:continue']= 'Tiếp tục';
$string['config:cleanlogs:disabled']= 'Tự động làm sạch nhật ký bị tắt trong cấu hình chung';
$string['config:cleanup:disabled']= 'Tùy chọn Tạm ngưng Người dùng \' dọn dẹp \'bị tắt trong cấu hình công cụ toàn cầu';
$string['config:fromfolder:disabled']= 'Tùy chọn Tạm ngưng người dùng \' tạm ngừng tải lên \'bị tắt trong cấu hình công cụ toàn cầu';
$string['config:smartdetect:disabled']= 'Tùy chọn Tạm ngưng Người dùng \' phát hiện thông minh \'bị tắt trong cấu hình công cụ toàn cầu';
$string['config:tool:disabled']= 'Tiện ích Tạm ngưng Người dùng bị tắt trong cấu hình công cụ toàn cầu';
$string['csv:delimiter']= 'Dấu phân cách';
$string['csv:enclosure']= 'Bao vây';
$string['csv:upload:continue']= 'Tiếp tục';
$string['email:user:delete:body']= '<p> Kính gửi {$a->name} </p>
<p> Tài khoản của bạn đã bị xóa sau khi bị tạm ngưng vì {$a->timesuspended} </p>
<p> Trân trọng <br/> {$a->signature} </p> ';
$string['email:user:delete:subject']= 'Tài khoản của bạn đã bị xóa';
$string['email:user:suspend:auto:body']= '<p> Kính gửi {$a->name} </p>
<p> Tài khoản của bạn đã bị tạm ngưng sau khi không hoạt động trong {$a->timeinactive} </p>
<p> Nếu bạn cảm thấy điều này là không mong muốn hoặc muốn kích hoạt lại tài khoản của mình,
vui lòng liên hệ {$a->contact} </p>
<p> Trân trọng <br/> {$a->signature} </p> ';
$string['email:user:suspend:manual:body']= '<p> Kính gửi {$a->name} </p>
<p> Tài khoản của bạn đã bị tạm ngưng. </p>
<p> Nếu bạn cảm thấy điều này là không mong muốn hoặc muốn kích hoạt lại tài khoản của mình,
vui lòng liên hệ {$a->contact} </p>
<p> Trân trọng <br/> {$a->signature} </p> ';
$string['email:user:suspend:subject']= 'Tài khoản của bạn đã bị tạm ngưng';
$string['email:user:unsuspend:body']= '<p> Kính gửi {$a->name} </p>
<p> Tài khoản của bạn đã được kích hoạt lại. </p>
<p> Nếu bạn cảm thấy điều này là không mong muốn hoặc muốn tài khoản của mình bị tạm ngưng một lần nữa,
vui lòng liên hệ {$a->contact} </p>
<p> Trân trọng <br/> {$a->signature} </p> ';
$string['email:user:unsuspend:subject']= 'Tài khoản của bạn đã được kích hoạt lại';
$string['err:statustable:set_sql']= 'set_sql () bị tắt. Bảng này xác định nó là của riêng và không thể tùy chỉnh ';
$string['excludeuser']= 'loại trừ người dùng khỏi quá trình xử lý';
$string['form:static:uploadfile:desc']= 'Tải lên tệp tạm ngưng người dùng của bạn tại đây <br/>
Tệp CSV đã tải lên có thể được định cấu hình như sau: <br/>
<ol>
Tệp <li> \'simple \' CHỈ chứa địa chỉ email, một địa chỉ trên mỗi dòng </li>
Tệp <li> \'smart \' chứa 2 cột, cho biết loại và giá trị. <br/>
Các giá trị có thể có cho cột loại là
<ul> <li> email: cột giá trị cho biết địa chỉ e-mail của tài khoản người dùng </li>
<li> idnumber: cột giá trị cho biết idnumber của tài khoản người dùng </li>
<li> tên người dùng: cột giá trị cho biết tên người dùng của tài khoản người dùng </li>
</ul> </ol> ';
$string['info:no-exclusion-cohorts']= 'Không thể định cấu hình thêm nhóm thuần tập để bị loại trừ nữa. Tất cả đều đã được thêm vào danh sách loại trừ ';
$string['label:users:excluded']= 'Người dùng bị loại trừ';
$string['label:users:potential']= 'Người dùng tiềm năng';
$string['link:currentstatus:overview']= 'Xem các thay đổi trạng thái hiện tại';
$string['link:exclude:overview']= 'Tổng quan về loại trừ';
$string['link:log:overview']= 'Xem nhật ký thay đổi trạng thái';
$string['link:upload']= 'Tải lên tệp tạm ngưng';
$string['link:viewstatus']= 'Xem danh sách trạng thái';
$string['msg:exclusion:cohort:none-selected']= 'Không có nhóm thuần tập nào được chọn để loại trừ';
$string['msg:exclusion:record:cohort:inserted']= 'Mục nhập loại trừ cho nhóm thuần tập \' {$a->name} \'được chèn thành công';
$string['msg:exclusion:record:exists']= 'Mục loại trừ đã tồn tại (không thêm bản ghi)';
$string['msg:exclusion:record:inserted']= 'Đã chèn thành công mục loại trừ';
$string['msg:exclusion:records:cohort:deleted']= 'Đã xóa thành công các mục nhập loại trừ cho nhóm thuần tập';
$string['msg:exclusion:records:deleted']= 'Đã xóa thành công các mục loại trừ';
$string['msg:exclusion:records:user:deleted']= 'Đã xóa thành công các mục loại trừ cho người dùng';
$string['msg:exclusion:record:user:deleted']= 'Mục nhập loại trừ cho người dùng \' {$a->fullname} \'đã xóa thành công';
$string['msg:exclusion:record:user:inserted']= 'Mục nhập loại trừ cho người dùng \' {$a->fullname} \'đã được chèn thành công';
$string['msg:file-not-readable']= 'Tập tin đã tải lên \' {$a} \'không thể đọc được';
$string['msg:file-not-writeable']= 'Tệp đã tải lên \' {$a} \'không thể ghi hoặc không thể xóa ';
$string['msg:file:upload:fail']= 'Không thể lưu thành công tệp đã tải lên. Xử lý bị hủy bỏ. ';
$string['msg:user:not-found']= 'không thể tìm thấy người dùng';
$string['msg:user:suspend:failed']= 'Người dùng \' {$a->username} \'không thể bị tạm ngưng';
$string['msg:user:suspend:success']= 'Người dùng \' {$a->username} \'bị tạm ngưng thành công';
$string['msg:user:unsuspend:failed']= 'Người dùng \' {$a->username} \'không thể bị tạm dừng';
$string['msg:user:unsuspend:success']= 'Người dùng \' {$a->username} \'đã hủy tạm dừng thành công';
$string['notify:load-exclude-list']= 'Đang tải danh sách loại trừ người dùng';
$string['notify:load-file']= 'Đang mở tệp \' {$a} \\';
$string['notify:load-file-fail']= 'Không thể mở tệp \' {$a} \'để đọc';
$string['notify:suspend-excluded-user']= 'người dùng: {$a->username} (id = {$a->id}) nằm trong danh sách loại trừ: không tạm ngưng';
$string['notify:suspend-user']= 'tạm ngưng người dùng: {$a->username} (id = {$a->id})';
$string['notify:unknown-suspend-type']= 'Định danh loại hệ thống treo không xác định \' {$a} \\';
$string['page:view:exclude.php:introduction']= '<p> Trang này hiển thị các loại trừ đã định cấu hình. <br/>
Loại trừ là người dùng hoặc nhóm thuần tập bị loại trừ hoàn toàn khỏi bất kỳ quá trình xử lý tự động nào. <br/>
Khi một nhóm thuần tập bị loại trừ, điều này có nghĩa là mọi người dùng là thành viên của nhóm đó sẽ không được xử lý.
Sử dụng các tùy chọn trên trang này để thêm nhóm thuần tập hoặc người dùng vào danh sách loại trừ. </p> ';
$string['page:view:log.php:introduction']= 'Bảng dưới đây hiển thị nhật ký các trạng thái mà người dùng đã được cung cấp hoặc trải qua
kết quả của việc xử lý tự động hoặc sử dụng công cụ này. Nó sẽ hiển thị, tùy thuộc vào cấu hình của bạn, trạng thái tạm ngưng hoặc trạng thái đã xóa
của người dùng tâm trạng của bạn và thời điểm mà các hành động nhất định được thực hiện. ';
$string['page:view:statuslist.php:introduction:delete']= '<p> Tổng quan này hiển thị các tài khoản người dùng sẽ bị xóa trong
khung thời gian đã định cấu hình của cài đặt của công cụ này </p> ';
$string['page:view:statuslist.php:introduction:status']= '<p> Tổng quan này hiển thị những người dùng được giám sát tích cực. <br/>
Người dùng được giám sát chủ động là người dùng được giám sát thực sự (nghĩa là họ không được định cấu hình để bị loại trừ khỏi việc giám sát). <br/>
Do đó, tổng quan này khác với tổng quan của quản trị viên chính là nó sẽ không hiển thị <i> bất kỳ </i> người dùng nào đã bị loại trừ
khỏi giám sát tạm ngừng bằng cách sử dụng các khả năng của công cụ này để loại trừ người dùng và nhóm thuần tập. </p> ';
$string['page:view:statuslist.php:introduction:suspended']= '<p> Phần tổng quan này hiển thị các tài khoản người dùng đã bị tạm ngưng. </p>';
$string['page:view:statuslist.php:introduction:tosuspend']= '<p> Tổng quan này hiển thị các tài khoản người dùng sẽ bị tạm ngưng trong
khung thời gian đã định cấu hình của cài đặt của công cụ này </p> ';
$string['pluginname']= 'Đình chỉ người dùng';
$string['privacy:metadata:tool_usersuspension_excl']= 'Các loại trừ tùy chọn người dùng lưu trữ người dùng bị loại trừ khỏi việc tạm ngưng tự động';
$string['privacy:metadata:tool_usersuspension_log']= 'Trạng thái kích hoạt người dùng lưu trữ thông tin lịch sử / nhật ký về người dùng bị tạm ngưng';
$string['privacy:metadata:tool_usersuspension:mailedto']= 'Địa chỉ e-mail của người dùng được khôi phục';
$string['privacy:metadata:tool_usersuspension:mailsent']= 'Email đã được gửi hay chưa';
$string['privacy:metadata:tool_usersuspension_status']= 'Trạng thái kích hoạt người dùng lưu trữ thông tin về người dùng bị tạm ngừng';
$string['privacy:metadata:tool_usersuspension:status']= 'Suspensionstatus';
$string['privacy:metadata:tool_usersuspension:timecreated']= 'Thời gian bản ghi được tạo.';
$string['privacy:metadata:tool_usersuspension:type']= 'Loại loại trừ Schorsings (altijd \' user \').';
$string['privacy:metadata:tool_usersuspension:userid']= 'Khóa chính của người dùng Moodle mà tài khoản đã được khôi phục.';
$string['promo']= 'plugin kích hoạt người dùng cho Moodle';
$string['promodesc']= 'Plugin này được viết bởi Sebsoft Managed Hosting & Software Development
(<a href=\'http://www.sebsoft.nl/\' target=\'_new\'> http://sebsoft.nl </a>). <br /> <br />
{$a} <br /> <br /> ';
$string['setting:cleanlogsafter']= 'Tần suất nhật ký sạch';
$string['setting:cleanup_deleteafter']= 'Khoảng thời gian xóa';
$string['setting:cleanup_interval']= 'Khoảng thời gian dọn dẹp';
$string['setting:desc:cleanlogsafter']= 'Định cấu hình tần suất mà sau đó các bản ghi được làm sạch. Bất kỳ nhật ký nào cũ hơn cài đặt này sẽ bị xóa. ';
$string['setting:desc:cleanup_deleteafter']= 'Đặt khoảng thời gian mà người dùng bị xóa sau khi tạm ngừng';
$string['setting:desc:cleanup_interval']= 'Đặt khoảng thời gian thực hiện dọn dẹp';
$string['setting:desc:enablecleanlogs']= 'Bật hoặc tắt tính năng tự động xóa nhật ký lịch sử.';
$string['setting:desc:enablecleanup']= 'Bật hoặc tắt tính năng dọn dẹp của người dùng';
$string['setting:desc:enabled']= 'Bật hoặc tắt tiện ích tạm ngưng người dùng';
$string['setting:desc:enablefromfolder']= 'Bật hoặc tắt tiện ích tạm ngưng người dùng để tự động tạm ngưng người dùng khỏi tệp CSV đã tải lên';
$string['setting:desc:enablefromupload']= 'Bật hoặc tắt tiện ích tạm ngưng người dùng từ tải tệp lên';
$string['setting:desc:enablesmartdetect']= 'Bật hoặc tắt tính năng phát hiện thông minh của tiện ích tạm ngưng người dùng.';
$string['setting:desc:senddeleteemail']= 'Gửi e-mail thông báo cho người dùng sau khi bị xóa?';
$string['setting:desc:sendsuspendemail']= 'Gửi e-mail thông báo cho người dùng sau khi bị đình chỉ?';
$string['setting:desc:smartdetect_interval']= 'Đặt khoảng thời gian phát hiện thông minh chạy';
$string['setting:desc:smartdetect_suspendafter']= 'Đặt khoảng thời gian người dùng bị tạm ngưng khi không hoạt động';
$string['setting:desc:uploaddetect_interval']= 'Đặt khoảng thời gian mà tại đó thư mục tải lên được kiểm tra các tệp tin';
$string['setting:desc:uploadfilename']= 'Đặt tên tệp của tệp tạm ngưng đã tải lên';
$string['setting:desc:uploadfolder']= 'Đặt thư mục nơi các tệp sẽ được tải lên qua ví dụ: FTP ';
$string['setting:enablecleanlogs']= 'Cho phép dọn dẹp logcleạch';
$string['setting:enablecleanup']= 'Bật Dọn dẹp';
$string['setting:enabled']= 'Bật';
$string['setting:enablefromfolder']= 'Tự động tạm ngưng sử dụng tệp CSV được lưu trữ';
$string['setting:enablefromupload']= 'Cho phép tải lên';
$string['setting:enablesmartdetect']= 'Bật tính năng phát hiện thông minh';
$string['setting:senddeleteemail']= 'Gửi xóa email?';
$string['setting:sendsuspendemail']= 'Gửi email tạm ngưng?';
$string['setting:smartdetect_interval']= 'Khoảng thời gian phát hiện thông minh';
$string['setting:smartdetect_suspendafter']= 'Khoảng thời gian tạm ngừng hoạt động';
$string['setting:uploaddetect_interval']= 'Khoảng thời gian xử lý thư mục tải lên';
$string['setting:uploadfilename']= 'Tải tên tệp lên';
$string['setting:uploadfolder']= 'Tải lên thư mục';
$string['status:deleted']= 'đã xóa';
$string['status:suspended']= 'bị treo';
$string['status:unsuspended']= 'chưa tạm dừng';
$string['suspensionsettings']= 'Cài đặt Tạm ngưng Người dùng';
$string['suspensionsettingscleanup']= 'Dọn dẹp';
$string['suspensionsettingscleanupdesc']= 'Định cấu hình cài đặt dọn dẹp bên dưới. <br/>
Quá trình dọn dẹp ở đây để tự động hóa hơn nữa việc dọn dẹp người dùng, có nghĩa là các tài khoản người dùng bị tạm ngưng sẽ bị xóa
khi tùy chọn này được sử dụng. Nếu tài khoản người dùng sẽ tự động bị xóa sau một thời gian nhất định, bạn nên định cấu hình các cài đặt này.
Nếu bạn không muốn tự động xóa tài khoản người dùng, bạn nên tắt tùy chọn này. ';
$string['suspensionsettingsdesc']= '';
$string['suspensionsettingsfolder']= 'Tạm ngừng từ thư mục';
$string['suspensionsettingsfolderdesc']= 'Định cấu hình cài đặt thư mục \' tạm ngưng từ thư mục \'bên dưới. <br/>
Sử dụng các cài đặt này, bạn có thể tự động tạm ngưng người dùng bằng cách tải tệp CSV lên một vị trí ngẫu nhiên trên máy chủ
(ví dụ một thư mục FTP chuyên dụng). Tệp CSV sẽ được xử lý theo cài đặt bên dưới.
Lưu ý: Tệp CSV đã tải lên sẽ bị xóa sau khi xử lý! ';
$string['suspensionsettingssmartdetect']= 'Phát hiện thông minh';
$string['suspensionsettingssmartdetectdesc']= 'Định cấu hình cài đặt phát hiện thông minh bên dưới. <br/>
Phát hiện thông minh hiệu quả có nghĩa là các tài khoản người dùng đã được tìm thấy \'không hoạt động \' theo cài đặt bên dưới sẽ
tự động bị tạm ngưng. Chỉ chạy trong khoảng thời gian đã định cấu hình, \'phát hiện thông minh \' sẽ xác định xem có tài khoản người dùng hay không
đang hoạt động theo cài đặt \'Khoảng thời gian tạm ngưng không hoạt động \' được định cấu hình và tạm ngưng tất cả các tài khoản người dùng được coi là không hoạt động. ';
$string['suspensionsettingsupload']= 'Tạm ngừng tải lên';
$string['suspensionsettingsuploaddesc']= 'Định cấu hình cài đặt \' tạm ngừng tải lên \'bên dưới';
$string['table:exclusions']= 'Loại trừ';
$string['table:log:all']= 'Nhật ký tạm ngưng lịch sử';
$string['table:log:latest']= 'Nhật ký tạm ngưng mới nhất';
$string['table:logs']= 'Nhật ký';
$string['table:status:delete']= 'Người dùng cần xóa';
$string['table:status:status']= 'Người dùng được giám sát tích cực';
$string['table:status:suspended']= 'Người dùng bị tạm ngưng';
$string['table:status:tosuspend']= 'Người dùng tạm ngưng';
$string['task:delete']= 'Tác vụ Usersuspension: tự động loại bỏ những người dùng bị treo';
$string['task:fromfolder']= 'Tác vụ Usersuspension: tự động tạm ngưng người dùng từ tệp đã tải lên';
$string['task:logclean']= 'Làm sạch nhật ký để tạm ngưng người dùng';
$string['task:mark']= 'Tác vụ Usersuspension: tự động tạm ngưng người dùng';
$string['thead:action']= '(Các) hành động';
$string['thead:lastlogin']= 'Lần đăng nhập cuối cùng';
$string['thead:mailedto']= 'Đã gửi e-mail tới';
$string['thead:mailsent']= 'Đã gửi e-mail';
$string['thead:name']= 'Tên';
$string['thead:status']= 'Trạng thái';
$string['thead:timecreated']= 'Thời gian được tạo';
$string['thead:timemodified']= 'Thời gian đã sửa đổi';
$string['thead:type']= 'Loại';
$string['thead:userid']= 'ID người dùng';
$string['thead:username']= 'Tên người dùng';
