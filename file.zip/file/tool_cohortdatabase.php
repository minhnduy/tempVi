<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_cohortdatabase', language 'en', branch 'MOODLE_35_STABLE'
 *
 * @package   tool_cohortdatabase
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['createusers_auth']= 'Xác thực';
$string['createusers_auth_desc']= 'Loại xác thực cần đặt cho những người dùng này.';
$string['createusers_email']= 'Email từ xa';
$string['createusers_email_desc']= 'Tên của trường trong bảng từ xa có chứa email';
$string['createusers_firstname']= 'Tên từ xa';
$string['createusers_firstname_desc']= 'Tên của trường trong bảng từ xa có chứa tên đầu tiên';
$string['createusers_idnumber']= 'Mã số từ xa';
$string['createusers_idnumber_desc']= 'Tên của trường trong bảng từ xa có chứa idnumber';
$string['createusers_lastname']= 'Họ từ xa';
$string['createusers_lastname_desc']= 'Tên của trường trong bảng từ xa có chứa họ';
$string['createusers_username']= 'Tên người dùng từ xa';
$string['createusers_username_desc']= 'Tên của trường trong bảng từ xa có chứa tên người dùng';
$string['dbencoding']= 'Mã hóa cơ sở dữ liệu';
$string['dbhost']= 'Máy chủ cơ sở dữ liệu';
$string['dbhost_desc']= 'Nhập địa chỉ IP máy chủ cơ sở dữ liệu hoặc tên máy chủ. Sử dụng tên DSN hệ thống nếu sử dụng ODBC. ';
$string['dbname']= 'Tên cơ sở dữ liệu';
$string['dbname_desc']= 'Để trống nếu sử dụng tên DSN trong máy chủ cơ sở dữ liệu.';
$string['dbpass']= 'Mật khẩu cơ sở dữ liệu';
$string['dbsetupsql']= 'Lệnh thiết lập cơ sở dữ liệu';
$string['dbsetupsql_desc']= 'Lệnh SQL để thiết lập cơ sở dữ liệu đặc biệt, thường được sử dụng để thiết lập mã hóa giao tiếp - ví dụ cho MySQL và PostgreSQL: <em> SET NAMES \' utf8 \'</em>';
$string['dbsybasequoting']= 'Sử dụng dấu ngoặc kép sybase';
$string['dbsybasequoting_desc']= 'Thoát trích dẫn đơn kiểu Sybase - cần thiết cho Oracle, MS SQL và một số cơ sở dữ liệu khác. Không sử dụng cho MySQL! ';
$string['dbtype']= 'Trình điều khiển cơ sở dữ liệu';
$string['dbtype_desc']= 'Tên trình điều khiển cơ sở dữ liệu ADOdb, loại công cụ cơ sở dữ liệu bên ngoài.';
$string['dbuser']= 'Người dùng cơ sở dữ liệu';
$string['debugdb']= 'Gỡ lỗi ADOdb';
$string['debugdb_desc']= 'Gỡ lỗi kết nối ADOdb với cơ sở dữ liệu bên ngoài - sử dụng khi nhận được trang trống trong khi đăng nhập. Không phù hợp với nơi sản xuất! ';
$string['keepincohort']= 'Giữ trong nhóm thuần tập';
$string['localuserfield']= 'Trường người dùng cục bộ';
$string['minrecords']= 'Bản ghi tối thiểu';
$string['minrecords_desc']= 'Ngăn không cho chạy đồng bộ nếu số bản ghi được trả về trong bảng bên ngoài thấp hơn số này (giúp ngăn chặn việc xóa người dùng khi bảng bên ngoài trống).';
$string['pluginname']= 'Cơ sở dữ liệu bên ngoài theo nhóm';
$string['pluginname_desc']= 'Bạn có thể sử dụng cơ sở dữ liệu bên ngoài (gần như bất kỳ loại nào) để kiểm soát các nhóm của mình.';
$string['privacy:metadata']= 'Plugin cơ sở dữ liệu Nhóm thuần tập không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['remotecohortdescfield']= 'Trường mô tả nhóm thuần tập từ xa';
$string['remotecohortdescfield_desc']= 'Tên của trường trong bảng từ xa mà chúng tôi đang sử dụng để khớp với các mục nhập trong bảng thuần tập.';
$string['remotecohortidfield']= 'Trường id nhóm từ xa';
$string['remotecohortidfield_desc']= 'Tên của trường trong bảng từ xa mà chúng tôi đang sử dụng để khớp với các mục nhập trong bảng thuần tập.';
$string['remotecohortnamefield']= 'Trường tên nhóm từ xa';
$string['remotecohortnamefield_desc']= 'Tên của trường trong bảng từ xa mà chúng tôi đang sử dụng để khớp với các mục nhập trong bảng thuần tập.';
$string['remotecohorttable']= 'Bảng thuần tập người dùng từ xa';
$string['remotecohorttable_desc']= 'Chỉ định tên của bảng chứa danh sách các nhóm người dùng.';
$string['remoteuserfield']= 'Trường người dùng từ xa';
$string['remoteuserfield_desc']= 'Tên của trường trong bảng từ xa mà chúng tôi đang sử dụng để khớp với các mục nhập trong bảng người dùng.';
$string['removedaction']= 'Hành động xóa bên ngoài';
$string['removedaction_desc']= 'Chọn hành động để thực hiện khi người dùng biến mất khỏi nguồn nhóm thuần tập bên ngoài. Xin lưu ý rằng một số dữ liệu người dùng và cài đặt sẽ bị xóa khỏi khóa học nếu điều này được đồng bộ hóa với đăng ký khóa học. ';
$string['removefromcohort']= 'Xóa khỏi nhóm thuần tập';
$string['settingscreateusers']= 'Tạo người dùng';
$string['settingscreateusers_desc']= 'Tạo người dùng nếu họ không tồn tại.';
$string['settingsheaderdb']= 'Kết nối cơ sở dữ liệu bên ngoài';
$string['settingsheaderlocal']= 'Ánh xạ trường cục bộ';
$string['settingsheaderremote']= 'Đồng bộ hóa nhóm từ xa';
$string['sync']= 'Đồng bộ hóa nhóm với cơ sở dữ liệu bên ngoài';
