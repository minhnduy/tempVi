<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_organisation', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_organisation
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['actions']= 'Hành động';
$string['addchilddepartment']= 'Phân khu mới cho bộ phận \' {$a} \\';
$string['addchildposition']= 'Vị trí con mới cho vị trí \' {$a} \\';
$string['adddepartment']= 'Bộ phận mới cho khung \' {$a} \\';
$string['adddepartmentframework']= 'Khung phòng ban mới';
$string['addjob']= 'Công việc mới';
$string['addjobforuser']= 'Công việc mới cho \' {$a} \\';
$string['addposition']= 'Vị trí mới cho khung \' {$a} \\';
$string['addpositionframework']= 'Khung vị trí mới';
$string['allframeworks']= 'Khung chức vụ và vị trí';
$string['anydepartment']= 'Bất kỳ';
$string['anyposition']= 'Bất kỳ';
$string['assfirstchildof']= 'Là con đầu tiên của \' {$a} \\';
$string['audienceand']= 'Và';
$string['audiencecustomise']= 'Tùy chỉnh ...';
$string['audienceor']= 'Hoặc';
$string['audienceselect']= 'Liên quan đến người xem báo cáo';
$string['audienceselectinitial']= 'Chọn đối tượng';
$string['audienceself']= 'Chính họ';
$string['audienceusersall']= 'Tất cả người dùng';
$string['audienceusersdept']= 'Ở cùng bộ phận với người xem báo cáo';
$string['audienceusersreporting']= 'Báo cáo cho người xem báo cáo';
$string['audienceusersreporting_help']= 'Bao gồm những người dùng báo cáo trực tiếp với người xem báo cáo (những người này nên có vị trí quản lý của chính họ)';
$string['cachedef_myjob']= 'Công việc của người dùng hiện tại và nhóm của họ';
$string['conditioncanallocateprograms']= 'Có thể cấp phát cho các chương trình';
$string['conditioncanreceivenotifications']= 'Có thể nhận thông báo';
$string['conditioncanviewreports']= 'Có thể xem báo cáo';
$string['conditionuserdepartment']= 'Người dùng đang ở trong bộ phận';
$string['conditionuserdepartmentdescription']= 'Người dùng được phân bổ cho bộ phận \' {$a->deptname} \'<br />
Các chi cục: {$a->subdeptsinclude} ';
$string['conditionuserdepartmentdescriptionnegated']= 'Người dùng không được phân bổ cho bộ phận \' {$a->deptname} \'<br />
Các chi cục: {$a->subdeptsinclude} ';
$string['conditionuserdepartmentdescriptionwithdate']= 'Người dùng được phân bổ cho bộ phận \' {$a->deptname} \'<br />
Các chi cục: {$a->subdeptsinclude} <br />
Bật hoặc sau: {$a->conditiondate} ';
$string['conditionusernotindepartment']= 'Người dùng không ở trong bộ phận';
$string['conditionuserposition']= 'Người dùng có vị trí';
$string['conditionuserpositiondescription']= 'Người dùng có vị trí \' {$a->posname} \'<br />
Các vị trí phụ: {$a->subposinclude} ';
$string['conditionuserpositiondescriptionnegated']= 'Người dùng không có vị trí \' {$a->posname} \'<br />
Các vị trí phụ: {$a->subposinclude} ';
$string['conditionuserpositiondescriptionwithdate']= 'Người dùng có vị trí \' {$a->posname} \'<br />
Vị trí phụ: {$a->subposinclude} <br />
Bật hoặc sau: {$a->conditiondate} ';
$string['conditionuserwithoutposition']= 'Người dùng không có vị trí';
$string['creategenericframework']= 'Tạo một khuôn khổ chung';
$string['delete']= 'Xóa';
$string['deletedepartment']= 'Xóa bộ phận \' {$a} \\';
$string['deletedepartmentconfirm']= 'Bạn có chắc chắn muốn xóa bộ phận \' {$a} \'?';
$string['deletedepartmentframework']= 'Xóa khung bộ phận \' {$a} \\';
$string['deletedepartmentframeworkconfirm']= 'Bạn có chắc chắn muốn xóa khung phòng ban \' {$a} \'?';
$string['deleteposition']= 'Xóa vị trí \' {$a} \\';
$string['deletepositionconfirm']= 'Bạn có chắc chắn muốn xóa vị trí \' {$a} \'?';
$string['deletepositionframework']= 'Xóa khung vị trí \' {$a} \\';
$string['deletepositionframeworkconfirm']= 'Bạn có chắc chắn muốn xóa khung vị trí \' {$a} \'?';
$string['department']= 'Cục';
$string['departmentandpositionrequiredforjobcreate']= 'Các phòng ban và vị trí cần được tạo để tiến hành phân công công việc';
$string['departmentdeleted']= 'Phòng ban đã được xóa thành công';
$string['departmentdescription']= 'Mô tả';
$string['departmentframework']= 'Khung phòng ban';
$string['departmentframeworkpostfix']= '{$a} (Bộ khung)';
$string['departmentframeworks']= 'Khuôn khổ bộ phận';
$string['departmentfrmidnumberconflict']= 'Số ID của khung phòng ban đã tồn tại';
$string['departmenthasjobs']= 'Không thể xóa phòng ban vì có các công việc liên quan đến nó.';
$string['department_help']= 'Chọn bộ phận';
$string['departmentidentifier']= 'Định danh phòng ban';
$string['departmentidentifier_help']= 'Đây là cột xác định hàng trong CSV, nó sẽ được sử dụng để tìm hàng chính';
$string['departmentidnumber']= 'Số ID';
$string['departmentidnumberconflict']= 'Số ID phòng ban đã tồn tại';
$string['departmentmanagementicons']= 'Biểu tượng quản lý bộ phận';
$string['departmentmanager']= 'Trưởng phòng';
$string['departmentmanager_help']= 'Một người có công việc lãnh đạo bộ phận sẽ được coi là người quản lý của bất kỳ ai trong cùng bộ phận hoặc một bộ phận, bất kể vị trí của họ.';
$string['departmentname']= 'Tên';
$string['departmentnotfound']= 'Không tìm thấy bộ phận';
$string['departmentparent']= 'Cha mẹ';
$string['departmentrequiredforjobcreate']= 'Các phòng ban cần được tạo để tiến hành phân công công việc';
$string['departments']= 'Phòng ban';
$string['departmentwithicons']= 'Biểu tượng trưởng bộ phận';
$string['details']= 'Chi tiết';
$string['editdepartment']= 'Chỉnh sửa bộ phận \' {$a} \\';
$string['editdepartmentframework']= 'Chỉnh sửa khung phòng ban \' {$a} \\';
$string['editdepartmentname']= 'Chỉnh sửa tên';
$string['editjob']= 'Chỉnh sửa công việc';
$string['editjobforuser']= 'Chỉnh sửa lệnh cho \' {$a} \\';
$string['editposition']= 'Chỉnh sửa vị trí \' {$a} \\';
$string['editpositionframework']= 'Chỉnh sửa khung vị trí \' {$a} \\';
$string['editpositionname']= 'Chỉnh sửa tên';
$string['enddate']= 'Ngày kết thúc';
$string['enddate_help']= 'Ngày kết thúc công việc';
$string['entitydepartment']= 'Cục';
$string['entityjob']= 'Công việc';
$string['entityposition']= 'Chức vụ';
$string['errorcreatingdepartment']= 'Đã xảy ra lỗi khi tạo bộ phận. Vui lòng thử lại.';
$string['errorcreatingjob']= 'Đã xảy ra lỗi khi tạo công việc. Vui lòng thử lại.';
$string['errorcreatingposition']= 'Đã xảy ra lỗi khi tạo vị trí. Vui lòng thử lại.';
$string['errorcsvinvalidparentmapping']= 'Ánh xạ cho trường \' Gốc \'không thể giống với mã định danh';
$string['errorcsvnohierarchy']= 'Khi phân cấp không được chọn, cột \' Gốc \'không thể có ánh xạ';
$string['errorcsvnoparent']= 'Khi phân cấp được chọn, cột \' Gốc \'phải có ánh xạ';
$string['erroridnumberdepartment']= 'Phòng có số ID \' {$a} \'đã tồn tại';
$string['erroridnumberposition']= 'Vị trí có số ID \' {$a} \'đã tồn tại';
$string['errorinvaliddepartment']= 'Bộ phận không hợp lệ';
$string['errorinvalidposition']= 'Vị trí không hợp lệ';
$string['errormovehierarchy']= 'Đã xảy ra lỗi khi di chuyển vị trí hoặc bộ phận sang vị trí phân cấp khác.';
$string['errorparentnotfound']= 'Không tìm thấy trang gốc';
$string['errorparentnotfounddepartment']= 'Không tìm thấy cấp độ gốc cho bộ phận có số id \' {$a} \\';
$string['errorparentnotfoundposition']= 'Không tìm thấy cấp độ gốc cho vị trí có số id \' {$a} \\';
$string['errorsameidnumberdepartment']= 'Phòng có cùng số ID đã tồn tại';
$string['errorsameidnumberposition']= 'Vị trí có cùng số ID đã tồn tại';
$string['eventdepartmentcreated']= 'Bộ phận được tạo';
$string['eventdepartmentdeleted']= 'Phòng bị xóa';
$string['eventdepartmentupdated']= 'Bộ phận được cập nhật';
$string['eventjobcreated']= 'Công việc đã tạo';
$string['eventjobdeleted']= 'Đã xóa công việc';
$string['eventjobupdated']= 'Đã cập nhật công việc';
$string['eventpositioncreated']= 'Vị trí đã tạo';
$string['eventpositiondeleted']= 'Vị trí đã bị xóa';
$string['eventpositionupdated']= 'Đã cập nhật vị trí';
$string['expanddepartmentframework']= 'Mở rộng khuôn khổ bộ phận \' {$a} \\';
$string['expandpositionframework']= 'Mở rộng khung vị trí \' {$a} \\';
$string['exporterjobs']= 'Cơ cấu tổ chức công việc';
$string['exporterjobsdesc']= 'Công việc với bộ phận liên quan và khung vị trí của họ';
$string['exporterorgstructure']= 'Khung cấu trúc tổ chức';
$string['exporterorgstructurecsv']= 'Khung cấu trúc tổ chức (CSV)';
$string['exporterorgstructuredesc']= 'Khung với toàn bộ hệ thống phân cấp cho các phòng ban và / hoặc các vị trí';
$string['exportframeworkssettings']= 'Mô tả, phân cấp và quyền';
$string['frameworks']= 'Khung';
$string['fullcompletionreport']= 'Báo cáo hoàn thành đầy đủ';
$string['fullname']= 'Người dùng';
$string['globalmanagementicons']= 'Biểu tượng trình quản lý';
$string['globalmanager']= 'Người quản lý';
$string['globalmanager_help']= 'Một người với công việc quản lý sẽ được coi là người quản lý của bất kỳ ai ở vị trí thấp hơn, bất kể họ ở bộ phận nào.';
$string['hasjobdepartment']= 'Có công việc trong bộ phận';
$string['hasjobposition']= 'Có công việc đúng vị trí';
$string['hierarchy']= 'Hệ thống phân cấp';
$string['hierarchydepartments']= 'Hệ thống phân cấp của các phòng ban ...';
$string['hierarchypositions']= 'Thứ bậc của các vị trí ...';
$string['importerdepartmentscsv']= 'Nhà nhập khẩu bộ phận (CSV)';
$string['importerdepartmentscsvdesc']= 'Các phòng ban có hoặc không có hệ thống phân cấp được nhập vào một khuôn khổ';
$string['importerpositionscsv']= 'Trình nhập vị trí (CSV)';
$string['importerpositionscsvdesc']= 'Các vị trí có hoặc không có phân cấp được nhập vào một khuôn khổ';
$string['importlogdeptfailed']= 'Không thể nhập bộ phận \' {$a->name} \\';
$string['importlogdeptfrmfailed']= 'Không thể nhập khuôn khổ bộ phận \' {$a->name} \\';
$string['importlogdeptfrmsuccess']= 'Đã tạo khung phòng ban mới \' <a href="{$a->url}"> {$a->name} </a> \\';
$string['importlogdeptsuccess']= 'Đã tạo bộ phận mới \' {$a->name} \\';
$string['importlogidnumberexistsdepartment']= 'Phòng có số ID \' {$a->originalidnumber} \'đã tồn tại';
$string['importlogidnumberexistsposition']= 'Vị trí có số ID \' {$a->originalidnumber} \'đã tồn tại';
$string['importlogjobfailed']= 'Không thể nhập lệnh cho \' {$a->userfullname} \'- {$a->position} ({$a->department})';
$string['importlogjobsuccess']= 'Đã tạo công việc mới cho \' <a href="{$a->url}"> {$a->userfullname} </a> \'- {$a->position} ( {$a->department}) ';
$string['importlogposfailed']= 'Không thể nhập vị trí \' {$a->name} \\';
$string['importlogposfrmfailed']= 'Không thể nhập khung vị trí \' {$a->name} \\';
$string['importlogposfrmsuccess']= 'Đã tạo khung vị trí mới \' <a href="{$a->url}"> {$a->name} </a> \\';
$string['importlogpossuccess']= 'Đã tạo vị trí mới \' {$a->name} \\';
$string['jobdeleteconfirm']= 'Bạn có chắc chắn muốn xóa công việc này và tất cả dữ liệu liên quan không? Hành động này không thể được hoàn tác.';
$string['jobdeleted']= 'Công việc đã được xóa thành công';
$string['jobfrom']= 'Từ {$a}';
$string['jobfromto']= 'Từ {$a->from} đến {$a->to}';
$string['jobnotfound']= 'Không tìm thấy công việc';
$string['jobpositiondepartment']= 'Chức vụ và bộ phận';
$string['jobs']= 'Nhiệm vụ công việc';
$string['jobsnumber']= 'Việc làm';
$string['jobsnumber_help']= 'Hiển thị công việc đang hoạt động và công việc trước đây. <br /> Ví dụ \'10 (2) \' có nghĩa là có 10 công việc đang hoạt động và 2 công việc trong quá khứ. ';
$string['jobstartdateafter']= 'Ngày bắt đầu công việc là vào hoặc sau';
$string['listdeptsnohierarchy']= 'Danh sách các phòng ban không có hệ thống phân cấp';
$string['listposnohierarchy']= 'Danh sách các vị trí không có phân cấp';
$string['mappingerrordeptnotfound']= 'Không tìm thấy bộ phận {$a}';
$string['mappingerrorposnotfound']= 'Không tìm thấy vị trí {$a}';
$string['mappingnoticenodeptidnumber']= 'Bộ phận được đặt theo tên vì số ID trống. Nên gán số ID cho các phòng ban ';
$string['mappingnoticenoposidnumber']= 'Vị trí được xác định theo tên vì số ID trống. Nên gán số ID cho các vị trí ';
$string['missingdepartment']= 'Bộ phận bị thiếu';
$string['missingposition']= 'Vị trí bị thiếu';
$string['missingusers']= 'Thiếu (các) người dùng';
$string['movedepartmentframework']= 'Di chuyển khung bộ phận \' {$a} \\';
$string['movepositionframework']= 'Di chuyển khung vị trí \' {$a} \\';
$string['myteams']= 'Nhóm';
$string['newframework']= 'Khung mới';
$string['newnamefor']= 'Tên mới cho \' {$a} \\';
$string['notification']= 'Thông báo';
$string['notificationcannotcreatejobs']= 'Trước khi giao việc cho người dùng, hãy tạo một số phòng ban và vị trí.';
$string['onlycurrent']= 'Chỉ hiện tại';
$string['onlyfuture']= 'Chỉ tương lai';
$string['onlypast']= 'Chỉ quá khứ';
$string['onorafter']= 'on or after';
$string['organisationadmintab']= 'Tổ chức';
$string['organisation:allocateuserstoprogramcertificationsdept']= 'Phân bổ người dùng cho các chương trình / chứng chỉ';
$string['organisation:allocateuserstoprogramcertificationsdept_help']= 'Trưởng bộ phận: Phân bổ người dùng cho các chương trình / chứng chỉ';
$string['organisation:allocateuserstoprogramcertificationsglob']= 'Phân bổ người dùng cho các chương trình / chứng chỉ';
$string['organisation:allocateuserstoprogramcertificationsglob_help']= 'Người quản lý: Phân bổ người dùng cho các chương trình / chứng chỉ';
$string['organisation:assignjobs']= 'Giao việc';
$string['organisation:managedepartments']= 'Quản lý các phòng ban';
$string['organisation:managepositions']= 'Quản lý vị trí';
$string['organisation:receivenotificationsdept']= 'Nhận thông báo';
$string['organisation:receivenotificationsdept_help']= 'Trưởng phòng: Nhận thông báo';
$string['organisation:receivenotificationsglob']= 'Nhận thông báo';
$string['organisation:receivenotificationsglob_help']= 'Người quản lý: Nhận thông báo';
$string['organisation:viewusersreportdept']= 'Xem báo cáo của người dùng';
$string['organisation:viewusersreportdept_help']= 'Trưởng bộ phận: Xem báo cáo của người dùng';
$string['organisation:viewusersreportglob']= 'Xem báo cáo của người dùng';
$string['organisation:viewusersreportglob_help']= 'Người quản lý: Xem báo cáo của người dùng';
$string['orgfiltercustomise']= 'Tùy chỉnh';
$string['orgfilterdirectreports']= 'Chỉ hiển thị các báo cáo trực tiếp của riêng tôi';
$string['orgfiltereverybody']= 'Cho mọi người báo cáo với tôi';
$string['orgstructure']= 'Cơ cấu tổ chức';
$string['pluginname']= 'Cơ cấu tổ chức';
$string['position']= 'Chức vụ';
$string['positionanddepartmentdisplay']= Dahdhaybf-104-b-41f-f-bskh-3456 f-dah-aakh (fidt-422-215d-4-sa4-057-13a-khif-tfs) a;
$string['positiondeleted']= 'Vị trí đã được xóa thành công.';
$string['positiondescription']= 'Mô tả';
$string['positionframework']= 'Khung vị trí';
$string['positionframeworkpostfix']= '{$a} (Khung vị trí)';
$string['positionframeworks']= 'Khung vị trí';
$string['positionfrmidnumberconflict']= 'Số ID khung vị trí đã tồn tại';
$string['positionhasjobs']= 'Không thể xóa vị trí vì có công việc liên quan đến nó.';
$string['position_help']= 'Chọn vị trí';
$string['positionidentifier']= 'Định danh vị trí';
$string['positionidentifier_help']= 'Đây là cột xác định hàng trong CSV, nó sẽ được sử dụng để tìm hàng chính';
$string['positionidnumber']= 'Số ID';
$string['positionidnumberconflict']= 'Số ID vị trí đã tồn tại';
$string['positionname']= 'Tên';
$string['positionnotfound']= 'Không tìm thấy vị trí';
$string['positionparent']= 'Cha mẹ';
$string['positionpermissions']= 'Quyền';
$string['positionrequiredforjobcreate']= 'Các vị trí cần được tạo để tiến hành phân công công việc.';
$string['positions']= 'Vị trí';
$string['positionwithicons']= 'Vị trí với các biểu tượng quản lý';
$string['privacy:metadata:department']= 'Bộ phận công việc';
$string['privacy:metadata:enddate']= 'Khi công việc này kết thúc';
$string['privacy:metadata:jobssummary']= 'Tóm tắt công việc';
$string['privacy:metadata:position']= 'Vị trí công việc';
$string['privacy:metadata:startdate']= 'Khi công việc này bắt đầu';
$string['privacy:metadata:timecreated']= 'Khi công việc này được tạo ra';
$string['privacy:metadata:timemodified']= 'Khi công việc này được sửa đổi lần cuối';
$string['privacy:metadata:userid']= 'Id người dùng';
$string['reg_wpdepartmentframeworks']= 'Số khuôn khổ bộ phận ({$a})';
$string['reg_wpdepartments']= 'Số phòng ban ({$a})';
$string['reg_wpjobs']= 'Số lượng công việc ({$a})';
$string['reg_wppositionframeworks']= 'Số khung vị trí ({$a})';
$string['reg_wppositions']= 'Số vị trí ({$a})';
$string['rolemanager']= 'Người quản lý cơ cấu tổ chức';
$string['rolemanagerdescription']= 'Cho phép tạo và quản lý công việc, vị trí và phòng ban trong người thuê hiện tại';
$string['roleslist']= 'Vai trò';
$string['selectallactivejobs']= 'Chọn tất cả các công việc đang hoạt động';
$string['selectalldepartmentframeworks']= 'Chọn tất cả các khuôn khổ phòng ban';
$string['selectallframeworks']= 'Chọn tất cả các khuôn khổ phòng ban và vị trí';
$string['selectalljobs']= 'Chọn tất cả các công việc đang hoạt động và trước đây';
$string['selectalljobsinfile']= 'Chọn tất cả công việc trong tập tin này';
$string['selectalljobsinframeworks']= 'Chọn tất cả công việc trong bất kỳ khuôn khổ nào đã chọn ...';
$string['selectallpositionframeworks']= 'Chọn tất cả các khung vị trí';
$string['selectexistingframework']= 'Chọn khung hiện có';
$string['select_framework']= 'Chọn khung';
$string['selectjobsinframeworks']= 'Chọn tất cả các công việc từ các khung cụ thể ...';
$string['showjobs']= 'Hiển thị công việc';
$string['showpastjobs']= 'Hiển thị công việc trước đây';
$string['somedepartmentsdonotexist']= 'Một số phòng ban không tồn tại';
$string['somepositionsdonotexist']= 'Một số vị trí không tồn tại';
$string['startdate']= 'Ngày bắt đầu';
$string['startdate_help']= 'Ngày bắt đầu công việc';
$string['timecreated']= 'Thời gian được tạo';
$string['usernotfound']= 'Không tìm thấy người dùng';
$string['users']= 'Chọn người dùng';
$string['users_help']= 'Tìm kiếm và chọn người dùng để giao việc';
$string['validationmsgedateonsdate']= 'Ngày kết thúc phải sau ngày bắt đầu.';
$string['withoutpermission']= 'Không được phép \' {$a} \\';
$string['withpermission']= 'Với sự cho phép \' {$a} \\';
$string['withsubdepartments']= 'Bao gồm các ngăn phụ';
$string['withsubpositions']= 'Bao gồm các vị trí con';
