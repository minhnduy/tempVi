<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'webinar', language 'en', branch 'MOODLE_26_STABLE'
 *
 * @package   webinar
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['addingsession']= 'Thêm một phiên mới';
$string['addmanageremailaddress']= 'Thêm địa chỉ email của người quản lý';
$string['addmanageremailinstruction']= 'Trước đây bạn chưa nhập địa chỉ email của người quản lý của mình. Vui lòng nhập nó vào bên dưới để đăng ký phiên này. ';
$string['addnewfield']= 'Thêm trường tùy chỉnh mới';
$string['addnewfieldlink']= 'Tạo một trường tùy chỉnh mới';
$string['addnewnotice']= 'Thêm thông báo trang web mới';
$string['addnewnoticelink']= 'Tạo một thông báo trang web mới';
$string['addremoveattendees']= 'Thêm / xóa người tham dự';
$string['addsession']= 'Thêm một phiên mới';
$string['addstudent']= 'Thêm sinh viên';
$string['alllocations']= 'Tất cả các vị trí';
$string['allowoverbook']= 'Cho phép đặt trước quá nhiều';
$string['allsessionsin']= 'Tất cả các phiên';
$string['alreadysignedup']= 'Bạn đã đăng ký hoạt động Hội thảo trên web này.';
$string['answer']= 'Đăng nhập';
$string['answercancel']= 'Đăng xuất';
$string['approvalreqd']= 'Yêu cầu phê duyệt';
$string['approve']= 'Phê duyệt';
$string['assessmentyour']= 'Đánh giá của bạn';
$string['attendance']= 'Điểm danh';
$string['attendanceinstructions']= 'Chọn người dùng đã tham dự phiên:';
$string['attendedsession']= 'Phiên đã tham dự';
$string['attendees']= 'Người tham dự';
$string['attendeestablesummary']= 'Những người đang lên kế hoạch hoặc đã tham dự phiên họp này.';
$string['booked']= 'Đã đặt trước';
$string['bookingcancelled']= 'Bạn đã hủy đặt chỗ {$a}.';
$string['bookingcompleted']= 'Đặt chỗ của bạn đã được hoàn tất.';
$string['bookingfull']= 'Đặt chỗ đầy đủ';
$string['bookingopen']= 'Đặt chỗ đang mở';
$string['bookingstatus']= 'Bạn đã được đặt chỗ cho phiên sau';
$string['calendareventdescriptionbooking']= 'Bạn đã được đăng ký cho phiên này.';
$string['calendareventdescriptionsession']= 'Bạn đã tạo phiên Hội thảo trên web này.';
$string['calendaroptions']= 'Tùy chọn lịch';
$string['cancelbooking']= 'Hủy đặt chỗ';
$string['cancelbookingfor']= 'Hủy đặt chỗ';
$string['cancellation']= 'Hủy bỏ';
$string['cancellationconfirm']= 'Bạn có chắc chắn muốn hủy đặt chỗ cho phiên này không?';
$string['cancellationmessage']= 'Thông báo hủy bỏ';
$string['cancellations']= 'Hủy bỏ';
$string['cancellationsent']= 'Bạn sẽ ngay lập tức nhận được một email hủy bỏ.';
$string['cancellationsentmgr']= 'Bạn và người quản lý của bạn sẽ ngay lập tức nhận được một email hủy bỏ.';
$string['cancellationstablesummary']= 'Danh sách những người đã hủy đăng ký phiên của họ.';
$string['cancelreason']= 'Lý do';
$string['capacity']= 'Dung lượng';
$string['changemanageremailaddress']= 'Thay đổi địa chỉ email của người quản lý';
$string['changemanageremailinstruction']= 'Vui lòng nhập địa chỉ email của người quản lý hiện tại của bạn dưới đây.';
$string['clearall']= 'Xóa tất cả';
$string['closed']= 'Đã đóng cửa';
$string['conditions']= 'Điều kiện';
$string['conditionsexplanation']= 'Tất cả các tiêu chí này phải được đáp ứng để thông báo được hiển thị trên lịch đào tạo:';
$string['confirm']= 'Xác nhận';
$string['confirmanager']= 'Xác nhận địa chỉ email của người quản lý';
$string['confirmation']= 'Xác nhận';
$string['confirmationmessage']= 'Thông báo xác nhận';
$string['confirmationsent']= 'Bạn sẽ ngay lập tức nhận được một email xác nhận.';
$string['confirmationsentmgr']= 'Bạn và người quản lý của bạn sẽ ngay lập tức nhận được một email xác nhận.';
$string['confirmcancelbooking']= 'Xác nhận việc hủy đặt chỗ';
$string['confirmed']= 'Đã xác nhận';
$string['confirmmanageremailaddress']= 'Xác nhận địa chỉ email của người quản lý';
$string['confirmmanageremailaddressquestion']= 'Đây có còn là địa chỉ email của người quản lý của bạn không?';
$string['confirmmanageremailinstruction1']= 'Trước đây bạn đã nhập thông tin sau làm địa chỉ email của người quản lý của bạn:';
$string['confirmmanageremailinstruction2']= 'Đây có còn là địa chỉ email của người quản lý của bạn không?';
$string['copy']= 'Sao chép';
$string['copyingsession']= 'Đang sao chép dưới dạng phiên mới';
$string['copysession']= 'Sao chép phiên';
$string['cost']= 'Chi phí';
$string['costheading']= 'Chi phí Phiên';
$string['currentstatus']= 'Tình trạng hiện tại';
$string['customfieldsheading']= 'Trường phiên tùy chỉnh';
$string['date']= 'Ngày';
$string['dateadd']= 'Thêm một ngày mới';
$string['dateremove']= 'Xóa ngày này';
$string['datetext']= 'Bạn đã đăng nhập vào ngày';
$string['datetimeknownhinttext']= '';
$string['decidelater']= 'Quyết định sau';
$string['decline']= 'Từ chối';
$string['deleteall']= 'Xóa tất cả';
$string['deletesession']= 'Xóa phiên';
$string['deletesessionconfirm']= 'Bạn có hoàn toàn chắc chắn muốn xóa phiên này và tất cả các đăng ký cho phiên này không?';
$string['deletingsession']= 'Đang xóa phiên';
$string['description']= 'Văn bản giới thiệu';
$string['details']= 'Chi tiết';
$string['discountcode']= 'Mã giảm giá';
$string['discountcost']= 'Chi phí chiết khấu';
$string['discountcosthinttext']= '';
$string['due']= 'do';
$string['duration']= 'Thời lượng';
$string['early']= '\\ {$a} sớm';
$string['edit']= 'Chỉnh sửa';
$string['editingsession']= 'Phiên chỉnh sửa';
$string['editsession']= 'Chỉnh sửa phiên';
$string['email:instrmngr']= 'Thông báo cho người quản lý';
$string['emailmanager']= 'Gửi thông báo cho người quản lý';
$string['email:message']= 'Tin nhắn';
$string['email:subject']= 'Chủ đề';
$string['emptylocation']= 'Vị trí trống rỗng';
$string['enrolled']= 'đã đăng ký';
$string['error:addalreadysignedupattendee']= '{$a} đã được đăng ký cho hoạt động Hội thảo trên web này.';
$string['error:addattendee']= 'Không thể thêm {$a} vào phiên.';
$string['error:cancelbooking']= 'Đã xảy ra sự cố khi hủy đặt phòng của bạn';
$string['error:cannotemailmanager']= 'Đã gửi thư nhắc nhở để gửi id {$a->submissionid} tới người dùng {$a->userid}, nhưng không thể gửi thư cho địa chỉ email người quản lý của người dùng (eedbb27f-db4a-4884 -a5f2-1366607d3988). ';
$string['error:cannotemailuser']= 'Không thể gửi thư để gửi id {$a->submissionid} tới người dùng {$a->userid} ({$a->useremail}).';
$string['error:cannotsendconfirmationmanager']= 'Một thông báo xác nhận đã được gửi đến tài khoản email của bạn, nhưng đã xảy ra sự cố khi gửi thông báo xác nhận đến địa chỉ email của người quản lý của bạn.';
$string['error:cannotsendconfirmationthirdparty']= 'Một thông báo xác nhận đã được gửi đến tài khoản email của bạn và tài khoản email của người quản lý của bạn, nhưng đã xảy ra sự cố khi gửi thông báo xác nhận đến địa chỉ email của bên thứ ba.';
$string['error:cannotsendconfirmationuser']= 'Đã xảy ra sự cố khi gửi thông báo xác nhận đến tài khoản email của bạn.';
$string['error:cannotsendconfirmationusermanager']= 'Không thể gửi một thông báo xác nhận đến địa chỉ email của bạn và đến địa chỉ email của người quản lý của bạn.';
$string['error:cannotsendrequestmanager']= 'Đã xảy ra sự cố khi gửi thông báo yêu cầu đăng ký đến tài khoản email của người quản lý của bạn.';
$string['error:cannotsendrequestuser']= 'Đã xảy ra sự cố khi gửi thông báo yêu cầu đăng ký đến tài khoản email của bạn.';
$string['error:couldnotaddfield']= 'Không thể thêm trường phiên tùy chỉnh.';
$string['error:couldnotaddnotice']= 'Không thể thêm thông báo trang web.';
$string['error:couldnotaddsession']= 'Không thể thêm phiên';
$string['error:couldnotcopysession']= 'Không thể sao chép phiên';
$string['error:couldnotdeletefield']= 'Không thể xóa trường phiên tùy chỉnh';
$string['error:couldnotdeletenotice']= 'Không thể xóa thông báo trang web';
$string['error:couldnotdeletesession']= 'Không thể xóa phiên';
$string['error:couldnotfindsession']= 'Không thể tìm thấy phiên mới được chèn vào';
$string['error:couldnotsavecustomfield']= 'Không thể lưu trường tùy chỉnh';
$string['error:couldnotupdatecalendar']= 'Không thể cập nhật sự kiện phiên trong lịch.';
$string['error:couldnotupdatefield']= 'Không thể cập nhật trường phiên tùy chỉnh.';
$string['error:couldnotupdatemanageremail']= 'Không thể cập nhật địa chỉ email của người quản lý.';
$string['error:couldnotupdatenotice']= 'Không thể cập nhật thông báo trang web.';
$string['error:couldnotupdatesession']= 'Không thể cập nhật phiên';
$string['error:coursemisconfigured']= 'Khóa học bị định cấu hình sai';
$string['error:cronprefix']= 'Lỗi: webinar cron:';
$string['error:emptylocation']= 'Vị trí trống.';
$string['error:emptymanageremail']= 'Địa chỉ email của người quản lý trống.';
$string['error:emptyvenue']= 'Địa điểm trống.';
$string['error:enrolmentfailed']= 'Không thể đăng ký {$a} vào khóa học.';
$string['error:eventoccurred']= 'Bạn không thể hủy một sự kiện đã xảy ra.';
$string['error:incorrectcoursemodule']= 'Mô-đun khóa học không chính xác';
$string['error:incorrectcoursemoduleid']= 'ID Mô-đun Khóa học không chính xác';
$string['error:incorrectcoursemodulesession']= 'Phiên hội thảo trên web của Mô-đun khóa học không chính xác';
$string['error:incorrectnotificationtype']= 'Loại thông báo được cung cấp không chính xác';
$string['error:incorrectwebinarid']= 'ID hội thảo trên web không chính xác';
$string['error:invaliduserid']= 'ID người dùng không hợp lệ';
$string['error:manageremailaddressmissing']= 'Bạn hiện không được chỉ định cho một người quản lý trong hệ thống. Vui lòng liên hệ với quản lý.';
$string['error:mustspecifycoursemodulewebinar']= 'Phải chỉ định mô-đun khóa học hoặc ID hội thảo trên web';
$string['error:nomanageremail']= 'Bạn đã không cung cấp địa chỉ email cho người quản lý của mình';
$string['error:nomanagersemailset']= 'Không có email người quản lý nào được đặt';
$string['error:problemsigningup']= 'Đã xảy ra sự cố khi đăng ký bạn.';
$string['error:removeattendee']= 'Không thể xóa {$a} khỏi phiên.';
$string['error:signedupinothersession']= 'Bạn đã đăng ký trong một phiên khác cho hoạt động này. Bạn chỉ có thể đăng ký một phiên cho mỗi hoạt động Hội thảo trên web. ';
$string['error:unknownbuttonclicked']= 'Không có hành động nào liên quan đến nút đã được nhấp vào';
$string['excelformat']= 'Excel';
$string['export']= 'Xuất';
$string['exportattendance']= 'Xuất điểm danh';
$string['exporttofile']= 'Xuất sang tệp';
$string['feedback']= 'Phản hồi';
$string['feedbackupdated']= 'Phản hồi được cập nhật cho \\ {$a} người';
$string['fielddeleteconfirm']= 'Xóa trường \' {$a} \'và tất cả dữ liệu phiên được liên kết với nó?';
$string['field:multiselect']= 'Nhiều lựa chọn';
$string['field:select']= 'Menu lựa chọn';
$string['field:text']= 'Văn bản';
$string['finishdatetime']= 'Ngày / giờ kết thúc';
$string['floor']= 'Tầng';
$string['format']= 'Định dạng';
$string['full']= 'Ngày được sử dụng đầy đủ';
$string['goback']= 'Quay lại';
$string['guestsno']= 'Xin lỗi, khách không được phép đăng ký phiên.';
$string['icalendarheading']= 'Phần đính kèm iCalendar';
$string['import']= 'Nhập';
$string['info']= 'Thông tin';
$string['jointime']= 'Tham gia thời gian';
$string['joinwebinar']= 'Tham gia phiên';
$string['joinwebinarashost']= 'Tham gia phiên với tư cách máy chủ';
$string['late']= '\\ {$a} trễ';
$string['leavetime']= 'Để lại thời gian';
$string['location']= 'Vị trí';
$string['lookfor']= 'Tìm kiếm';
$string['manageradded']= 'Địa chỉ email của người quản lý của bạn đã được chấp nhận.';
$string['managerchanged']= 'Địa chỉ email của người quản lý của bạn đã được thay đổi.';
$string['manageremail']= 'Email của người quản lý';
$string['manageremailaddress']= 'Địa chỉ email của người quản lý';
$string['manageremailformat']= 'Địa chỉ email phải có định dạng \' {$a} \'để được chấp nhận.';
$string['manageremailheading']= 'Email người quản lý';
$string['manageremailinstruction']= 'Để đăng ký một buổi đào tạo, một email xác nhận phải được gửi đến địa chỉ email của bạn và được sao chép vào địa chỉ email của người quản lý của bạn.';
$string['manageremailinstructionconfirm']= 'Vui lòng xác nhận rằng đây là địa chỉ email của người quản lý của bạn:';
$string['managername']= 'Tên người quản lý';
$string['managerupdated']= 'Địa chỉ email của người quản lý của bạn đã được cập nhật.';
$string['maximumattendees']= 'Người tham dự tối đa';
$string['maximumpoints']= 'Số điểm tối đa';
$string['maximumsize']= 'Số lượng người tham dự tối đa';
$string['message']= 'Thay đổi cách đặt chỗ trong khóa học {$a->coursename}!
Đã có một vị trí miễn phí trong phiên trên {$a->duedate} ({$a->name}) trong khóa học {$a->coursename}.
Bạn đã được đăng ký. Nếu ngày không còn phù hợp với bạn nữa, vui lòng hủy đăng ký tại <a href=\'{$a->url}\'> {$a->url} </a>. ';
$string['modulename']= 'Hội thảo trên web';
$string['modulenameplural']= 'Hội thảo trên web';
$string['moreinfo']= 'Thông tin khác';
$string['multiday']= 'nhiều ngày';
$string['newmanageremailaddress']= 'Địa chỉ email của người quản lý';
$string['noactionableunapprovedrequests']= 'Không có yêu cầu chưa được phê duyệt có thể hành động';
$string['nocustomfields']= '<p> Không có trường tùy chỉnh nào được xác định. </p>';
$string['none']= 'Không có';
$string['noremindersneedtobesent']= 'Không cần gửi lời nhắc.';
$string['normalcost']= 'Chi phí bình thường';
$string['normalcosthinttext']= '';
$string['nosignedupusers']= 'Không có người dùng nào đăng ký phiên này.';
$string['nositenotices']= '<p> Không có thông báo trang web nào được xác định. </p>';
$string['note']= 'Ghi chú';
$string['notefull']= 'Ngay cả khi Phiên đã được đặt hết, bạn vẫn có thể đăng ký. Bạn sẽ được xếp hàng (đánh dấu màu đỏ). Nếu ai đó đăng xuất, học sinh đầu tiên trong hàng đợi sẽ được chuyển vào học sinh đăng ký và thông báo sẽ được gửi đến người đó qua thư. ';
$string['noticedeleteconfirm']= 'Xóa thông báo trang web \' {$a->name} \'? <br/> <blockquote> {$a->text} </blockquote>';
$string['noticetext']= 'Văn bản thông báo';
$string['notificationboth']= 'Thông báo qua email và cuộc hẹn iCalendar';
$string['notificationemail']= 'Chỉ thông báo qua email';
$string['notificationical']= 'Chỉ cuộc hẹn iCalendar';
$string['notificationtype']= 'Loại thông báo';
$string['notsignedup']= 'Bạn chưa đăng ký phiên này.';
$string['notsubmittedyet']= 'Chưa được đánh giá';
$string['noupcoming']= '<i> Không có phiên sắp tới </i>';
$string['nowebinars']= 'Không có hoạt động Hội thảo trên web nào';
$string['odsformat']= 'OpenDocument';
$string['onehour']= '1 giờ';
$string['oneminute']= '1 phút';
$string['options']= 'Tùy chọn';
$string['or']= 'hoặc';
$string['order']= 'Đặt hàng';
$string['place']= 'Phòng';
$string['placeholder:alldates']= '[tất cả các ngày]';
$string['placeholder:attendeeslink']= '[liên kết người tham dự]';
$string['placeholder:cost']= '[chi phí]';
$string['placeholder:details']= '[chi tiết]';
$string['placeholder:duration']= '[thời lượng]';
$string['placeholder:finishtime']= '[thời gian kết thúc]';
$string['placeholder:firstname']= '[tên đầu tiên]';
$string['placeholder:lastname']= '[họ]';
$string['placeholder:reminderperiod']= '[lời nhắc]';
$string['placeholder:sessiondate']= '[sessiondate]';
$string['placeholder:starttime']= '[thời gian bắt đầu]';
$string['placeholder:webinarname']= '[tên hội thảo trên web]';
$string['pluginadministration']= 'Hội thảo trên web';
$string['pluginname']= 'Hội thảo trên web';
$string['points']= 'Điểm';
$string['pointsplural']= 'Điểm';
$string['presenter']= 'Máy chủ';
$string['previoussessions']= 'Phiên trước';
$string['previoussessionslist']= 'Danh sách tất cả các phiên trước đây cho hoạt động Hội thảo trên web này';
$string['printversionid']= 'Phiên bản in: không có tên';
$string['printversionname']= 'Phiên bản in: với tên';
$string['really']= 'Bạn có thực sự muốn xóa tất cả các kết quả cho hội thảo trên web này không?';
$string['register']= 'Đăng ký';
$string['registeredon']= 'Đã đăng ký trên';
$string['registeron']= 'Đăng ký trên {$a}';
$string['registersuccess']= 'Đăng ký thành công';
$string['registrations']= 'Đăng ký';
$string['registrationsuccessful']= 'Bạn đã đăng ký thành công trên {$a}.';
$string['reminder']= 'Nhắc nhở';
$string['remindermessage']= 'Tin nhắn nhắc nhở';
$string['reminderperiod']= 'Số ngày trước khi tin nhắn được gửi đi';
$string['requestmessage']= 'Yêu cầu tin nhắn';
$string['requeststablesummary']= 'Những người yêu cầu tham dự phiên họp này.';
$string['room']= 'Phòng';
$string['saveallfeedback']= 'Lưu tất cả các câu trả lời';
$string['saveattendance']= 'Lưu điểm danh';
$string['scheduledsession']= 'Phiên đã lên lịch';
$string['scheduledsessions']= 'Phiên đã lên lịch';
$string['seatsavailable']= 'Có chỗ ngồi';
$string['seeattendees']= 'Xem người tham dự';
$string['selecthost']= 'Chọn máy chủ tổ chức hội thảo trên web ..';
$string['selecthosterror']= 'Bạn phải chọn máy chủ cho phiên hội thảo trên web này.';
$string['sentremindermanager']= 'Đã gửi email nhắc nhở tới người quản lý người dùng';
$string['sentreminderuser']= 'Đã gửi email nhắc nhở tới người dùng';
$string['sessiondate']= 'Ngày phiên họp';
$string['sessiondatetime']= 'Ngày / giờ của phiên';
$string['sessiondatetimeknown']= 'Đã biết ngày / giờ của phiên';
$string['sessiondeletedcontact']= '{$a->adminemail}';
$string['sessiondeletedmessage']= 'Kính gửi {$a->name},
Một buổi đào tạo mà bạn đã đăng ký tham gia đã bị hủy. Nội dung chi tiết của phiên họp như sau:
Đề tài:
Ahkhai 0 B - Bbaa - 4 Bhid - 96 In - Sabbhahkhah 45
Sự miêu tả:
{$a->webinarintro}
Chương trình:
F015 Dsas-Abhif-42 BP-Start 4-420A03 Dsaba05
Ngày giờ:
{$a->starttime} ';
$string['sessiondeletedsubject']= 'Hội thảo trên web bị hủy: {$a->webinarname}';
$string['sessionfinishtime']= 'Thời gian kết thúc phiên';
$string['sessioninprogress']= 'Phiên đang diễn ra';
$string['sessionisfull']= 'Phiên này đã đầy. Bạn sẽ cần chọn thời gian khác hoặc nói chuyện với người hướng dẫn. ';
$string['sessionover']= 'Phiên kết thúc';
$string['sessionregistercontact']= Afhab 09 VT-Bast-4S40-933YA-SS 407
$string['sessionregistermessage']= 'Kính gửi {$a->name}!
Bạn đã đăng ký tham gia một buổi đào tạo trên {$a->starttime}.
Chi tiết phiên là:
Đề tài:
{$a->webinarname}
Sự miêu tả:
28756 C-755 F-4 A-4 A-901 F-Sew 4 Pin 4
Chương trình:
8 Afsbadab-2-Ava-4-Ba`-b-love 4-5-morning-2 423
Để tham dự buổi học, hãy nhấp vào liên kết bên dưới vào thời gian đã lên lịch. Thao tác này sẽ đưa bạn đến danh sách các phiên Hội thảo trên web, nơi bạn sẽ thấy nút \'Tham gia \' bên cạnh hội thảo trên web mà bạn đã đăng ký. Bấm vào nút để tham gia buổi đào tạo.
{$a->sessionurl}
Xin lưu ý: nút \'Tham gia \' sẽ không khả dụng cho đến khi phiên đang diễn ra. ';
$string['sessionregistersubject']= 'Đăng ký hội thảo trên web: {$a->webinarname}';
$string['sessionrequiresmanagerapproval']= 'Phiên này yêu cầu sự chấp thuận của người quản lý để đặt chỗ.';
$string['sessionroles']= 'Vai trò phiên';
$string['sessions']= 'Phiên';
$string['sessionsdetailstablesummary']= 'Mô tả đầy đủ về phiên hiện tại.';
$string['sessionsoncoursepage']= 'Phiên hiển thị trên trang khóa học';
$string['sessionstartdate']= 'Ngày bắt đầu phiên';
$string['sessionstarttime']= 'Thời gian bắt đầu phiên';
$string['sessionunregistercontact']= Efa 02 yisb-5217-4187-8033-9a 4 Cho 4 với 19 bệnh nhân;
$string['sessionunregistermessage']= 'Kính gửi {$a->name}!
Bạn đã được hủy đăng ký khỏi buổi đào tạo sau, dự kiến ​​diễn ra trên {$a->starttime}.
Đề tài:
156 A449-8833-4779- Nissi 0-Bhabd 1674 A
Sự miêu tả:
232 Bfs 0 S-Dsddd-4642-8 Akh-Dubai 443 Khối 0761
Chương trình:
{$a->webinaragenda} ';
$string['sessionunregistersubject']= 'Bỏ đăng ký hội thảo trên web: {$a->webinarname}';
$string['sessionupdatedcontact']= '{$a->adminemail}';
$string['sessionupdatedmessage']= 'Kính gửi {$a->name}!
Một buổi đào tạo mà bạn đăng ký tham gia đã được thay đổi. Các chi tiết mới như sau:
Đề tài:
64 b 0 bơm 1-fhakha-46 sakh-a-8
Sự miêu tả:
916 AA-47-ISKA-4 101-B 41-3E
Chương trình:
7 D006823-2723-464F-9156-34
Ngày giờ:
Yiddischas-yabb-43 bf-bbb-4c451-daf14
Để tham dự buổi học, hãy nhấp vào liên kết bên dưới vào thời gian đã lên lịch. Thao tác này sẽ đưa bạn đến danh sách các phiên Hội thảo trên web, nơi bạn sẽ thấy nút \'Tham gia \' bên cạnh hội thảo trên web mà bạn đã đăng ký. Bấm vào nút để tham gia buổi đào tạo.
4 Thoát nước 0-A-4 SM-850 A-6 bằng cách bơm 13705 BF
Xin lưu ý: nút \'Tham gia \' sẽ không khả dụng cho đến khi phiên đang diễn ra. ';
$string['sessionupdatedsubject']= 'Thay đổi chi tiết hội thảo trên web: {$a->webinarname}';
$string['sessionvenue']= 'Địa điểm phiên họp';
$string['setting:adminemail']= 'Địa chỉ email được liên kết với tài khoản Adobe Connect của bạn.';
$string['setting:adminemail_caption']= 'Email quản trị viên';
$string['setting:adminemaildefault']= '';
$string['setting:adminpassword']= 'Mật khẩu được liên kết với tài khoản Adobe Connect của bạn.';
$string['setting:adminpassword_caption']= 'Mật khẩu quản trị viên';
$string['setting:adminpassworddefault']= '';
$string['setting:adminusername']= 'Số ID của người dùng mà tất cả các phiên và tài khoản người dùng sẽ được tạo.';
$string['setting:adminusername_caption']= 'Tên người dùng quản trị viên';
$string['setting:adminusernamedefault']= '';
$string['setting:createaccounts']= 'Nếu được đặt, tài khoản hội thảo trên web sẽ được tạo cho tất cả những người tham dự nếu họ chưa có. Nếu không được đặt, người tham dự sẽ được đăng ký phiên với tư cách là khách truy cập. ';
$string['setting:createaccounts_caption']= 'Tạo tài khoản';
$string['setting:createaccountsdefault']= '';
$string['setting:messagesenderusername']= 'Tên người dùng Moodle của người có tin nhắn do mô-đun hội thảo trên web cấp sẽ được gửi từ đó (nếu hệ thống nhắn tin của Moodle đang được sử dụng).';
$string['setting:messagesenderusername_caption']= 'Tên người dùng người gửi tin nhắn';
$string['setting:messagesenderusernamedefault']= '';
$string['setting:siteid']= '';
$string['setting:siteid_caption']= 'ID trang web';
$string['setting:siteiddefault']= '';
$string['setting:siteurl']= '';
$string['setting:siteurlapiurl']= 'URL của URL API cho trang web hội thảo (không bao gồm dấu gạch chéo sau)';
$string['setting:siteurlapiurl_caption']= 'URL API URL của trang web';
$string['setting:siteurlapiurldefault']= '';
$string['setting:siteurl_caption']= 'URL trang web';
$string['setting:siteurldefault']= '';
$string['setting:sitexmlapiurl']= 'URL của API XML cho trang web hội thảo (không bao gồm dấu gạch chéo sau). Điều này thường trông giống như https://meet12345678.adobeconnect.com/api/xml. ';
$string['setting:sitexmlapiurl_caption']= 'URL API XML của trang web';
$string['setting:sitexmlapiurldefault']= '';
$string['setting:usemoodlemessaging']= 'Nếu được đặt, thông báo hội thảo trên web sẽ được gửi qua hệ thống nhắn tin của Moodle cũng như qua email (trừ khi email bị tắt trên toàn cầu).';
$string['setting:usemoodlemessaging_caption']= 'Sử dụng tin nhắn Moodle';
$string['setting:usemoodlemessagingdefault']= '';
$string['showbylocation']= 'Hiển thị theo vị trí';
$string['showoncalendar']= 'Hiển thị trên lịch';
$string['signup']= 'Đăng ký';
$string['signupfor']= 'Đăng ký {$a}';
$string['signupforsession']= 'Đăng ký một phiên sắp tới có sẵn';
$string['signupforthissession']= 'Đăng ký phiên Hội thảo trên web này';
$string['signups']= 'Đăng ký';
$string['sign-ups']= 'Đăng ký';
$string['sitenoticesheading']= 'Thông báo trang web';
$string['startdatetime']= 'Ngày / giờ bắt đầu';
$string['status']= 'Trạng thái';
$string['status_approved']= 'Được chấp thuận';
$string['status_booked']= 'Đã đặt trước';
$string['status_declined']= 'Bị từ chối';
$string['status_fully_attended']= 'Đã tham dự đầy đủ';
$string['status_no_show']= 'Không hiển thị';
$string['status_partially_attended']= 'Đã tham dự một phần';
$string['status_requested']= 'Yêu cầu';
$string['status_session_cancelled']= 'Phiên bị hủy';
$string['status_user_cancelled']= 'Người dùng bị hủy';
$string['status_waitlisted']= 'Danh sách chờ';
$string['subject']= 'Thay đổi đặt chỗ trong khóa học {$a->coursename} ({$a->duedate})';
$string['submissions']= 'Bài gửi';
$string['submit']= 'Gửi';
$string['submitted']= 'Đã gửi';
$string['summary']= 'Tóm tắt';
$string['suppressemail']= 'Bỏ thông báo qua email';
$string['takeattendance']= 'Điểm danh';
$string['thirdpartyemailaddress']= '(Các) địa chỉ email của bên thứ ba';
$string['thirdpartywaitlist']= 'Thông báo cho bên thứ ba về các phiên được liệt kê trong danh sách chờ';
$string['time']= 'Thời gian';
$string['timecancelled']= 'Thời gian bị hủy bỏ';
$string['timedue']= 'Thời hạn đăng ký';
$string['timefinish']= 'Thời gian kết thúc';
$string['timerequested']= 'Thời gian yêu cầu';
$string['timesignedup']= 'Thời gian đã đăng ký';
$string['timestart']= 'Thời gian bắt đầu';
$string['timezone']= 'Múi giờ';
$string['unapprovedrequests']= 'Yêu cầu chưa được duyệt';
$string['unknowndate']= '(ngày không xác định)';
$string['unknowntime']= '(thời gian không xác định)';
$string['upcomingsessions']= 'Phiên sắp tới';
$string['upcomingsessionslist']= 'Danh sách tất cả các phiên sắp tới cho hoạt động Hội thảo trên web này';
$string['usercancelledon']= 'Người dùng đã hủy trên {$a}';
$string['usernotsignedup']= 'Trạng thái: chưa đăng ký';
$string['usersignedup']= 'Trạng thái: đã đăng ký';
$string['usersignedupon']= 'Người dùng đã đăng ký trên {$a}';
$string['userwillbewaitlisted']= 'Phiên này hiện đã đầy. Bằng cách nhấp vào nút \\ "Đăng ký \\", bạn sẽ được đưa vào danh sách chờ của phiên. ';
$string['validation:needatleastonedate']= 'Bạn cần cung cấp ít nhất một ngày hoặc đánh dấu phiên đó là đã chờ đợi.';
$string['venue']= 'Địa điểm';
$string['viewallsessions']= 'Xem tất cả các phiên';
$string['viewrecording']= 'Xem ghi âm';
$string['viewsubmissions']= 'Xem các bài gửi';
$string['wait-list']= 'Danh sách chờ';
$string['wait-listed']= 'Danh sách chờ';
$string['waitlistedmessage']= 'Tin nhắn được liệt kê chờ';
$string['webinar']= 'Hội thảo trên web';
$string['webinar:addattendees']= 'Thêm người tham dự vào phiên hội thảo trên web';
$string['webinar:addinstance']= 'Hội thảo trên web';
$string['webinarbooking']= 'Đặt chỗ hội thảo trên web';
$string['webinar:editsessions']= 'Thêm, chỉnh sửa, sao chép và xóa các phiên hội thảo trên web';
$string['webinarname']= 'Tên hội thảo trên web';
$string['webinar:overbook']= 'Đăng ký các phiên đầy đủ.';
$string['webinar:removeattendees']= 'Xóa người tham dự khỏi phiên hội thảo trên web';
$string['webinarsession']= 'Phiên hội thảo trên web';
$string['webinar:signup']= 'Đăng ký một phiên';
$string['webinar:takeattendance']= 'Điểm danh';
$string['webinar:view']= 'Xem các hoạt động và phiên hội thảo trên web';
$string['webinar:viewattendees']= 'Xem danh sách tham dự và những người tham dự';
$string['webinar:viewcancellations']= 'Xem các lần hủy bỏ';
$string['webinar:viewemptyactivities']= 'Xem các hoạt động hội thảo trên web trống';
$string['xhours']= '{$a} giờ';
$string['xminutes']= '{$a} phút';
$string['youarebooked']= 'Bạn đã được đặt chỗ cho phiên sau';
$string['youremailaddress']= 'Địa chỉ email của bạn';
