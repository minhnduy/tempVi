<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'videoconference', language 'en', branch 'MOODLE_23_STABLE'
 *
 * @package   videoconference
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['adminkeydesc']= 'Khóa quản trị để quản lý phòng Hội nghị truyền hình của bạn';
$string['adminkeylabel']= 'Khóa quản trị';
$string['adminuserid']= 'Ai là quản trị viên (User_ID)';
$string['advancedCamSettings']= 'Cài đặt Máy ảnh Nâng cao';
$string['amfdesc']= 'RTMP AMF (AMF3: Red5, Wowza, FMIS3, FMIS3.5)';
$string['amflabel']= 'RTMP AMF';
$string['background_url']= 'Url nền';
$string['bufferFulldesc']= 'Đặt Bộ đệm Đầy đủ';
$string['bufferFulllabel']= 'Bộ đệm đầy đủ';
$string['bufferFullPlaybackdesc']= 'Đặt phát lại đầy đủ bộ đệm';
$string['bufferFullPlaybacklabel']= 'Phát lại đầy đủ bộ đệm';
$string['bufferLivedesc']= 'Đặt Bộ đệm Trực tiếp';
$string['bufferLivelabel']= 'Bộ đệm Trực tiếp';
$string['bufferLivePlaybackdesc']= 'Đặt phát lại trực tiếp bộ đệm';
$string['bufferLivePlaybacklabel']= 'Phát lại trực tiếp bộ đệm';
$string['camBandwidthdesc']= 'Đặt băng thông máy ảnh';
$string['camBandwidthlabel']= 'Băng thông máy ảnh';
$string['camFPS']= 'FPS máy ảnh';
$string['camFPSdesc']= 'Đặt FPS cho máy ảnh';
$string['camFPSlabel']= 'FPS máy ảnh';
$string['camHeight']= 'Chiều cao máy ảnh';
$string['camHeightdesc']= 'Đặt Chiều cao Máy ảnh';
$string['camHeightlabel']= 'Chiều cao máy ảnh';
$string['camMaxBandwidthdesc']= 'Đặt băng thông máy ảnh tối đa';
$string['camMaxBandwidthlabel']= 'Băng thông máy ảnh tối đa';
$string['camWidth']= 'Chiều rộng máy ảnh';
$string['camWidthdesc']= 'Đặt chiều rộng máy ảnh';
$string['camWidthlabel']= 'Chiều rộng máy ảnh';
$string['change_background']= 'Thay đổi nền';
$string['configureSource']= 'Định cấu hình nguồn';
$string['desc']= 'Mô tả';
$string['disableBandwidthDetectiondesc']= 'Đặt vô hiệu hóa phát hiện băng thông';
$string['disableBandwidthDetectionlabel']= 'Tắt phát hiện băng thông';
$string['disableSound']= 'Tắt âm thanh';
$string['disableUploadDetectiondesc']= 'Đặt vô hiệu hóa phát hiện tải lên';
$string['disableUploadDetectionlabel']= 'Tắt tính năng phát hiện tải lên';
$string['disableVideo']= 'Tắt video';
$string['enter']= 'Nhập';
$string['externalStream']= 'Dòng bên ngoài';
$string['file_delete']= 'Xóa tệp';
$string['files_enabled']= 'Kích hoạt tập tin';
$string['file_upload']= 'Tải lên tệp';
$string['fillWindow']= 'Điền cửa sổ';
$string['filterRegex']= 'Lọc regex';
$string['filterReplace']= 'Bộ lọc thay thế';
$string['floodProtection']= 'Chống lũ lụt';
$string['headersetting']= 'Cài đặt Webcam mặc định';
$string['layoutCode']= 'Mã bố cục';
$string['limitByBandwidthdesc']= 'Đặt giới hạn theo băng thông';
$string['limitByBandwidthlabel']= 'Giới hạn theo băng thông';
$string['micRate']= 'Tỷ lệ micrô';
$string['micRatedesc']= 'Đặt tỷ lệ micrô';
$string['micRatelabel']= 'Tỷ lệ micrô';
$string['modulename']= 'Hội nghị truyền hình';
$string['modulenameplural']= 'tham khảo video';
$string['moduletitle']= 'Hội nghị truyền hình';
$string['notallowenter']= 'Bạn không có quyền truy cập vào phòng này';
$string['novideoconference']= 'Không có phòng họp video trong khóa học này';
$string['open']= 'Phòng đang mở';
$string['pluginadministration']= 'Quản trị Hội nghị truyền hình';
$string['pluginname']= 'hội nghị truyền hình';
$string['privateTextchat']= 'Trò chuyện Văn bản Riêng tư';
$string['regularCams']= 'Cam thông thường';
$string['regularWatch']= 'Xem thường xuyên';
$string['room_limitdesc']= 'Đặt giới hạn phòng tối đa';
$string['room_limitlabel']= 'Giới hạn phòng';
$string['rtmpdesc']= 'Địa chỉ máy chủ RTMP';
$string['rtmplabel']= 'Máy chủ RTMP';
$string['showCamSettings']= 'Hiển thị Cài đặt Máy ảnh';
$string['tutorial']= 'Hướng dẫn';
$string['videoconference']= 'Hội nghị truyền hình';
$string['videoconference:administrator']= 'người kiểm duyệt';
$string['videoconference:advancedcamsettings']= 'cài đặt cam trước';
$string['videoconference:autoviewcams']= 'tự động lấp đầy các khe webcam có sẵn';
$string['videoconference:configuresource']= 'cho phép bộ mã hóa bên ngoài';
$string['videoconference:disablesound']= 'bật âm thanh';
$string['videoconference:disablevideo']= 'đã bật video';
$string['videoconferencefieldset']= 'Bộ trường mẫu tùy chỉnh';
$string['videoconference:file_delete']= 'cho phép xóa tệp';
$string['videoconference:file_upload']= 'cho phép tải tệp lên';
$string['videoconferencename']= 'trợ giúp hội nghị truyền hình';
$string['videoconferencename_help']= 'Vui lòng nhập mô tả ngắn gọn về phòng Hội nghị Truyền hình.';
$string['videoconference:panelfiles']= 'xem bảng điều khiển tệp, có thể tải xuống';
$string['videoconference:room_create']= 'Tạo phòng';
$string['videoconference:room_delete']= 'Xóa phòng';
$string['videoconferenceroomname']= 'Tên phòng họp video';
$string['videoconference:showcamsettings']= 'hiển thị cài đặt cam';
$string['videoconference:showtimer']= 'Hiển thị bộ đếm thời gian';
$string['videoconference:view']= 'Truy cập phòng họp video';
$string['welcome']= 'Tin nhắn chào mừng';
