<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_coursefields', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_coursefields
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['coursefields:setfields']= 'Đặt các trường khóa học của tất cả các khóa học trong một danh mục.';
$string['fieldisrequired']= '<strong> Trường tùy chỉnh này được đặt thành bắt buộc. </strong> Với công cụ này, bạn có thể ghi đè quy tắc này và ghi đè trường này bằng các giá trị trống. Vui lòng chỉ làm điều này nếu bạn biết mình đang làm gì. ';
$string['fieldisunique']= '<strong> Trường tùy chỉnh này được đặt thành duy nhất. </strong> Với công cụ này, bạn có thể ghi đè quy tắc này và ghi đè trường này bằng tất cả các giá trị giống nhau. Vui lòng chỉ làm điều này nếu bạn biết mình đang làm gì. ';
$string['overwritefield']= 'Ghi đè các giá trị trường hiện có';
$string['pluginname']= 'Đặt các trường khóa học';
$string['privacy:metadata']= 'Plugin Đặt các trường khóa học không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['setfields']= 'Đặt các trường khóa học';
$string['setfieldsinstruction']= 'Đặt các trường khóa học cho tất cả các khóa học trong một danh mục, bao gồm các danh mục phụ. Chọn các tùy chọn của bạn và nhấp vào "Xác nhận". Khi xác nhận, Moodle sẽ tạo một "nhiệm vụ adhoc" để đặt tất cả các trường khóa học ở chế độ nền. Điều này yêu cầu phải bật cron. ';
$string['updatequeued']= 'Một nhiệm vụ adhoc đã được xếp hàng đợi để cập nhật tất cả các khóa học trong danh mục <strong> {$a} </strong>. Nó sẽ chạy vào lần tiếp theo cron thực thi. ';
