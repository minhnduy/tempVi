<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_modedit', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_modedit
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['delete']= 'Xóa {$a}';
$string['deleteconfirm']= 'Xóa {$a}?';
$string['edit']= 'Chỉnh sửa {$a}';
$string['editactivities']= 'Chỉnh sửa hoạt động';
$string['editactivities_desc']= 'Trang này chứa các liên kết trực tiếp đến các hoạt động của bạn \' các trang chỉnh sửa. Điều này rất hữu ích nếu bạn có
thứ gì đó trên trang của bạn đang phá vỡ bố cục và có thể làm cho các liên kết chỉnh sửa không sử dụng được. ';
$string['pluginname']'Đã sửa đổi';
$string['privacy:metadata']= 'Plugin tool_modedit không lưu trữ bất kỳ dữ liệu cá nhân nào.';
