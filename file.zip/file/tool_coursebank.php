<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_coursebank', language 'en', branch 'MOODLE_34_STABLE'
 *
 * @package   tool_coursebank
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['backupdate']= 'Ngày sao lưu';
$string['backupfailed']= 'Không gửi được bản sao lưu {$a}.';
$string['backupfilename']= 'Tên tệp';
$string['backupfiles']= '{$a} (các) tệp';
$string['backupqueue']= 'Hàng đợi chuyển khoản sao lưu của Ngân hàng khóa học';
$string['backupsummary']= 'Báo cáo chuyển khoản sao lưu của Ngân hàng Khóa học';
$string['check_delete']= 'Bạn có chắc chắn muốn xóa {$a} khỏi hàng đợi chuyển không?';
$string['check_go']= 'Bạn có chắc chắn muốn tiếp tục chuyển {$a} không?';
$string['checking']= 'Đang kiểm tra ...';
$string['check_stop']= 'Bạn có chắc chắn muốn tạm dừng chuyển {$a} không?';
$string['completion']= 'Hoàn thành';
$string['conncheckbutton']= 'Kiểm tra kết nối';
$string['conncheckfail']= 'Không thể kết nối với "{$a}". Vui lòng xác nhận rằng cài đặt ngân hàng khóa học bên ngoài và cấu hình mạng của bạn là chính xác. ';
$string['connchecksuccess']= 'Đã thông qua kiểm tra kết nối với "{$a}"!';
$string['connchecktitle']= 'Kiểm tra kết nối';
$string['coursebank:download']= 'Tải xuống tệp sao lưu ngân hàng khóa học';
$string['coursebank:edit']= 'Chỉnh sửa tệp sao lưu ngân hàng khóa học';
$string['coursebanklogging']= 'Ghi nhật ký ngân hàng khóa học';
$string['coursebank:view']= 'Xem danh sách các tập tin sao lưu ngân hàng khóa học';
$string['coursebank:viewlogs']= 'Xem nhật ký Ngân hàng Khóa học';
$string['coursefullname']= 'Tên khóa học';
$string['coursename']= 'Tên khóa học';
$string['cron_duplicate']= 'Sao chép khóa cron';
$string['cron_force']= 'Khóa có thể được gỡ bỏ bằng cách chạy tập lệnh này với --force làm đối số.';
$string['cron_lock_cleared']= 'Xóa bản ghi khóa cron cũ trong cơ sở dữ liệu vì nó bị coi là cũ.';
$string['cron_locked']= 'Bản ghi khóa Cron có trong cơ sở dữ liệu. Quá trình này có thể đã bị gián đoạn gần đây hoặc vẫn đang chạy. ';
$string['cron_removinglock']= 'Xóa khóa cron trong cơ sở dữ liệu ...';
$string['cron_sending']= 'Đang gửi bản sao lưu ...';
$string['cron_skippingexternal']= 'Công cụ không được cấu hình để chạy qua CLI. Đang thoát ... ';
$string['cron_skippingmoodle']= 'Được cấu hình để sử dụng cron bên ngoài. Bỏ qua ... ';
$string['crontimeout']= 'Đã đạt đến giới hạn thời gian thực thi Cron! Hoãn chuyển các khóa học còn lại sang đợt học tiếp theo. ';
$string['delete']= 'Xóa khỏi hàng đợi';
$string['deletefailed']= 'Không xóa được bản sao lưu {$a}.';
$string['disabled']= 'Tất nhiên việc gửi các bản sao lưu bị vô hiệu hóa.';
$string['download']= 'Tải xuống tệp sao lưu';
$string['downloadsummary']= 'Bản sao lưu tải xuống Ngân hàng khóa học bên ngoài';
$string['errordownloading']= 'Lỗi khi tải xuống tệp sao lưu.';
$string['errorgetdownloadlist']= 'Không thể lấy danh sách sao lưu từ ngân hàng khóa học bên ngoài. Vui lòng xác nhận rằng cài đặt ngân hàng khóa học bên ngoài và cấu hình mạng của bạn là chính xác. ';
$string['ERROR_MAX_ATTEMPTS_REACHED']= 'Đã đạt được số lần thử tối đa.';
$string['errorsonly']= 'Chỉ lỗi';
$string['ERROR_TIMEOUT']= 'Kết nối đã hết thời gian chờ.';
$string['errorupdatingstatus']= 'Lỗi khi cập nhật trạng thái';
$string['event_backup_chunk_interrupted']= 'Truyền bản sao lưu với {$a} bị gián đoạn do lỗi chunk.';
$string['eventbackupdeleted']= 'Đã xóa tập tin sao lưu';
$string['eventbackupdeletefailed']= 'Sao lưu xóa không thành công';
$string['eventbackupdeleteskipped']= 'Đã bỏ qua xóa sao lưu';
$string['eventbackupdownloaded']= 'Đã tải xuống bản sao lưu';
$string['eventbackupdownloadfailed']= 'Tải xuống sao lưu không thành công';
$string['event_backup_init_completed']= 'Bản sao lưu khóa học với {$a} đã được chuyển đến Coursebank.';
$string['event_backup_init_exists_data']= 'Bản sao lưu khóa học với {$a} đã tồn tại trong Coursebank. Dữ liệu hiện có sẽ bị ghi đè. ';
$string['event_backup_init_exists_nodata']= 'Bản sao lưu khóa học với {$a} đã tồn tại trong Coursebank, nhưng chưa có dữ liệu nào được chuyển.';
$string['event_backup_init_interrupted']= 'Truyền bản sao lưu với {$a} bị gián đoạn trong quá trình khởi tạo sao lưu';
$string['eventbackupsendfailed']= 'Gửi sao lưu không thành công';
$string['event_backup_transfer_completed']= 'Đã hoàn tất chuyển bản sao lưu khóa học với {$a}.';
$string['event_backup_transfer_started']= 'Đã bắt đầu chuyển bản sao lưu khóa học với {$a}.';
$string['event_backup_update']= 'Chuyển bản ghi sao lưu với {$a} được cập nhật.';
$string['eventbackupupdated']= 'Cập nhật hồ sơ sao lưu';
$string['event_backup_update_interrupted']= 'Quá trình chuyển bản sao lưu với {$a} bị gián đoạn do lỗi cập nhật sao lưu.';
$string['eventconnectionchecked']= 'Đã kiểm tra kết nối';
$string['eventconnectioncheckfailed']= 'Kiểm tra kết nối không thành công';
$string['eventcroncompleted']= 'Đã hoàn thành nhiệm vụ theo lịch trình Coursebank';
$string['eventcronstarted']= 'Đã bắt đầu tác vụ theo lịch trình Coursebank';
$string['eventdownloadsviewed']= 'Đã xem trang tải xuống';
$string['event_downloads_viewed']= 'Người dùng có id \' {$a} \'đã xem trang tải xuống dự phòng.';
$string['eventdownloadviewfailed']= 'Không tải được chế độ xem trang';
$string['event_download_view_failed']= 'Người dùng có id \' {$a} \'đã cố xem trang tải xuống dự phòng nhưng đã xảy ra lỗi.';
$string['eventgetsession']= 'Khóa phiên mới được tạo.';
$string['eventgetsessionfailed']= 'Không tạo được khóa phiên.';
$string['eventhttprequest']= 'Yêu cầu HTTP';
$string['eventhttprequestfailed']= 'Yêu cầu HTTP không thành công';
$string['eventloggedas']= '{$a->realusername} là {$a->asusername}';
$string['eventname']= 'Tên sự kiện';
$string['eventorigin']= 'Nguồn gốc';
$string['eventqueuepopulated']= 'Đã điền hàng đợi dự phòng khóa học';
$string['eventstatusupdated']= 'Trạng thái sao lưu được cập nhật';
$string['eventstatusupdatefailed']= 'Cập nhật trạng thái sao lưu không thành công';
$string['eventtimeoutreached']= 'Đã hết thời gian Cron';
$string['eventtimeoutreached_desc']= 'Đã đạt đến giới hạn thời gian thực thi Cron trong quá trình chuyển khóa học {$a}.';
$string['eventtransfercompleted']= 'Đã hoàn tất quá trình chuyển sao lưu';
$string['eventtransferinterrupted']= 'Quá trình chuyển sao lưu bị gián đoạn';
$string['event_transfer_queue_populated']= '{$a} tệp sao lưu khóa học đã được thêm vào hàng đợi chuyển.';
$string['eventtransferresumed']= 'Đã tiếp tục chuyển bản sao lưu';
$string['eventtransferstarted']= 'Đã bắt đầu chuyển sao lưu';
$string['eventtransferstartfailed']= 'Bắt ​​đầu chuyển sao lưu không thành công';
$string['filename']= 'Tên tệp';
$string['filesize']= 'Kích thước tệp';
$string['filetimemodified']= 'Ngày sao lưu';
$string['filterisequalto']= 'bằng';
$string['filterlessthan']= 'nhỏ hơn';
$string['filtermorethan']= 'nhiều hơn';
$string['go']= 'Tiếp tục chuyển giao';
$string['identify_backup']= 'UUID \' {$a->uuid} \'và tên tệp \' {$a->filename} \\';
$string['limiterfor']= '{$a} giới hạn trường';
$string['localdeletesuccess']= '{$a} đã xóa thành công khỏi vùng lưu trữ được chỉ định.';
$string['moodledeleteskip']= 'Bỏ qua việc xóa {$a} khỏi vùng tập tin sao lưu tự động vì bản sao lưu tự động cuối cùng cho khóa học không thành công.';
$string['moodledeletesuccess']= '{$a} đã xóa thành công khỏi vùng tập tin sao lưu tự động.';
$string['nav_download']= 'Tải xuống các bản sao lưu';
$string['nav_queue']= 'Hàng đợi chuyển';
$string['nav_report']= 'Nhật ký Ngân hàng Khóa học';
$string['nav_summary']= 'Báo cáo chuyển bản sao lưu';
$string['noaccesstofeature']= 'Xin lỗi, chỉ quản trị viên hoặc CLI mới có quyền truy cập vào tính năng này.';
$string['nologreaderenabled']= 'Không bật trình đọc nhật ký';
$string['notavailable']= 'Không có sẵn';
$string['notcompleted']= 'Chưa hoàn thành';
$string['notstarted']= 'Chưa bắt đầu';
$string['pluginname']= 'Ngân hàng khóa học';
$string['reportpageheader']= 'Nhật ký Ngân hàng Khóa học';
$string['return']= 'Đi tới trang cài đặt';
$string['selectlogreader']= 'Chọn trình đọc nhật ký';
$string['sendcoursebackups']= 'Sao lưu khóa học bên ngoài';
$string['settings_authtoken']= 'Mã thông báo xác thực';
$string['settings_authtoken_desc']= 'Mã thông báo xác thực để sử dụng trong giao tiếp với phiên bản ngân hàng khóa học bên ngoài.';
$string['settings_chunksize']= 'Kích thước tập tin';
$string['settings_chunksize_desc']= 'Kích thước của các khối sao lưu riêng lẻ sẽ được gửi đến máy chủ sao lưu.';
$string['settings_deletelocalbackup']= 'Xóa các bản sao lưu cục bộ';
$string['settings_deletelocalbackup_desc']= 'Nếu được kích hoạt, một tệp sao lưu cục bộ sẽ bị xóa khi nó đã được gửi đến ngân hàng khóa học.';
$string['settings_disablestring']= 'Tắt';
$string['settings_displaypages']= 'Trang hiển thị';
$string['settings_displaypages_desc']= 'Ẩn / Hiển thị các trang Ngân hàng Khóa học trong menu điều hướng trong Quản trị trang> Khóa học> Sao lưu> Ngân hàng Khóa học';
$string['settings_enable']= 'Hoạt động';
$string['settings_enable_desc']= 'Bật hoặc tắt gửi các bản sao lưu của khóa học.';
$string['settings_enablestring']= 'Bật';
$string['settings_externalcron']= 'Sử dụng cron bên ngoài';
$string['settings_externalcron_desc']= 'Nếu được chọn, quá trình sẽ được kích hoạt bởi cron bên ngoài.
Quản trị viên máy chủ <br /> phải thiết lập cron bên ngoài.
<br /> Ví dụ đơn giản: <PRE> 2-57/5 * * * * www-data php /path/to/your/moodle/admin/tool/coursebank/cli/backup.php >>/ var / log /backup.log </PRE> ';
$string['settings_header']= 'Tùy chọn cấu hình Ngân hàng khóa học';
$string['settings_intro']= 'Vui lòng xem <a href="https://account.coursebank.biz/content/moodle-setup" target="_blank"> tài liệu thiết lập Moodle </a> để tìm hiểu cách định cấu hình plugin của bạn. Ngoài ra còn có <a href="https://account.coursebank.biz/content/faq" target="_blank"> trang Câu hỏi thường gặp </a>. ';
$string['settingspage']= 'Cấu hình';
$string['settings_proxyheader']= 'Cấu hình proxy';
$string['settings_proxypass']= 'Mật khẩu';
$string['settings_proxypass_desc']= 'Thông tin đăng nhập mật khẩu proxy';
$string['settings_proxyport']= 'Cổng';
$string['settings_proxyport_desc']= 'Cổng proxy';
$string['settings_proxyurl']= 'URL proxy';
$string['settings_proxyurl_desc']= 'URL nhà cung cấp proxy';
$string['settings_proxyuser']= 'Tên người dùng';
$string['settings_proxyuser_desc']= 'Thông tin đăng nhập tên người dùng proxy';
$string['settings_requestretries']= 'Yêu cầu HTTP thử lại';
$string['settings_requestretries_desc']= 'Số lần thử lại việc gửi một yêu cầu không thành công.';
$string['settings_sessionkey']= 'Khóa phiên';
$string['settings_sessionkey_desc']= 'Khóa phiên được Ngân hàng khóa học (Moodle) sử dụng để xác thực với Ngân hàng khóa học bên ngoài.';
$string['settings_timeout']= 'Dịch vụ web hết giờ';
$string['settings_timeout_desc']= 'Hết thời gian (tính bằng giây) cho các yêu cầu HTTP riêng lẻ.';
$string['settings_url']= 'URL mục tiêu';
$string['settings_url_desc']= 'Vị trí của máy chủ sao lưu mục tiêu.';
$string['speedtestbutton']= 'Tốc độ truyền thử nghiệm';
$string['speedtestchunk']= 'Kích thước phân đoạn được đề xuất cho hệ thống của bạn là';
$string['speedtestfail']= 'Không kết nối được với "{$a}". Vui lòng xác nhận rằng cài đặt ngân hàng khóa học bên ngoài và cấu hình mạng của bạn là chính xác. ';
$string['speedtestslow']= 'Chuyển đi đến "{$a}" rất chậm. Tốc độ truyền thử nghiệm xấp xỉ ';
$string['speedtestsuccess']= 'Đã vượt qua kiểm tra tốc độ kết nối với "{$a}"! Tốc độ truyền thử nghiệm xấp xỉ ';
$string['speedtesttitle']= 'Kiểm tra tốc độ kết nối';
$string['status']= 'Trạng thái';
$string['statuscancelled']= 'Chuyển khoản bị hủy bỏ';
$string['statuserror']= 'Lỗi';
$string['statusfinished']= 'Chuyển hoàn tất';
$string['statusinprogress']= 'Đang chuyển tiền';
$string['statusnotstarted']= 'Đang chờ chuyển khoản';
$string['statusonhold']= 'Đang chuyển khoản';
$string['stop']= 'Giữ lại';
$string['timecompleted']= 'Đã chuyển xong ';
$string['timecreated']= 'Đã bắt đầu chuyển giao ';
$string['timetransferstarted']= 'Đã bắt đầu chuyển giao ';
$string['transferinprogress']= 'Không thể tiếp tục. Đang chuyển giao hoặc có thể đã bị gián đoạn gần đây. Bản ghi khóa có trong cơ sở dữ liệu. ';
$string['valuefor']= 'Giá trị {$a}';
