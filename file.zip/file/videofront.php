<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'videofront', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   videofront
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['identifier']= 'Định danh video';
$string['identifier_help']= 'Số nhận dạng của video chỉ trong VideoTeca!';
$string['loadind']= 'Đang tải danh sách video ...';
$string['modulename']= 'Thư viện video';
$string['modulename_help']= 'Videoteca là một plugin đơn giản hóa và thêm nhiều bảo mật trong các giao dịch Moodle với Thư viện Video';
$string['modulenameplural']= 'Thư viện video';
$string['name_title']= 'Tiêu đề';
$string['pluginadministration']= 'Quản trị Videoteca';
$string['pluginname']= 'Thư viện video';
$string['privacy:metadata']= 'Videoteca nếu được tích hợp với <a href="https://www.videofront.com.br/en/LiveSparrow"> Live Sparrow </a> sẽ lưu dữ liệu để phát hiện vi phạm bản quyền.';
$string['safety_desc']= 'Giới thiệu về chương trình Người chơi?';
$string['safety_id']= 'Mã số sinh viên';
$string['safety_none']= 'Bất cứ điều gì';
$string['safety_title']= 'Bảo mật';
$string['token_desc']= 'Mã thông báo để API giao tiếp với VideoTeca!';
$string['token_title']= 'Mã thông báo VideoTeca';
$string['url_desc']= 'Thêm URL video để đồng bộ hóa video!';
$string['url_title']= 'Url VideoTeca';
$string['videofront']= 'Thư viện video';
$string['videofront:addinstance']= 'Thêm một Videoteca mới';
$string['videofront:submit']= 'Gửi Videoteca';
$string['videofront:view']= 'Xem Videoteca';
