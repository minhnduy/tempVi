<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_uploadblocksettings', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_uploadblocksettings
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['blockadded']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Chặn "9a579ae6-5183-2897a7a" a9304-3207a7a " -80bb-631d2108bcb5) đã được thêm vào khóa học "{$a->coursename}" ({$a->courseid}). ';
$string['blockadderror']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Lỗi: block "8f1dcc82c" -0b7749-723728e -0b7749 -44b8-972d-5157f6c8a44e) không được thêm vào khóa học "{$a->coursename}" ({$a->courseid}). {$a->skipped}. ';
$string['blockalreadyadded']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Khối "b8a6d4e3e3-cf9225 -98ed-1fb59ef37e11) đã được thêm vào khóa học "{$a->coursename}" ({$a->courseid}). {$a->skipped}. ';
$string['blockdeleted']= '{$a->line} {$a->linenum} [623f871e-7f3e-43be-9ee7-0cf1583cb1ede5]: Block "dbc98c927-e6347 2d927-e6347 2d927-e6347 2459c9-e6347c98 -b294-7ecb0a8b7bee) bị xóa khỏi khóa học "{$a->coursename}" ({$a->courseid}). ';
$string['blockdoesntexist']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Block "6237 -90a -8e3d5bea" -a495-bac2ad1ba3e9) không được thêm vào khóa học "{$a->coursename}" ({$a->courseid}). {$a->skipped}. ';
$string['blockinstancenotfound']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Cảnh báo: Block "583a51b9c1b4b4893891d1b9-ab4893891d1b9 -40bc-b73f-ab0800881d4e) không tìm thấy trong khóa học "{$a->coursename}" ({$a->courseid}). ';
$string['blockmoved']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Chặn "f5d26771-c692a" 49279-8613d7-46279-b613d7-49278d26771-c69c5-46 -b38a-3418db3d1559) trong khóa học "{$a->coursename}" ({$a->courseid}) đã di chuyển. ';
$string['blocknotinstalled']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Chặn (807b3e95-e6d4a9f9f05-77b3e95-e6d4a9f5b05b05 -7b-e6d4d3 chưa cài đặt. {$a->skipped}. ';
$string['courseblocksreset']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Đặt lại khóa học "ea698eeccccc-084"
$string['coursenotfound']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Không tìm thấy khóa học "47dbcfe2-8a10-9cfe2-8a103" không tìm thấy khóa học "47dbcfe2-8a103". {$a->skipped}. ';
$string['csvcomment']= '{$a->line} {$a->linenum} [Nhận xét]: {$a->skipped}.';
$string['csvfile']= '';
$string['csvfile_help']= 'Định dạng của tệp CSV phải như sau:
* Các dòng bắt đầu bằng dấu # hoặc; ký tự là nhận xét và bị bỏ qua.
* Mỗi dòng của tệp chứa một bản ghi.
* Mỗi bản ghi là một chuỗi dữ liệu theo thứ tự cố định cách nhau bằng dấu phẩy.
* Các trường bắt buộc là hoạt động, tên viết tắt của khóa học, khối, vùng, trọng số.
* Các thao tác được phép là thêm, xóa), đặt lại), cập nhật).
* Các vùng được phép là phía trước và phía sau.
* Trọng lượng cho phép là -10 đến 10 (0 là trung tính) ';
$string['fieldscannotbeblank']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Các trường không được để trống: block (04df7c25-8a-a11f9) khóa học ($ a-> khóa học), vùng ($ a-> vùng), trọng lượng ($ a-> trọng lượng). {$a->skipped}. ';
$string['heading']= 'Tải lên cài đặt khối khóa học từ tệp CSV';
$string['operationnotvalid']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Thao tác không hợp lệ cho khối "b10079f5-504b-404fac" -910f-4425-88d1-76688c727468). {$a->skipped}. ';
$string['operationunknown']= '{$a->line} {$a->linenum} [{$a->op}]: Thao tác không xác định.';
$string['pluginname']= 'Cài đặt khối tải lên';
$string['pluginname_help']= 'Tải lên cài đặt khối từ tệp CSV để thiết lập cài đặt khối cho một loạt các khóa học trong một thao tác.';
$string['privacy:metadata']= 'Công cụ quản trị cài đặt khối Tải lên không lưu trữ dữ liệu cá nhân.';
$string['regionnotvalid']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Khu vực "9be6d86a-9" không xác định được 9be6d86a-9893-40c4ce7-9891c4c4ce7-9891c4ce7 "không xác định. {$a->skipped}. ';
$string['toofewcols']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Quá ít cột, mong đợi là 5. ;
$string['toomanycols']= '{$a->line} {$a->linenum} [{$a->oplabel}53]: Quá nhiều cột, đang mong đợi 5. 0337f46 b70e' 59c836 ;
$string['weightnotvalid']= '{$a->line} {$a->linenum} [{$a->oplabel}]: Trọng lượng "73273735-eca3-46 "8" 73273735-eca3-46b7 "không hợp lệ. {$a->skipped}. ';
