<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_passwordvalidator', language 'en', branch 'MOODLE_38_STABLE'
 *
 * @package   tool_passwordvalidator
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['configpassworddigits']= 'Có vẻ như chính sách mật khẩu được thực thi yêu cầu ít nhất một số. NIST khuyến nghị không thực thi các ký tự bắt buộc trong mật khẩu. ';
$string['configpasswordgood']= 'Cấu hình Moodle dường như đúng.';
$string['configpasswordlowerletter']= 'Có vẻ như chính sách mật khẩu được thực thi yêu cầu ít nhất một chữ cái thường. NIST khuyến nghị không thực thi các ký tự bắt buộc trong mật khẩu. ';
$string['configpasswordminlength']= 'Có vẻ như chính sách mật khẩu được thực thi yêu cầu ít nhất một ký tự. Bạn nên đặt điều khiển này thành 0 và thực thi độ dài tối thiểu bằng cách sử dụng plugin này. ';
$string['configpasswordpolicy']= 'Có vẻ như điều khiển "Chính sách mật khẩu" đã bị tắt. Nếu điều khiển này bị tắt, người dùng mới sẽ không thể xem thông tin về chính sách mật khẩu khi đặt mật khẩu của họ. ';
$string['configpasswordrotationempty']= 'Có vẻ như giới hạn xoay mật khẩu hiện tại là 0. Plugin này dựa trên cấu hình này được đặt ở mức ít nhất là 1 trong thời gian khóa đặt lại mật khẩu.
Bạn nên đặt giá trị này ở mức ít nhất là 1, nhưng càng cao thì càng tốt. ACSC khuyến cáo không sử dụng lại mật khẩu trong vòng 8 lần thay đổi. ';
$string['configpasswordspecialchars']= 'Có vẻ như chính sách mật khẩu được thực thi yêu cầu ít nhất một ký tự chữ và số. NIST khuyến nghị không thực thi các ký tự bắt buộc trong mật khẩu. ';
$string['configpasswordupperletter']= 'Có vẻ như chính sách mật khẩu được thực thi yêu cầu ít nhất một chữ cái viết hoa. NIST khuyến nghị không thực thi các ký tự bắt buộc trong mật khẩu. ';
$string['passwordbadconfigload']= 'Không thể tải tệp cấu hình mẫu. Kiểm tra các biến là chính xác và mẫu đó nằm trong thư mục mẫu. - ';
$string['passwordblacklistdesc']= 'Kiểm tra an toàn mật khẩu với API mật khẩu bị vi phạm hasibeenpwned.com.';
$string['passwordblacklistname']= 'Kiểm tra mật khẩu chống lại danh sách đen';
$string['passwordcharsdesc']= 'Thực thi số ký tự lặp lại tối đa';
$string['passwordcharsinputdesc']= 'Thực thi số lượng tối đa các chữ số tuần tự trong mật khẩu người dùng. Nhập một số để sử dụng hoặc 0 để tắt điều khiển này. ';
$string['passwordcharsinputname']= 'Nhập ký tự lặp lại tối đa';
$string['passwordcharsname']= 'Các ký tự lặp lại tối đa';
$string['passwordconfigloc']= 'tại vị trí:';
$string['passwordconfigpath']= '/config_policies/{$a}.php';
$string['passworddictcheckdesc']= 'Thực thi rằng mật khẩu không được dựa trên một từ trong từ điển. Mật khẩu sẽ được tách thành các chữ cái, sau đó được chia thành các khoảng trắng. ';
$string['passworddictcheckfiledesc']= 'Nhập tên của tệp từ điển để tìm kiếm.';
$string['passworddictcheckfilename']= 'Tên tệp từ điển';
$string['passworddictcheckname']= 'Kiểm tra số từ trong từ điển';
$string['passworddigitsdesc']= 'Thực thi số lượng tối đa các chữ số liên tiếp.';
$string['passworddigitsinputdesc']= 'Thực thi số lượng tối đa các chữ số tuần tự trong mật khẩu người dùng. Nhập một số để sử dụng hoặc 0 để tắt điều khiển này ';
$string['passworddigitsinputname']= 'Đầu vào các chữ số tuần tự tối đa';
$string['passworddigitsname']= 'Các chữ số tuần tự tối đa';
$string['passwordenabledesc']= 'Kiểm tra để kích hoạt xác thực mật khẩu.';
$string['passwordenablename']= 'Bật plugin';
$string['passwordforcedconfig']= 'Cài đặt chỉ được đọc, cấu hình bị ép buộc trong tệp mẫu:';
$string['passwordirapcomplexitycomplex']= 'Độ dài phức tạp tối thiểu';
$string['passwordirapcomplexitycomplexdesc']= 'Độ dài tối thiểu cho mật khẩu phức tạp có 3 bộ ký tự trở lên.';
$string['passwordirapcomplexitydesc']= 'Thực thi Kiểm soát Bảo mật ACSC 0421: Độ phức tạp của mật khẩu tối thiểu. Mật khẩu chỉ chứa các chữ cái phải có ít nhất 13 ký tự. Mật khẩu có ít nhất 3 trong 4: Chữ thường, Chữ hoa, Số, Ký tự đặc biệt, phải có ít nhất 10 ký tự. ';
$string['passwordirapcomplexityname']= 'Thực thi các tiêu chuẩn phức tạp ISM';
$string['passwordirapcomplexitysimple']= 'Độ dài phức tạp đơn giản tối thiểu';
$string['passwordirapcomplexitysimpledesc']= 'Độ dài tối thiểu cho các mật khẩu đơn giản chỉ có các chữ cái.';
$string['passwordirapnumbersdesc']= 'Thực thi Kiểm soát Bảo mật ACSC 0417: Mật khẩu không được chỉ có số hoặc chỉ chứa số và ký tự.';
$string['passwordirapnumbersname']= 'Thực thi các chữ cái trong mật khẩu';
$string['passwordlockoutdesc']= 'Cho phép thực thi thời hạn khóa khi thay đổi mật khẩu.';
$string['passwordlockoutinputdesc']= 'Áp dụng thời hạn khóa đối với người dùng thay đổi mật khẩu. Thời gian đã nhập sẽ là khoảng thời gian mà người dùng không thể thay đổi mật khẩu của mình. Nhập một số tính bằng giây hoặc 0 để tắt điều khiển này. ';
$string['passwordlockoutinputname']= 'Nhập thời gian khóa thay đổi mật khẩu';
$string['passwordlockoutname']= 'Thời gian khóa thay đổi mật khẩu';
$string['passwordpersonalinfodesc']= 'Đảm bảo không có thông tin cá nhân đã biết nào được chứa trong mật khẩu.';
$string['passwordpersonalinfoname']= 'Trình kiểm tra thông tin cá nhân';
$string['passwordphrasedesc']= 'Thực thi danh sách đen các cụm từ đã chọn như tên dịch vụ trong mật khẩu';
$string['passwordphraseinputdesc']= 'Nhập các từ hoặc cụm từ vào danh sách đen trong mật khẩu, chẳng hạn như tên dịch vụ. Đặt mỗi từ hoặc cụm từ mới trên một dòng riêng biệt. Đối sánh KHÔNG phân biệt chữ hoa chữ thường. Ví dụ. "moodle" đối sánh với "MOODLE". ';
$string['passwordphraseinputname']= 'Mục nhập danh sách đen cụm từ';
$string['passwordphrasename']= 'Thực thi cụm từ danh sách đen';
$string['passwordpolicyISM0519']= 'tuân thủ ISM của Úc 2019';
$string['passwordpolicyNIST2018']= 'tuân thủ NIST 2018';
$string['passwordpolicyNIST_ISM_2019']= 'tuân thủ NIST 2018 và Australian ISM 2019';
$string['passwordpolicynotemplate']= 'tuân thủ một bộ kiểm soát bảo mật tùy chỉnh';
$string['passwordsettingsheading']= 'Trình kiểm tra cấu hình Moodle';
$string['passwordsettingsheadingdesc']= 'Kiểm tra cấu hình moodle hiện tại và cảnh báo người dùng về bất kỳ xung đột nào với plugin hoặc cài đặt không an toàn';
$string['passwordtesterdesc']= 'Trình kiểm tra mật khẩu. Nhập mật khẩu và lưu các thay đổi để xem xác thực. ';
$string['passwordtesterempty']= 'Không có mật khẩu nào được nhập để kiểm tra.';
$string['passwordtesterfail']= 'Không thành công: Cài đặt xác thực mật khẩu người kiểm tra không thành công: <br>';
$string['passwordtesterheading']= 'Trình kiểm tra xác thực mật khẩu';
$string['passwordtesterheadingdesc']= 'Nhập mật khẩu vào hộp và lưu các thay đổi để kiểm tra mật khẩu so với cài đặt xác nhận hiện tại';
$string['passwordtestername']= 'Trường trình kiểm tra mật khẩu';
$string['passwordtesterpass']= 'Đạt: Mật khẩu người kiểm tra đã thông qua cài đặt xác thực.';
$string['pluginname']= 'Trình xác thực mật khẩu';
$string['privacy:metadata']= 'Plugin trình kiểm tra chính sách mật khẩu không lưu trữ bất kỳ dữ liệu cá nhân nào.';
$string['responseapierror']= 'API mật khẩu của Dịch vụ HaveIBeenPwned.com không phản hồi.';
$string['responseblacklistphrase']= 'Mật khẩu chứa cụm từ danh sách đen: {$a}.';
$string['responsebreachedpassword']= 'Mật khẩu được tìm thấy trong bộ sưu tập mật khẩu bị vi phạm trực tuyến.';
$string['responsedatabaseerror']= 'Lỗi khi lấy thông tin từ cơ sở dữ liệu.';
$string['responsedictionaryfailoneword']= 'Mật khẩu không thể dựa trên một từ trong từ điển: {$a}, hãy xem xét thêm nhiều từ hơn.';
$string['responseidentifyinginformation']= 'Mật khẩu chứa thông tin nhận dạng: {$a}';
$string['responselockoutperiod']= 'Mật khẩu đã được thay đổi gần đây. Vui lòng thử lại sau: {$a}. ';
$string['responseminimumlength']= 'Mật khẩu phải có ít nhất {$a} ký tự.';
$string['responsenoletters']= 'Mật khẩu không được chỉ bao gồm số và / hoặc ký tự đặc biệt, hoặc không chứa chữ cái.';
$string['responsenouser']= 'Không tìm thấy tài khoản người dùng nào cho truy vấn thông tin cá nhân về mật khẩu.';
$string['responsenumericsequence']= 'Mật khẩu chứa dãy số dài hơn: {$a}.';
$string['responserepeatedcharacters']= 'Mật khẩu chứa các ký tự lặp lại dài hơn: {$a}.';
$string['templateISM0519']= 'Mẫu này thực thi các khuyến nghị từ ISM Úc vào tháng 5 năm 2019. Thực thi độ dài tối thiểu cho các mật khẩu và bộ ký tự phức tạp khác nhau.';
$string['templateNIST2018']= 'Mẫu này thực thi các đề xuất từ ​​đề xuất mật khẩu NIST. Không bao gồm các yêu cầu phức tạp về thành phần mật khẩu. ';
$string['templateNIST_ISM_2019']= 'Mẫu này thực thi các đề xuất từ ​​cả ISM Úc, cũng như đề xuất mật khẩu NIST. Mẫu mạnh nhất được triển khai theo mặc định. ';
$string['testpasswordconfigchecker']= 'Trình kiểm tra cấu hình Moodle';
$string['testpasswordpage']= 'Cấu hình xác thực mật khẩu';
$string['testpasswordpagepasswordbox']= 'Nhập mật khẩu để kiểm tra:';
$string['testpasswordpagestring']= 'Trình kiểm tra cấu hình và xác thực';
$string['testpasswordpagetestbutton']= 'Mật khẩu kiểm tra';
$string['testpasswordpageusernamebox']= 'Nhập email tài khoản người dùng hoặc tên người dùng để kiểm tra mật khẩu được cấu hình dựa trên:';
$string['testpasswordvalidationpassed']= 'Mật khẩu đã vượt qua kiểm tra xác thực thành công.';
$string['testpasswordvalidationtester']= 'Trình kiểm tra xác thực mật khẩu';
