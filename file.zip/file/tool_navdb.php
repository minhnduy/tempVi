<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_navdb', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   tool_navdb
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['err_sql_error']= 'LỖI BỘ LỌC: {$a->error} <br/> <br/> SQL: {$a->sql}';
$string['err_table_not_found']= 'Không tìm thấy bảng {$a}';
$string['goto_at_cua_proces_registres']= 'Goto proces đăng ký';
$string['goto_at_cua_registre']= 'Goto cua_registre record';
$string['goto_context']= 'Chuyển đến bản ghi ngữ cảnh';
$string['goto_context_subcontexts']= 'Đi tới bản ghi điều kiện con';
$string['goto_course_categories_courses']= 'Chuyển đến hồ sơ các khóa học danh mục';
$string['goto_course_categories_sons']= 'Chuyển đến bản ghi danh mục con';
$string['goto_course_modules']= 'Đi tới bản ghi mô-đun khóa học';
$string['goto_logstore_standard_log_action']= 'Chuyển đến bản ghi nhật ký hành động';
$string['goto_logstore_standard_log_component']= 'Chuyển đến bản ghi nhật ký thành phần';
$string['goto_logstore_standard_log_component_action']= 'Đi tới thành phần + bản ghi hành động';
$string['goto_logstore_standard_log_context']= 'Chuyển đến bản ghi nhật ký ngữ cảnh';
$string['goto_logstore_standard_log_course']= 'Chuyển đến bản ghi nhật ký khóa học';
$string['goto_logstore_standard_log_user']= 'Chuyển đến bản ghi nhật ký người dùng';
$string['goto_role_assignments']= 'Chuyển đến bản ghi role_assignments';
$string['goto_user_info_data']= 'Chuyển đến bản ghi dữ liệu user_info';
$string['mainform']= 'Điều hướng hiện tại';
$string['navdb_filter']= 'Bộ lọc';
$string['navdb_limit']= 'Giới hạn';
$string['navdb_limitfrom']= 'Giới hạn Từ';
$string['navdb_muggle']= 'Mở rộng truy vấn và xóa các trường không cần thiết';
$string['navdb_table']= 'Bảng';
$string['noresults']= 'Không có kết quả nào được trả lại cho bộ lọc <b> {$a->filter} </b> trên bảng <b> {$a->table} </b>';
$string['pluginname']= 'Điều hướng Cơ sở dữ liệu';
$string['rowcount']= 'Số hàng: {$a}';
$string['show_db']= 'Quay lại danh sách bảng';
$string['show_results']= 'Thực thi truy vấn';
$string['starred_elements']= 'Phần tử được gắn dấu sao:';
$string['too_results']= '¿D5949989-8ad9-4a27-a2ad-db745667459d? (Quá nhiều kết quả) ';
$string['typetoseach']= 'Nhập để tìm kiếm "{$a}"';
$string['unknown']= '¿{$a}? (Giá trị không xác định) ';
$string['view_activity']= 'Xem hoạt động';
$string['view_at_cua_proces']= 'Xem Process';
$string['view_at_cua_proces_cuastudio']= 'Xem quá trình trong cutstudio';
$string['view_course']= 'Xem khóa học';
$string['view_course_category']= 'Xem danh mục khóa học';
$string['view_course_category_management']= 'Xem trong quản lý danh mục';
$string['view_course_delete']= 'Xóa các khóa học';
$string['view_course_enrolments']= 'Ghi danh khóa học';
$string['view_enrol_methods']= 'Xem phương thức đăng ký';
$string['view_enrol_settings']= 'Cài đặt đăng ký';
$string['view_grade_items_edit']= 'Chỉnh sửa hạng mục';
$string['view_grade_items_edit_calculation']= 'Chỉnh sửa phép tính';
$string['view_grades']= 'Điểm khóa học';
$string['view_user']= 'Hồ sơ người dùng';
$string['view_user_edit']= 'Chỉnh sửa người dùng';
$string['view_user_info_field_edit']= 'Chỉnh sửa trường người dùng';
