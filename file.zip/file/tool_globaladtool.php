<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_globaladtool', language 'en', branch 'MOODLE_37_STABLE'
 *
 * @package   tool_globaladtool
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['block_positionh']= 'Vị trí khối nằm ngang';
$string['block_positionv']= 'Vị trí khối dọc';
$string['botton']= 'Botton';
$string['categorias']= 'Danh mục';
$string['changessaved']= 'Thay đổi được lưu.';
$string['dashb']= 'Trang tổng quan';
$string['descblock_dashboard']= 'Vị trí vào DASHBOARD nơi khối xuất hiện:';
$string['descblock_position']= 'Vị trí vào COURSE nơi khối xuất hiện:';
$string['desccategorias']= 'Chọn danh mục sẽ hiển thị Khối Globalad:';
$string['desc_dashboard']= 'Chọn hộp kiểm này để hiển thị Khối Globalad vào trang tổng quan:';
$string['headerconfig']= 'Cài đặt';
$string['inserterror']= 'Chèn lỗi';
$string['left']= 'Trái';
$string['modulename']= 'Globaladtool';
$string['pluginname']= 'Globaladtool';
$string['privacy:metadata']= 'Globaladtool chỉ lưu cấu hình cấp trang dữ liệu.';
$string['right']= 'Đúng';
$string['up']= 'Lên';
$string['updateerror']= 'Lỗi cập nhật';
