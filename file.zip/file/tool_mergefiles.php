<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_mergefiles', language 'en', branch 'MOODLE_33_STABLE'
 *
 * @package   tool_mergefiles
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['availablehere']= 'Có sẵn ở đây! <br>';
$string['coursefiles']= 'Tệp khóa học <br> <h6> (Lưu ý: Chỉ tệp ở định dạng pdf) </h6>';
$string['heading']= 'Tập tin khóa học';
$string['mergeddoc']= 'Tài liệu được hợp nhất';
$string['mergedfiles']= 'Các tệp PDF được hợp nhất <br> <h6> (Danh sách các tệp pdf được hợp nhất gần đây.) </h6>';
$string['mergedpdfdoc']= '<br> <b> Tài liệu pdf mới được hợp nhất </b>';
$string['mergefiles']= 'Hợp nhất các tệp PDF';
$string['mergefiles:view']= 'Xem tệp pdf đã hợp nhất';
$string['note']= '(Lưu ý: Chỉ tập tin ở định dạng pdf) <br> <br>';
$string['pluginname']= 'Hợp nhất các tệp PDF';
$string['pluginsummary']= 'Hợp nhất các tài liệu PDF trong một khóa học.';
