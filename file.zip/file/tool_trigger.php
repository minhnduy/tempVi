<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_trigger', language 'en', branch 'MOODLE_35_STABLE'
 *
 * @package   tool_trigger
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['action']= 'Hành động';
$string['active']= 'Hoạt động';
$string['addworkflow']= 'Thêm dòng công việc kích hoạt mới';
$string['areatomonitor']= 'Khu vực cần giám sát';
$string['areatomonitor_help']= 'Vùng Moodle có chứa sự kiện để kích hoạt dòng công việc.';
$string['availablefields']= 'Các trường có sẵn';
$string['badstepclass']= 'Tên lớp bước không chính xác';
$string['badsteptype']= 'Loại bước không chính xác';
$string['cachedef_eventsubscriptions']= 'Bộ đệm đăng ký sự kiện Tool Trigger';
$string['cleanupsettings']= 'Xóa cài đặt';
$string['cleanupsettingsdesc']= 'Các cài đặt sau kiểm soát các tác vụ dọn dẹp cho plugin này.';
$string['cli_extractfields']= 'Trích xuất các trường cho các sự kiện đã học từ cơ sở dữ liệu ...';
$string['cli_filefail']= 'Không ghi được tệp: {$a}';
$string['cli_filesummary']= 'Tệp được ghi vào: {$a}';
$string['cli_writingfile']= 'Viết định nghĩa trường sự kiện {$a} vào tệp ...';
$string['core']= 'Cốt lõi';
$string['deleterule']= 'Xóa quy tắc';
$string['deletestep']= 'Xóa bước';
$string['description']= 'Mô tả';
$string['downloadrule']= 'Quy tắc tải xuống';
$string['draft']= 'Bản nháp';
$string['draftmode']= 'Chế độ nháp';
$string['draftmode_help']= 'Sử dụng chế độ nháp để kiểm tra quy trình làm việc với các trình kích hoạt.';
$string['duplicatedworkflowname']= '{$a} (bản sao)';
$string['duplicaterule']= 'Quy tắc trùng lặp';
$string['editrule']= 'Chỉnh sửa quy tắc';
$string['editsettings']= 'Cài đặt quy trình làm việc';
$string['editstep']= 'Chỉnh sửa bước';
$string['editworkflow']= 'Chỉnh sửa quy trình làm việc của trình kích hoạt';
$string['emailactionstepdesc']= 'Bước cho phép gửi e-mail';
$string['emailactionstepname']= 'Email';
$string['emailcontent']= 'Nội dung';
$string['emailcontent_help']= 'Nội dung sử dụng trong email';
$string['emailsubject']= 'Chủ đề';
$string['emailsubject_help']= 'Văn bản sử dụng trong chủ đề của e-mail';
$string['emailto']= 'Tới';
$string['emailto_help']= 'Gửi email cho ai';
$string['erroreditstep']= 'Đã xảy ra lỗi khi cố gắng lưu bước quy trình làm việc. Vui lòng thử lại.';
$string['errorimportworkflow']= 'Đã xảy ra lỗi khi nhập quy trình làm việc. Vui lòng thử lại.';
$string['errorsavingworkflow']= 'Đã xảy ra lỗi khi cố gắng lưu quy trình làm việc. Vui lòng thử lại.';
$string['event']= 'Sự kiện';
$string['eventfields']= 'Các trường sự kiện';
$string['eventtomonitor']= 'Sự kiện cần theo dõi';
$string['eventtomonitor_help']= 'Sự kiện Moodle để kích hoạt quy trình làm việc.';
$string['filter']= 'Bộ lọc';
$string['httpostactionheaders']= 'Tiêu đề';
$string['httpostactionheaders_help']= 'Các tiêu đề yêu cầu để gửi.';
$string['httpostactionparams']= 'Tham số';
$string['httpostactionparams_help']= 'Các tham số để gửi cùng với yêu cầu.';
$string['httpostactionurl']= 'URL';
$string['httpostactionurl_help']= 'URL để đăng dữ liệu lên.';
$string['httppostactionstepdesc']= 'Một bước để cho phép quy trình công việc Moodle gửi dữ liệu đến điểm cuối HTTP / S.';
$string['httppostactionstepname']= 'Bài đăng HTTP';
$string['importmodaltitle']= 'Nhập dòng công việc từ tệp';
$string['importworkflow']= 'Nhập quy trình làm việc';
$string['invalidjson']= 'Tệp nhập dòng công việc chứa JSON không hợp lệ và không thể nhập được';
$string['invalidversion']= 'Tệp nhập dòng công việc không hợp lệ với phiên bản plugin này';
$string['jsonencode']= 'Tham số mã hóa JSON';
$string['jsonencode_help']= 'Nếu các giá trị được bật trong trường Tham số sẽ được mã hóa JSON.';
$string['lasttriggered']= 'Được kích hoạt lần cuối';
$string['learning']= 'Bật chế độ học tập';
$string['learning_help']= 'Chế độ học tập sẽ thu thập dữ liệu về các trường có sẵn cho các sự kiện đã kích hoạt';
$string['learningsettings']= 'Cài đặt chế độ học tập';
$string['learningsettingsdesc']= 'Mỗi sự kiện Moodle cung cấp một tập hợp các trường có thể được sử dụng làm trình giữ chỗ trong quy trình làm việc được kích hoạt cho sự kiện đó. <br/>
Plugin này đi kèm với một tập hợp các trình giữ chỗ được xác định trước cho một số sự kiện cốt lõi của Moodle. Việc bật chế độ học tập cập nhật động danh sách các trình giữ chỗ có sẵn cho các sự kiện Moodle. <br/> <br/>
Cài đặt này có thể gây ra các vấn đề về hiệu suất Moodle và chỉ nên được bật khi có các sự kiện, chẳng hạn như các sự kiện trong các plugin không có
định nghĩa trình giữ chỗ có sẵn. <br/>
Vui lòng tham khảo tài liệu plugin để biết thêm thông tin. ';
$string['lookup']= 'Tra cứu';
$string['manage']= 'Quản lý';
$string['manageworkflow']= 'Quản lý quy trình làm việc';
$string['messageprovider:tool_trigger']= 'Thông báo kích hoạt sự kiện';
$string['modaltitle']= 'Thêm bước quy trình làm việc.';
$string['movestepdown']= 'Di chuyển bước về cuối';
$string['movestepup']= 'Chuyển bước về phía bắt đầu';
$string['name']= 'Tên';
$string['noavailablefields']= 'Không có trường nào, hãy xem xét việc bật chế độ học tập.';
$string['noworkflowfile']= 'Không tìm thấy tệp quy trình làm việc';
$string['numsteps']= 'Các bước';
$string['outputprefix']= 'Tiền tố cho các trường đã thêm';
$string['pluginname']= 'Trình kích hoạt sự kiện';
$string['pluginname_help']= 'Kích hoạt sự kiện cho Moodle';
$string['pluginsettings']= 'Cài đặt Plugin';
$string['privacy:metadata:events']= 'Dữ liệu từ các sự kiện Moodle được giám sát';
$string['privacy:metadata:events:anonymous']= 'Liệu sự kiện có được gắn cờ là ẩn danh hay không';
$string['privacy:metadata:events:eventname']= 'Tên sự kiện';
$string['privacy:metadata:events:ip']= 'Địa chỉ IP được sử dụng tại thời điểm diễn ra sự kiện';
$string['privacy:metadata:events:origin']= 'Nguồn gốc của sự kiện';
$string['privacy:metadata:events:other']= 'Thông tin bổ sung về sự kiện';
$string['privacy:metadata:events:realuserid']= 'ID của người dùng thực đằng sau sự kiện, khi giả mạo người dùng.';
$string['privacy:metadata:events:relateduserid']= 'ID của người dùng liên quan đến sự kiện này';
$string['privacy:metadata:events:timecreated']= 'Thời gian mà sự kiện xảy ra';
$string['privacy:metadata:events:userid']= 'ID của người dùng đã kích hoạt sự kiện này';
$string['privacy:path:events']= '';
$string['step_action_email:privacy:desc']= 'Plugin này có thể được cấu hình để gửi email chứa dữ liệu từ Moodle.';
$string['step_action_httppost:privacy:desc']= 'Plugin này có thể được cấu hình để gửi các yêu cầu HTTP đến các địa chỉ bên ngoài, chứa dữ liệu từ Moodle.';
$string['step_action_logdump_desc']= 'Bước này in dữ liệu các bước sự kiện và quy trình làm việc vào nhật ký cron. (Hầu hết hữu ích cho việc thử nghiệm.) ';
$string['step_action_logdump_name']= 'Nhật ký Cron';
$string['stepclass']= 'Bước';
$string['stepclass_help']= 'Chọn bước để áp dụng.';
$string['stepdescription']= 'Mô tả bước';
$string['stepdescription_help']= 'Mô tả có ý nghĩa cho bước này.';
$string['step_filter_fail_desc']= 'Một bước luôn luôn thất bại. (Hầu hết hữu ích cho việc thử nghiệm.) ';
$string['step_filter_fail_name']= 'Không đạt';
$string['step_lookup_course_courseidfield']= 'Trường dữ liệu id khóa học';
$string['step_lookup_course_desc']= 'Bước này tra cứu dữ liệu về một khóa học.';
$string['step_lookup_course_name']= 'Tra cứu khóa học';
$string['step_lookup_course:privacy:coursedata_desc']= 'Dữ liệu về các khóa học, bao gồm id, tên khóa học, ngày bắt đầu và kết thúc, v.v.';
$string['step_lookup_user_desc']= 'Bước này tra cứu dữ liệu về người dùng.';
$string['step_lookup_user_name']= 'Tra cứu người dùng';
$string['step_lookup_user_nodeleted']= 'Thoát nếu người dùng đã bị xóa?';
$string['step_lookup_user:privacy:userdata_desc']= 'Dữ liệu cá nhân về người dùng, chẳng hạn như tên người dùng, tên, địa chỉ email, v.v.';
$string['step_lookup_user_useridfield']= 'Trường dữ liệu id người dùng';
$string['stepmodalbutton']= 'Thêm bước quy trình làm việc';
$string['stepname']= 'Tên bước';
$string['stepname_help']= 'Tên của bước này.';
$string['steprequired']= 'Quy trình làm việc phải có ít nhất một bước.';
$string['steptype']= 'Loại bước';
$string['steptype_help']= 'Loại bước áp dụng.';
$string['taskcleanup']= 'Xóa các sự kiện đã xử lý cũ';
$string['tasklearn']= 'Tìm hiểu về các trường trong các sự kiện được lưu trữ.';
$string['tasklearnstart']= 'Bắt ​​đầu xử lý trích xuất trường sự kiện ...';
$string['taskprocessworkflows']= 'Xử lý tác vụ đã lên lịch của quy trình công việc.';
$string['timetocleanup']= 'Thời gian để xóa các sự kiện cũ';
$string['timetocleanup_help']= 'Cài đặt này đặt thời gian cho các dòng công việc được thực thi thành công vẫn còn trong cơ sở dữ liệu Moodle trước khi bị xóa.';
$string['trigger:manageworkflows']= 'Tạo và định cấu hình dòng công việc tự động kích hoạt sự kiện';
$string['workflowactive']= 'Dòng công việc đang hoạt động';
$string['workflowactive_help']= 'Chỉ các dòng công việc đang hoạt động mới được xử lý khi một sự kiện được kích hoạt.';
$string['workflowcopysuccess']= 'Đã sao chép thành công quy trình làm việc';
$string['workflowdeleteareyousure']= 'Bạn có chắc chắn muốn xóa dòng công việc "{$a}" không?';
$string['workflowdeletesuccess']= 'Đã xóa thành công quy trình làm việc';
$string['workflowdescription']= 'Mô tả';
$string['workflowdescription_help']= 'Mô tả ngắn gọn về mục đích của quy trình công việc này.';
$string['workflowfile']= 'Tệp quy trình làm việc';
$string['workflowimported']= 'Dòng công việc được nhập thành công';
$string['workflowname']= 'Tên';
$string['workflowname_help']= 'Tên có thể đọc được của con người cho quy trình làm việc này.';
$string['workflowoverview']= 'Tổng quan về quy trình làm việc';
