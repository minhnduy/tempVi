<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_uploadenrolmentmethods', language 'en', branch 'MOODLE_39_STABLE'
 *
 * @package   tool_uploadenrolmentmethods
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['cohortnotfound']= 'Không tìm thấy nhóm thuần tập.';
$string['csvfile']= '';
$string['csvfile_help']= 'Định dạng của tệp CSV như sau:
* Mỗi dòng của tệp chứa một bản ghi.
* Mỗi bản ghi là một chuỗi dữ liệu theo bất kỳ thứ tự nào được phân tách bằng dấu phẩy hoặc các dấu phân cách tiêu chuẩn khác.
* Các trường là: hoạt động, phương thức đăng ký, tên viết tắt của khóa học đích, tên viết tắt của khóa học chính hoặc idnumber nhóm, trạng thái bị vô hiệu hóa [, tên nhóm, vai trò].
* Tất cả các trường là bắt buộc ngoại trừ nhóm và vai trò.
* Các thao tác là thêm, xóa) và cập nhật).
* Các phương pháp đăng ký được hỗ trợ là meta và nhóm thuần tập.
* Các giá trị trạng thái bị vô hiệu hóa là 1 (đã tắt) hoặc 0 (đã bật).
* Học sinh đăng ký theo phương thức này sẽ được xếp vào nhóm được chỉ định trong trường tên nhóm.
Nhóm sẽ được tạo nếu chưa tồn tại.
* Trường vai trò phải là tên vai trò hợp lệ chẳng hạn như giáo viên biên tập, sinh viên, v.v. ';
$string['heading']= 'Tải lên các phương thức đăng ký khóa học từ tệp CSV';
$string['invalidmethod']= 'Phương thức không hợp lệ.';
$string['invalidop']= 'Thao tác không hợp lệ.';
$string['method']= 'Phương pháp';
$string['methoddisabledwarning']= 'Phương thức ghi danh "{$a}" bị vô hiệu hóa.';
$string['methodscreated']= 'Đã tạo: {$a}';
$string['methodsdeleted']= 'Đã xóa: {$a}';
$string['methodserrors']= 'Lỗi: {$a}';
$string['methodstotal']= 'Tổng: {$a}';
$string['methodsupdated']= 'Đã cập nhật: {$a}';
$string['operation']= 'Hoạt động';
$string['parentnotfound']= 'Không tìm thấy khóa học liên kết meta.';
$string['pluginname']= 'Tải lên các phương thức đăng ký';
$string['pluginname_help']= 'Tải lên các phương thức ghi danh từ tệp CSV để thiết lập các phương thức ghi danh cho một loạt các khóa học trong một thao tác.';
$string['privacy:metadata']= 'Công cụ quản trị phương pháp đăng ký Tải lên không lưu trữ dữ liệu cá nhân.';
$string['reladderror']= 'Lỗi liên kết phương thức với khóa học.';
$string['relalreadyexists']= 'Phương thức đã được liên kết với khóa học.';
$string['reldoesntexist']= 'Phương thức không tồn tại.';
$string['result']= 'Kết quả';
$string['results']= 'Tải lên kết quả các phương thức tuyển sinh';
$string['targetisparent']= 'Phương thức là cha của khóa học, vì vậy không thể thêm vào làm mục tiêu của nó.';
$string['targetnotfound']= 'Khóa học không xác định.';
