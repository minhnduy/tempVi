<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Strings for component 'tool_objectfs', language 'en', branch 'MOODLE_34_STABLE'
 *
 * @package   tool_objectfs
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$string['delete_local_objects_task']= 'Hệ thống tệp đối tượng xóa tác vụ đối tượng cục bộ';
$string['generate_status_report_task']= 'Nhiệm vụ trình tạo báo cáo trạng thái đối tượng';
$string['not_enabled']= 'Các tác vụ nền của hệ thống tệp đối tượng không được kích hoạt. Không có đối tượng nào sẽ di chuyển vị trí cho đến khi bạn thực hiện. ';
$string['object_status:files']= 'Đối tượng';
$string['object_status:last_run']= 'Báo cáo này được tạo trên {$a}';
$string['object_status:location']= 'Vị trí đối tượng';
$string['object_status:location:duplicated']= 'Được sao chép trong bộ nhớ trong và bộ nhớ ngoài';
$string['object_status:location:error']= 'Thiếu từ bộ lưu trữ và bộ nhớ ngoài';
$string['object_status:location:external']= 'Chỉ trong bộ nhớ ngoài';
$string['object_status:location:local']= 'Chỉ trong hồ sơ';
$string['object_status:location:total']= 'Tổng số';
$string['object_status:location:unknown']= 'Vị trí đối tượng không xác định';
$string['object_status:never_run']= 'Tác vụ tạo báo cáo này chưa được chạy.';
$string['object_status:page']= 'Trạng thái đối tượng';
$string['object_status:size']= 'Tổng kích thước';
$string['pluginname']= 'Hệ thống tệp lưu trữ đối tượng';
$string['pull_objects_from_storage_task']= 'Nhiệm vụ tải các đối tượng của hệ thống tệp đối tượng';
$string['push_objects_to_storage_task']= 'Nhiệm vụ tải lên hệ thống tệp đối tượng';
$string['recover_error_objects_task']= 'Nhiệm vụ khôi phục lỗi đối tượng';
$string['settings']= 'Cài đặt';
$string['settings:aws:bucket']= 'Thùng';
$string['settings:aws:bucket_help']= 'Bộ chứa Amazon S3 để lưu trữ các tệp trong.';
$string['settings:aws:header']= 'Cài đặt Amazon S3';
$string['settings:aws:key']= 'Chìa khóa';
$string['settings:aws:key_help']= 'Thông tin đăng nhập chính của Amazon S3.';
$string['settings:aws:region']= 'vùng';
$string['settings:aws:region_help']= 'Vùng cổng API Amazon S3.';
$string['settings:aws:secret']= 'Bí mật';
$string['settings:aws:secret_help']= 'Thông tin xác thực bí mật của Amazon S3.';
$string['settings:azure:accountname']= 'Tên tài khoản';
$string['settings:azure:accountname_help']= 'Tên của tài khoản lưu trữ.';
$string['settings:azure:container']= 'Tên vùng chứa';
$string['settings:azure:container_help']= 'Tên của vùng chứa sẽ lưu trữ các đốm màu.';
$string['settings:azure:header']= 'Cài đặt Bộ nhớ Azure Blob';
$string['settings:azure:sastoken']= 'Chữ ký Truy cập Chung';
$string['settings:azure:sastoken_help']= 'Chữ ký Truy cập Dùng chung này chỉ nên có hai chữ ký hiệu sau. Đọc viết.';
$string['settings:clientnotavailable']= 'Máy khách đã định cấu hình \' {$a} \'không khả dụng. Vui lòng cài đặt các phụ thuộc bắt buộc. ';
$string['settings:clientselection:header']= 'Lựa chọn Hệ thống Tệp Lưu trữ';
$string['settings:clientselection:matchfilesystem']= 'Cài đặt này phù hợp với $ CFG-> alternative_file_system_class';
$string['settings:clientselection:mismatchfilesystem']= 'Cài đặt này không phù hợp với $ CFG-> alternative_file_system_class';
$string['settings:clientselection:title']= 'Hệ thống tệp lưu trữ';
$string['settings:clientselection:title_help']= 'Hệ thống tệp lưu trữ. Đây cũng là hệ thống tệp hoạt động cho các tác vụ nền. ';
$string['settings:connectionfailure']= 'Không thể thiết lập kết nối với bộ nhớ đối tượng bên ngoài.';
$string['settings:connectionsuccess']= 'Có thể thiết lập kết nối với bộ nhớ đối tượng bên ngoài.';
$string['settings:consistencydelay']= 'Độ trễ nhất quán';
$string['settings:consistencydelay_help']= 'Một đối tượng phải tồn tại bao lâu sau khi được chuyển sang bộ nhớ đối tượng bên ngoài trước khi chúng là đối tượng để xóa cục bộ.';
$string['settings:deleteerror']= 'Không thể xóa đối tượng khỏi bộ nhớ đối tượng bên ngoài.';
$string['settings:deletelocal']= 'Xóa các đối tượng cục bộ';
$string['settings:deletelocal_help']= 'Xóa các đối tượng cục bộ khi chúng ở trong bộ nhớ đối tượng bên ngoài sau độ trễ nhất quán.';
$string['settings:deletesuccess']= 'Có thể xóa đối tượng khỏi bộ nhớ đối tượng bên ngoài - Người dùng không nên có quyền xóa.';
$string['settings:enablelogging']= 'Bật ghi nhật ký thời gian thực';
$string['settings:enablelogging_help']= 'Bật hoặc tắt ghi nhật ký hệ thống tệp. Sẽ xuất thông tin chẩn đoán vào nhật ký lỗi php. ';
$string['settings:enabletasks']= 'Bật các tác vụ chuyển giao';
$string['settings:enabletasks_help']= 'Bật hoặc tắt các tác vụ hệ thống tệp đối tượng di chuyển tệp giữa bộ lưu trữ tệp được lưu trữ và đối tượng bên ngoài.';
$string['settings:filetransferheader']= 'Cài đặt truyền tệp';
$string['settings:generalheader']= 'Cài đặt chung';
$string['settings:handlernotset']= '$ CFG-> alternative_file_system_class không được đặt, hệ thống tệp sẽ không thể đọc từ bộ nhớ đối tượng bên ngoài. Các tác vụ nền vẫn có thể hoạt động. ';
$string['settings:maxtaskruntime']= 'Thời gian chạy tác vụ chuyển tối đa';
$string['settings:maxtaskruntime_help']= 'Các tác vụ nền xử lý việc chuyển các đối tượng đến và từ bộ lưu trữ đối tượng bên ngoài. Cài đặt này kiểm soát thời gian chạy tối đa cho tất cả các tác vụ liên quan đến chuyển đối tượng. ';
$string['settings:minimumage']= 'Tuổi tối thiểu';
$string['settings:minimumage_help']= 'Tuổi tối thiểu mà một đối tượng phải tồn tại trên hồ sơ địa phương trước khi nó được xem xét để chuyển giao.';
$string['settings:permissioncheckpassed']= 'Kiểm tra quyền đã được thông qua.';
$string['settings:preferexternal']= 'Thích đối tượng bên ngoài';
$string['settings:preferexternal_help']= 'Nếu một tệp được lưu trữ cục bộ và trong bộ nhớ đối tượng bên ngoài, hãy đọc từ bên ngoài \\. Cài đặt này chủ yếu dành cho mục đích thử nghiệm và giới thiệu chi phí để kiểm tra vị trí. ';
$string['settings:readfailure']= 'Không thể đọc đối tượng từ bộ nhớ đối tượng bên ngoài.';
$string['settings:sizethreshold']= 'Ngưỡng kích thước tối thiểu (KB)';
$string['settings:sizethreshold_help']= 'Ngưỡng kích thước tối thiểu để chuyển các đối tượng sang bộ nhớ đối tượng bên ngoài. Nếu các đối tượng vượt quá kích thước này, chúng sẽ được chuyển. ';
$string['settings:writefailure']= 'Không thể ghi đối tượng vào bộ nhớ đối tượng bên ngoài.';
